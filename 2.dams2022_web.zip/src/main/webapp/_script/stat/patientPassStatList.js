// ------------------------------------------------------------
// Init
// ------------------------------------------------------------
$(function () {
   // Init
   setProjectList();
   selectProject();
});

// ------------------------------------------------------------
// Get Set
// ------------------------------------------------------------
// GET+SET :: Project List
function setProjectList() {
   const url = CONTEXT_PATH + "/stat/patientPassStat/getProjectList.do";
   const async = false;
   callAjax(url, null, async, function (json) {
      console.log("setProjectList RESPONSE");
      console.log(json);

      var rows = json.projectList;
      var html = "";
      html += '<h4 class="subject_title">프로젝트 선택</h4>';
      html += "<tr><td><select id='projCdSelect' onchange='selectProject()'> ";
      for (i in rows) {
         const projCdSharing = getProjCdSharingCookie();
         if (rows[i].projCd == projCdSharing) {
            html += "<option value='" + rows[i].projCd + "' style='font-size:16px;' selected>" + rows[i].projNm + "</option>";
         } else {
            html += "<option value='" + rows[i].projCd + "' style='font-size:16px;'>" + rows[i].projNm + "</option>";
         }
      }
      html += " </select></td></tr>"
      $("#project_div").html(html);

      $("#projCdSelect").on("change", function () {
         setProjCdSharingCookie($("#projCdSelect").val());
      });
   });
}

// 프로젝트 콤보박스 선택 이벤트 ( 프로젝트에 해당하는 기준일자 등록/검수 목록 등을 조회 및 화면에 출력하는 기능 )
function selectProject() {
   
   showLoading();

   setTimeout(() => {
      setPatientPassTable();
      // setPatientPassRatioTable();   // 2022-11-10 기능 추가했으나 필요없어짐.

      hideLoading();
   }, 10);
}

// GET+SET :: Exceed Case List - 테이블데이터
function setPatientPassTable() {
   var colModel = [];
   var rows;

   const sendData = {
      projCd: $("#projCdSelect").val(),
   }
   console.log("setPatientPassTable PARAM");
   console.log(sendData);

   $.ajax({
      url: CONTEXT_PATH + '/stat/patientPassStat/getPatientPassList.do',
      type: "POST",
      data: sendData,
      dataType: "json",
      async: false,
   }).done(function (response) {
      console.log("setPatientPassTable RESPONSE");
      console.log(response);

      if (response.code == 0) {
         rows = response.rows;
         colModel = [
            { name: 'patientNo', label: '환자 번호', width: 80, align: 'center', frozen: true, key: true },
            { name: 'regCnt', label: '등록 건수', width: 80, align: 'center', sorttype:'number' },
            { name: 'passCnt', label: 'Pass 건수', width: 80, align: 'center', sorttype:'number' },
            { name: 'failCnt', label: 'Fail 건수', width: 80, align: 'center', sorttype:'number' },
            { name: 'noInspCnt', label: '미검수 건수', width: 100, align: 'center', sorttype:'number' },
            { name: 'passAndNoInspCnt', label: 'Pass 건수 +<br>미검수 건수', width: 110, align: 'center', sorttype:'number' },
            { name: 'passMinUnderCnt', label: 'Pass건중<br>최소기준 미만 건수', width: 130, align: 'center', sorttype:'number' },
            { name: 'passMaxExcessCnt', label: 'Pass건중<br>최대기준 초과 건수', width: 130, align: 'center', sorttype:'number' },
            { name: 'taskList', label: '검수태스크 목록', width: 370, align: 'center' },
            { name: 'minV', label: '최소기준수량', width: 100, align: 'center', sorttype:'number' },
            { name: 'maxV', label: '최대기준수량', width: 100, align: 'center', sorttype:'number' },
         ]
         
      } else {
         alert(response.msg);
         return;
      }
   }).fail(function (jqXHR, textStatus, errorThrown) {
      alert(jqXHR.status);
      return;
   });

   $.jgrid.gridUnload("grid");

   $("#grid").jqGrid({
      data: rows,
      datatype: "local",
      colModel: colModel,
      // rowNum: -1,
      multiSort: true, // 복수컬럼 정렬
      rowNum: 9999,
      height: '453',
      loadonce: true,
      viewrecords: true,
      // autowidth: true,    	 // jQgrid width 자동100% 채워지게
      // shrinkToFit: false,  // width를 자동설정 해주는 기능
      // gridview: true,
      // cmTemplate: { sortable: false },
      // headerrow: true,
      // userDataOnHeader: true, // use the userData parameter of the JSON response to display data on header
      rownumbers: true,
      onCellSelect: function (rowId, iCol, cellcontent, e) {},
      onSelectRow: function (rowId, status, e) {},
      caption: " ",
   })
   
   $("#grid").jqGrid('setFrozenRows', {
      first : 1,
      saveFirstLastId : true,
      classes : 'ui-state-active'
   });

   $("#grid").jqGrid("setFrozenColumns");
   $("#list_num").text(rows ? rows.length - 1: 0); // 합계 1줄 빼야함.

   // 2022-10-28 통계 디테일
   // setPassCntTable(rows);

}

const setPatientPassRatioTable = () => {
   // function 예약어 사용 미권장. 리소스 낭비

   $div = $("#patientPassRatioDiv");
   $div.hide();

   const sendData = {
      projCd: $("#projCdSelect").val(),
   }

   if ("2022A1" != sendData.projCd && "2022B1" != sendData.projCd) {
      return;
   }

   console.log("setPatientPassRatioTable PARAM");
   console.log(sendData);

   $.ajax({
      type: "POST",
      url: CONTEXT_PATH + '/stat/patientPassStat/getPatientPassRatioList.do',
      data: sendData,
      dataType: 'json',
      async: false,
      success: function (response) {
         console.log("setPatientPassRatioTable RESPONSE");
         console.log(response);

         data = response.rows[0];
         const $table_1 = $("#patientPassRatioTable_1");
         let inputHtml = `<tr><th>등록건수</th><td>${data.regCnt}</td><th>검수건수</th><td>${data.inspCnt}</td></tr>`;
         $table_1.html(inputHtml);


         const $table_2 = $("#patientPassRatioTable_2");

         inputHtml = "";
         inputHtml += `<tr><th></th><th>Pass건수</th><th>Pass율(%)</th></tr>`;
         inputHtml += `<tr><td>전체</td><td>${data.passCnt}</td><td>${data.passPercentage}</td></tr>`;
         inputHtml += `<tr><td>3건 이상</td><td>${data.above3Cnt}</td><td>${data.above3Percentage}</td></tr>`;
         inputHtml += `<tr><td>4건 이상</td><td>${data.above4Cnt}</td><td>${data.above4Percentage}</td></tr>`;
         inputHtml += `<tr><td>5건 이상</td><td>${data.above5Cnt}</td><td>${data.above5Percentage}</td></tr>`;
         $table_2.html(inputHtml);

         $div.show();

      },
      error: function (a, b, c) {
         alert("error");
      }
   });
}

// 엑셀 다운로드
function excelDown() {
   var url = CONTEXT_PATH + "/stat/patientPassStat/excelPatientPassList.do";
   var data = {
      projCd: $("#projCdSelect").val()
   }

   $(".loading-image").show();

   $.fileDownload(url, {
      httpMethod: "POST",
      data: data,
      successCallback: function (url) {
         $(".loading-image").hide();
      },
      failCallback: function (responseHtml, url, error) {
         $(".loading-image").hide();
      }
   });
}

/** 테이블데이터의 통계 테이블 */
function setPassCntTable(rows) {
   const minV = rows[0]?.minV;
   const maxV = rows[0]?.maxV;

   // 전체 환자
   const totalCnt = rows.length - 1 // 합계 제외 1
   let underCnt = 0;
   let overCnt = 0;

   let normalInspCnt = 0;
   let noInspCnt = 0;
   
   for (val of rows) {
      if (val.patientNo == '합계') { // 너무 하드코딩인데
         continue;
      }


      if (val.noInspCnt == 0) {
         if (Number(val.passMinUnderCnt) > 0) {
            underCnt++;
         } else if (Number(val.passMaxExcessCnt) > 0) {
            overCnt++;
         } else {
            normalInspCnt++;
         }
      } else {
         noInspCnt++;
      }
   }

   const $table = $("#passCntTable");
   let inputHtml = "<tr>";
   inputHtml += "<th>전체 환자 수</th>";
   inputHtml += `<td>${totalCnt}</td>`;
   inputHtml += "<th>검수완료 환자 중<br>최소기준수량 미만 환자 수</th>";
   inputHtml += `<td>${underCnt}</td>`;
   inputHtml += "<th>검수완료 환자 중<br>최대기준수량 초과 환자 수</th>";
   inputHtml += `<td>${overCnt}</td>`;
   inputHtml += "<th>검수완료 정상 환자 수</th>";
   inputHtml += `<td>${normalInspCnt}</td>`;
   inputHtml += "<th>미검수 환자 수</th>";
   inputHtml += `<td>${noInspCnt}</td>`;
   inputHtml += "</tr>";

   $table.html(inputHtml);
}