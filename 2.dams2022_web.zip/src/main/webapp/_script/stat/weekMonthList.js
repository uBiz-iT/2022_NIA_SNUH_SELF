// ------------------------------------------------------------
// Init
// ------------------------------------------------------------
$(function () {
    // Init
    setProjectList();
    selectProject();

});

// ------------------------------------------------------------
// Event
// ------------------------------------------------------------
// Change :: 프로젝트선택박스 변경 시




// ------------------------------------------------------------
// Ajax Get Data 
// ------------------------------------------------------------
/**
 * 프로젝트 리스트 가져오기 - get set 분할 위한 테스트
 * @param {Object} sendData - ajax data
 * @returns {Object} response
 */
function ajaxGetProjectList(sendData) {
    console.log("ajaxGetProjectList PARAM");
    console.log(sendData);

    let result = null;
    $.ajax({
        type: "post",
        url: CONTEXT_PATH + "/work/crossValidation/getProjectList.do",
        data: sendData,
        dataType: "json",
        async: false,
        success: function (response) {
            console.log("ajaxGetProjectList RESPONSE");
            console.log(response);
            result = response;
        },
        error: function (request, status, error) {
            console.log(request, status, error);
            alert("에러, 관리자에게 문의바람.");
        },
    });
    return result;
}

/**
 * 프로젝트 선택박스 세팅
 * 아래 get+set 을 지금 방식처럼 메서드 분할 해야하나?
 */
function setProjectList2() {
    const response = ajaxGetProjectList(null);
    const rows = response.projectList;
    var html = "";
    html += '<h4 class="subject_title">프로젝트 선택</h4>';
    html += "<tr><td><select id='projCdSelect' onchange='selectProject()'> ";
    for (i in rows) {
        const projCdSharing = getProjCdSharingCookie();
        if (rows[i].projCd == projCdSharing) {
            html += "<option value='" + rows[i].projCd + "' style='font-size:16px;' selected>" + rows[i].projNm + "</option>";
        } else {
            html += "<option value='" + rows[i].projCd + "' style='font-size:16px;'>" + rows[i].projNm + "</option>";
        }
    }
    html += " </select></td></tr>";
    $("#project_div").html(html);

    $("#projCdSelect").on("change", function () {
        setProjCdSharingCookie($("#projCdSelect").val());
    });
}


// ------------------------------------------------------------
// Get Set
// ------------------------------------------------------------
// GET+SET :: Project List
function setProjectList() {
    const url = CONTEXT_PATH + "/work/crossValidation/getProjectList.do";
    const async = false;
    callAjax(url, null, async, function (json) {
        console.log("setProjectList RESPONSE");
        console.log(json);

        var rows = json.projectList;
        var html = "";
        html += '<h4 class="subject_title">프로젝트 선택</h4>';
        html += "<tr><td><select id='projCdSelect' onchange='selectProject()'> ";
        for (i in rows) {
            const projCdSharing = getProjCdSharingCookie();
            if (rows[i].projCd == projCdSharing) {
                html += "<option value='" + rows[i].projCd + "' style='font-size:16px;' selected>" + rows[i].projNm + "</option>";
            } else {
                html += "<option value='" + rows[i].projCd + "' style='font-size:16px;'>" + rows[i].projNm + "</option>";
            }
        }
        html += " </select></td></tr>";
        $("#project_div").html(html);

        $("#projCdSelect").on("change", function () {
            setProjCdSharingCookie($("#projCdSelect").val());
        });
    });
}

/**
 * 프로젝트값 변경시 실행할 함수.
 */
function selectProject() {

    showLoading();

    setTimeout(() => {
        setProgressList();

        initWeekChartAll();
        initMonthChartAll();

        hideLoading();
    }, 10);
    /*
    비동기 처리. 
    0초로 하면 ajax부분이 showLoading 보다 stack에 먼저 들어감.(랜덤으로) 왜지?
    100은 길고 10으로 설정
    1로 하면 또 안된다. 
    */

};


// GET+SET :: Progress List - 테이블데이터
function setProgressList() {
    var colNames = [];
    var colModels = [];
    var rows = [];
    var row_size;
    var keys;

    var indexName;

    const sendData = {
        projCd: $("#projCdSelect").val()
    }

    $.ajax({
        type: "POST",
        url: CONTEXT_PATH + '/stat/weekMonth/getProgressList.do',
        data: sendData,
        dataType: "json",
        async: false,
    }).done(function (jsonData) {

        if (jsonData.rows != '') {
            rows = jsonData.rows;
            keys = Object.keys(jsonData.rows[0]);
            values = Object.values(jsonData.rows[0]);

            for (i in keys) {
                // 컬럼 명칭 수정
                if (keys[i] == "baseYmd") indexName = "기준 일자";
                if (keys[i] == "regCnt") indexName = "등록 수량";
                if (keys[i] == "assnCnt") indexName = "검수자 할당 수량";
                if (keys[i] == "diagWorkCnt") indexName = "진단 완료 수량";
                if (keys[i] == "inspWorkCnt") indexName = "검수 완료 수량";
                if (keys[i] == "workCnt") indexName = "완료 수량";
                if (keys[i] == "sameCnt") indexName = "검수 일치 수량";
                if (keys[i] == "passCnt") indexName = "일치 건 중 PASS 수량";

                var model = { name: keys[i], index: keys[i], width: 100, align: "center" };

                // width 조정
                if (keys[i] == "baseYmd") {
                    model.width = 200;
                } else if (keys[i] == "regCnt") {
                    model.width = 166;
                } else if (keys[i] == "assnCnt") {
                    model.width = 166;
                } else if (keys[i] == "diagWorkCnt") {
                    model.width = 166;
                } else if (keys[i] == "inspWorkCnt") {
                    model.width = 166;
                } else if (keys[i] == "workCnt") {
                    model.width = 166;
                } else if (keys[i] == "sameCnt") {
                    model.width = 166;
                } else if (keys[i] == "passCnt") {
                    model.width = 166;
                }

                // 숨길 컬럼 목록
                if (keys[i] == "projCd") {

                } else if (keys[i] == "baseYm") {
                } else if (keys[i] == "weekBeg") {
                } else if (keys[i] == "weekEnd") {
                } else if (keys[i] == "weekYm") {
                } else if (keys[i] == "weekNo") {
                } else {
                    colModels.push(model);
                    colNames.push(indexName);
                }
            }
            // 2022-09-07 첫번째 컬럼 고정
            colModels[0].frozen = true;

        } else {
            colModels.push({ name: "기준 일자", index: "기준 일자", width: 200, align: "center" }, { name: "등록 수량", index: "등록 수량", width: 166, align: "center" },
                { name: "검수자 할당 수량", index: "검수자 할당 수량", width: 166, align: "center" }, { name: "진단 완료 수량", index: "진단 완료 수량", width: 166, align: "center" }
                , { name: "진단 완료 수량", index: "진단 완료 수량", width: 166, align: "center" }, { name: "검수 완료 수량", index: "검수 완료 수량", width: 166, align: "center" }
                , { name: "완료 수량", index: "완료 수량", width: 166, align: "center" }, { name: "검수 일치 수량", index: "검수 일치 수량", width: 166, align: "center" }
                , { name: "일치 건 중 PASS 수량", index: "일치 건 중 PASS 수량", width: 166, align: "center" }
            );
        }
    }).fail(function (jqXHR, textStatus, errorThrown) {
        var msg = "조회된 데이터가 없습니다.";
        alert(msg);

        colModels.push({ name: "기준 일자", index: "기준 일자", width: 200, align: "center" }, { name: "등록 수량", index: "등록 수량", width: 166, align: "center" },
            { name: "검수자 할당 수량", index: "검수자 할당 수량", width: 166, align: "center" }, { name: "진단 완료 수량", index: "진단 완료 수량", width: 166, align: "center" }
            , { name: "진단 완료 수량", index: "진단 완료 수량", width: 166, align: "center" }, { name: "검수 완료 수량", index: "검수 완료 수량", width: 166, align: "center" }
            , { name: "완료 수량", index: "완료 수량", width: 166, align: "center" }, { name: "검수 일치 수량", index: "검수 일치 수량", width: 166, align: "center" }
            , { name: "일치 건 중 PASS 수량", index: "일치 건 중 PASS 수량", width: 166, align: "center" }
        );
    });

    $.jgrid.gridUnload("grid");

    $("#grid").jqGrid({
        data: rows,
        datatype: "local",
        colNames: colNames,
        colModel: colModels,
        rowNum: 9999,
        //	    rowList: [50,100,150, 200],
        height: 500,
        loadonce: true,
        autowidth: true,    	 // jQgrid width 자동100% 채워지게
        shrinkToFit: false,  // width를 자동설정 해주는 기능
        gridview: true,
        cmTemplate: { sortable: false },
        rownumbers: true,
        //	    pager: '#pager',
        onCellSelect: function (rowId, iCol, cellcontent, e) {

        },
        onSelectRow: function (rowId, status, e) {
            var psg_id = $("#grid").getCell(rowId, "검사(환자) ID");
            var task_cd = $("#task_cd").val();

            $("#psg_id").val(psg_id);

            var obj = new Object();
            obj.psg_id = psg_id;
            obj.task_cd = task_cd;

            if ($(".tabs").find(".tab-link").hasClass('current')) {
                obj.user_id = $(".tabs").find(".current").find("span").text();
            } else {
                obj.user_id = '';
            }
        },
        viewrecords: true,
        loadComplete: function (data) {
            var ids = $("#grid").getDataIDs();
            var total = $("#grid").getGridParam("records");
            $("#list_num").text(total);

            $.each(ids, function (idx, rowId) {
                rowData = $("#grid").getRowData(rowId);
            });
        },
        caption: " "
    });
    $("#grid").jqGrid("setFrozenColumns");

    $("#list_num").text(rows.length - 1); // 통계 하나 빼야됨.

}

// ------------------------------------------------------------
// CHART
// ------------------------------------------------------------
// 주간차트 연도 변경 시 함수
function initWeekChartAll() {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;

    // 연도 변경 select 생성
    var html = '';
    html += "<select class='selectbox' id='select1' onchange='changeWeek()' style='width:100px'>";
    for (i = 2022; i <= year; i++) {
        if (i == year) {
            html += format("<option value='{0}' selected>{0}년도</option>", i);
        } else {
            html += format("<option value='{0}'>{0}년도</option>", i);
        }
    }
    html += "</select>";
    $("#select_span1").html(html);

    // 월 변경 select 생성
    var html = '';
    html += "<select class='selectbox' id='select3' onchange='changeWeek()' style='width:100px'>";
    for (i = 1; i <= 12; i++) {
        if (i == month) {
            html += format("<option value='{0}' selected>{0}월</option>", i);
        } else {
            html += format("<option value='{0}'>{0}월</option>", i);
        }
    }
    html += "</select>";
    $("#select_span3").html(html);

    changeWeek();
}


// 월간차트 연도 변경 시 함수
function initMonthChartAll() {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;

    // 연도 변경 select 생성
    var html = '';
    html += "<select class='selectbox' id='select2' onchange='changeMonth()' style='width:100px'>";
    for (i = 2022; i <= year; i++) {
        html += "<option value='" + i + "' ";
        if (i == year - 1 && month < 2) {
            html += "selected";
        } else if (i == year && month >= 2) {
            html += "selected";
        }
        html += ">" + i + "년도</option>";
    }
    html += "</select>";
    $("#select_span2").html(html);

    changeMonth(month);
}


// 주간차트 둘다 변경
function changeWeek(month) {

    if (month == null || month == undefined) {
        month = $("#select3").val();
        if (month == null || month == undefined) {
            var date = new Date();
            month = date.getMonth() + 1;
        }
    }

    const sendData = {
        projCd: $("#projCdSelect").val(),
        year: $("#select1").val(),
        month: lpad(month, 2, '0'),
    }
    setWeekChart(sendData);
    setWeekAcmChart(sendData);
}


// 월간차트 둘다 변경
function changeMonth() {
    var jsondata = new Object();

    jsondata.wm = 'M';
    jsondata.wmVal = $('#select2 option:selected').val();
    jsondata.projCd = $("#projCdSelect").val();

    setMonthChart(jsondata);
    setMonthAcmChart(jsondata);
}

// ------------------------------------------------------------
// CHART making
// ------------------------------------------------------------
// 아래 차트 4개 만드는거 data만드는거나 config 설정하는거나 대부분 공통적임. 통합할 필요성 있음.
function makeChartData(projCd) {
    // 보류
    const data = {
        labels: labels,
        datasets: [
            {
                label: '등록 수량',
                data: regCnt,
                borderColor: "rgba(255, 205, 86,1)",
                backgroundColor: "rgba(255, 205, 86,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '진단 완료 수량',
                data: diagWorkCnt,
                borderColor: "rgba(75, 192, 192,1)",
                backgroundColor: "rgba(75, 192, 192,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '검수 완료 수량',
                data: inspWorkCnt,
                borderColor: "rgba(255, 99, 132,1)",
                backgroundColor: "rgba(255, 99, 132,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '일치 건 중 PASS 수량',
                data: passCnt,
                borderColor: "rgba(54, 162, 235,1)",
                backgroundColor: "rgba(54, 162, 235,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            }
        ]
    }

    // 
    if (projCd == "2022B1") {
        // 
    }

    return chartData;
}


// 1. 주간 실적 그래프
function setWeekChart(sendData) {
    var rows = [];
    var labels = [];
    var regCnt = [];
    var diagWorkCnt = [];
    var inspWorkCnt = [];
    var passCnt = [];

    console.log("setWeekChart PARAM");
    console.log(sendData);

    $.ajax({
        url: CONTEXT_PATH + "/stat/weekMonth/getWeekChartData.do",
        type: "post",
        dataType: "json",
        data: sendData,
        async: false
    }).done(function (response) {
        console.log("setWeekChart RESPONSE");
        console.log(response);

        rows = response.rows;
        for (var i = 0; i < rows.length; i++) {
            rows[i].weekLong = rows[i].weekOfMonth + '주차(' + rows[i].weekStart.substring(3) + '~' + rows[i].weekEnd.substring(3) + ')';
            labels.push(rows[i].weekLong);
            regCnt.push(rows[i].regCnt);
            diagWorkCnt.push(rows[i].diagWorkCnt);
            inspWorkCnt.push(rows[i].inspWorkCnt);
            passCnt.push(rows[i].passCnt);
        }
    });

    $("#chart1").remove();
    $("#div_chart1").append('<canvas id="chart1"></canvas>');

    var ctx = document.getElementById("chart1").getContext("2d");

    var gradientStroke = ctx.createLinearGradient(100, 0, 800, 0);
    gradientStroke.addColorStop(0, '#80b6f4');
    gradientStroke.addColorStop(0.5, '#f7e28f');
    gradientStroke.addColorStop(1, '#e27a6e');

    const data = {
        labels: labels,
        datasets: [
            {
                label: '등록 수량',
                data: regCnt,
                borderColor: "rgba(255, 205, 86,1)",
                backgroundColor: "rgba(255, 205, 86,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '진단 완료 수량',
                data: diagWorkCnt,
                borderColor: "rgba(75, 192, 192,1)",
                backgroundColor: "rgba(75, 192, 192,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '검수 완료 수량',
                data: inspWorkCnt,
                borderColor: "rgba(255, 99, 132,1)",
                backgroundColor: "rgba(255, 99, 132,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '일치 건 중 PASS 수량',
                data: passCnt,
                borderColor: "rgba(54, 162, 235,1)",
                backgroundColor: "rgba(54, 162, 235,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            }
        ]
    }

    // 하드코딩 :: 폐기능
    if (sendData.projCd == "2022B1") {
        data.datasets.splice(1, 1)
    }

    const config = {
        type: 'bar',
        data: data,
        options: {
            legend: {
                labels: {
                    fontFamily: 'NanumGothic',
                    fontColor: '#000',
                    fontStyle: 'bold'
                }
            },
            tooltips: {
                titleFontFamily: 'NanumGothic',
                callbacks: {
                    label: function (tooltipItem, data) {
                        var label = data.datasets[tooltipItem.datasetIndex].label || '';
                        if (label) {
                            label += ' : ';
                        }
                        label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
                        return label;
                    }
                }
            }
        }
    }
    var chart = new Chart(ctx, config);

    // TABLE
    const $table = $("#chart1_table");
    let inputHtml = "<thead><tr>";
    if (sendData.projCd == "2022B1") {
        inputHtml += "<th>주차</th><th>등록 수량</th><th>검수 완료 수량</th><th>일치 건 중 PASS 수량</th>";    
    } else {
        inputHtml += "<th>주차</th><th>등록 수량</th><th>진단 완료 수량</th><th>검수 완료 수량</th><th>일치 건 중 PASS 수량</th>";
    }
    inputHtml += "</tr></thead><tbody>";
    for (i in rows) {
        inputHtml += format("<tr><td>{0}</td>", rows[i].weekLong);
        inputHtml += format("<td>{0}</td>", rows[i].regCnt);
        if (sendData.projCd != "2022B1") {
            inputHtml += format("<td>{0}</td>", rows[i].diagWorkCnt);
        }
        inputHtml += format("<td>{0}</td>", rows[i].inspWorkCnt);
        inputHtml += format("<td>{0}</td></tr>", rows[i].passCnt);
    }
    inputHtml += "</tbody>";
    $table.html(inputHtml);
}


// 2. 주간 누적 그래프
function setWeekAcmChart(sendData) {
    var rows = [];
    var labels = [];
    var regCnt = [];
    var diagWorkCnt = [];
    var inspWorkCnt = [];
    var passCnt = [];

    console.log("setWeekAcmChart PARAM");
    console.log(sendData);

    $.ajax({
        url: CONTEXT_PATH + "/stat/weekMonth/getWeekAcmChartData.do",
        type: "post",
        dataType: "json",
        data: sendData,
        async: false
    }).done(function (response) {
        console.log("setWeekAcmChart RESPONSE");
        console.log(response);

        rows = response.rows;
        for (i in rows) {
            rows[i].weekLong = rows[i].weekOfMonth + '주차(' + rows[i].weekStart.substring(3) + '~' + rows[i].weekEnd.substring(3) + ')';
            labels.push(rows[i].weekLong);
            regCnt.push(rows[i].regCnt);
            diagWorkCnt.push(rows[i].diagWorkCnt);
            inspWorkCnt.push(rows[i].inspWorkCnt);
            passCnt.push(rows[i].passCnt);
        }
    });

    $("#chart2").remove();
    $("#div_chart2").append('<canvas id="chart2"></canvas>');

    var ctx = document.getElementById("chart2").getContext("2d");

    var gradientStroke = ctx.createLinearGradient(100, 0, 800, 0);
    gradientStroke.addColorStop(0, '#80b6f4');
    gradientStroke.addColorStop(0.5, '#f7e28f');
    gradientStroke.addColorStop(1, '#e27a6e');

    const data = {
        labels: labels,
        datasets: [
            {
                label: '등록 수량',
                data: regCnt,
                borderColor: "rgba(255, 205, 86,1)",
                backgroundColor: "rgba(255, 205, 86,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '진단 완료 수량',
                data: diagWorkCnt,
                borderColor: "rgba(75, 192, 192,1)",
                backgroundColor: "rgba(75, 192, 192,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '검수 완료 수량',
                data: inspWorkCnt,
                borderColor: "rgba(255, 99, 132,1)",
                backgroundColor: "rgba(255, 99, 132,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '일치 건 중 PASS 수량',
                data: passCnt,
                borderColor: "rgba(54, 162, 235,1)",
                backgroundColor: "rgba(54, 162, 235,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            }
        ]
    }

    // 하드코딩 :: 폐기능
    if (sendData.projCd == "2022B1") {
        data.datasets.splice(1, 1)
    }

    const config = {
        type: 'line',
        data: data,
        options: {
            legend: {
                labels: {
                    fontFamily: 'NanumGothic',
                    fontColor: '#000',
                    fontStyle: 'bold'
                }
            },
            tooltips: {
                titleFontFamily: 'NanumGothic',
                callbacks: {
                    label: function (tooltipItem, data) {
                        var label = data.datasets[tooltipItem.datasetIndex].label || '';
                        if (label) {
                            label += ' : ';
                        }
                        label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
                        return label;
                    }
                }
            }
        }
    }
    var chart = new Chart(ctx, config);

    // TABLE
    const $table = $("#chart2_table");
    let inputHtml = "<thead><tr>";
    if (sendData.projCd == "2022B1") {
        inputHtml += "<th>주차</th><th>등록 수량</th><th>검수 완료 수량</th><th>일치 건 중 PASS 수량</th>";    
    } else {
        inputHtml += "<th>주차</th><th>등록 수량</th><th>진단 완료 수량</th><th>검수 완료 수량</th><th>일치 건 중 PASS 수량</th>";
    }
    inputHtml += "</tr></thead><tbody>";
    for (i in rows) {
        inputHtml += format("<tr><td>{0}</td>", rows[i].weekLong);
        inputHtml += format("<td>{0}</td>", rows[i].regCnt);
        if (sendData.projCd != "2022B1") {
            inputHtml += format("<td>{0}</td>", rows[i].diagWorkCnt);
        }
        inputHtml += format("<td>{0}</td>", rows[i].inspWorkCnt);
        inputHtml += format("<td>{0}</td></tr>", rows[i].passCnt);
    }
    inputHtml += "</tbody>";
    $table.html(inputHtml);

}


// 3. 월간 실적 그래프
function setMonthChart(sendData) {
    var rows = [];
    var labels = [];
    var regCnt = [];
    var diagWorkCnt = [];
    var inspWorkCnt = [];
    var passCnt = [];

    console.log("setMonthChart PARAM");
    console.log(sendData);

    $.ajax({
        url: CONTEXT_PATH + "/dashBoard/getMonthChartData.do",
        type: "post",
        dataType: "json",
        data: sendData,
        async: false
    }).done(function (response) {
        console.log("setMonthChart RESPONSE");
        console.log(response);

        rows = response.rows;
        for (i in rows) {
            if (rows[i].wm == 'W') {
                labels.push(rows[i].WeekOfMonth + '주차(' + rows[i].WeekStart + '~' + rows[i].WeekEnd + ')');
            } else {
                rows[i].monthStr = rows[i].Month + '월';
                labels.push(rows[i].monthStr);
            }
            regCnt.push(rows[i].regCnt);
            diagWorkCnt.push(rows[i].diagWorkCnt);
            inspWorkCnt.push(rows[i].inspWorkCnt);
            passCnt.push(rows[i].passCnt);
        }

        // max = Math.max.apply(null, workCnt.map(Number));
        // if (max < 100) {
        //     max = 100;
        // }

    })

    $("#chart3").remove();
    $("#div_chart3").append('<canvas id="chart3"></canvas>');

    var ctx = document.getElementById("chart3").getContext("2d");

    var gradientStroke = ctx.createLinearGradient(100, 0, 800, 0);
    gradientStroke.addColorStop(0, '#80b6f4');
    gradientStroke.addColorStop(0.5, '#f7e28f');
    gradientStroke.addColorStop(1, '#e27a6e');

    const data = {
        labels: labels,
        datasets: [
            {
                label: '등록 수량',
                data: regCnt,
                borderColor: "rgba(255, 205, 86,1)",
                backgroundColor: "rgba(255, 205, 86,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '진단 완료 수량',
                data: diagWorkCnt,
                borderColor: "rgba(75, 192, 192,1)",
                backgroundColor: "rgba(75, 192, 192,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '검수 완료 수량',
                data: inspWorkCnt,
                borderColor: "rgba(255, 99, 132,1)",
                backgroundColor: "rgba(255, 99, 132,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '일치 건 중 PASS 수량',
                data: passCnt,
                borderColor: "rgba(54, 162, 235,1)",
                backgroundColor: "rgba(54, 162, 235,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            }
        ]
    }

    // 하드코딩 :: 폐기능
    if (sendData.projCd == "2022B1") {
        data.datasets.splice(1, 1)
    }

    const config = {
        type: 'bar',
        data: data,
        options: {
            legend: {
                labels: {
                    fontFamily: 'NanumGothic',
                    fontColor: '#000',
                    fontStyle: 'bold'
                }
            },
            tooltips: {
                titleFontFamily: 'NanumGothic',
                callbacks: {
                    label: function (tooltipItem, data) {
                        var label = data.datasets[tooltipItem.datasetIndex].label || '';
                        if (label) {
                            label += ' : ';
                        }
                        label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
                        return label;
                    }
                }
            }
        }
    }
    var chart = new Chart(ctx, config);
    
    // TABLE
    const $table = $("#chart3_table");
    let inputHtml = "<thead><tr>";
    if (sendData.projCd == "2022B1") {
        inputHtml += "<th>월</th><th>등록 수량</th><th>검수 완료 수량</th><th>일치 건 중 PASS 수량</th>";    
    } else {
        inputHtml += "<th>월</th><th>등록 수량</th><th>진단 완료 수량</th><th>검수 완료 수량</th><th>일치 건 중 PASS 수량</th>";
    }
    inputHtml += "</tr></thead><tbody>";
    for (i in rows) {
        inputHtml += format("<tr><td>{0}</td>", rows[i].monthStr);
        inputHtml += format("<td>{0}</td>", rows[i].regCnt);
        if (sendData.projCd != "2022B1") {
            inputHtml += format("<td>{0}</td>", rows[i].diagWorkCnt);
        }
        inputHtml += format("<td>{0}</td>", rows[i].inspWorkCnt);
        inputHtml += format("<td>{0}</td></tr>", rows[i].passCnt);
    }
    inputHtml += "</tbody>";
    $table.html(inputHtml);
}



// 4. 월간 누적 그래프
function setMonthAcmChart(sendData) {
    var rows = [];
    var labels = [];
    var regCnt = [];
    var diagWorkCnt = [];
    var inspWorkCnt = [];
    var passCnt = [];

    console.log("setMonthAcmChart PARAM");
    console.log(sendData);

    $.ajax({
        url: CONTEXT_PATH + "/dashBoard/getMonthAcmChartData.do",
        type: "post",
        dataType: "json",
        data: sendData,
        async: false
    }).done(function (response) {
        console.log("setMonthAcmChart RESPONSE");
        console.log(response);

        rows = response.rows;
        for (i in rows) {
            if (rows[i].wm == 'W') {
                labels.push(rows[i].WeekOfMonth + '주차(' + rows[i].WeekStart + '~' + rows[i].WeekEnd + ')');
            } else {
                rows[i].monthStr = rows[i].Month + '월';
                labels.push(rows[i].monthStr);
            }
            regCnt.push(rows[i].regCnt);
            diagWorkCnt.push(rows[i].diagWorkCnt);
            inspWorkCnt.push(rows[i].inspWorkCnt);
            passCnt.push(rows[i].passCnt);
        }
    });

    $("#chart4").remove();
    $("#div_chart4").append('<canvas id="chart4"></canvas>');

    var ctx = document.getElementById("chart4").getContext("2d");

    var gradientStroke = ctx.createLinearGradient(100, 0, 800, 0);
    gradientStroke.addColorStop(0, '#80b6f4');
    gradientStroke.addColorStop(0.5, '#f7e28f');
    gradientStroke.addColorStop(1, '#e27a6e');

    const data = {
        labels: labels,
        datasets: [
            {
                label: '등록 수량',
                data: regCnt,
                borderColor: "rgba(255, 205, 86,1)",
                backgroundColor: "rgba(255, 205, 86,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '진단 완료 수량',
                data: diagWorkCnt,
                borderColor: "rgba(75, 192, 192,1)",
                backgroundColor: "rgba(75, 192, 192,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '검수 완료 수량',
                data: inspWorkCnt,
                borderColor: "rgba(255, 99, 132,1)",
                backgroundColor: "rgba(255, 99, 132,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            },
            {
                label: '일치 건 중 PASS 수량',
                data: passCnt,
                borderColor: "rgba(54, 162, 235,1)",
                backgroundColor: "rgba(54, 162, 235,1)",
                fill: false,
                borderWidth: 2,
                tension: 0
            }
        ]
    }

    // 하드코딩 :: 폐기능
    if (sendData.projCd == "2022B1") {
        data.datasets.splice(1, 1)
    }
    
    const config = {
        type: 'line',
        data: data,
        options: {
            legend: {
                labels: {
                    fontFamily: 'NanumGothic',
                    fontColor: '#000',
                    fontStyle: 'bold'
                }
            },
            tooltips: {
                titleFontFamily: 'NanumGothic',
                callbacks: {
                    label: function (tooltipItem, data) {
                        var label = data.datasets[tooltipItem.datasetIndex].label || '';
                        if (label) {
                            label += ' : ';
                        }
                        label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
                        return label;
                    }
                }
            }
        }
    }
    var chart = new Chart(ctx, config);
    
    // TABLE
    const $table = $("#chart4_table");
    let inputHtml = "<thead><tr>";
    if (sendData.projCd == "2022B1") {
        inputHtml += "<th>월</th><th>등록 수량</th><th>검수 완료 수량</th><th>일치 건 중 PASS 수량</th>";    
    } else {
        inputHtml += "<th>월</th><th>등록 수량</th><th>진단 완료 수량</th><th>검수 완료 수량</th><th>일치 건 중 PASS 수량</th>";
    }
    inputHtml += "</tr></thead><tbody>";
    for (i in rows) {
        inputHtml += format("<tr><td>{0}</td>", rows[i].monthStr);
        inputHtml += format("<td>{0}</td>", rows[i].regCnt);
        if (sendData.projCd != "2022B1") {
            inputHtml += format("<td>{0}</td>", rows[i].diagWorkCnt);
        }
        inputHtml += format("<td>{0}</td>", rows[i].inspWorkCnt);
        inputHtml += format("<td>{0}</td></tr>", rows[i].passCnt);
    }
    inputHtml += "</tbody>";
    $table.html(inputHtml);
}


// 엑셀 다운로드
function excelDown() {
    var url = CONTEXT_PATH + "/stat/weekMonth/excelProgressList.do";
    var data = new Object();
    data.projCd = $("#projCdSelect").val();

    $(".loading-image").show();

    $.fileDownload(url, {
        httpMethod: "POST",
        data: data,
        successCallback: function (url) {
            $(".loading-image").hide();
        },
        failCallback: function (responseHtml, url, error) {
            $(".loading-image").hide();
        }
    });
}
