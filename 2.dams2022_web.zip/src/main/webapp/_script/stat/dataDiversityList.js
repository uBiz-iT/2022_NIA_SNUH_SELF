// ------------------------------------------------------------
// Init
// ------------------------------------------------------------
$(function () {
    // Init
    setProjectList();
    selectProject();
});

// ------------------------------------------------------------
// Event
// ------------------------------------------------------------




// ------------------------------------------------------------
// Ajax Get Data
// ------------------------------------------------------------
/**
 * 진행률 분석 - 데이터 다양성 분포 현황 - 프로젝트 리스트
 * ajax: POST "/work/crossValidation/getProjectList.do"
 * @param {*} sendData {}
 * @returns response | null
 */
function ajaxGetProjectList(sendData) {
    console.log("ajaxGetProjectList PARAM");
    console.log(sendData);
    $.ajax({
        type: "post",
        url: CONTEXT_PATH + "/work/crossValidation/getProjectList.do",
        data: sendData,
        dataType: "json",
        success: function (response) {
            console.log("ajaxGetProjectList RESPONSE");
            console.log(response);
            return response;
        },
        error: function (request, status, error) {

        },

    });
    return null;
}

/**
 * 진행률 분석 - 데이터 다양성 분포 현황 - 테이블 데이터
 * ajax: POST "/stat/dataDiversity/getDiversityDistributionData.do"
 * @param {*} sendData {}
 * @returns response | null
 */
function ajaxGetDiversityDistributionData(sendData) {
    console.log("ajaxGetDiversityDistributionData PARAM");
    console.log(sendData);
    $.ajax({
        type: "post",
        url: CONTEXT_PATH + "/stat/dataDiversity/getDiversityDistributionData.do",
        data: sendData,
        dataType: "json",
        success: function (response) {
            console.log("ajaxGetDiversityDistributionData RESPONSE");
            console.log(response);
            return response;
        },
        error: function (request, status, error) {

        },

    });
    return null;
}



// ------------------------------------------------------------
// Get Set
// ------------------------------------------------------------
// GET+SET :: Project List
function setProjectList() {
    const url = CONTEXT_PATH + "/stat/dataDiversity/getProjectList.do";
    const async = false;
    callAjax(url, null, async, function (json) {
        console.log("setProjectList RESPONSE");
        console.log(json);

        var rows = json.projectList;
        var html = "";
        html += '<h4 class="subject_title">프로젝트 선택</h4>';
        html += "<tr><td><select id='projCdSelect' onchange='selectProject()'> ";
        for (i in rows) {
            const projCdSharing = getProjCdSharingCookie();
            if (rows[i].projCd == projCdSharing) {
                html += "<option value='" + rows[i].projCd + "' style='font-size:16px;' selected>" + rows[i].projNm + "</option>";
            } else {
                html += "<option value='" + rows[i].projCd + "' style='font-size:16px;'>" + rows[i].projNm + "</option>";
            }
        }
        html += " </select></td></tr>"
        $("#project_div").html(html);

        $("#projCdSelect").on("change", function () {
            setProjCdSharingCookie($("#projCdSelect").val());
        });
    });
}


// 프로젝트 콤보박스 선택 이벤트 ( 프로젝트에 해당하는 기준일자 등록/검수 목록 등을 조회 및 화면에 출력하는 기능 )
function selectProject() {

    showLoading();

    setTimeout(() => {
        setDiversityTable();

        hideLoading();
    }, 10);
}


// GET+SET :: Diversity Distribution List - 테이블데이터
function setDiversityTable() {
    var colNames = [];
    var colModel = [];
    var rows;
    var row_size;

    const sendData = {
        projCd: $("#projCdSelect").val(),
    }
    console.log("setDiversityTable PARAM");
    console.log(sendData);

    $.ajax({
        url: CONTEXT_PATH + '/stat/dataDiversity/getDiversityDistributionData.do',
        type: "POST",
        data: sendData,
        dataType: "json",
        async: false,
    }).done(function (response) {
        if (response.rows != '') {
            console.log("setDiversityTable RESPONSE");
            console.log(response);

            rows = response.rows;
            row_size = response.total;

            // 2022-08-30
            // 하드코딩 :: 수면(2022A1) | 폐기능(2022B1)
            if (sendData.projCd == '2022A1') {
                // colNames = ['라벨', '라벨값', '목표구성비(%)', '4건 이상 환자수', '4건 이상 건수', '4건 이상 Pass 환자구성비(%)', '4건 이상 Pass 건수구성비(%)'];
                colNames = ['라벨', '라벨값', '목표구성비(%)', '환자수', '건수', 'Pass 환자구성비(%)', 'Pass 건수구성비(%)'];
                colModel = [
                    { name: 'baseGrp', index: '라벨', align: 'center', width: 120 },
                    { name: 'subGrpNm', index: '라벨값', align: 'center', width: 120 },
                    { name: 'plnRate', index: '목표구성비(%)', align: 'center', width: 120 },
                    { name: 'patientCnt', index: '환자수', align: 'center', width: 120 },
                    { name: 'cnt', index: '건수', align: 'center', width: 120 },
                    { name: 'patientRate', index: 'Pass 환자구성비(%)', align: 'center', width: 200 },
                    { name: 'rate', index: 'Pass 건수구성비(%)', align: 'center', width: 200 }
                ];
            } else if (sendData.projCd == '2022B1') {
                colNames = ['진단명', '목표', '등록', 'PASS', '달성률(%)', '목표', '등록', 'PASS', '달성률(%)', '목표', '등록', 'PASS', '달성률(%)', '목표', '등록', 'PASS', '달성률(%)', '목표', '등록', 'PASS', '달성률(%)'];
                const keys = Object.keys(rows[0]);
                colModel = [];
                for (i in keys) {
                    if (i == 0) {
                        colModel.push({ name: keys[i], index: keys[i], align: 'center', width: 80, frozen: true });
                    } else {
                        // 폐기능(2022b1) : 달성률에 따른 색상 변경.
                        if (keys[i].indexOf("Rate")) {
                            colModel.push({
                                name: keys[i], index: keys[i], align: 'center', width: 80,
                                formatter: function (value, options, rData) {
                                    let color = "";
                                    if (value >= 120) {
                                        color = "#f33";
                                    } else if (value >= 100) {
                                        color = "#33f";
                                    }
                                    return format("<span color='{0}'>{1}</span>", color, value);
                                }
                            });
                        } else {
                            colModel.push({ name: keys[i], index: keys[i], align: 'center', width: 80 });
                        }
                    }
                }
            }
        } else {
            // alert("조회된 데이터가 없습니다.");
        }
    }).fail(function (jqXHR, textStatus, errorThrown) {
        alert("조회된 데이터가 없습니다.");
    });

    $.jgrid.gridUnload("grid");

    $("#grid").jqGrid({
        data: rows,
        datatype: "local",
        colNames: colNames,
        colModel: colModel,
        rowNum: 9999,
        height: 'auto',
        loadonce: true,
        viewrecords: true,
        // autowidth: true,    	 // jQgrid width 자동100% 채워지게
        // shrinkToFit: false,  // width를 자동설정 해주는 기능
        // gridview: true,
        // cmTemplate: { sortable: false },
        // rownumbers: true,
        onCellSelect: function (rowId, iCol, cellcontent, e) { },
        onSelectRow: function (rowId, status, e) { },
        loadComplete: function (data) { },
        caption: " ",
    });
    $("#grid").jqGrid("setFrozenColumns");


    // 2022-08-30
    // 하드코딩 :: 수면(2022A1) | 폐기능(2022B1)
    if (sendData.projCd == '2022A1') {
        $("#grid").jqGrid('setGroupHeaders', {
            useColSpanStyle: true,
            groupHeaders: [
                { startColumnName: 'patientCnt', numberOfColumns: 4, titleText: '4건 이상' },
            ]
        });
        $("#bottomMsgDiv").empty();
    } else if (sendData.projCd == '2022B1') {
        $("#grid").jqGrid('setGroupHeaders', {
            useColSpanStyle: true,
            groupHeaders: [
                { startColumnName: 'plnCnt', numberOfColumns: 4, titleText: '전체' },
                { startColumnName: 'plnMaleCnt', numberOfColumns: 4, titleText: '남성' },
                { startColumnName: 'plnFemaleCnt', numberOfColumns: 4, titleText: '여성' },
                { startColumnName: 'plnAge65BelowCnt', numberOfColumns: 4, titleText: '65세 이하' },
                { startColumnName: 'plnAge65ExceedCnt', numberOfColumns: 4, titleText: '65세 초과' },
            ]
        });
        $("#bottomMsgDiv").html("<p style='margin: 8px; font-size: 13px; font-weight: bold;'>※ Pass건수는 5건 이상 환자의 데이터에 한함.</p>");
    }
}

// 엑셀 다운로드
function excelDown() {
    var url = CONTEXT_PATH + "/stat/dataDiversity/excelDiversityDistributionData.do";
    var data = {
        projCd: $("#projCdSelect").val()
    }

    $(".loading-image").show();

    $.fileDownload(url, {
        httpMethod: "POST",
        data: data,
        successCallback: function (url) {
            $(".loading-image").hide();
        },
        failCallback: function (responseHtml, url, error) {
            $(".loading-image").hide();
        }
    });
}
