// ------------------------------------------------------------
// Init
// ------------------------------------------------------------
$(function () {
   // Init
   setProjectList();
   selectProject();
});

// ------------------------------------------------------------
// Get Set
// ------------------------------------------------------------
// GET+SET :: Project List
function setProjectList() {
   const url = CONTEXT_PATH + "/stat/institutionStat/getProjectList.do";
   const async = false;
   callAjax(url, null, async, function (json) {
      console.log("setProjectList RESPONSE");
      console.log(json);

      var rows = json.projectList;
      var html = "";
      html += '<h4 class="subject_title">프로젝트 선택</h4>';
      html += "<tr><td><select id='projCdSelect' onchange='selectProject()'> ";
      for (i in rows) {
         const projCdSharing = getProjCdSharingCookie();
         if (rows[i].projCd == projCdSharing) {
            html += "<option value='" + rows[i].projCd + "' style='font-size:16px;' selected>" + rows[i].projNm + "</option>";
         } else {
            html += "<option value='" + rows[i].projCd + "' style='font-size:16px;'>" + rows[i].projNm + "</option>";
         }
      }
      html += " </select></td></tr>"
      $("#project_div").html(html);

      $("#projCdSelect").on("change", function () {
         setProjCdSharingCookie($("#projCdSelect").val());
      });
   });
}


// 프로젝트 콤보박스 선택 이벤트 ( 프로젝트에 해당하는 기준일자 등록/검수 목록 등을 조회 및 화면에 출력하는 기능 )
function selectProject() {

   setInstitutionStatTable();
}


// GET+SET :: Diversity Distribution List - 테이블데이터
function setInstitutionStatTable() {
   var colNames = [];
   var colModel = [];
   var rows;
   var row_size;

   const sendData = {
      projCd: $("#projCdSelect").val(),
   }
   console.log("setInstitutionStatTable PARAM");
   console.log(sendData);

   $.ajax({
      url: CONTEXT_PATH + '/stat/institutionStat/getInstitutionStatList.do',
      type: "POST",
      data: sendData,
      dataType: "json",
      async: false,
   }).done(function (response) {
      if (response.rows != '') {
         console.log("setInstitutionStatTable RESPONSE");
         console.log(response);

         rows = response.rows;
         row_size = response.total;

         colModel = [
            { name: 'hospCd', label: '기관', width: 93, align: 'center', frozen: true, key: true },
            { name: 'regPatientCnt', label: '인원수', width: 65, align: 'center', sorttype:'number' },
            { name: 'regCnt', label: '건수', width: 65, align: 'center', sorttype:'number' },
            { name: 'cntPerPatient', label: '건수/인', width: 70, align: 'center', sorttype:'number' },
            { name: 'inspCnt', label: '건수', width: 65, align: 'center', sorttype:'number' },
            { name: 'passCnt', label: 'Pass건수', width: 65, align: 'center', sorttype:'number' },
            { name: 'passRatio', label: 'Pass율(%)', width: 85, align: 'center', sorttype:'number' },
            { name: 'above3PatientCnt', label: '인원수', width: 65, align: 'center', sorttype:'number' },
            { name: 'above3Cnt', label: '건수', width: 65, align: 'center', sorttype:'number' },
            { name: 'above3CntPerPatient', label: '건수/인', width: 70, align: 'center', sorttype:'number' },
            { name: 'above3Ratio', label: 'Pass율(%)', width: 85, align: 'center', sorttype:'number' },
            { name: 'above4PatientCnt', label: '인원수', width: 65, align: 'center', sorttype:'number' },
            { name: 'above4Cnt', label: '건수', width: 65, align: 'center', sorttype:'number' },
            { name: 'above4CntPerPatient', label: '건수/인', width: 70, align: 'center', sorttype:'number' },
            { name: 'above4Ratio', label: 'Pass율(%)', width: 85, align: 'center', sorttype:'number' },
            { name: 'above5PatientCnt', label: '인원수', width: 65, align: 'center', sorttype:'number' },
            { name: 'above5Cnt', label: '건수', width: 65, align: 'center', sorttype:'number' },
            { name: 'above5CntPerPatient', label: '건수/인', width: 70, align: 'center', sorttype:'number' },
            { name: 'above5Ratio', label: 'Pass율(%)', width: 85, align: 'center', sorttype:'number' },
         ]

      } else {
         // alert("조회된 데이터가 없습니다.");
      }
   }).fail(function (jqXHR, textStatus, errorThrown) {
      alert("조회된 데이터가 없습니다.");
   });

   $.jgrid.gridUnload("grid");

   $("#grid").jqGrid({
      data: rows,
      datatype: "local",
      // colNames: colNames,
      multiSort: true, // 복수컬럼 정렬
      colModel: colModel,
      rowNum: 9999,
      height: 'auto',
      loadonce: true,
      viewrecords: true,
      // autowidth: true,    	 // jQgrid width 자동98% 채워지게
      // shrinkToFit: false,  // width를 자동설정 해주는 기능
      // gridview: true,
      // cmTemplate: { sortable: false },
      rownumbers: true,
      onCellSelect: function (rowId, iCol, cellcontent, e) {},
      onSelectRow: function (rowId, status, e) {},
      loadComplete: function (data) {},
      caption: " ",
   });

   $("#grid").jqGrid("setFrozenColumns");
   $("#grid").jqGrid('setGroupHeaders', {
      useColSpanStyle: true, 
      groupHeaders: [
         { startColumnName: 'regPatientCnt', numberOfColumns: 3, titleText: '전체' },
         { startColumnName: 'inspCnt', numberOfColumns: 3, titleText: '검수' },
         { startColumnName: 'above3PatientCnt', numberOfColumns: 4, titleText: '3건이상' },
         { startColumnName: 'above4PatientCnt', numberOfColumns: 4, titleText: '4건이상' },
         { startColumnName: 'above5PatientCnt', numberOfColumns: 4, titleText: '5건이상' },
      ]
    });
}

// 엑셀 다운로드
function excelDown() {
   var url = CONTEXT_PATH + "/stat/institutionStat/excelInstitutionStatList.do";
   var data = {
      projCd: $("#projCdSelect").val()
   }

   $(".loading-image").show();

   $.fileDownload(url, {
      httpMethod: "POST",
      data: data,
      successCallback: function (url) {
         $(".loading-image").hide();
      },
      failCallback: function (responseHtml, url, error) {
         $(".loading-image").hide();
      }
   });
}
