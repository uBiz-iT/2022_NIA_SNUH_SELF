$(function () {
   // Init
   setProjectList();
   setTotalStat();
   setTaskList();
});

/** Click : search - 검색 조회 */
$("#search").click(function () {
   setTotalStat();
   setTaskList();
});

/** Submit : form - 검색 조회 */
$("#form").submit(function (e) {
   e.preventDefault();
   $("#search").click();
});

/** 프로젝트 리스트 */
function setProjectList() {
   var url = CONTEXT_PATH + "/work/crossValidation/getProjectList.do"; // 이건 따로 common 으로 두는게 차라리 나을듯 너무 많이 쓰인다.
   var async = false;
   callAjax(url, null, async, function (json) {
      console.log("setProjectList RESPONSE");
      console.log(json);

      var rows = json.projectList;

      var html = "";
      html += "<tr><td><select id='projCdSelect' onchange='selectProject()'> ";
      for (i in rows) {
         const projCdSharing = getProjCdSharingCookie();
         if (rows[i].projCd == projCdSharing) {
            html += "<option value='" + rows[i].projCd + "' style='font-size:16px;' selected>" + rows[i].projNm + "</option>";
         } else {
            html += "<option value='" + rows[i].projCd + "' style='font-size:16px;'>" + rows[i].projNm + "</option>";
         }
      }
      html += " </select></td></tr>"
      $("#tb_project2").html(html);

      $("#projCdSelect").on("change", function () {
         setProjCdSharingCookie($("#projCdSelect").val());
      });
   });
}

/** 프로젝트 선택 이벤트 */
function selectProject() {
   setTotalStat();
   setTaskList();

   $("#search").click();
   $(".div_title")[0].style.display = "none";
}

/** 검색창 테이블 사이에 있는 통계 : GET+SET :: Total Stat */
function setTotalStat() {
   const url = CONTEXT_PATH + "/stat/taskStat/getTotalStat.do";
   const sendData = {
      projCd: $("#projCdSelect").val(),
      taskCd: $("#taskCd").val(),
      completeYn: $("#completeYn option:selected").val(),
   }
   const async = false;
   callAjax(url, sendData, async, function (json) {
      var row = json.rows;
      $("#regCnt").text(row.regCnt);
      $("#diagWorkCnt").text(row.diagWorkCnt);
      $("#diagRate").text(row.diagRate);
      $("#inspWorkCnt").text(row.inspWorkCnt);
      $("#inspRate").text(row.inspRate);
      $("#passCnt").text(row.passCnt);
      $("#passInspRate").text(row.passInspRate);
      $("#passRate").text(row.passRate);
   });
}

/** 테이블 데이터 (태스크 리스트) getAjax + set */
function setTaskList() {
   const url = CONTEXT_PATH + "/stat/taskStat/getTaskList.do";
   const sendData = {
      projCd: $("#projCdSelect").val(),
      taskCd: $("#taskCd").val(),
      completeYn: $("#completeYn option:selected").val(),
   }
   const async = false;
   callAjax(url, sendData, async, function (json) {
      createTableRow("progressTitleTable", json);

      var rowLength = $("#progressTitleTable").find("tr").length - 1;
      $("#list_num").text(rowLength);

      if (json.total < 10) {
         $(".list_title").css('height', 'auto');
      }
   });
}

/** 프로젝트 진행률 확인 **/
function progress_chk(project_cd, task_cd) {
   $("#project_code").val(project_cd);
   //    $(".div_title").find(".project_title").text('태스크 : ' + project_cd);
   $(".div_title").find(".project_title").text('태스크 : ' + task_cd);

   graph1(project_cd, task_cd);
   graph2(project_cd, task_cd);
   graph3(project_cd, task_cd);

   $(".div_title").show();
   //    $('html, body').stop().animate({ scrollTop :  $("#panel").offset().top }, 1200);
   $('html,body').animate({ scrollTop: $(".list_title").offset().top }, 100);
}

/** func : 클릭 시 해당 교차검증 페이지로 이동 **/
function cross_chk(project_cd, task_cd) {
   $("#project_code").val(project_cd);
   location.href = CONTEXT_PATH + "/work/crossValidation.do?taskStatYn=Y&taskStatYn2=Y&taskStatProjCd=" + project_cd + "&taskStatTaskCd=" + task_cd;
}
 
/** 하단 좌측 그래프 - 검수자 PASS, FAIL **/
function graph1(project_cd, task_cd) {
   var html = "<canvas id='myChart1'></canvas>";
   $("#chart1").html(html);

   var label = [];
   var labels = [];
   var datasets = [];

   $.ajax({
      url: CONTEXT_PATH + "/stat/taskStat/getChart1Data.do",
      type: "POST",
      dataType: "json",
      data: { "projCd": project_cd, "taskCd": task_cd },
      async: false
   }).done(function (json) {
      var rows = json.rows;

      var diagCnt = [];
      var inspCnt = [];
      var passCnt = [];
      var failCnt = [];

      // 진단 검수 진행률
      var diagRate_data = [];
      var inspRate_data = [];
      var pass_data = [];
      var fail_data = [];

      for (var i = 0; i < rows.length; i++) {
         label.push(rows[i].userNm);
      }

      labels = label.reduce((a, b) => {
         if (a.indexOf(b) < 0) a.push(b);
         return a;
      }, []);

      for (var i = 0; i < rows.length; i++) {
         if (labels[i] = rows[i].userNm) {
            //          pass_data.push(rows[i].pass_progress);

            if (rows[i].caseCnt > 0) {
               diagRate_data.push(Math.round((rows[i].diagWorkCnt / rows[i].caseCnt) * 100));
               inspRate_data.push(Math.round((rows[i].inspWorkCnt / rows[i].caseCnt) * 100));
               //        		inspRate_data.push( rows[i].inspWorkCnt / rows[i].caseCnt );
            } else {
               diagRate_data.push(0);
               inspRate_data.push(0);
            }

            pass_data.push(rows[i].passInspRate);
            //          fail_data.push(rows[i].fail_progress);
            fail_data.push(rows[i].failInspRate);
            diagCnt.push(rows[i].diagWorkCnt);
            inspCnt.push(rows[i].inspWorkCnt);
            passCnt.push(rows[i].inspPassCnt);
            failCnt.push(rows[i].inspFailCnt);
         }
      }

      // 2022-08-17(인수인계) 차트에 뿌려주지 않는상태임
      var diag_dataset = {};
      diag_dataset.label = '진단 건 수';
      diag_dataset.backgroundColor = 'rgba(255, 99, 132, 1)';
      diag_dataset.borderColor = 'rgba(255, 255, 255, 1)';
      diag_dataset.borderWidth = 1;
      //      diag_dataset.data = diagRate_data;
      //      diag_dataset.count = diagCnt;
      diag_dataset.data = diagCnt;
      diag_dataset.progress = diagRate_data;
      //    diag_dataset.stack = 'Stack 0';

      // 2022-08-17(인수인계) 차트에 뿌려주지 않는상태임
      var insp_dataset = {};
      insp_dataset.label = '검수 건 수';
      insp_dataset.backgroundColor = 'rgba(201, 203, 207, 1)';
      insp_dataset.borderColor = 'rgba(255, 255, 255, 1)';
      insp_dataset.borderWidth = 1;
      //      insp_dataset.data = inspRate_data;
      //      insp_dataset.count = inspCnt;
      insp_dataset.data = inspCnt;
      insp_dataset.progress = inspRate_data;
      //    insp_dataset.stack = 'Stack 0';

      var pass_dataset = {};
      pass_dataset.label = 'PASS 건 수(진행률%)';
      pass_dataset.backgroundColor = 'rgba(54, 162, 235, 1)';
      pass_dataset.borderColor = 'rgba(255, 255, 255, 1)';
      pass_dataset.borderWidth = 1;
      //      pass_dataset.data = pass_data;
      //      pass_dataset.count = passCnt;
      pass_dataset.data = passCnt;
      pass_dataset.progress = pass_data;
      //      pass_dataset.data = passCnt;
      //      pass_dataset.count = pass_data;
      //    pass_dataset.stack = 'Stack 1';

      var fail_dataset = {};
      fail_dataset.label = 'FAIL 건 수(진행률%)';
      fail_dataset.backgroundColor = 'rgba(255, 99, 132, 1)';
      fail_dataset.borderColor = 'rgba(255, 255, 255, 1)';
      fail_dataset.borderWidth = 1;
      //      fail_dataset.data = fail_data;
      //      fail_dataset.count = failCnt;
      fail_dataset.data = failCnt;
      fail_dataset.progress = fail_data;
      //    pass_dataset.stack = 'Stack 1';

      //    datasets.push(diag_dataset);
      //    datasets.push(insp_dataset);

      // 2022-08-17(인수인계) PASS건수/FAIL건수만 뿌려줌
      datasets.push(pass_dataset);
      datasets.push(fail_dataset);

   });

   var barCharData = {
      labels: labels,
      datasets: datasets
   };

   var canvas = document.getElementById("myChart1");
   var myChart = new Chart(canvas, {
      type: 'bar',
      data: barCharData,
      options: {
         plugins: {
            //           events: false,
            //	          tooltips: {
            //	              enabled: true
            //	          },
            legend: {
               display: true,
               labels: { fontSize: 13, fontFamily: 'NanumGothic', fontColor: '#000', fontStyle: 'bold' }
            },
            tooltip: {
               titleFontFamily: 'NanumGothic',
               callbacks: {
                  label: function (context) {
                     return context.formattedValue + "건 (" + context.dataset.progress[context.dataIndex] + "% )";
                  }
               }
            }
         }
      }
   })
}

/** 2022-08-17(인수인계) 하단 중앙 그래프 */
function graph2(project_cd, task_cd) {
   var html = "<canvas id='myChart2'></canvas>";
   $("#chart2").html(html);

   var labels = ['진단', 'DROP', '미진단'];
   var _data = [];
   var _datas = [];

   var backgroundColors = ['rgba(255, 205, 86, 1)', 'rgba(255, 99, 132, 1)', 'rgba(75, 192, 192, 1)'];
   var borderColors = ['rgba(255, 255, 255, 1)', 'rgba(255, 255, 255, 1)', 'rgba(255, 255, 255, 1)'];

   $.ajax({
      url: CONTEXT_PATH + "/stat/taskStat/getChart2Data.do",
      type: "POST",
      dataType: "json",
      data: { "projCd": project_cd, "taskCd": task_cd },
      async: false
   }).done(function (json) {
      var rows;
      rows = json.rows;

      var diagNotZRate;
      var dropRate;
      var diagRemRate;
      if (rows[0].caseCnt > 0) {
         diagNotZRate = (rows[0].diagNotZCnt / rows[0].caseCnt) * 100;
         dropRate = (rows[0].dropCnt / rows[0].caseCnt) * 100;
         diagRemRate = (rows[0].diagRemCnt / rows[0].caseCnt) * 100;
      } else {
         diagNotZRate = 0;
         dropRate = 0;
         diagRemRate = 0;
      }
      //건수
      _datas.push(rows[0].diagNotZCnt); // 진단
      _datas.push(rows[0].dropCnt); // DROP
      _datas.push(rows[0].diagRemCnt); // 미진단
      //      datas.push(rows[0].no_work);

      //백분율
      _data.push(diagNotZRate); // 진단 율
      _data.push(dropRate); // DROP 률
      _data.push(diagRemRate); // 미진단 율
      //	  data.push(rows[0].no_work_percent);
   });

   var canvas = document.getElementById("myChart2");
   var myChart = new Chart(canvas, {
      type: 'pie',
      data: {
         labels: labels,
         datasets: [{
            label: 'PASS / FAIL 일치 비율',
            fill: false,
            data: _data,
            datas: _datas,
            backgroundColor: backgroundColors,
            borderColor: borderColors,
            colors: ['rgba(0, 0, 0, 1)', 'rgba(0, 0, 0, 1)', 'rgba(0, 0, 0, 1)'],
            borderWidth: 1
         }]
      },
      options: {
         // events: true,
         // tooltips: {
         //    enabled: false
         // },
         plugins: {
            legend: {
               display: true,
               labels: { fontSize: 13, fontFamily: 'NanumGothic', fontColor: '#000', fontStyle: 'bold' }
            },
            tooltip: {
               titleFontFamily: 'NanumGothic',
               callbacks: {
                  label: function (data) {
                     return data.formattedValue + "% (" + data.dataset.datas[data.dataIndex] + "건 )";
                  }
               }
            }
         }
      }
   });
}

/** 하단 우측 그래프 */
function graph3(project_cd, task_cd) {
   var html = "<canvas id='myChart3'></canvas>";
   $("#chart3").html(html);

   var labels = ['PASS 일치', 'FAIL 일치', '불일치', '미검수'];
   var _data = [];
   var _datas = [];
   var ratio = [];

   var backgroundColors = ['rgba(54, 162, 235, 1)', 'rgba(255, 99, 132, 1)', 'rgba(255, 159, 64, 1)', 'rgba(75, 192, 192, 1)'];
   var borderColors = ['rgba(255, 255, 255, 1)', 'rgba(255, 255, 255, 1)', 'rgba(255, 255, 255, 1)', 'rgba(255, 255, 255, 1)'];

   $.ajax({
      url: CONTEXT_PATH + "/stat/taskStat/getChart2Data.do",
      type: "POST",
      dataType: "json",
      data: { "projCd": project_cd, "taskCd": task_cd },
      async: false
   }).done(function (json) {
      var rows = json;
      rows = json.rows;

      var samePassRate;
      var sameFailRate;
      var sameNotRate;
      var inspRemRate;

      samePassRate = (rows[0].samePassCnt / rows[0].caseCnt) * 100;
      sameFailRate = (rows[0].sameFailCnt / rows[0].caseCnt) * 100;
      sameNotRate = (rows[0].sameNotCnt / rows[0].caseCnt) * 100;
      inspRemRate = (rows[0].inspRemCnt / rows[0].caseCnt) * 100;

      //건수
      _datas.push(rows[0].samePassCnt); // pass
      _datas.push(rows[0].sameFailCnt); // fail
      _datas.push(rows[0].sameNotCnt); // 불일치
      _datas.push(rows[0].inspRemCnt); // 미검수

      //백분율
      if (rows[0].caseCnt > 0) {
         _data.push(samePassRate); // PASS 일치 비율
         _data.push(sameFailRate); // FAIL 일치 비율
         _data.push(sameNotRate); // 불일치 비율
         _data.push(inspRemRate); // 미검수 비율
      }

      ratio = [samePassRate, sameFailRate, sameNotRate, inspRemRate];
   });

   var canvas = document.getElementById("myChart3");
   var myChart = new Chart(canvas, {
      type: 'pie',
      data: {
         labels: labels,
         datasets: [{
            label: 'PASS / FAIL 일치 비율',
            fill: false,
            data: _data,
            datas: _datas,
            backgroundColor: backgroundColors,
            borderColor: borderColors,
            colors: backgroundColors,
            borderWidth: 1
         }]
      },
      options: {
         plugins: {
            legend: {
               display: true,
               labels: { fontSize: 13, fontFamily: 'NanumGothic', fontColor: '#000', fontStyle: 'bold' }
            },
            tooltip: {
               titleFontFamily: 'NanumGothic',
               callbacks: {
                  label: function (data) {
                     return data.formattedValue + "% (" + data.dataset.datas[data.dataIndex] + "건 )";
                  }
               }
            }
         }
      }
   });
}

/** 엑셀 다운로드 */
function excelTaskList() {
   var url = CONTEXT_PATH + "/stat/taskStat/excelTaskList.do";
   var data = new Object();
   data.projCd = $("#projCdSelect").val();
   data.taskCd = $("#taskCd").val();
   data.completeYn = $("#completeYn option:selected").val();

   $(".loading-image").show();

   $.fileDownload(url, {
      httpMethod: "POST",
      data: data,
      successCallback: function (url) {
         $(".loading-image").hide();
      },
      failCallback: function (responseHtml, url, error) {
         $(".loading-image").hide();
      }
   });
}