$(".input_text").keydown(function (key) {
	if (key.keyCode == 13) {
		$("#search").click();
	}
});

$(function () {
	setProjectList();
	setInspectorStatTable();
})

// GET+SET :: Project List
function setProjectList() {
	var url = CONTEXT_PATH + "/work/crossValidation/getProjectList.do";
	var async = false;
	callAjax(url, null, async, function (json) {
		console.log("setProjectList RESPONSE");
		console.log(json);
		
		var rows = json.projectList;

		var html = "";
		html += "<tr><td><select id='projCdSelect' onchange='selectProject()'> ";
		for (i in rows) {
			const projCdSharing = getProjCdSharingCookie();
			if (rows[i].projCd == projCdSharing) {
			   html += "<option value='" + rows[i].projCd + "' style='font-size:16px;' selected>" + rows[i].projNm + "</option>";
			} else {
			   html += "<option value='" + rows[i].projCd + "' style='font-size:16px;'>" + rows[i].projNm + "</option>";
			}
		 }
		 html += " </select></td></tr>"
		 $("#tb_project2").html(html);
   
		 $("#projCdSelect").on("change", function () {
			setProjCdSharingCookie($("#projCdSelect").val());
		 });
	});
}


// 프로젝트 코드/명 선택
function selectProject() {

	setInspectorStatTable();

	$("#search").click();
}


// GET+SET :: Table
function setInspectorStatTable() {
	// 이건 뭐지?
	$("#userId_hide").val($("#userId").val());
	$("#userNm_hide").val($("#userNm").val());

	const sendData = {
		projCd: $("#projCdSelect").val(),
		userId: $('#userId').val(),
		userNm: $('#userNm').val(),
	};

	console.log("setInspectorStatTable PARAM");
	console.log(sendData);

	// 기본 vs 폐음(2022B2)
	let colNames;
	let colModel;
	// 1. 폐음(2022B2)
	if (sendData.projCd == '2022B2') {
		colNames = ['진단 및 검수자 아이디(이름)', '참여 태스크 수', '진단 대상건 수', '검수 대상건 수', '진단/검수 대상건 수', '진단 완료건 수', '검수 완료건 수', '진단/검수 완료건 수', '진단 검수 진행률', '검수 PASS건수', '검수 FAIL건수', '검수 PASS율', '검수 FAIL율', '진행률 확인'];
		colModel = [
			{
				name: 'userId', key: true, index: 'userId', width: 165, align: "center",
				formatter: function (value, options, rData) {
					return value + "(" + rData['userNm'] + ")";
				},
				frozen: true,
			},
			{ name: 'taskCnt', index: 'taskCnt', width: 90, align: "center" },
			{ name: 'diagCaseCnt', index: 'daigCaseCnt', width: 88, align: "center" },
			{ name: 'inspCaseCnt', index: 'inspCaseCnt', width: 88, align: "center" },
			{ name: 'caseCnt', index: 'caseCnt', width: 120, align: "center" },
			{ name: 'diagWorkCnt', index: 'diagWorkCnt', width: 88, align: "center" },
			{ name: 'inspWorkCnt', index: 'inspWorkCnt', width: 88, align: "center" },
			{ name: 'workCnt', index: 'workCnt', width: 120, align: "center" },
			{ name: 'inspRate', index: 'inspRate', width: 100, align: "center" },
			{ name: 'inspPassCnt', index: 'inspPassCnt', width: 90, align: "center" },
			{ name: 'inspFailCnt', index: 'inspFailCnt', width: 90, align: "center" },
			{ name: 'inspPassRate', index: 'inspPassRate', width: 79, align: "center" },
			{ name: 'inspFailRate', index: 'inspFailRate', width: 79, align: "center" },
			{ name: 'progressChk', index: 'progressChk', width: 77, align: "center" },
		];
	} else {
		// 2. 나머지
		colNames = ['진단 및 검수자 아이디(이름)', '참여 태스크 수', '진단/검수 대상건 수', '진단 완료건 수', '검수 완료건 수', '진단/검수 완료건 수', '진단 검수 진행률', '검수 PASS 건수', '검수 FAIL 건수', '검수 PASS 율', '검수 FAIL 율', '진행률 확인'];
		colModel = [
			{
				name: 'userId', key: true, index: 'userId', width: 165, align: "center",
				formatter: function (value, options, rData) {
					return value + "(" + rData['userNm'] + ")";
				},
				frozen: true,
			},
			{ name: 'taskCnt', index: 'taskCnt', width: 100, align: "center" },
			{ name: 'caseCnt', index: 'caseCnt', width: 120, align: "center" },
			{ name: 'diagWorkCnt', index: 'diagWorkCnt', width: 100, align: "center" },
			{ name: 'inspWorkCnt', index: 'inspWorkCnt', width: 100, align: "center" },
			{ name: 'workCnt', index: 'workCnt', width: 125, align: "center" },
			{ name: 'inspRate', index: 'inspRate', width: 120, align: "center" },
			{ name: 'inspPassCnt', index: 'inspPassCnt', width: 110, align: "center" },
			{ name: 'inspFailCnt', index: 'inspFailCnt', width: 110, align: "center" },
			{ name: 'inspPassRate', index: 'inspPassRate', width: 110, align: "center" },
			{ name: 'inspFailRate', index: 'inspFailRate', width: 110, align: "center" },
			{ name: 'progressChk', index: 'progressChk', width: 90, align: "center" },
		];
	}

	$.jgrid.gridUnload("grid");

	$("#grid").jqGrid({
		url: CONTEXT_PATH + '/stat/inspectorStat/getInspectorList.do',
		// data: sendData,
		mtype: "POST",
		datatype: 'json',
		jsonReader: {
			root: "insStatList",
		},
		postData: sendData,
		colNames: colNames,
		colModel: colModel,
		rowNum: 9999,
		// 	    rowList: [10,20,30],
		height: 400,
		loadonce: true,
		autowidth: true,    	 // jQgrid width 자동100% 채워지게
		shrinkToFit: false,  // width를 자동설정 해주는 기능
		gridview: true,
		cmTemplate: { sortable: false },
		rownumbers: true,
		// 	    pager: '#pager',
		onCellSelect: function (rowid, icol, cellcontent, e) {
			// 22-07-06 폼으로 바로 연동하기 위해 파라미터 값 추가
			var rowData = $(this).jqGrid("getRowData", rowid);

			//         	popupView(rowData.projCd, rowData.projNm, rowData.useYn, rowData.weekRepoStdDayw, rowData.planDsetQty, rowData.projBegYmd, rowData.projEndYmd, rowData.regDt);
		},

		viewrecords: true,
		loadComplete: function (response) {
			console.log("setInspectorStatTable RESPONSE");
			console.log(response);

			var total = $("#grid").getGridParam("records");
			$("#list_num").text(total);
		},
		caption: " "
	});
	// 2022-09-07
	$("#grid").jqGrid("setFrozenColumns");
}


// 진행률 확인 버튼 이벤트
function progressChk(userId, userNm) {

	$(".div_title").find(".user_title").text('검수자 이름(아이디) : ' + userNm + '(' + userId + ')');
	//   $(".div_title").slideDown('fast');
	$(".div_title").show();

	$('html,body').animate({ scrollTop: $(".list_grid").offset().top }, 100);

	setInspectChart(userId);
	setTaskChart(userId);
}


function userProgress(userId) {
	var data = new Object();
	data.userId = userId;

	var async = false;
	$.ajax({
		url: "progress.user.view.total.do",
		type: "POST",
		dataType: "json",
		global: true,
		data: { "userId": userId },
		async: false
	}).done(function (json) {
		var row = json.rows;

		$(".div_title").find("#workCnt").text(row[0].workCnt);
		$(".div_title").find("#workCnt_ing").text(row[0].work_ing);
		$(".div_title").find("#workCnt_ani").val(row[0].workCnt);
		$(".div_title").find("#workCnt_ani").attr('max', row[0].assign_cnt);
		$(".div_title").find("#work_part").text("( " + row[0].workCnt + " / " + row[0].assign_cnt + " )")

		$(".div_title").find("#event_workCnt").text(row[0].event_workCnt);
		$(".div_title").find("#event_workCnt_ing").text(row[0].event_work_ing);
		$(".div_title").find("#event_workCnt_ani").val(row[0].event_workCnt);
		$(".div_title").find("#event_workCnt_ani").attr('max', row[0].event_assign_cnt);
		$(".div_title").find("#event_work_part").text("( " + row[0].event_workCnt + " / " + row[0].event_assign_cnt + " )")

		$(".div_title").find("#event_ok_cnt").text(row[0].event_ok_cnt);
		$(".div_title").find("#event_ok_cnt_ing").text(row[0].event_ok_ing);
		$(".div_title").find("#event_ok_cnt_ani").val(row[0].event_ok_cnt);
		$(".div_title").find("#event_ok_cnt_ani").attr('max', row[0].event_assign_cnt);
		$(".div_title").find("#event_ok_part").text("( " + row[0].event_ok_cnt + " / " + row[0].event_assign_cnt + " )")

		$(".div_title").find("#event_ng_cnt").text(row[0].event_ng_cnt);
		$(".div_title").find("#event_ng_cnt_ing").text(row[0].event_ng_ing);
		$(".div_title").find("#event_ng_cnt_ani").val(row[0].event_ng_cnt);
		$(".div_title").find("#event_ng_cnt_ani").attr('max', row[0].event_assign_cnt);
		$(".div_title").find("#event_ng_part").text("( " + row[0].event_ng_cnt + " / " + row[0].event_assign_cnt + " )")

		$(".div_title").find("#project_cnt").text(row[0].project_cnt);

		$(".div_title").find("#count").text('검수 할당 건 수 : 총 ' + row[0].assign_cnt + ' 건 / 이벤트 할당 건 수 : 총 ' + row[0].event_assign_cnt + ' 건');

	});
}

/*
차트 2개
1. inspectChart
2. taskChart
*/

// Chart 1. inspectChart
function setInspectChart(userId) {
	$("#chart1").html("");
	var html = "";

	//	alert("projCd : " + $("#projCdSelect").val());

	$("#projCd").val($("#projCdSelect").val());

	var projCd = $("#projCdSelect").val();

	html += "<canvas id='myChart1'></canvas>";
	$("#chart1").append(html);

	var label = [];
	var labels = [];
	var datasets = [];
	var max = 0;

	$.ajax({
		url: CONTEXT_PATH + '/stat/inspectorStat/getChart1Data.do',
		type: "POST",
		dataType: "json",
		data: { "userId": userId, "projCd": projCd },
		async: false
	}).done(function (json) {

		var rows;
		rows = json.rows;

		var caseCnt = [];
		var workCnt = [];
		var diagWorkCnt = [];
		var inspWorkCnt = [];

		for (var i = 0; i < rows.length; i++) {
			label.push(rows[i].taskCd);
		}

		labels = label.reduce((a, b) => {
			if (a.indexOf(b) < 0) a.push(b);
			return a;
		}, []);

		for (var i = 0; i < rows.length; i++) {
			if (labels[i] = rows[i].taskCd) {
				caseCnt.push(rows[i].caseCnt);
				workCnt.push(rows[i].workCnt);
				diagWorkCnt.push(rows[i].diagWorkCnt);
				inspWorkCnt.push(rows[i].inspWorkCnt);
			}
		}

		max = Math.max.apply(null, caseCnt.map(Number));
		if (max < 10) {
			max = 10;
		}

		var case_dataset = {};
		case_dataset.label = '할당 건 수';
		//	      case_dataset.backgroundColor = 'rgba(216, 43, 24, 0.2)';
		case_dataset.backgroundColor = 'rgba(75, 192, 192, 1)';
		//	      case_dataset.borderColor = 'rgba(216, 43, 24, 1)';
		case_dataset.borderColor = 'rgba(255, 255, 255, 1)';
		case_dataset.borderWidth = 1;
		case_dataset.data = caseCnt;
		case_dataset.stack = 'Stack 0';

		var diag_work_dataset = {};
		diag_work_dataset.label = '진단 완료 건 수';
		//	      diag_work_dataset.backgroundColor = 'rgba(35, 84, 131, 0.2)';
		diag_work_dataset.backgroundColor = 'rgba(54, 162, 235, 1)';
		//	      diag_work_dataset.borderColor = 'rgba(35, 84, 131, 1)';
		diag_work_dataset.borderColor = 'rgba(255, 255, 255, 1)';
		diag_work_dataset.borderWidth = 1;
		diag_work_dataset.data = diagWorkCnt;
		diag_work_dataset.stack = 'Stack 1';

		var insp_work_dataset = {};
		insp_work_dataset.label = '검수 완료 건 수';
		//	      insp_work_dataset.backgroundColor = 'rgba(35, 84, 131, 0.2)';
		insp_work_dataset.backgroundColor = 'rgba(255, 159, 64, 1)';
		//	      insp_work_dataset.borderColor = 'rgba(35, 84, 131, 1)';
		insp_work_dataset.borderColor = 'rgba(255, 255, 255, 1)';
		insp_work_dataset.borderWidth = 1;
		insp_work_dataset.data = inspWorkCnt;
		insp_work_dataset.stack = 'Stack 1';

		datasets.push(case_dataset);
		datasets.push(diag_work_dataset);
		datasets.push(insp_work_dataset);

	});

	var barCharData = {
		labels: labels,
		datasets: datasets
	};

	var canvas = document.getElementById("myChart1");
	var myChart = new Chart(canvas, {
		type: 'bar',
		data: barCharData,
		options: {
			//	           events: false,
			tooltips: {
				enabled: false
			},
			legend: {
				display: true,
				labels: { fontSize: 13, fontFamily: 'NanumGothic', fontColor: '#000', fontStyle: 'bold' }
			},
			tooltips: {
				titleFontFamily: 'NanumGothic',
				callbacks: {
					label: function (tooltipItem, data) {
						var label = data.datasets[tooltipItem.datasetIndex].label || '';
						if (label) {
							label += ' : ';
						}
						label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
						return label;
					}
				}
			},

		}
	})
}


// Chart 2. taskChart
function setTaskChart(userId) {
	$("#chart2").html("");

	$("#projCd").val($("#projCdSelect").val());

	var projCd = $("#projCdSelect").val();

	var html = "";
	html += "<canvas id='myChart2'></canvas>";
	$("#chart2").append(html);

	var label = [];
	var labels = [];
	var datasets = [];
	var max = 0;

	$.ajax({
		url: CONTEXT_PATH + '/stat/inspectorStat/getChart2Data.do',
		type: "POST",
		dataType: "json",
		data: { "userId": userId, "projCd": projCd },
		async: false
	})
		.done(function (json) {

			var rows = json;
			rows = json.rows;

			var caseCnt = [];
			//	var pass_cnt = [];
			//	var fail_cnt = [];
			//	var pass_progress = [];
			//	var fail_progress = [];

			var inspPassCnt = [];
			var inspFailCnt = [];
			var inspPassRate = [];
			var inspFailRate = [];

			for (var i = 0; i < rows.length; i++) {
				label.push(rows[i].taskCd);
			}

			labels = label.reduce((a, b) => {
				if (a.indexOf(b) < 0) a.push(b);
				return a;
			}, []);

			for (var i = 0; i < rows.length; i++) {
				if (labels[i] = rows[i].taskCd) {
					caseCnt.push(rows[i].caseCnt);
					//            pass_cnt.push(rows[i].pass_cnt);
					//            fail_cnt.push(rows[i].fail_cnt);
					//            pass_progress.push(rows[i].pass_progress);
					//            fail_progress.push(rows[i].fail_progress);
					inspPassCnt.push(rows[i].inspPassCnt);
					inspFailCnt.push(rows[i].inspFailCnt);
					inspPassRate.push(rows[i].inspPassRate);
					inspFailRate.push(rows[i].inspFailRate);
				}
			}

			max = Math.max.apply(null, caseCnt.map(Number));
			if (max < 10) {
				max = 10;
			}

			var caseDataset = {};
			caseDataset.label = '진단/검수 완료 건수';
			caseDataset.backgroundColor = 'rgba(75, 192, 192, 1)';
			caseDataset.borderColor = 'rgba(255, 255, 255, 1)';
			caseDataset.borderWidth = 1;
			caseDataset.data = caseCnt;
			//      caseDataset.progress = 100;
			//      caseDataset.stack = 'Stack 0';

			var inspPassDataset = {};
			inspPassDataset.label = 'PASS 건 수(진행률%)';
			inspPassDataset.backgroundColor = 'rgba(255, 205, 86, 1)';
			inspPassDataset.borderColor = 'rgba(255, 255, 255, 1)';
			inspPassDataset.borderWidth = 1;
			inspPassDataset.data = inspPassCnt;
			inspPassDataset.progress = inspPassRate;
			//      inspPassDataset.stack = 'Stack 1';

			var inspFailDataset = {};
			inspFailDataset.label = 'FAIL 건 수(진행률%)';
			inspFailDataset.backgroundColor = 'rgba(255, 99, 132, 1)';
			inspFailDataset.borderColor = 'rgba(255, 255, 255, 1)';
			inspFailDataset.borderWidth = 1;
			inspFailDataset.data = inspFailCnt;
			inspFailDataset.progress = inspFailRate;
			//      inspFailDataset.stack = 'Stack 1';

			//      datasets.push(caseDataset);
			datasets.push(inspPassDataset);
			datasets.push(inspFailDataset);

		})

	var barCharData = {
		labels: labels,
		datasets: datasets
	};

	var canvas = document.getElementById("myChart2");
	var myChart = new Chart(canvas, {
		type: 'bar',
		data: barCharData,
		options: {
			plugins: {
				legend: {
					display: true,
					labels: { fontSize: 13, fontFamily: 'NanumGothic', fontColor: '#000', fontStyle: 'bold' }
				},
				tooltip: {
					titleFontFamily: 'NanumGothic',
					callbacks: {
						label: function (context) {
							//	        			var label = data.datasets[tooltipItem.datasetIndex].label || '';
							var label = ' ';

							//	        			label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + "건 (" + data.datasets[tooltipItem.datasetIndex]['progress'][tooltipItem['index']] + "% )";
							label += context.formattedValue + "건 (" + context.dataset.progress[context.dataIndex] + "% )";

							return label;
						}
					}
				}
				/** 그래프 위에 글씨 보이게 하려면 아래 주석 사용하면 됨 **/
				//	          hover: {
				//	               animationDuration: 0
				//	           },
				//	          animation : {
				//	             onComplete : function(){
				//
				//	                  var chartInstance  = this.chart;
				//	                  ctx = chartInstance .ctx;
				//	                  ctx.font = "bold 13px NanumGothic";
				//	                  ctx.textAlign = "center";
				//	                  ctx.textBaseline = "bottom";
				//
				//	                   this.data.datasets.forEach(function (dataset, i) {
				//	                       var meta = chartInstance.controller.getDatasetMeta(i);
				//	                       meta.data.forEach(function (bar, index) {
				//	                           var data = dataset.data[index] + '건';
				//	                           var data2 = dataset.progress[index] + '%';
				//	                           ctx.fillText(data + " (" + data2 + ")", bar._model.x, bar._model.y - 5);
				//	                       });
				//	                   });
				//	                
				//	             }
				//	          }
			}
		}
	})
}

function excelDown() {
	var url = CONTEXT_PATH + "/stat/excelInspectorList.do";

	var data = new Object();
	data.projCd = $("#projCdSelect").prop("selected", true).val();
	data.userId = $("#userId").val();
	data.userNm = $("#userNm").val();

	$(".loading-image").show();

	$.fileDownload(url, {
		httpMethod: "POST",
		data: data,
		successCallback: function (url) {
			$(".loading-image").hide();
		},
		failCallback: function (responseHtml, url, error) {
			$(".loading-image").hide();
		}
	});
}


