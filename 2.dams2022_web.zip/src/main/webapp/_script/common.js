// ------------------------------------------------------------
// Loading Modal
// ------------------------------------------------------------
function showLoading() {
    $("#loading_modal_div").show();
}

function hideLoading() {
    setTimeout(() => {
        $("#loading_modal_div").hide();
    }, 0);
}

// ------------------------------------------------------------
// BASE
// ------------------------------------------------------------

// 현재 메뉴 표시.
$(function() {
    const _url = new URL(location.href);
    const _path = _url.pathname;

    const _target = $("#gnb a[href='"+_path+"']");
    _target.addClass("checked");

    if (_target.hasClass("two_dep")) {
        const _oneDep = _target.parents("li").find(".one_dep");
        _oneDep.addClass("checked");
    }

    const _target2 = $("#gnb_side_nav a[href='"+_path+"']");
    _target2.addClass("checked");
    
});



// 10초마다 세션 체크.
// $(function() {
//     setInterval(() => {
//         loginSessionCheck();
//     }, 10000);
// });
function loginSessionCheck() {
    $.ajax({
        type: "post",
        url: CONTEXT_PATH + "/loginSessionCheck.do",
        data: "data",
        dataType: "json",
        success: function (response) {
            if (response.result) {
                // pass
            } else {
                alert("세션이 만료되었습니다.");
                location.href = CONTEXT_PATH + "/logout.do";
            }
        }
    });
}

// Click :: 사이드 메뉴 바
$(function() {
    $(".gnb_side_open_button").click(function() {
        $("#gnb_side_back").fadeIn(200);
        $("#gnb_side_div").css("right", "0");
    });
    $(".gnb_side_close_button").click(function() {
        $("#gnb_side_back").fadeOut(200);
        $("#gnb_side_div").css("right", "-280px");
    });

    // gnb_side_back 선택시 gnb_side 닫기.
    $("#gnb_side_back").click(function() {
        $("#gnb_side_back").fadeOut(200);
        $("#gnb_side_div").css("right", "-280px");
    })

    // 일단 보류 필요 없을거 같기는 한데..
    $("#one_dep").click(function() {
        $(this).find(".two_dep_div").show();
    });
});

// ------------------------------------------------------------
// 2022-09-06
// projCdSharing : 각 페이지 넘길때마다 프로젝트콤보박스(projCdSelect박스) 값 유지하기 위한 기능.
// ------------------------------------------------------------
/**
 * 페이지마다 공유되는 프로젝트코드 쿠키세팅.
 * @param {string} projCd
 */
function setProjCdSharingCookie(projCd) {
    Cookies.set("projCdSharing", projCd, {path: CONTEXT_PATH});
}


/**
 * 페이지마다 공유되는 프로젝트코드 쿠키 가져오기.
 * @returns {string}
 */
function getProjCdSharingCookie() {
    return Cookies.get("projCdSharing", {path: CONTEXT_PATH});
}


/**
 * 페이지마다 공유되는 프로젝트코드 쿠키 제거.
 */
function removeProjCdSharingCookie() {
    Cookie.remove("projCdSharing");
}


/**
 * 프로젝트코드 배열을 넣어 있으면 프로젝트코드 반환 없으면 null 반환.
 * @param {Object} projCdArr 
 * @returns {String | null} projCd | null
 */
function getProjCdSharingIncludedInArr(projCdArr) {
    const projCdSharing = getProjCdSharingCookie();
    const index = projCdArr.indexOf(projCdSharing);
    return index > -1 ? arr[index] : null;
}


/**
 * 프로젝트 코드 이벤트 부여.
 * @param {String} element 
 * @param {String} event 
 * @param {Function} projCdCallback
 */
function setProjCdSharingEvent(element, event, projCdCallback) {
    $(element).on(event, function () {
        setProjCdSharingCookie(projCdCallback());
    });
}



// test
const projCdSharingObj = {
    /**
     * 페이지마다 공유되는 프로젝트코드 쿠키세팅.
     * @param {string} projCd
     */
    setCookie: function (projCd) {
        Cookies.set("projCdSharing", projCd, {path: CONTEXT_PATH});
    }
}



// ------------------------------------------------------------
// UTIL
// ------------------------------------------------------------
function format() {
    let args = Array.prototype.slice.call(arguments, 1);
    return arguments[0].replace(/\{(\d+)\}/g, function(match, index) {
        return args[index];
    });
}

/**
 * 좌측문자열채우기
 * @params
 *  - str : 원 문자열
 *  - padLen : 최대 채우고자 하는 길이
 *  - padStr : 채우고자하는 문자(char)
 */
function lpad(str, padLen, padStr) {
    if (padStr.length > padLen) {
        console.log("오류 : 채우고자 하는 문자열이 요청 길이보다 큽니다");
        return str;
    }
    str += ""; // 문자로
    padStr += ""; // 문자로
    while (str.length < padLen)
        str = padStr + str;
    str = str.length >= padLen ? str.substring(0, padLen) : str;
    return str;
}

/**
 * 우측문자열채우기
 * @params
 *  - str : 원 문자열
 *  - padLen : 최대 채우고자 하는 길이
 *  - padStr : 채우고자하는 문자(char)
 */
function rpad(str, padLen, padStr) {
    if (padStr.length > padLen) {
        console.log("오류 : 채우고자 하는 문자열이 요청 길이보다 큽니다");
        return str + "";
    }
    str += ""; // 문자로
    padStr += ""; // 문자로
    while (str.length < padLen)
        str += padStr;
    str = str.length >= padLen ? str.substring(0, padLen) : str;
    return str;
}


/** 숫자 0 및 배열, 객체의 빈값 전부 체크 */
function isEmpty(val){
	if (val === "" || val === null || val === undefined || (val !== null && typeof val === "object" && !Object.keys(val).length)){
		return true
	} else {
		return false
	}
}

function isNotEmpty(val) {
    return !isEmpty(val);
}



