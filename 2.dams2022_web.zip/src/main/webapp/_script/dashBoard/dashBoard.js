/*
	**************************
	2022.06. 
	/dashBoard.do
	**************************
*/
$(function () {
	// 차트 숨기고 시작.
	$(".div_chart_dash").hide();

	// html 페이지에서 'rel=tooltip'이 사용된 곳에 마우스를 가져가면 
	/*$('.boxy').mouseover(function(e) 
	{
		 var tip = $(this).attr('title');         

		// 브라우져에서 제공하는 기본 툴 팁을 끈다
		$(this).attr('title','');
	    
		if($(this).attr("id") == 'boxy1'){
			tip = "*목표 수량 대비 구축 수량 백분율*";
		}else if($(this).attr("id") == 'boxy2'){
			tip = "*목표 수량 대비 등록 수량 백분율*";
		}else if($(this).attr("id") == 'boxy3'){
			tip = "*목표 수량 대비 할당 수량 백분율*";
		}else if($(this).attr("id") == 'boxy4'){
			tip = "*할당 수량 대비 진단 수량 백분율*";
		}else if($(this).attr("id") == 'boxy5'){
			tip = "*할당 수량 대비 검수 수량 백분율*";
		}else if($(this).attr("id") == 'boxy6'){
			tip = "*검수 수량 대비 PASS 수량 백분율*";
		}else {
			tip = "";
		}

		// css와 연동하기 위해 html 태그를 추가해줌
		$(this).append('<div id="tooltip"><div class="tipBody" style="color:red;">' 
					  + tip + '</div></div>');               
	}).mousemove(function(e) 
   {
		 //마우스가 움직일 때 툴 팁이 따라 다니도록 위치값 업데이트
		$('#tooltip').css('top', $(this).pageY + 15 );
		$('#tooltip').css('left', $(this).pageX + 115 );
	}).mouseout(function() 
	{
		//위에서 껐던 브라우져에서 제공하는 기본 툴 팁을 복원
		$(this).attr('title',$('.tipBody').html());
		$(this).children('div#tooltip').remove();
	});
	*/

	// $(".div_value").tooltip(); // 보류 2022-10-17
});


// 클릭이벤트 해당 프로젝트 그래프/실적도 보여주기 + 클릭위치 상단으로 이동
$('.div_progress').on('click', function () {
	$(".div_chart_dash").hide();
	$(this).siblings().show();

	var _index = $(this).parent().attr('class').substr(-1);
	fnBarChart(_index);
	wmOnChange(_index);
});


function fnTotalProgress() {
	var url = CONTEXT_PATH + "/manager/main.total.progress.do";
	var data = {
		projCd: $("[name='projCd']").val()
	}
	console.log("fnTotalProgress PARAM");
	console.log(data);

	var async = false;
	callAjax(url, data, async, function (json) {
		var row = json.rows;

		// 등록 건 수
		//		$("#plan_cnt").text(row[0].plan_cnt);
		$("#regCnt").text(row[0].regCnt);

		$("#regPercent").text(row[0].regPercent);
		$("#regAccord").text(row[0].regAccord);

		// 검수/진행 건수 - 검수자 할당 수량  / PSG 검수 일치 건 수
		$("#assnCnt").text(row[0].assnCnt);
		$("#assnPercent").text(row[0].assnPercent);
		$("#assnAni").val(row[0].assnAni);
		$("#assn").text('(' + row[0].assn + ')');

		/** PSG 이벤트 검수 OK 건 수 **/
		$("#diagWorkCnt").text(row[0].diagWorkCnt);
		$("#diagWorkPercent").text(row[0].diagWorkPercent);

		/** 과제 목표 달성율 **/
		$("#inspWorkCnt").text(row[0].inspWorkCnt);
		$("#inspWorkPercent").text(row[0].inspWorkPercent);

		/** PSG 검수 완료 건 수 **/
		$("#sameCnt").text(row[0].sameCnt);
		$("#samePercent").text(row[0].samePercent);

		/** PSG PASS 건 수 **/
		$("#passCnt").text('(' + row[0].passCnt + ')');
		$("#passPercent").text('(' + row[0].passPercent + ')');

	});

}

/** 주간/월간 선택 이벤트 **/
function wmOnChange(_index) {
	if ($("#select2" + _index).length > 0) {
		$("#select2" + _index).remove();
	}

	var select = $('#select1' + _index + ' option:selected').val();
	var html = '';
	html += "<select class='selectbox' id='select2" + _index + "' onchange='weekOnChange(_index)' style='width:100px'>";
	html += "<option value='2022'>2022 년도</option>";
	html += "</select>";
	$("#select_span" + _index).append(html);

	if (select == '') {
		$("#select2" + _index).remove();
	}

	fnLineChart(_index);
}

/** 주간 월별 및 월간 년도별 선택 이벤트 **/
function weekOnChange(_index) {
	fnLineChart(_index);
}

function fnLineChart(_index) {

	var labels = [];
	var psgCnt = [];
	var workCnt = [];
	var passCnt = [];
	var max = 0;
	var jsondata = {
		projCd: $('#projCd' + _index).val(),
		wmVal: $('#select2' + _index + ' option:selected').val(),
		wm: $('#select1' + _index + ' option:selected').val() == 'month' ? 'M' : 'W' // month 일때 M 나머지 W (week) 기본값.
	}

	$.ajax({
		url: CONTEXT_PATH + "/dashBoard/getMonthChartData.do",
		type: "post",
		dataType: "json",
		data: jsondata,
		async: false
	}).done(function (data) {
		var rows = data.rows;
		for (i in rows) {
			labels.push(rows[i].Month + '월');
			psgCnt.push(rows[i].regCnt);
			workCnt.push(rows[i].workCnt);
			passCnt.push(rows[i].passCnt);
		}

		max = Math.max.apply(null, workCnt.map(Number));
		if (max < 100) {
			max = 100;
		}

	})

	$("#chart1" + _index).remove();

	//	var _chartId = 'chart1'+_index;
	var appendStr = '<canvas id=\"chart1' + _index + '\"></canvas>';

	$("#div_chart1" + _index).html(appendStr);
	var ctx = document.getElementById("chart1" + _index).getContext("2d");
	var gradientStroke = ctx.createLinearGradient(100, 0, 800, 0);
	gradientStroke.addColorStop(0, '#80b6f4');
	gradientStroke.addColorStop(0.5, '#f7e28f');
	gradientStroke.addColorStop(1, '#e27a6e');

	const data = {
		labels: labels,
		datasets: [
			{
				label: '등록 건 수',
				data: psgCnt,
				borderColor: "rgba(255, 205, 86,1)",
				backgroundColor: "rgba(255, 205, 86,1)",
				fill: false,
				borderWidth: 2,
				tension: 0
			},
			{
				label: '검수 완료 건 수',
				data: workCnt,
				borderColor: "rgba(255, 99, 132,1)",
				backgroundColor: "rgba(255, 99, 132,1)",
				fill: false,
				borderWidth: 2,
				tension: 0
			},
			{
				label: 'PASS 건 수',
				data: passCnt,
				borderColor: "rgba(54, 162, 235,1)",
				backgroundColor: "rgba(54, 162, 235,1)",
				fill: false,
				borderWidth: 2,
				tension: 0
			}

		]
	}

	const config = {
		type: 'bar',
		data: data,
		options: {
			legend: {
				labels: {
					fontFamily: 'NanumGothic',
					fontColor: '#000',
					fontStyle: 'bold'
				}
			},
			//			scales: {
			//				yAxes: [{
			//					ticks:{
			//                        beginAtZero: true,
			//                        responsive: true,
			//                        maintainAspectRatio: true,
			////                        steps: 5,
			//                        max: max
			//					}
			//				}]
			//			},
			tooltips: {
				titleFontFamily: 'NanumGothic',
				callbacks: {
					label: function (tooltipItem, data) {
						var label = data.datasets[tooltipItem.datasetIndex].label || '';
						if (label) {
							label += ' : ';
						}
						label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
						return label;
					}
				}
			}
		}
	}

	var chart = new Chart(ctx, config);

}


function fnBarChart(_index) {
	var labels = [];
	var assnCnt = [];
	var diagWorkCnt = [];
	var inspWorkCnt = [];
	var max = 0;
	var jsondata = new Object();

	jsondata.projCd = $(".projCd")[_index].value;

	$.ajax({
		url: CONTEXT_PATH + "/dashBoard/main.user.chart.do",
		type: "post",
		dataType: "json",
		data: jsondata,
		async: false,
	}).done(function (data) {
		var rows = data.lineList;

		for (var i = 0; i < rows.length; i++) {
			labels.push(rows[i].userNm);
			assnCnt.push(rows[i].assnCnt);
			diagWorkCnt.push(rows[i].diagWorkCnt);
			inspWorkCnt.push(rows[i].inspWorkCnt);
		}

		max = Math.max.apply(null, assnCnt.map(Number));
		if (max < 10) {
			max = 10;
		}

	}).fail(function (request, status, error) {
		console.log(request, status, error);
		alert("error, 관리자에게 문의바람.");
	});


	$("#chart2" + _index).remove();
	//	$(".chart2").remove();

	var appendStr = '<canvas id=\"chart2' + _index + '\"></canvas>';
	//	var _chartId = 'chart2'+_index;

	$("#div_chart2" + _index).html(appendStr);
	//	$(".div_chart2").append('<canvas id="chart2" class="chart2"></canvas>');
	//	$(".div_chart2").append('<canvas id="chart2" ></canvas>');

	var ctx = document.getElementById("chart2" + _index).getContext("2d");
	//	var ctx = document.getElementsByClassName("chart2").getContext("2d");

	const data = {
		labels: labels,
		datasets: [
			{
				label: '할당건 수',
				data: assnCnt,
				borderColor: 'rgba(255, 255, 255, 1)',
				backgroundColor: 'rgba(75, 192, 192, 1)',
				borderWidth: 2,
				tension: 0
				, stack: 'Stack 0'
			},
			{
				label: '진단 완료건 수',
				data: diagWorkCnt,
				borderColor: 'rgba(255, 255, 255, 1)',
				backgroundColor: 'rgba(54, 162, 235, 1)',
				borderWidth: 2,
				tension: 0
				, stack: 'Stack 1'
			},
			{
				label: '검수 완료건 수',
				data: inspWorkCnt,
				borderColor: 'rgba(255, 255, 255, 1)',
				backgroundColor: 'rgba(255, 159, 64, 1)',
				borderWidth: 2,
				tension: 0
				, stack: 'Stack 1'
			}

		]
	}

	const config = {
		type: 'bar',
		data: data,
		options: {
			legend: {
				labels: {
					fontFamily: 'NanumGothic',
					fontColor: '#000',
					fontStyle: 'bold'
				}
			},
			//			scales: {
			//				yAxes: [{
			//					ticks:{
			//                        beginAtZero: true,
			//                        responsive: true,
			//                        maintainAspectRatio: true,
			////                        steps: 5,
			//                        max: max
			//					}
			//				}]
			//			},
			tooltips: {
				titleFontFamily: 'NanumGothic',
				callbacks: {
					label: function (tooltipItem, data) {
						var label = data.datasets[tooltipItem.datasetIndex].label || '';
						if (label) {
							label += ' : ';
						}
						label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
						return label;
					}
				}
			}
		}
	}

	//	chart.draw(ctx, config);
	var chart = new Chart(ctx, config);

	//	$(".boxy").css("height" , height*2);

}
