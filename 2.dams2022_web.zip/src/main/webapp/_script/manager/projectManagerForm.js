/*
	**************************
	2022.05
	프로젝트 등록 폼
	**************************
*/

$(function () {
	if ($("#updateYn_Hid").val() == 'Y') {
		var projCd = $("#projCd").val();
		// fnReadLabel(projCd);
	}

	$("#projCd").on("change", function () {
		for (var i = 0; i < $(".label_clone").find(".lblCd").length; i++) {
			//			$(".label_clone").find(".lblCd").find(".input_text").val();

			//			if( $("#projCd").val() != $(".projCd").find(".input_text")[i].value ){
			$(".projCd").find(".input_text")[i].value = $("#projCd").val();
			//			}

		}
	});
})

function fnReadLabel(projCd) {
	var url = CONTEXT_PATH + "/manager/project/getLabelList.do";
	var data = new Object();
	data.projCd = projCd;

	var async = false;
	callAjax(url, data, async, function (json) {

		createTableRow("projectLabelTable", json);
	});
}

/** 라벨 추가폼 */
function addLabel(obj) {
	$(obj).closest("tr").clone(true).appendTo("#projectLabelTableBody");
}

/** 라벨 추가폼 삭제 */
function remove(obj) {
	$(obj).closest("tr").remove();
}

/** 라벨 한줄 추가 */
function addLabelRow() {
	var reg_userNm = $("#regUserNm").val();
	var projCd = $("#projCd").val();
	if (projCd == '') {
		alert("프로젝트 코드를 먼저 입력해주세요");
		return false;
	}
	var trCnt = $("#projectLabelTableBody tr").length;

	var date = new Date();
	var today = date.getFullYear() + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + ("0" + (date.getDate())).slice(-2);

	var html = "";
	html += '<tr class="label_clone" index="' + trCnt + '">';
	html += '<td><button class="" ></button></td>';
	html += '<td class="projCd"><input type="text" class="input_text" value="' + projCd + '" readOnly/></td>';
	html += '<td class="lblCd""><input type="text" class="input_text" /></td>';
	html += '<td class="lblDisp""><input type="text" class="input_text" /></td>';
	html += '<td class="lblNm""><input type="text" class="input_text" /></td>';
	html += '<td><select name="useYn" class="useYn" style="text-align:center;"><option value="N" ${useYn ne "Y" ? "selected" : ""} >N</option>';
	html += '<option value="Y" ${useYn eq "Y" ? "selected" : ""} selected >Y</option></select></td>';
	html += '<td class="dispSeq""><input type="text" class="input_text" /></td>';
	html += '<td style="display:none;">' + today + '</td>';
	html += '<td style="display:none;" class="reg_user">' + reg_userNm + '</td>';
	html += '<td><button class="remove_user" onclick="remove(this);"></button></td>';
	html += '</tr>';

	$("#projectLabelTableBody").append(html);
}

/** 데이터 검증 */
function validation(updateYn) {
	if (updateYn != 'Y') { // 등록일때만.
		if ($("#projCd").val() == "") {
			alert("프로젝트 코드은 필수 입력 사항입니다.");
			$("#projCd").focus();
			return false;
		}
	}

	if ($("#projNm").val() == "") {
		alert("프로젝트명은 필수 입력 사항입니다.");
		$("#projNm").focus();
		return false;
	}

	if ($("#useYn").val() == "") {
		alert("데이터 디렉토리는 필수 입력 사항입니다.");
		$("#useYn").focus();
		return false;
	}

	// 목표 데이터 수량은 필수 아님 NULL 가능(DB)
	// if ($("#planDsetQty").val() == "") {
	// 	alert("목표 데이터 수량은 필수 입력 사항입니다.");
	// 	$("#planDsetQty").focus();
	// 	return false;
	// }

	if ($("#projBegYmd").val() == "") {
		alert("시작일자는 필수 입력 사항입니다.");
		$("#projBegYmd").focus();
		return false;
	}

	if ($("#projEndYmd").val() == "") {
		alert("종료일자는 필수 입력 사항입니다.");
		$("#projEndYmd").focus();
		return false;
	}

	if ($("#projEndYmd").val().replaceAll("-", "") < $("#projBegYmd").val().replaceAll("-", "")) {
		alert("종료일자는 시작일자보다 늦어야 합니다.");
		$("#projEndYmd").focus();
		return false;
	}

	return true;
}

/** 프로젝트 등록 */
function fnSaveData() {
	// valid 1.
	var bool = validation('');
	if (!bool) {
		return false;
	}

	var JsonObject = new Object();
	JsonObject.projCd = $("#projCd").val();
	JsonObject.projNm = $("#projNm").val();
	JsonObject.useYn = $("#useYn").val();
	JsonObject.weekRepoStdDayw = $("#weekRepoStdDayw").val();
	JsonObject.planDsetQty = $("#planDsetQty").val();
	JsonObject.projBegYmd = $("#projBegYmd").val().replace(/\-/g, '');
	JsonObject.projEndYmd = $("#projEndYmd").val().replace(/\-/g, '');
	JsonObject.regId = $("#regId").val();
	JsonObject.regDt = $("regDt").val();

	var user_tr = $(".label_clone").length;
	var lblCds = [];
	var lblNms = [];
	var lblDisps = [];
	var lblUseYns = [];
	var dispSeqs = [];
	for (var j = 0; j < user_tr; j++) {
		lblCds.push($(".lblCd").find(".input_text")[j].value.replace(/ /gi, ""));
		lblNms.push($(".lblNm").find(".input_text")[j].value.replace(/ /gi, ""));
		lblDisps.push($(".lblDisp").find(".input_text")[j].value.replace(/ /gi, ""));
		lblUseYns.push($(".useYn").prop("selected", true)[j].value.replace(/ /gi, ""));
		dispSeqs.push($(".dispSeq").find(".input_text")[j].value.replace(/ /gi, ""));
	}

	JsonObject.lblCds = JSON.stringify(lblCds);
	JsonObject.lblNms = JSON.stringify(lblNms);
	JsonObject.lblDisps = JSON.stringify(lblDisps);
	JsonObject.lblUseYns = JSON.stringify(lblUseYns);
	JsonObject.lblDispSeqs = JSON.stringify(dispSeqs);

	$.ajax({
		url: CONTEXT_PATH + "/manager/project/registProject.do",
		type: "POST",
		async: false,
		dataType: "json",
		data: JsonObject
	}).done(function (response) {
		console.log("registProject RESPONSE");
		console.log(response)

		var msg = response.msg;
		var code = response.code;
		if (code == 0) {
			alert(msg);

			opener.parent.location.reload();
			self.close();
		} else {
			alert(msg);
		}
	}).fail(function (jqXHR, textStatus, errorThrown) {
		var msg = "처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		alert(msg);
	});
}

/** 프로젝트 수정 */
function fnUpdateData(updateYn) {
	// valid
	var bool = validation(updateYn);
	if (!bool) {
		return false;
	}

	var JsonObject = new Object();

	JsonObject.projCd = $("#projCd").val();
	JsonObject.projNm = $("#projNm").val();
	JsonObject.useYn = $(".useYn option:selected").val();
	JsonObject.weekRepoStdDayw = $("#weekRepoStdDayw").val();
	JsonObject.planDsetQty = $("#planDsetQty").val();
	JsonObject.projBegYmd = $("#projBegYmd").val().replace(/\-/g, '');
	JsonObject.projEndYmd = $("#projEndYmd").val().replace(/\-/g, '');
	JsonObject.regId = $("#reg_user_id").val();

	var user_tr = $(".label_clone").length;

	var lblCds = [];
	var lblNms = [];
	var lblDisps = [];
	var lblUseYns = [];
	var dispSeqs = [];
	for (var j = 0; j < user_tr; j++) {
		lblCds.push($(".lblCd").find(".input_text")[j].value.replace(/ /gi, ""));
		lblNms.push($(".lblNm").find(".input_text")[j].value.replace(/ /gi, ""));
		lblDisps.push($(".lblDisp").find(".input_text")[j].value.replace(/ /gi, ""));
		lblUseYns.push($(".useYn").prop("selected", true)[j].value.replace(/ /gi, ""));
		dispSeqs.push($(".dispSeq").find(".input_text")[j].value.replace(/ /gi, ""));
	}

	JsonObject.lblCds = JSON.stringify(lblCds);
	JsonObject.lblNms = JSON.stringify(lblNms);
	JsonObject.lblDisps = JSON.stringify(lblDisps);
	JsonObject.lblUseYns = JSON.stringify(lblUseYns);
	JsonObject.lblDispSeqs = JSON.stringify(dispSeqs);

	$.ajax({
		url: CONTEXT_PATH + "/manager/project/modifyProject.do",
		type: "POST",
		async: false,
		dataType: "json",
		data: JsonObject
	}).done(function (response) {
		console.log("modifyProject RESPONSE");
		console.log(response)

		var msg = response.msg;
		var code = response.code;
		if (code == 0) {
			alert(msg);

			opener.parent.location.reload();
			self.close();
		} else {
			alert(msg);
		}

		self.close();
	}).fail(function (jqXHR, textStatus, errorThrown) {
		var msg = "처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		alert(msg);
	});
}

/** 프로젝트 삭제 */
function fnDeleteData() {
	// valid 1. 
	var user_tr = $(".label_clone").length;
	if (user_tr > 0) {
		alert("등록된 라벨을 삭제한 후 다시 시도해 주세요.");
		return false;
	}

	// 삭제여부 다시 묻기
	if (confirm("정말 삭제하시겠습니까?")) {
		const sendData = {
			projCd: $("#projCd").val(),
		}

		$.ajax({
			type: "POST",
			url: CONTEXT_PATH + "/manager/project/removeProject.do",
			data: sendData,
			dataType: "json",
			async: false,
		}).done(function (response) {
			console.log("modfiyProject RESPONSE");
			console.log(response)

			var msg = response.msg;
			var code = response.code;
			if (code == 0) {
				alert(msg);

				opener.parent.location.reload();
				self.close();
			} else {
				alert(msg);
			}
		}).fail(function (jqXHR, textStatus, errorThrown) {
			var msg = "처리에 실패 하였습니다.";
			msg += "\n관리자에게 문의 하세요.";
			alert(msg);
		});
	}
}

