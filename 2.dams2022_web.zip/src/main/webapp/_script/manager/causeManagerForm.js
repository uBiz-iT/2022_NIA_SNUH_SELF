/*
	**************************
	2022.05
	유저 등록 폼
	**************************
*/

$(function () {
	// 부모페이지에서 선택한 프로젝트 가져옴.
	const openerProjCd = $(opener.document.querySelector("#projNmHid")).val()
	const openerProjNm = $(opener.document.querySelector("#projNmHid > [value='" + openerProjCd + "']")).text();
	$("#projCdChange").val(openerProjCd);
	$("#projNmChange").val(openerProjNm);

});

function fnReadProject(failCausCd) {
	var url = CONTEXT_PATH + "/manager/causeProject.read.do";
	var data = {
		failCausCd: failCausCd
	}
	var async = false;
	callAjax(url, data, async, function (json) {
		createTableRow("userProjectTable", json);
	});
}

function popupProject(v, i) {
	var url = CONTEXT_PATH + "/manager/project.popup.do"
	if (v == 0) {
		url += "?manager=Y&index=" + i;
	} else if (v == 1) {
		url += "?manager=N&index=" + i;
	}

	openPopup(url, "700", "500", "POPUP_USER_SEARCH", "yes", "yes", "");

}

function addManager(obj) {
	$(obj).closest("tr").clone(true).appendTo("#userManagerTableBody");
}

function addProject(obj) {
	$(obj).closest("tr").clone(true).appendTo("#userProjectTableBody");
}

function remove(obj) {
	var projCdVal = $('.remove_user').parent().parent()[0].querySelector('.projCd').querySelector('input').value;
	var userIdVal = $('.remove_user').parent().parent()[0].querySelector('.userId').querySelector('input').value;
	alert("validation Chk : " + projCdVal + " START");

	var url = CONTEXT_PATH + "/manager/user.project.validation.do";

	var data = new Object();

	
	var async = false;
	
	var JsonObject = new Object();
	JsonObject.projCd = projCdVal;
	JsonObject.userId = projCdVal;

	callAjax(url, data, async, function (json) {
		var row = json.rows;

		$("#psg_cnt").text(row[0].psg_cnt);
	});

	alert("validation Chk : " + projCdVal + " END");

	$(obj).closest("tr").remove();
}

/*
function addManagerRow(){

	var reg_userNm  = $("#regUserNm").val();
	
	var date = new Date();
	var today = date.getFullYear() + "-" + ("0"+(date.getMonth()+1)).slice(-2) + "-" + ("0"+(date.getDate())).slice(-2);
	
	var trCnt = $("#userManagerTableBody tr").length;
	
	var html = "";
	
	html += '<tr class="manager_clone" index="'+trCnt+'">';
	html += '<td><button class="add_manager" onclick="addManager(this);"></button></td>';
	html += '<td class="manager_id"><input type="text" class="input_text" onclick="popupProject(0, '+trCnt+')" readOnly/></td>';
	html += '<td class="manager_name"><input type="text" class="input_text" readOnly/></td>';
	html += '<td>'+today+'</td>';
	html += '<td class="reg_user">'+reg_userNm+'</td>';
	html += '<td class="manager_expt"><select name="is_expt" class="is_expt"><option value="N">N</option><option value="Y">Y</option></select></td>';
	html += '<td><button class="remove_manager" onclick="remove(this);"></button></td>';
	html += '</tr>';

	$("#userManagerTableBody").append(html);
	
}
*/

function addProjectRow() {
	var reg_userNm = $("#regUserNm").val();

	var date = new Date();
	var today = date.getFullYear() + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + ("0" + (date.getDate())).slice(-2);

	var trCnt = $("#userProjectTableBody tr").length;

	var html = "";
	html += '<tr class="project_clone" index="' + trCnt + '">';
	html += '<td><button class="" onclick="addProject(this);"></button></td>';
	html += '<td class="projCd"><input type="text" class="input_text" onclick="popupProject(1, ' + trCnt + ')" readOnly/></td>';
	html += '<td class="projNm""><input type="text" class="input_text" readOnly/></td>';
	html += '<td>' + today + '</td>';
	html += '<td class="reg_user">' + reg_userNm + '</td>';
	html += '<td><button class="remove_user" onclick="remove(this);"></button></td>';
	html += '</tr>';

	$("#userProjectTableBody").append(html);
}

function fnSaveData() {
	var bool = validation('');
	if (!bool) {
		return false;
	}

	var user_array = new Array();
	var JsonObject = new Object();

	if ($("#projCdChange").val() == null) {
		JsonObject.projCd = $("#projCd").val();
	} else {
		JsonObject.projCd = $("#projCdChange").val();
	}
	JsonObject.failCausCd = $("#failCausCd").val();
	JsonObject.failCausNm = $("#failCausNm").val();
	JsonObject.diagInspFg = $("#diagInspFg option:selected").val();
	JsonObject.dispSeq = $("#dispSeq").val();
	JsonObject.useYn = $("#useYn option:selected").val();
	JsonObject.regId = $("#regUserNm").val();

	$.ajax({
		url: CONTEXT_PATH + "/manager/cause/registCause.do",
		type: "POST",
		async: false,
		dataType: "json",
		data: JsonObject
	})
		.done(function (data) {

			var msg = data.p_ret_msg;
			var code = data.p_ret_code;

			if (code == 0) {
				alert(msg);
			} else {
				alert(msg);
				return false;
			}

			opener.parent.location.reload();
			self.close();

		})
		.fail(function (jqXHR, textStatus, errorThrown) {
			var msg = "처리에 실패 하였습니다.";
			msg += "\n관리자에게 문의 하세요.";

			//		alert(msg);
		});

	//	alert("Fail Cause 등록이 완료되었습니다.");
	opener.parent.location.reload();
	self.close();
}


function fnUpdateData(updateYn) {
	//	var msg = confirm("현재 검수 작업 중인 검수자를 삭제할 경우\n작업이 중지되오니 반드시 확인 후 변경해주세요!");
	var msg = "";
	//	if(msg){
	var bool = validation(updateYn);

	if (!bool) {
		return false;
	}

	var user_array = new Array();
	var JsonObject = new Object();

	if ($("#projCdChange").val() == null) {
		JsonObject.projCd = $("#projCd").val();
	} else {
		JsonObject.projCd = $("#projCdChange").val();
	}
	JsonObject.failCausCd = $("#failCausCd").val();
	JsonObject.failCausNm = $("#failCausNm").val();
	JsonObject.diagInspFg = $("#diagInspFg option:selected").val();
	JsonObject.dispSeq = $("#dispSeq").val();
	JsonObject.useYn = $("#useYn option:selected").val();
	JsonObject.regId = $("#regUserNm").val();

	$.ajax({
		url: CONTEXT_PATH + "/manager/cause/modifyCause.do",
		type: "POST",
		async: false,
		dataType: "json",
		data: JsonObject
	})
		.done(function (data) {
			var msg = "정상적으로 수정되었습니다.";

			var msg = data.p_ret_msg;
			var code = data.p_ret_code;

			if (code == 0) {
				alert(msg);
			} else {
				alert(msg);
				return false;
			}

			self.close();
		})
		.fail(function (jqXHR, textStatus, errorThrown) {
			var msg = "처리에 실패 하였습니다.";
			msg += "\n관리자에게 문의 하세요.";

			//			alert(msg);
		});

	//		alert("Fail Cause 업데이트가 완료되었습니다.");
	opener.parent.location.reload();
	self.close();
	//	}else{
	//	    return false;
	//	}

}


function fnDeleteData() {
	var JsonObject = new Object();
	var projCdValid = '';

	if ($("#projCdChange").val() == null) {
		JsonObject.projCd = $("#projCd").val();
		projCdValid = $("#projCd").val();
	} else {
		JsonObject.projCd = $("#projCdChange").val();
		projCdValid = $("#projCdChange").val();
	}
	JsonObject.failCausCd = $("#failCausCd").val();

	if (projCdValid == null) {
		alert("Fail Cause 삭제에 실패하였습니다.");
		return false;
	}

	// 등록된 프로젝트가 있을경우 삭제 못하게 막음
	//	if( $(".project_clone").length > 0){
	//		alert("등록된 프로젝트가 있어 삭제할 수 없습니다. 프로젝트를 삭제하여 수정한 후 다시 시도해주세요. ");
	//		return false;
	//	}

	if (confirm("정말 삭제하시겠습니까?")) {
		//	if(confirm("현재 검수 작업 중인 검수자를 삭제할 경우\n작업이 중지되오니 반드시 체크한 후 삭제해주세요!")){

		$.ajax({
			url: "cause/removeCause.do",
			type: "POST",
			async: false,
			dataType: "json",
			data: JsonObject
		})
			.done(function (data) {

				var msg = data.p_ret_msg;
				var code = data.p_ret_code;

				if (code == 0) {
					//				alert(msg);
				} else {
					//				alert(msg);
					//				return false;
				}

				opener.parent.location.reload();
				self.close();
			})
			.fail(function (jqXHR, textStatus, errorThrown) {
				var msg = "처리에 실패 하였습니다.";
				msg += "\n관리자에게 문의 하세요.";

				//			alert(msg);
			});

	} else {
		return false;
	}

	alert("Fail Cause 삭제가 완료되었습니다.");
}

function validation(updateYn) {
	if (updateYn != 'Y') {
		if ($("#userId").val() == "") {
			alert("유저 코드은 필수 입력 사항입니다.");
			$("#userId").focus();
			return false;
		}
	}

	if ($("#userNm").val() == "") {
		alert("유저명은 필수 입력 사항입니다.");
		$("#userNm").focus();
		return false;
	}

	if ($("#useYn").val() == "") {
		alert("데이터 디렉토리는 필수 입력 사항입니다.");
		$("#useYn").focus();
		return false;
	}

	return true;
}

