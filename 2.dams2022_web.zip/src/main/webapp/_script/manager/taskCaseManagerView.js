/*
	**************************
	2022.05
	유저 관리 뷰
	**************************
*/

$(document).ready(function() {
	
});

$(function(){
	
	var viewObj = new Object();
	var projCd = $("#projCd").val();
	var taskCd = $("#taskCd").val();
	var caseNo = $("#caseNo").val();
	viewObj.projCd = projCd;
	viewObj.taskCd = taskCd;
	viewObj.caseNo = caseNo;
	
	
	fnReadProject(viewObj);
})

function fnReadProject(viewObj){

	var url = CONTEXT_PATH + "/manager/taskCase.read.do";
	var data = new Object();
	data.projCd = viewObj.projCd;
	data.taskCd = viewObj.taskCd;
	data.caseNo = viewObj.caseNo;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRow("caseTaskTable", json);
	});
	
}

function fnUpdateData(){
	
	var projCd = $("#projCd").val();
	var taskCd = $("#taskCd").val();
	var caseNo = $("#caseNo").val();
	
	if(caseNo == ""){
		alert("태스크케이스 조회에 실패하였습니다.");
		return false;
	}
	
	self.close();
	
//	var url = "/MLA_VIDEO";
//	var url = "/DAMS_SNUH_2022";
	var url = "";
	url += CONTEXT_PATH + "/manager/taskCase.update.form.do"
	url += "?projCd=" + projCd + "&&taskCd="+taskCd + "&&caseNo="+caseNo + "&updateYn=Y";
	
	openPopup(url, "1024", "500", "POPUP_USER_WRITE", "yes", "yes", "");
	
}


function fnDeleteData(){
	
	var JsonObject = new Object();
	
	JsonObject.projCd = $("#projCd").val();
	JsonObject.taskCd = $("#taskCd").val();
	JsonObject.caseNo = $("#caseNo").val();
	
	if(caseNo == ""){
		alert("태스크케이스 삭제에 실패하였습니다.");
		return false;
	}

	// 삭제여부 다시 묻기
	
	if(confirm("정말 삭제하시겠습니까?")){
//	if(confirm("현재 검수 작업 중인 검수자를 삭제할 경우\n작업이 중지되오니 반드시 체크한 후 삭제해주세요!")){
		
		$.ajax({
			url : "taskCase.delete.do",
			type :"POST",
			async : false,
			dataType : "json",
			data : JsonObject
		})
		.done(function(data){
			
			var msg = data.p_ret_msg;
			var code = data.p_ret_code;
			
			if(code == 0){
//				alert(msg);
			}else{
//				alert(msg);
//				return false;
			}
			
			opener.parent.location.reload();
			self.close();
		})
		.fail(function(jqXHR, textStatus, errorThrown){
			var msg="처리에 실패 하였습니다.";
			msg += "\n관리자에게 문의 하세요.";
			
//			alert(msg);
		});
		
	}else{
		return false;
	}
}
