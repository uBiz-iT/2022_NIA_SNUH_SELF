
$(function () {
	$(".input_text").keydown(function (key) {
		if (key.keyCode == 13) {
			$("#search").click();
		}
	});

	setProjectList();
	setCauseList();

});

/** 검색버튼 이벤트 */
$("#search").parent().click(function () {
	setCauseList();
});

/** 원인 수정 팝업 */
function popupView(val1, val2, val3, val4, val5, val6) {
	var url = CONTEXT_PATH + "/manager/cause/modifyForm.do"
	url += "?projCd=" + val1 + "&failCausCd=" + val2 + "&failCausNm=" + val3 + "&diagInspFg=" + val4 + "&useYn=" + val5 + "&dispSeq=" + val6;
	openPopup(url, "1024", "500", "POPUP_USER_VIEW", "yes", "yes", "");
}

/** 원인 등록 팝업 */
function causeAdd() {
	var url = CONTEXT_PATH + "/manager/cause/registForm.do";
	openPopup(url, "1024", "500", "POPUP_USER_WRITE", "yes", "yes", "");
}

/** 프로젝트 SELECT 박스 */
function setProjectList() {
	var url = CONTEXT_PATH + "/work/crossValidation/getProjectList.do";
	var async = false;
	callAjax(url, null, async, function (json) {
		console.log("setProjectList RESPONSE");
		console.log(json);
		
		var rows = json.projectList;

		var html = "";
		html += "<tr><td><select name='projCdSelect' id='projCdSelect' class='projCdSelect' onchange='selectProject()'> ";
		for (i in rows) {
			const projCdSharing = getProjCdSharingCookie();
			if (rows[i].projCd == projCdSharing) {
			   html += "<option value='" + rows[i].projCd + "' style='font-size:16px;' selected>" + rows[i].projNm + "</option>";
			} else {
			   html += "<option value='" + rows[i].projCd + "' style='font-size:16px;'>" + rows[i].projNm + "</option>";
			}
		 }
		 html += " </select></td></tr>"
		 $("#tb_project2").html(html);
   
		 $("#projCdSelect").on("change", function () {
			setProjCdSharingCookie($("#projCdSelect").val());
		 });
	});
}

// 프로젝트 코드/명 선택
function selectProject() {
	// $("#projNmParam").val($("#projCdSelect").val());

	// var projCd = $(obj).prop("selected", true).val();

	// $("#projCd").val($(obj).prop("selected", true).val());

	setCauseList();
	// $("#search").click();
}

/** 테이블 데이터 */
function setCauseList() {
	const data = {
		projCd: $("#projCdSelect").val()
	}

	if (data.projCd != '') {
		$("#projCd_hide").val(data.projCd);
		$("#projCd").val(data.projCd);
	} else {
		$("#projCd_hide").val($('#projCd').val());
	}

	//	$("#projCd_hide").val($("#projCd").val());
	$("#failCausCd_hide").val($("#failCausCd").val());
	$("#failCausNm_hide").val($('#failCausNm').val());

    $.jgrid.gridUnload("grid"); // 필수
	$("#grid").jqGrid({
		url: CONTEXT_PATH + '/manager/cause/getCauseList.do',
		mtype: "POST",
		datatype: 'json',
		jsonReader: {
			root: "causeList"
			//	    	records : "pageCnt"
		},
		postData: {
			//			projCd 	: $('#projCd').val(),
			projCd: $("#projCdSelect").val(),
			failCausCd: $('#failCausCd').val(),
			failCausNm: $('#failCausNm').val()
		},
		colNames: ['프로젝트 코드', 'Fail Cause 코드', 'Fail Cause 내용', '진단 검수 사용여부', '사용여부', '표시 순번', '등록자', '등록 일자'],
		//	    colNames:['Fail Cause 코드','Fail Cause 내용' ,'진단 검수 사용여부' , '사용여부' , '표시 순번' , '등록자' , '등록 일자'],
		colModel: [
			{ name: 'projCd', index: 'projCd', width: 155, align: "center", hidden: true },
			{ name: 'failCausCd', index: 'failCausCd', width: 185, align: "center" },
			{ name: 'failCausNm', index: 'failCausNm', width: 240, align: "center" },
			{ name: 'diagInspFg', index: 'diagInspFg', width: 185, align: "center" },
			{ name: 'useYn', index: 'useYn', width: 185, align: "center" },
			{ name: 'dispSeq', index: 'dispSeq', width: 185, align: "center" },
			{ name: 'regId', index: 'regId', width: 155, align: "center" },
			{ name: 'regDt', index: 'regDt', width: 225, align: "center" }
		],
		rowNum: 9999,
		//	    rowList: [10,20,30],
		height: 400,
		loadonce: true,
		autowidth: true,    	 // jQgrid width 자동100% 채워지게
		shrinkToFit: false,  // width를 자동설정 해주는 기능
		gridview: true,
		cmTemplate: { sortable: false },
		rownumbers: true,
		//	    pager: '#pager',
		onCellSelect: function (rowid, icol, cellcontent, e) {
			var rowData = $(this).jqGrid("getRowData", rowid);
			popupView(rowData.projCd, rowData.failCausCd, rowData.failCausNm, rowData.diagInspFg, rowData.useYn, rowData.dispSeq);
		},
		viewrecords: true,
		loadComplete: function (data) {
			var total = $("#grid").getGridParam("records");
			$("#list_num").text(total);
		},
		caption: " "
	});
}

/** 엑셀 다운로드 */
function excelDown() {
	var url = CONTEXT_PATH + "/manager/cause/excelCauseList.do";

	var data = new Object();
	data.projCd = $("#projCdSelect").prop("selected", true).val(),
	data.failCausCd = $('#failCausCd').val();
	data.failCausNm = $('#failCausNm').val();

	$(".loading-image").show();

	$.fileDownload(url, {
		httpMethod: "POST",
		data: data,
		successCallback: function (url) {
			$(".loading-image").hide();
		},
		failCallback: function (responseHtml, url, error) {
			$(".loading-image").hide();
		}

	});

}
