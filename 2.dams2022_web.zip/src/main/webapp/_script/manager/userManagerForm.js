/*
	**************************
	2022.05
	유저 등록 폼
	**************************
*/

// ------------------------------------------------------------
// 2022-09-19 initPswd
// ------------------------------------------------------------

// html 요소 4개
// openInitPswdBtn
// initPswdDiv
// initPswd
// initPswdBtn

// '초기화' 버튼 클릭시.
$(document).on("click", "#openInitPswdBtn", function () {
	$("#initPswdDiv").css("display", "flex");
	$("#initPswd").val('');  // 초기화 안해주면 크롬 id/pw 자동저장 기능에 의한 pswd값 들어감 autocomplete="off"도 소용없음.
	$("#initPswd").focus();
});

// 초기화 안에 비밀번호 입력 후 '확인' 버튼 클릭시.
$(document).on("click", "#initPswdBtn", function () {
	initPswd();
});

/**
 * 비밀번호 초기화 ajax 요청.
 */
function initPswd() {
	const sendData = {
		userId: $("#userId").val(),
		pswd: $("#initPswd").val()
	}
	console.log("initPswd PARAM");
	console.log(sendData);

	$.ajax({
		type: "POST",
		url: CONTEXT_PATH + "/manager/user/initPswd.do",
		data: sendData,
		dataType: "json",
		async: false,
		success: function (response) {
			console.log("initPswd RESPONSE");
			console.log(response);

			if (response.code == 0) {
				alert("초기화되었습니다.");
				$("#initPswdDiv").css("display", "none");
			} else {
				if (response.msg) {
					alert(response.msg);
				} else {
					alert("error");
				}
			}
		},
		error: function (request, status, error) {
			alert("code:" + request.status + "\n" + "message:" + request.responseText + "\n" + "error:" + error);
		}
	});
}


// ------------------------------------------------------------
// 기존
// ------------------------------------------------------------
$(function () {
	// 2022-07-05 뷰에서 수정버튼으로 온 경우
	if ($("#updateYn_Hid").val() == 'Y') {
		var userId = $("#userId").val();
		//		fnReadProject(userId);
	}

});

$(document).ready(function () {
	
	// 실패.
	// 2022-09-21 브라우저 저장된 id/pw 값 들어감 -> 다시 초기화 시켜줘야 함.
	// **주의 : 등록일때만. 수정폼[type=hidden]일때는 하면 안됨.
	// for (let i=0; i<100; i++) {
	// 	setTimeout(() => {
	// 		$("#userId[type=text]").val('');
	// 		$("#pswd[type=password]").val('');
	// 	}, i);
	// }

	// 다른방법 - 포기.
	// $("#userIdTd").html('<input type="text" class="input_text" id="userId" name="userId" autocomplete="off">');
	// $("#pswdTd").html('<input type="password" class="input_text" id="pswd" name="pswd" autocomplete="off">');

	// Ver. 2022-09-23 :: type(text) -> type(password) :: 시간초과 기법 :: 단점(불안정)
	// setTimeout(() => {
	// 	$("#pswd").attr("type", "password");
	// }, 10);

	// Ver. 2022-09-23_2 :: type(text) -> type(password) :: focus 기법 :: 안정적
	// var passElem = $("#pswd");
	// passElem.focus(function() { 
	// 	passElem.prop("type", "password");                                             
	// });

	// 위에꺼 다 필요없고 autocomplete="new-password" 만 하면 되네;;
	
});


function fnReadProject(userId) {
	var url = CONTEXT_PATH + "/manager/project.read.do";
	var data = new Object();
	data.userId = userId;

	var async = false;
	callAjax(url, data, async, function (json) {
		createTableRow("userProjectTable", json);
	});
}

function popupProject(v, i, obj) {
	var url = CONTEXT_PATH + "/manager/project.popup.do"

	// 2022-10-27 index attribute 로 하면 안됨 덮어씌우기.
	i = $(obj).closest(".project_clone").index() + 1;
	// console.log("popupProject CLICKED");
	// console.log(i);

	if (v == 0) {
		url += "?manager=Y&index=" + i;
	} else if (v == 1) {
		url += "?manager=N&index=" + i;
	}
	openPopup(url, "700", "500", "POPUP_USER_SEARCH", "yes", "yes", "");
}

function addManager(obj) {
	$(obj).closest("tr").clone(true).appendTo("#userManagerTableBody");
}

function addProject(obj) {
	$(obj).closest("tr").clone(true).appendTo("#userProjectTableBody");
}

function remove(obj) {
	$(obj).closest("tr").remove();
}


function addProjectRow() {

	var reg_userNm = $("#regUserNm").val();

	var date = new Date();
	var today = date.getFullYear() + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + ("0" + (date.getDate())).slice(-2);

	var trCnt = $("#userProjectTableBody tr").length;

	var html = "";
	html += '<tr class="project_clone" index="' + trCnt + '">';
	//	html += '<td><button class="add_project" onclick="addProject(this);"></button></td>';
	//	html += '<td><button class="add_project" ></button></td>';
	html += '<td><button class="" ></button></td>';
	html += '<td class="projCd"><input type="text" class="input_text" onclick="popupProject(1, ' + trCnt + ', this)" readOnly/></td>';
	html += '<td class="projNm""><input type="text" class="input_text" onclick="popupProject(1, ' + trCnt + ', this)" readOnly/></td>';
	html += '<td class="mgrYn"><select name="mgrYn" id="mgrYn"><option value="N" ${mgrYn eq "N" ? "selected" : "" style="text-align:center;"}>N</option>'
	html += '<option value="Y" ${mgrYn eq "Y" ? "selected" : "" style="text-align:center;"}>Y</option></select></td>'
	html += '<td>' + today + '</td>';
	html += '<td class="reg_user">' + reg_userNm + '</td>';
	html += '<td><button class="remove_user" onclick="remove(this);"></button></td>';
	html += '</tr>';

	$("#userProjectTableBody").append(html);
}


/**
 * 유저 신규 등록
 */
function registUser() {
	var bool = validation('');
	if (!bool) {
		return false;
	}

	var user_array = new Array();
	var JsonObject = new Object();

	JsonObject.userId = $("#userId").val();
	JsonObject.userNm = $("#userNm").val();
	JsonObject.pswd = $("#pswd").val();
	JsonObject.useYn = $("#useYn option:selected").val();
	JsonObject.sysMgrYn = $("#sysMgrYn option:selected").val();
	JsonObject.mgrYn = $("#mgrYn option:selected").val();
	JsonObject.regId = $("#regId").val();
	JsonObject.regDt = $("#regDt").val();

	var user_tr = $(".project_clone").length;

	var projs = [];	// 프로젝트
	var mgrs = [];	// 관리자여부

	// 2022-09-21
	// Ver 3. 공백인건 애초에 전송안함
	const $projCloneList = $(".project_clone");
	for (let i=0; i<$projCloneList.length; i++) {
		const projCdVal = $($projCloneList[i]).find(".projCd > input").val();
		const mgrYnVal = $($projCloneList[i]).find(".mgrYn :selected").val();
		if (projCdVal.length > 0) {
			projs.push(projCdVal);
			mgrs.push(mgrYnVal);
		}
	}


	// Ver 1.
	/*
	for(var j = 0; j < user_tr; j++){
		if($(".project_clone:eq("+j+")").find(".projCd").find(".input_text").val() == ""){
			alert("입력되지 않은 항목이 있습니다.");
			$(".project_clone:eq("+j+")").find(".projCd").find(".input_text").focus();
			return false;
	projs.push($(".project_clone:eq("+j+")").find(".projCd").find(".input_text").val());
//			projs.push($(".project_clone:eq("+j+")").find(".mgrYn").find(".input_text").val());
//			projs.push($(".project_clone:eq("+j+")").find(".mgrYn option:selected").val());
		}else{
		}
	}
	*/
	// Ver 2.
	// for (var j = 0; j < user_tr; j++) {
	// 	projs.push($(".project_clone:eq(" + j + ")").find(".projCd").find(".input_text").val());
	// 	//		mgrs.push($(".project_clone:eq("+j+")").find(".mgrYn").find(".input_text").val());
	// 	mgrs.push($(".project_clone:eq(" + j + ")").find(".mgrYn :selected").val());
	// }

	JsonObject.projs = JSON.stringify(projs);
	JsonObject.mgrs = JSON.stringify(mgrs);

	$.ajax({
		type: "POST",
		url: CONTEXT_PATH + "/manager/user/registUser.do",
		data: JsonObject,
		dataType: "json",
		async: false,
	}).done(function (data) {

		var msg = data.msg;
		var code = data.code;

		if (code == 0) {
			alert(msg);
			opener.parent.location.reload();
			self.close();
		} else {
			alert(msg);
		}
	}).fail(function (jqXHR, textStatus, errorThrown) {
		var msg = "처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		alert(msg);
	});
}

/**
 * 유저수정
 * @param {*} updateYn - valid 할때 사용
 */
function modifyUser(updateYn) {
	//	var msg = confirm("현재 검수 작업 중인 검수자를 삭제할 경우\n작업이 중지되오니 반드시 확인 후 변경해주세요!");
	var msg = "";
	//	if(msg){
	var bool = validation(updateYn);
	if (!bool) {
		return false;
	}

	var JsonObject = new Object();

	JsonObject.userId = $("#userId").val();
	JsonObject.userNm = $("#userNm").val();
	JsonObject.useYn = $("#useYn option:selected").val();
	JsonObject.pswd = $("#pswd").val();
	JsonObject.sysMgrYn = $("#sysMgrYn option:selected").val();
	JsonObject.regId = $("#regId").val();
	JsonObject.regDt = $("#regDt").val();

	var projs = [];
	var mgrs = [];

	// 2022-09-21
	// Ver 3. 공백인건 애초에 전송안함
	const $projCloneList = $(".project_clone");
	for (let i=0; i<$projCloneList.length; i++) {
		const projCdVal = $($projCloneList[i]).find(".projCd > input").val();
		const mgrYnVal = $($projCloneList[i]).find(".mgrYn :selected").val();
		if (projCdVal.length > 0) {
			projs.push(projCdVal);
			mgrs.push(mgrYnVal);
		}
	}

	// Ver 1. 2.
	// for (var j = 0; j < user_tr; j++) {
	// 	//			if($(".project_clone:eq("+j+")").find(".projCd").find(".input_text").val() == ""){
	// 	//				alert("입력되지 않은 항목이 있습니다.");
	// 	//				$(".project_clone:eq("+j+")").find(".projCd").find(".input_text").focus();
	// 	//				return false;
	// 	//			}else{
	// 	projs.push($(".project_clone:eq(" + j + ")").find(".projCd").find(".input_text").val());
	// 	//				mgrs.push($(".project_clone:eq("+j+")").find(".mgrYn").find(".input_text").val());
	// 	mgrs.push($(".project_clone:eq(" + j + ")").find(".mgrYn :selected").val());
	// 	//			}
	// }

	JsonObject.projs = JSON.stringify(projs);
	JsonObject.mgrs = JSON.stringify(mgrs);

	$.ajax({
		type: "POST",
		url: CONTEXT_PATH + "/manager/user/modifyUser.do",
		data: JsonObject,
		dataType: "json",
		async: false,
	}).done(function (response) {
		console.log("modifyUser RESPONSE");
		console.log(response);

		var code = response.code;
		var msg = response.msg;

		if (code == 0) {
			alert(msg);
			
			opener.parent.location.reload();
			self.close();
		} else {
			alert(msg);
			return false;
		}

		self.close();
	}).fail(function (jqXHR, textStatus, errorThrown) {
		var msg = "처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";

		alert(msg);
	});


}


function validation(updateYn) {

	if (updateYn != 'Y') {
		if ($("#userId").val() == "") {
			alert("유저 코드은 필수 입력 사항입니다.");
			$("#userId").focus();
			return false;
		}
	}

	if ($("#userNm").val() == "") {
		alert("유저명은 필수 입력 사항입니다.");
		$("#userNm").focus();
		return false;
	}

	if ($("#useYn").val() == "") {
		alert("데이터 디렉토리는 필수 입력 사항입니다.");
		$("#useYn").focus();
		return false;
	}

	return true;

}

/**
 * 유저 삭제 
 * @returns 
 */
function removeUser() {
	// valid 1. 뭐지?
	if ($("#userId").val() == "") {
		alert("유저 삭제에 실패하였습니다.");
		return;
	}
	// valid 2. 등록된 프로젝트가 있을경우 삭제 못하게 막음
	if ($(".project_clone").length > 0) {
		alert("등록된 프로젝트를 삭제 후 다시 시도해주세요. ");
		return;
	}

	if (confirm("현재 검수 작업 중인 검수자를 삭제할 경우\n작업이 중지되오니 반드시 체크한 후 삭제해주세요!")) {
		const sendData = {
			userId: $("#userId").val()
		}
		console.log("removeUser PARAM");
		console.log(sendData);

		$.ajax({
			type: "POST",
			url: CONTEXT_PATH + "/manager/user/removeUser.do",
			data: sendData,
			dataType: "json",
			async: false,
		}).done(function (data) {
			console.log("removeUser RESPONSE");
			console.log(data);

			var code = data.code;
			var msg = data.msg;

			if (code == 0) {
				alert(msg);

				opener.parent.location.reload();
				self.close();
			} else {
				alert(msg);
			}

		}).fail(function (jqXHR, textStatus, errorThrown) {
			var msg = "처리에 실패 하였습니다.";
			msg += "\n관리자에게 문의 하세요.";

			alert(msg);
		});
	}
}

