/*
	**************************
	2022.05. 
	프로젝트 관리 뷰
	**************************
*/
$(document).ready(function() {
	
});

$(function(){
	
	var projCd = $("#projCd").val();
	fnReadLabel(projCd);
})

function fnReadLabel(projCd){

	var url = CONTEXT_PATH + "/manager/project/getLabelList.do";
	var data = new Object();
	data.projCd = projCd;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRow("projectLabelTable", json);
	});
	
}

//폼으로 이동
function fnUpdateData(){
	
	var projCd = $("#projCd").val();
	
	if(projCd == ""){
		alert("프로젝트 불러오기를 실패하였습니다.");
		return false;
	}
	
	self.close();
	
//	var url = "/MLA_VIDEO";
//	var url = "/DAMS_SNUH_2022";
	var url = "";
//	url += CONTEXT_PATH + "/manager/project/registForm.do"
	url += CONTEXT_PATH + "/manager/project/modifyForm.do"
	url += "?projCd="+ projCd +"&updateYn=Y" ;
		
	openPopup(url, "1024", "500", "POPUP_PROJECT_WRITE", "yes", "yes", "");
	
}

function fnDeleteData(){
	
	var JsonObject = new Object();
	
	JsonObject.projCd = $("#projCd").val();
	
	if(projCd == ""){
		alert("프로젝트 삭제에 실패하였습니다.");
		return false;
	}

	// 삭제여부 다시 묻기
	if(confirm("정말 삭제하시겠습니까?")){
		
		$.ajax({
			url : "project.delete.do",
			type :"POST",
			async : false,
			dataType : "json",
			data : JsonObject
		})
		.done(function(data){
			
			var msg = data.p_ret_msg;
			var code = data.p_ret_code;
			
			if(code == 0){
//				alert(msg);
			}else{
//				alert(msg);
//				return false;
			}
			
			opener.parent.location.reload();
			self.close();
		})
		.fail(function(jqXHR, textStatus, errorThrown){
			var msg="처리에 실패 하였습니다.";
			msg += "\n관리자에게 문의 하세요.";
			
//			alert(msg);
		});
		
	}else{
		return false;
	}
	
}
