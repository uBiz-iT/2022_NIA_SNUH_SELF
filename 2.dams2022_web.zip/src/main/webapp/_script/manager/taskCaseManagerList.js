// -------------------------------------------------------
// UTIL
// -------------------------------------------------------
function nullToNot(val) {
	return val == null || val == undefined || val == '' || val == 'null' || Number.isNaN(val) ? "<span style='color: red;'>없음</span>" : val; // 너무 야매다.
}

function clickCheckedEvent(selectorStr) {
	$(document).on("click", selectorStr, function () {
		$(selectorStr).removeClass("checked");
		$(this).addClass("checked");
	});
}

function showProjectForm() {
	$("#main_section_body").show();
}

function hideProjectForm() {
	$("#main_section_body").hide();
}

// -------------------------------------------------------
// GLOBAL VARIABLE
// -------------------------------------------------------
// 폐음관련 임의 설정.
var processMode = "insp";

// 현재 케이스 {projCd, taskCd, caseNo}
var curTaskCase;

// 2022-10-11 현재 프로젝트 폼 사용중인 페이지 3개
// workTask, crossValidation, taskCaseManager.
// taskCaseManager 는 진단결과 또는 진단버튼이 보이면 안됨.
// viewMode 설정?
var viewMode = "view";
if (viewMode && viewMode == "view") {
	console.log("viewMode=view SHOW");
}

// -------------------------------------------------------
// FUNCTION
// -------------------------------------------------------
function initProjectForm() {
	const _projCd = $("#project_select").val();
	console.log("initProjctForm PROJCD");
	console.log(_projCd);
	loadProjectFormHtml(_projCd);
}

$(document).on("change", "#project_select", function () {
	$("#grid").empty();
	hideProjectForm();
	const _projCd = $(this).val();
	loadProjectFormHtml(_projCd);

	$($(".task")[0]).click(); // 위에 로드하고 첫번째 요소 클릭.

});

// Task :: Toggle, Click
clickCheckedEvent(".task");
$(document).on("click", ".task", function () {
	// task 선택시 프로젝트 폼 안보이게..
	hideProjectForm();
});

// 프로젝트 폼 로드 :: proj 선택 시 불러오기.
function loadProjectFormHtml(projCd) {

	// 이벤트 누적 방지
	$("#main_section_body").off();

	// 캐시 누적 방지 + url 생성
	const date = new Date().toISOString().replaceAll("-", "").replaceAll("T", "_").replaceAll(":", "");
	const date2 = date.substring(0, date.indexOf("."));
	const _htmlUrl = CONTEXT_PATH + "/_html/workTask/" + projCd + ".html?dt=" + date2;
	console.log("loadProject URL");
	console.log(_htmlUrl);

	// 애니메이션 정지
	const $body = $("#main_section_body");
	$body.stop(false, true);
	$body.fadeOut(0);
	$body.empty();
	$.ajax({
		type: "get",
		url: _htmlUrl,
		async: false,
		dataType: "text",
		success: function (response) {
			// console.log(response); // 너무 김.
			$body.html(response);
			curProjCd = projCd;
		}
	});

}

// 케이스(tr[role=row]) 클릭 이벤트
$(document).on("click", "tr[role=row]", function () {
	const sendData = {
		projCd: $(".task.checked").data("projCd"),
		taskCd: $(".task.checked").data("taskCd"),
		caseNo: $(this).children("td[aria-describedby=grid_caseNo]").attr("title"),
	}
	curTaskCase = sendData;
	console.log("case click PARAM");
	console.log(sendData);
	getCaseDataItemAll(sendData);
	showProjectForm();

	// 2022-10-11 하드코딩
	// epoch 초기화 && 해당 화면에 필요없는 테이블(진단결과/진단버튼) 삭제 :: 수면(2022A1)  |  폐기능(2022B1)  |  폐음(2022B2)
	$("#epoch_input").val("1");
	const projCd = sendData.projCd;

});

// -------------------------------------------------------
// 기존
// -------------------------------------------------------
/** document 로딩시 이벤트 */
$(document).ready(function () {
	// promise 처리 해줘야 함.
	setProjectList();
	setTaskList();
	initProjectForm();
	$("#task_list_ul > li.task:first-child").click();

	if ($("#taskSelCd").val() != '') {
		var taskCd = $("#taskSelCd").val();
		$(".task[data-task-cd=[" + taskCd + "]").click();
	}
});

/** ajaxGet ProjectList -> set ProjectList */
function setProjectList() {
	var url = CONTEXT_PATH + "/work/crossValidation/getProjectList.do";
	var async = false;
	callAjax(url, null, async, function (json) {
		console.log("setProjectList RESPONSE");
		console.log(json);

		// 22-07-07 기존 테이블로 그려주던 방식을 콤보박스로 변경함
		var rows = json.projectList;
		var html = "";
		html += "<select name='projectSelect' id='project_select' onchange='setTaskList()'>";
		for (i in rows) {
			const projCdSharing = getProjCdSharingCookie();
			if (rows[i].projCd == projCdSharing) {
				html += format("<option value='{0}' selected >{1}</option>", rows[i].projCd, rows[i].projNm);
			} else {
				html += format("<option value='{0}'>{1}</option>", rows[i].projCd, rows[i].projNm);
			}
		}
		html += "</select>";
		$("#project_div").html(html);

		$("#project_select").on("change", function () {
			setProjCdSharingCookie($("#project_select").val());
		});
	});
}

/** ajaxGet TaskList -> set TaskList */
function setTaskList() {
	var url = CONTEXT_PATH + "/work/taskCaseManager/getTaskList.do";
	var projCd = $("#project_select").val();

	// Task Stat 에서 넘어온 경우.
	if ($("#taskStatYn").val() != '') {
		projCd = $("#taskStatProjCd").val();
		$("#project_select").prop("selected", true).val(projCd);
		$("#taskStatYn").val('');
	}
	var data = {
		projCd: projCd,
	}
	var async = false;
	callAjax(url, data, async, function (json) {
		console.log("setTaskList RESPONSE");
		console.log(json);

		var rows = json.taskList;
		var html = "";
		for (var i = 0; i < rows.length; i++) {
			html += format("<li class='task' data-proj-cd='{0}' data-task-cd='{1}'>{1}</li>", projCd, rows[i].taskCd);
		}
		$("#task_list_ul").html(html);
	});
}

// Click :: Task
$(document).on("click", ".task", function () {
	var data = {
		projCd: $(this).data('projCd'),
		taskCd: $(this).data('taskCd'),
	}
	$("#task_cd").val(data.taskCd);

	$("#projCdExcel").val($("#project_select").val());
	$("#taskCdExcel").val($(this).data('taskCd'));

	createGrid(data);
});


/** 그리드 생성 **/
function createGrid(data) {
	var colNames = [];
	var colModels = [];
	var rows;
	var row_size;
	var keys;

	$.ajax({
		url: CONTEXT_PATH + "/manager/taskCaseManager/getTaskCaseStepList.do",
		async: false,
		dataType: "json",
		type: "POST",
		data: data
	}).done(function (jsonData) {
		console.log("createGrid PESPONSE");
		console.log(jsonData);

		if (jsonData.rows != '') {
			rows = jsonData.rows;
			keys = Object.keys(jsonData.rows[0]);
			row_size = jsonData.total;

			for (var i = 0; i < keys.length; i++) {

				// 컬럼 명칭 수정
				if (keys[i] == "caseNo") indexName = "케이스 No";
				if (keys[i] == "age") indexName = "나이";
				if (keys[i] == "gen") indexName = "성별";
				if (keys[i] == "regDt") indexName = "등록 일자";

				var model = { name: keys[i], index: keys[i], width: 280, align: "center" };
				if (keys[i] == "caseNo") {
					model.width = 281;
				}

				if (keys[i] == "projCd") {

				} else {
					colModels.push(model);
					colNames.push(indexName);
				}

			}
		} else {
			colModels.push(
				{ name: "케이스 No", index: "케이스 No", width: 272, align: "center" },
				{ name: "나이", index: "나이", width: 272, align: "center" },
				{ name: "성별", index: "성별", width: 272, align: "center" },
				{ name: "등록 일자", index: "등록 일자", width: 272, align: "center" }
			);
		}
	}).fail(function (jqXHR, textStatus, errorThrown) {
		alert("조회된 데이터가 없습니다.");
		colModels.push(
			{ name: "케이스 No", index: "케이스 No", width: 272, align: "center" },
			{ name: "나이", index: "나이", width: 272, align: "center" },
			{ name: "성별", index: "성별", width: 272, align: "center" },
			{ name: "등록 일자", index: "등록 일자", width: 272, align: "center" }
		);
	});

	$.jgrid.gridUnload("grid");

	$("#grid").jqGrid({
		data: rows,
		datatype: "local",
		colNames: colNames,
		colModel: colModels,
		rowNum: 9999,
		//	    rowList: [50,100,150, 200],
		height: "453",
		loadonce: true,
		autowidth: true,    	 // jQgrid width 자동100% 채워지게
		shrinkToFit: false,  // width를 자동설정 해주는 기능
		gridview: true,
		cmTemplate: { sortable: false },
		rownumbers: true,
		//	    pager: '#pager',
		onCellSelect: function (rowId, iCol, cellcontent, e) {},
		onSelectRow: function (rowId, status, e) {
			var psg_id = $("#grid").getCell(rowId, "검사(환자) ID");
			var task_cd = $("#task_cd").val();

			$("#psg_id").val(psg_id);

			var obj = new Object();
			obj.psg_id = psg_id;
			obj.task_cd = task_cd;

			if ($(".tabs").find(".tab-link").hasClass('current')) {
				obj.user_id = $(".tabs").find(".current").find("span").text();
			} else {
				obj.user_id = '';
			}
		},
		//	    ondbClickRow : function(rowId, iRow, iCol, e) {},        
		viewrecords: true,
		loadComplete: function (data) {
			var ids = $("#grid").getDataIDs();
			var total = $("#grid").getGridParam("records");
			$("#list_num").text(total);

			$.each(ids, function (idx, rowId) {
				rowData = $("#grid").getRowData(rowId);

				if (rowData.검수일치여부 == 'X') {
					//        			$("#grid").setRowData(rowId, false, {background:"#1191d033"});
					$("#grid").jqGrid('setCell', rowId, '검수일치여부', '', { 'background': "#1191d033" });
				}
				if (rowData.검수일치결과 == 'Fail') {
					$("#grid").jqGrid('setCell', rowId, '검수일치결과', '', { 'color': "#ff0505", 'font-weight': 'bold' });
				}
			});
		},
		caption: " "
	})

	$("#event_chk_list").css("display", "none");

}

// 2022-08-17(인수인계) 안쓰는것같은데 확인 필요
function excelDown2() {

	if ($("#list_grid1").css("display") == "block") {
		excelDown('Analysis_1', 'grid');
	} else {
		alert("크로스체크 리스트 조회가 되지 않았습니다.");
	}

	if ($("#list_grid2").css("display") == "block") {
		excelDown('Analysis_2', 'grid2');
	}

}

function excelDown() {
	var url = CONTEXT_PATH + "/manager/taskCaseExcelDown.do";

	var data = new Object();
	data.projCd = $("#projCdExcel").val();
	data.taskCd = $("#taskCdExcel").val();

	$(".loading-image").show();

	$.fileDownload(url, {
		httpMethod: "POST",
		data: data,
		successCallback: function (url) {
			$(".loading-image").hide();
		},
		failCallback: function (responseHtml, url, error) {
			$(".loading-image").hide();
		}
	});
}

function destroyWave() { console.log("destroyWave BLACK"); }

// waveSurfer 강제 제거
$(document).on("submit", "#epoch_form", function () {
	destroyWave();
});
$(document).on("click", ".task", function () {
	destroyWave();
});
$(document).on("click", ".task_case", function () {
	destroyWave();
});
// 교차검증, 케이스 등록관리.
$(document).on("click", "tr[role=row]", function () {
	destroyWave();
});