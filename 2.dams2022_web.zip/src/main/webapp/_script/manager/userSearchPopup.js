

// ------------------------------------------------------------
// GLOBAL VARIABLE
// ------------------------------------------------------------
// 부모 페이지에서 projCd 가져옴.
// 이렇게 할 수도 있고.
// const $projCd = $(parent.opener.document.querySelector("#projCdChange"));
// // const projCd = $projCd.val();
// // console.log("projCd");
// // console.log(projCd);


// // 그냥 url 에서 꺼내옴.
// const urlParams = new URL(location.href).searchParams;
// const projCd = urlParams.get('projCd');
// const index = urlParams.get('index');
// const manager = urlParams.get('manager');
// console.log(projCd+"  "+index+"  "+manager);

// ------------------------------------------------------------
// EVENT
// ------------------------------------------------------------
$("#search_form").submit(function (e) {
	e.preventDefault();
	listPage(1);
})


$(document).on("click", "#userTableBody tr", function () {
	$(this).find(".checkbox").click();
});


// ------------------------------------------------------------
// FUNCTION
// ------------------------------------------------------------

$(function () {
	// Init: 1페이지 검색
	listPage(1);
})

/** 선택한 요소의 결과를 부모창에 전달 **/
function saveItem() {

	var userId = "";
	var userNm = "";

	// if ($(".selectBox span").length < 1) {
	// 	alert("선택된 정보가 없습니다. \n최소 하나 이상 선택해주세요.");
	// 	return false;
	// }

	$(".selectBox span.selectedBox").each(function (i) {
		userId = $(this).attr("id");
		userNm = $(this).find("input[type=hidden]").val();
	});

	var index = $("#index").val();
	var manager = $("#manager").val();

	if (manager == 'Y') {
		$(".manager_clone[index=" + index + "] .manager_id .input_text", parent.opener.document).val(userId);
		$(".manager_clone[index=" + index + "] .manager_name .input_text", parent.opener.document).val(userNm);
		// $(".manager_clone:nth-child(" + index + ") .manager_id .input_text", parent.opener.document).val(userId);
		// $(".manager_clone:nth-child(" + index + ") .manager_name .input_text", parent.opener.document).val(userNm);
	} else if (manager == 'N') {
		var isReturn = false;
		$(parent.opener.document).find("#userTaskTableBody tr").each(function (i) {
			if ($(this).find(".userId").find("input[type=text]").val() == userId) {
				alert("이미 추가되어 있습니다.");
				isReturn = true;
				return false;
				// jquery each 구문에서는 return false 가 break 작용을 함. 함수를 빠져나가지 않음... 콜백함수에 대한 리턴임. 덕분에 조건 변수(isReturn) 따로 생성해야함.
				// 그냥 jquery each는 쓰지 말아야 하나?
			}
		});
		if (isReturn) return false;
		
		// 2022-10-27 index attribute 로 하면 안됨 덮어씌우기.
		// $(".user_clone[index=" + index + "] .userId .input_text", parent.opener.document).val(userId);
		// $(".user_clone[index=" + index + "] .userNm .input_text", parent.opener.document).val(userNm);
		$(".user_clone:nth-child(" + index + ") .userId .input_text", parent.opener.document).val(userId);
		$(".user_clone:nth-child(" + index + ") .userNm .input_text", parent.opener.document).val(userNm);
	}

	self.close();
}

// 검색.
function listPage(pageNo) {
	var url = CONTEXT_PATH + "/manager/user.popup.search.do";
	var data = {
		projCd: $("#projCd").val(),
		// 검색
		userId: $("#userId").val(),
		userNm: $("#userNm").val(),
		page_no: pageNo,
		row_size: 5,
	}
	console.log("listPage PARAM");
	console.log(data);

	var async = false;

	callAjax(url, data, async, function (json) {
		createTableRowPage("userTable", json, pageNo, 5, "listPage");
	});

	for (var i = 0; i < $("input.checkbox").length; i++) {
		//		$("input.checkbox")[i].style.display="none";
		$("input.checkbox")[i].style.visibility = "hidden";
	}

	var ids = new Array();
	$(".selectBox span.selectedBox").each(function () {
		var id = $(this).attr("id").trim();
		$("#userTableBody tr").each(function () {
			var text = $(this).find("td:eq(1)").text().trim();
			if (text == id) {
				$(this).find("td:eq(0) .checkbox").prop("checked", true);
			}
		})
	})

}


/** row checkbox 선택 이벤트 **/
function addItem(obj) {
	var isChecked = $(obj).find(".checkbox").is(":checked");
	var userId = $(obj).parents("td").next().text().trim();
	var userNm = $(obj).parents("td").next().next().text().trim();

	if (isChecked) {
		if ($("#" + userId + "").length == 0) {
			// 한 명만 선택
			if (checkItem("row") == "excess") {
				$(".selectBox").find("#" + userId + "").remove();
				$(".selectBox").find("#del_" + userId + "").remove();
				$(obj).find(".checkbox").prop("checked", false);
			} else {
				$(".selectBox").append("<span id=" + userId + " class='selectedBox'>" + userId + "<input type='hidden' value='" + userNm + "'/></span>");
				$(".selectBox").append("<span id='del_" + userId + "' class='del_icon'><i class='btn btn-del' onclick='delItem(this)'>&nbsp;&nbsp;&nbsp;&nbsp;</i></span>");
			}
		}

	} else {
		$(".selectBox").find("#" + userId + "").remove();
		$(".selectBox").find("#del_" + userId + "").remove();
	}

	saveItem();
}


/** 선택 개수 제한하기 위함 **/
function checkItem(row) {
	if (row == "row") {
		if ($(".selectBox span").length >= 1) {
			alert("한 명만 선택 가능합니다.");
			return "excess";
		}
	}
}


/** selectedBox에서 지우기 **/
function delItem(obj) {
	var id = $(obj).parents("span").attr("id");
	id = id.replace("del_", "");

	$(".selectBox").find("#" + id + "").remove();
	$(".selectBox").find("#del_" + id + "").remove();

	$("#userTableBody tr").each(function () {
		var text = $(this).find("td:eq(1)").text().trim();
		if (text == id) {
			$(this).find("td:eq(0) .checkbox").prop("checked", false);
		}
	});
}









