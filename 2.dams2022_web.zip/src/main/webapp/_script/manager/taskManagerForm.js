
// ------------------------------------------------------------
// Global Variable
// ------------------------------------------------------------
const $projChecked = $(opener.document.querySelector("#projCdSelect"));
const initProjCd = $projChecked.val();
const initProjNm = $projChecked.find("option[value=" + initProjCd + "]").text();

console.log("projCd + projNm");
console.log(initProjCd + " | " + initProjNm);


// ------------------------------------------------------------
// Function
// ------------------------------------------------------------
$(function () {
	if ($("#updateYn_Hid").val() == 'Y') {
		var projCd = $("#projCd").val();
		var taskCd = $("#taskCd").val();
		//		fnReadLabel(taskCd,projCd);
	}

	// 추가 220811 기본값.
	// 수정 아닌 등록 화면
	var modifyYn = $("#modifyYn").val();
	console.log("modifyYn");
	console.log(modifyYn);
	if (modifyYn != "Y") {
		$("#projCdChange").val(initProjCd);
		$("#projNmChange").val(initProjNm);
		setUserTaskTable();
	}

	$("#projCdChange").on("change", function () {
		setUserTaskTable();
	});

});


function setUserTaskTable() {
	console.log("HI2");

	var projCd = $("#projCdChange").val();
	var loginId = $("#regUserNm").val();
	var regDt = $("#regDt_Hid").val();

	var html = "";
	html += '<colgroup><col width="5%"><col width="20%"><col width="20%">';
	// 폐기능 추가 - colgroup
	if (projCd == '2022B2') {
		html += '<col width="15%">';
	}
	html += '<col width="15%"><col width="15%"><col width="auto"></colgroup>';
	html += '<thead><tr><th data-opt="{"col":"add_btn"}" style="text-align:end;"><button class="add_user" onclick="addUserRow();"></button></th>';
	html += '<th data-opt="{"col":"userId", "align":"center"}">사용자 ID</th><th data-opt="{"col":"userNm", "align":"center"}">사용자 이름</th>';
	// 폐기능 추가 - thead
	if (projCd == '2022B2') {
		html += '<th data-opt="{"col":"diagInspFgBtn", "align":"center"}">진단자 여부</th>';
	}
	html += '<th data-opt="{"col":"regDt", "align":"center"}">지정 일자</th><th data-opt="{"col":"regId", "align":"center"}">등 록 자</th><th data-opt="{"col":"remove_btn"}">삭제</th>';
	html += '</tr></thead>';
	html += '<tbody id="userTaskTableBody"><tr class="user_clone" index="0"><td><button class="" onclick="addUserRow();"></button></td>';
	html += '<td class="userId"><input type="text" class="input_text" onclick="popupUser(1, 0, this)" readOnly/></td>';
	html += '<td class="userNm"><input type="text" class="input_text" onclick="popupUser(1, 0, this)" readOnly/></td>';
	// 폐기능 추가 - tbody
	if (projCd == '2022B2') {
		html += '<td class="diagInspFgBtn" ><input type="radio" name="input_radio" class="input_radio" /></td>';
	}
	html += '<td class="diagInspFg" style="display:none;"><input type="text" class="input_text" readOnly/></td>';
	html += '<td>' + regDt + '</td><td class="reg_user">' + loginId + '<input type="hidden" class="reg_user_id" value="' + loginId + '"/></td><td><button class="remove_user" onclick="remove(this);"></button></td>';
	html += '</tr></tbody>';

	$("#userTaskTable").html(html);

	if (projCd == '2022B2') {
		$("[name='input_radio']")[0].checked = true;
	}
}


function fnReadLabel(taskCd, projCd) {

	var url = CONTEXT_PATH + "/manager/user.read.do";
	var data = new Object();
	data.projCd = projCd;
	data.taskCd = taskCd;

	var async = false;

	callAjax(url, data, async, function (json) {
		createTableRow("userTaskTable", json);
	});
}

function popupUser(v, i, obj) {
	var projCd = $("#projCdChange").val();
	if (projCd == '') {
		alert("프로젝트를 먼저 선택해 주십시오.");
		return false;
	}
	
	// 2022-10-27 index attribute 로 하면 안됨 덮어씌우기.
	i = $(obj).closest(".user_clone").index() + 1;
	// console.log("userRow CLICKED OBJ");
	// console.log(obj);
	// console.log($(obj));
	// console.log($(obj).closest(".user_clone"));
	// console.log(i);

	var url = CONTEXT_PATH + "/manager/user.popup.do"
	if (v == 0) {
		url += "?manager=Y&index=" + i + "&projCd=" + projCd;
	} else if (v == 1) {
		url += "?manager=N&index=" + i + "&projCd=" + projCd;
	}

	openPopup(url, "700", "500", "POPUP_USER_SEARCH", "yes", "yes", "");

}

function popupProject(v, i) {

	//	var projCd = $("#projCdChange").val();

	//	var url = "/MLA_VIDEO";
	var url = CONTEXT_PATH + "/manager/project.popup.do"
	if (v == 0) {
		url += "?manager=Y&index=" + i;
		//		url += "?manager=Y&index=" +i + "&projCd=" + projCd ;
	} else if (v == 1) {
		url += "?manager=N&index=" + i;
		//		url += "?manager=N&index="+i + "&projCd=" + projCd ;
	}

	openPopup(url, "700", "500", "POPUP_PROJECT_SEARCH", "yes", "yes", "");
}

function addManager(obj) {
	$(obj).closest("tr").clone(true).appendTo("#userTaskTableBody");
}

function addUser(obj) {
	$(obj).closest("tr").clone(true).appendTo("#userTaskTableBody");
}

function remove(obj) {
	$(obj).closest("tr").remove();

	for (var i = 0; i < $(".user_clone").find("[name='input_radio']").length; i++) {
		if ($(".user_clone").find("[name='input_radio']")[i].checked) {
			return;
		} else {
			if (i == $(".user_clone").find("[name='input_radio']").length - 1) {
				$("[name='input_radio']")[0].checked = true;
				alert("진단자를 다시 선택해주세요.");
			}
		}
	}

}

function addManagerRow() {

	var reg_user_nm = $("#regUserNm").val();

	var date = new Date();
	var today = date.getFullYear() + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + ("0" + (date.getDate())).slice(-2);

	var trCnt = $("#userTaskTableBody tr").length;

	var html = "";

	// 2022-07-12 진단자 여부 컬럼생성 체크용
	var projCd = $("#projCdChange").val();

	html += '<tr class="manager_clone" index="' + trCnt + '">';
	//	html += '<td><button class="add_manager" onclick="addManager(this);"></button></td>';
	html += '<td><button class="add_manager" ></button></td>';
	html += '<td class="manager_id"><input type="text" class="input_text" onclick="popupUser(0, ' + trCnt + ', this)" readOnly/></td>';
	html += '<td class="manager_name"><input type="text" name="input_radio" class="input_text" readOnly/></td>';

	if (projCd == '2022B2') {

		html += '<td class="manager_cd"><input type="radio" name="input_radio" class="input_radio" readOnly/></td>';
	}

	html += '<td>' + today + '</td>';
	html += '<td class="reg_user">' + reg_user_nm + '</td>';
	html += '<td class="manager_expt"><select name="is_expt" class="is_expt"><option value="N">N</option><option value="Y">Y</option></select></td>';
	html += '<td><button class="remove_manager" onclick="remove(this);"></button></td>';
	html += '</tr>';

	$("#userTaskTableBody").append(html);

}

function addUserRow() {

	var reg_user_nm = $("#regUserNm").val();

	var date = new Date();
	var today = date.getFullYear() + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + ("0" + (date.getDate())).slice(-2);

	var trCnt = $("#userTaskTableBody tr").length;

	var html = "";

	// 2022-07-12 진단자 여부 컬럼 체크용
	var projCd = $("#projCdChange").val();

	html += '<tr class="user_clone" index="' + trCnt + '">';
	//	html += '<td><button class="add_user" onclick="addUser(this);"></button></td>';
	//	html += '<td><button class="add_user"></button></td>';
	html += '<td><button class=""></button></td>';
	html += '<td class="userId"><input type="text" class="input_text" onclick="popupUser(1, ' + trCnt + ', this)" readOnly/></td>';
	html += '<td class="userNm""><input type="text" class="input_text" onclick="popupUser(1, ' + trCnt + ', this)" readOnly/></td>';

	if (projCd == '2022B2') {
		html += '<td class="diagInspFgBtn"><input type="radio" name="input_radio" class="input_radio"/></td>';
	}

	//	html += '<td class="diagInspFg" style="display:none;" ><input type="text" class="input_text" readOnly/></td>';

	html += '<td>' + today + '</td>';
	html += '<td class="reg_user">' + reg_user_nm + '</td>';
	html += '<td><button class="remove_user" onclick="remove(this);"></button></td>';
	html += '</tr>';

	if (projCd == '2022B2' && $(".user_clone").length == 0) {
		$("#userTaskTableBody").append(html);
		$("[name='input_radio']")[0].checked = true;
	} else {
		$("#userTaskTableBody").append(html);
	}
}

/** 값 검사 */
function validation(updateYn) {
	if (updateYn != 'Y') {
		if ($("#projCd").val() == "") {
			alert("프로젝트 코드은 필수 입력 사항입니다.");
			$("#projCd").focus();
			return false;
		}
	}

	if ($("#projNm").val() == "") {
		alert("프로젝트명은 필수 입력 사항입니다.");
		$("#projNm").focus();
		return false;
	}

	if ($("#taskCd").val() == "") {
		alert("태스크코드는 필수 입력 사항입니다.");
		$("#taskCd").focus();
		return false;
	}

	if ($("#taskNm").val() == "") {
		alert("태스크명은 필수 입력 사항입니다.");
		$("#taskNm").focus();
		return false;
	}

	if ($("#dataDir").val() == "") {
		alert("데이터 경로는 필수 입력 사항입니다.");
		$("#dataDir").focus();
		return false;
	}

	return true;
}

/** 태스크 등록 프로세스 */
function registTask() {
	// valid 1.
	var bool = validation('');
	if (!bool) {
		return false;
	}

	var JsonObject = new Object();

	if ($("#projCdChange").val() == '2022A1') { // 수면 A
		JsonObject.diagInspFg = null;
	} else if ($("#projCdChange").val() == '2022B1') { // 폐음 I
		JsonObject.diagInspFg = 'I';
	} else if ($("#projCdChange").val() == '2022B2') { // 폐기능 S
		//		if(  ){ // 진단자
		//			JsonObject.diagInspFg = 'D';
		//		}else if(){ // 검수자
		//			JsonObject.diagInspFg = 'I';
		//		}
	} else {

	}

	//	JsonObject.projCd = $("#projCd").val();
	JsonObject.projCd = $("#projCdChange").val();
	JsonObject.taskCd = $("#taskCd").val();
	JsonObject.taskNm = $("#taskNm").val();
	JsonObject.dataDir = $("#dataDir").val();
	JsonObject.dataRegYmd = $("#regDt").val();
	JsonObject.statYn = $("#statYn").val();
	JsonObject.regUserNm = $("#regUserNm").val();
	var user_tr = $(".user_clone").length;

	var users = [];
	var userdi = [];
	var diagCnt = 0;

	for (var j = 0; j < user_tr; j++) {
		const val = $(".user_clone:eq(" + j + ")").find(".userId").find(".input_text").val();
		if (val.length > 0) { // 빈칸 무시.
			users.push(val);
			// 진단자 여부 체크
			if ($("#projCdChange").val() == '2022A1') { // 수면 A
				JsonObject.diagInspFg = null;
				userdi.push(null);
			} else if ($("#projCdChange").val() == '2022B1') { // 폐음 I
				JsonObject.diagInspFg = 'I';
				userdi.push('I');
			} else if ($("#projCdChange").val() == '2022B2') { // 폐기능 S
				if ($(".diagInspFgBtn").find('input')[j].checked) { // 진단자
					userdi.push('D');
					diagCnt++;
				} else { // 검수자
					userdi.push('I');
				}

				if (diagCnt >= 2) {

					alert("진단자는 중복으로 선택할 수 없습니다.");

					return false;
				}
			}
		}
	}
	JsonObject.users = JSON.stringify(users);
	JsonObject.userdi = JSON.stringify(userdi);

	$.ajax({
		url: CONTEXT_PATH + "/manager/task/registTask.do",
		type: "POST",
		async: false,
		dataType: "json",
		data: JsonObject
	}).done(function (response) {
		console.log("registTask RESPONSE");
		console.log(response)

		var msg = response.msg;
		var code = response.code;
		if (code == 0) {
			alert(msg);

			opener.parent.location.reload();
			self.close();
		} else {
			alert(msg);
		}

	}).fail(function (jqXHR, textStatus, errorThrown) {
		var msg = "처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		alert(msg);
	});
}

/** 태스크 수정 프로세스 */
function modifyTask(updateYn) {
	var msg = confirm("현재 검수 작업 중인 검수자를 삭제할 경우\n작업이 중지되오니 반드시 확인 후 변경해주세요!");
	//	if(msg){}

	// valid 1.
	var bool = validation(updateYn);
	if (!bool) {
		return false;
	}

	var JsonObject = new Object();

	JsonObject.projCd = $("#projCdChange").val();
	JsonObject.taskCd = $("#taskCd").val();
	JsonObject.taskNm = $("#taskNm").val();
	JsonObject.dataDir = $("#dataDir").val();
	JsonObject.dataRegYmd = $("#regDt").val();
	JsonObject.statYn = $("#statYn").val();
	JsonObject.regId = $("#regUserNm").val();

	var user_tr = $(".user_clone").length;
	var users = [];
	var userdi = [];
	var diagCnt = 0;

	for (var j = 0; j < user_tr; j++) {
		//		if($(".user_clone:eq("+j+")").find(".userId").find(".input_text").val() == ""){
		//			alert("입력되지 않은 항목이 있습니다.");
		//			$(".user_clone:eq("+j+")").find(".userId").find(".input_text").focus();
		//			return false;
		//		}else{
		const val = $(".user_clone:eq(" + j + ")").find(".userId").find(".input_text").val();
		if (val.length > 0) { // 빈칸 무시.
			users.push(val);

			// 진단자 여부 체크
			if ($("#projCdChange").val() == '2022A1') { // 수면 A
				JsonObject.diagInspFg = null;
				userdi.push(null);
				//			alert("AA");
			} else if ($("#projCdChange").val() == '2022B1') { // 폐음 I
				JsonObject.diagInspFg = 'I';
				userdi.push('I');
				//			alert("BB");
			} else if ($("#projCdChange").val() == '2022B2') { // 폐기능 S
				//			alert("CC");
				//			if( $(".user_clone").length > 0 ){

				//				for (var i = 0; i < $(".user_clone").length; i++) {
				//					$(".diagInspFgBtn").find('input')[1].checked
				if ($(".diagInspFgBtn").find('input')[j].checked) { // 진단자
					userdi.push('D');
					//						alert("DD");

					diagCnt++;
				} else { // 검수자
					userdi.push('I');
					//						alert("EE");
				}

				if (diagCnt >= 2) {

					alert("진단자는 중복으로 선택할 수 없습니다.");

					return false;
				}
			}
		}
	}
	JsonObject.users = JSON.stringify(users);
	JsonObject.userdi = JSON.stringify(userdi);

	$.ajax({
		url: CONTEXT_PATH + "/manager/task/modifyTask.do",
		type: "POST",
		async: false,
		dataType: "json",
		data: JsonObject
	}).done(function (response) {
		console.log("modfiyTask RESPONSE");
		console.log(response)

		var msg = response.msg;
		var code = response.code;
		if (code == 0) {
			alert(msg);
			opener.parent.location.reload();
			self.close();
		} else {
			alert(msg);
		}

		self.close();
	}).fail(function (jqXHR, textStatus, errorThrown) {
		var msg = "처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";

		alert(msg);
	});


}

/** 태스크 삭제 프로세스 */
function removeTask() {
	if (confirm("정말 삭제하시겠습니까?")) {
		const sendData = {
			projCd: $("#projCd").val(),
			taskCd: $("#taskCd").val()
		}
		console.log("removeTask PARAM");
		console.log(sendData);

		$.ajax({
			type: "POST",
			url: CONTEXT_PATH + "/manager/task/removeTask.do",
			async: false,
			dataType: "json",
			data: sendData,
		}).done(function (response) {
			console.log("modfiyProject RESPONSE");
			console.log(response)
	
			var code = response.code;
			var msg = response.msg;
			if (code == 0) {
				if (msg) {
					alert(msg);
				} else {
					alert("삭제가 완료되었습니다.");
				}

				opener.parent.location.reload();
				self.close();
			} else {
				if (msg) {
					alert(msg);
				} else {
					alert("처리에 실패 하였습니다. 관리자에게 문의하여 주십시오.");
				}
			}
		}).fail(function (jqXHR, textStatus, errorThrown) {
			alert("처리에 실패 하였습니다. 관리자에게 문의하여 주십시오.");
		});
	}
}