/*
	**************************
	2022.05.23 
	프로젝트 관리 리스트
	**************************
*/
$(function () {
	$(".input_text").keydown(function (key) {
		if (key.keyCode == 13) {
			$("#search").click();
		}
	});
	$(".ui-pg-selbox").change(function () {
		$("#page_cnt").val($(this).val());
	});

	// Init
	setTableData();
});

/** 검색버튼 이벤트 */
$("#search").parent().click(function () {
	setTableData();
});

/**
 * 프로젝트 수정 폼 팝업창
 * 원래 이런식으로 url 파라미터 넘겨주지 않고 model로 넘겨주는게 깔끔한데 두가지가 섞여있음;;
 * @param {*} val1 
 * @param {*} val2 
 * @param {*} val3 
 * @param {*} val4 
 * @param {*} val5 
 * @param {*} val6 
 * @param {*} val7 
 * @param {*} val8 
 * @param {*} val9 
 */
function popupModifyForm(val1, val2, val3, val4, val5, val6, val7, val8, val9) {
	var startDate = val6.substr(0, 4) + "-" + val6.substr(4, 2) + "-" + val6.substr(6, 2);
	var endDate = val7.substr(0, 4) + "-" + val7.substr(4, 2) + "-" + val7.substr(6, 2);

	var url = CONTEXT_PATH + "/manager/project/modifyForm.do"
	url += "?projCd=" + val1 + "&projNm=" + val2 + "&useYn=" + val3 + "&weekRepoStdDayw=" + val4 + "&planDsetQty=" + val5 + "&projBegYmd=" + startDate + "&projEndYmd=" + endDate + "&regDt=" + val8 + "&weekRepoStdDaywStr=" + val9;

	openPopup(url, "1024", "500", "POPUP_PROJECT_VIEW", "yes", "yes", "");
}

/** 프로젝트 추가팝업 열기  */
function projAdd() {
	var url = CONTEXT_PATH + "/manager/project/registForm.do";
	openPopup(url, "1024", "500", "POPUP_PROJECT_WRITE", "yes", "yes", "");
}

/** ajax테이블데이터 가져오고, 테이블 세팅 */
function setTableData() {
	// 엑셀 변수
	$("#projCd_hide").val($("#projCd").val());
	$("#projNm_hide").val($("#projNm").val());

    $.jgrid.gridUnload("grid"); // 필수
	$("#grid").jqGrid({
		url: CONTEXT_PATH + '/manager/project/getProjectList.do',
		mtype: "POST",
		datatype: 'json',
		jsonReader: {
			root: "projectList",
			//	    	records : "pageCnt"
		},
		postData: {
			projCd: $('#projCd').val(),
			projNm: $('#projNm').val(),
		},
		colNames: ['프로젝트 코드', '프로젝트명', '사용여부', '주간보고 요일', '목표 데이터셋 수량', '시작일자', '종료일자', '프로젝트 생성자', '프로젝트 생성일자', '주간보고 요일'],
		colModel: [
			{ name: 'projCd', index: 'projCd', width: 155, align: "center" },
			{ name: 'projNm', index: 'projNm', width: 225, align: "center" },
			{ name: 'useYn', index: 'useYn', width: 105, align: "center" },
			{ name: 'weekRepoStdDaywStr', index: 'weekRepoStdDaywStr', width: 105, align: "center" },
			//	              {name:'weekRepoStdDayw',index:'weekRepoStdDayw'	,width:105  	,align:"center"},
			{ name: 'planDsetQty', index: 'planDsetQty', width: 155, align: "center" },
			{ name: 'projBegYmd', index: 'projBegYmd', width: 140, align: "center" },
			{ name: 'projEndYmd', index: 'projEndYmd', width: 140, align: "center" },
			{ name: 'regId', index: 'regId', width: 155, align: "center" },
			{ name: 'regDt', index: 'regDt', width: 185, align: "center" },
			{ name: 'weekRepoStdDayw', index: 'weekRepoStdDayw', width: 105, align: "center", hidden: true }
		],
		rowNum: 9999,
		// 	    rowList: [10,20,30],
		height: 400,
		loadonce: true,
		autowidth: true,    	 // jQgrid width 자동100% 채워지게
		shrinkToFit: false,  // width를 자동설정 해주는 기능
		gridview: true,
		cmTemplate: { sortable: false },
		rownumbers: true,
		// 	    pager: '#pager',
		onCellSelect: function (rowid, icol, cellcontent, e) {
			// 22-07-06 폼으로 바로 연동하기 위해 파라미터 값 추가
			var rowData = $(this).jqGrid("getRowData", rowid);

			popupModifyForm(rowData.projCd, rowData.projNm, rowData.useYn, rowData.weekRepoStdDayw, rowData.planDsetQty, rowData.projBegYmd, rowData.projEndYmd, rowData.regDt, rowData.weekRepoStdDaywStr);
		},
		viewrecords: true,
		loadComplete: function (data) {
			var total = $("#grid").getGridParam("records");
			$("#list_num").text(total);
		},
		caption: " "

	});
}

/** 엑셀 다운로드 */
function excelDown() {
	var url = CONTEXT_PATH + "/manager/project/excelProjectList.do";

	var data = new Object();
	data.projCd = $('#projCd_hide').val();
	data.projNm = $('#projNm_hide').val();

	$(".loading-image").show();

	$.fileDownload(url, {
		httpMethod: "POST",
		data: data,
		successCallback: function (url) {
			$(".loading-image").hide();
		},
		failCallback: function (responseHtml, url, error) {
			$(".loading-image").hide();
		}
	});
}


