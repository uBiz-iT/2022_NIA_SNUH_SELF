/*
	**************************
	2022.05.23 
	프로젝트 관리 리스트
	**************************
*/

$(function () {
	
	// 검색 - enter
	$(".input_text").keydown(function (key) {
		if (key.keyCode == 13) {
			$("#search").click();
		}
	});
	// paging - 지금은 없음
	$(".ui-pg-selbox").change(function () {
		$("#page_cnt").val($(this).val());
	});

	// Init
	setTableData();

});

/** 검색버튼 이벤트 */
$("#search").parent().click(function () {
	setTableData();
});

/** 유저 업데이트 팝업 */
function popupModifyForm(val1, val2, val3, val4, val5) {
	var url = CONTEXT_PATH + "/manager/user/modifyForm.do"
	url += "?updateYn=Y&userId=" + val1 + "&userNm=" + val2 + "&useYn=" + val3 + "&sysMgrYn=" + val4 + "&pswd=" + val5;
	openPopup(url, "1024", "500", "POPUP_PROJECT_WRITE", "yes", "yes", "");
}

/** 유저 신규생성 팝업 */
function popupRegistForm() {
	var url = CONTEXT_PATH + "/manager/user/registForm.do";
	openPopup(url, "1024", "500", "POPUP_USER_WRITE", "yes", "yes", "");
}

/** 유저 리스트 ajaxGet + setGrid */
function setTableData() {

	$("#userId_hide").val($("#userId").val());
	$("#userNm_hide").val($("#userNm").val());
	$("#useYn_hide").val($('#useYn option:selected').val());

    $.jgrid.gridUnload("grid");
	$("#grid").jqGrid({
		url: CONTEXT_PATH + '/manager/user/getUserList.do',
		mtype: "POST",
		datatype: 'json',
		jsonReader: {
			root: "userList",
			//	    	records : "pageCnt"
		},
		postData: {
			userId: $('#userId').val(),
			userNm: $('#userNm').val(),
		},
		colNames: ['사용자 아이디', '사용자 명', '등록 프로젝트 목록', '사용여부', '시스템 관리자 여부', '등록자', '등록일자', '패스워드'],
		colModel: [
			{ name: 'userId', index: 'userId', width: 175, align: "center" },
			{ name: 'userNm', index: 'userNm', width: 175, align: "center" },
			{ name: 'projMapping', index: 'projMapping', width: 245, align: "center" },
			{ name: 'useYn', index: 'useYn', width: 100, align: "center" },
			{ name: 'sysMgrYn', index: 'sysMgrYn', width: 130, align: "center" },
			{ name: 'regId', index: 'regId', width: 205, align: "center" },
			{ name: 'regDt', index: 'regDt', width: 330, align: "center" },
			{ name: 'pswd', index: 'pswd', width: 300, align: "center", hidden: true }
		],
		rowNum: 9999,
		// 	    rowList: [10,20,30],
		height: 400,
		loadonce: true,
		autowidth: true,    	 // jQgrid width 자동100% 채워지게
		shrinkToFit: false,  // width를 자동설정 해주는 기능
		gridview: true,
		cmTemplate: { sortable: false },
		rownumbers: true,
		// 	    pager: '#pager',
		onCellSelect: function (rowid, icol, cellcontent, e) {
			var rowData = $(this).jqGrid("getRowData", rowid);
			// 팝업 호출시 넘겨주는 파라미터값 추가
			popupModifyForm(rowData.userId, rowData.userNm, rowData.useYn, rowData.sysMgrYn, rowData.pswd);
		},
		viewrecords: true,
		loadComplete: function (data) {
			var total = $("#grid").getGridParam("records");
			$("#list_num").text(total);
		},
		caption: " "

	});

}


/** 유저테이블 엑셀 다운로드 */
function excelDown() {
	var url = CONTEXT_PATH + "/manager/user/excelUserList.do";

	var data = new Object();
	data.userId = $('#userId_hide').val();
	data.userNm = $('#userNm_hide').val();

	$(".loading-image").show();

	$.fileDownload(url, {
		httpMethod: "POST",
		data: data,
		successCallback: function (url) {
			$(".loading-image").hide();
		},
		failCallback: function (responseHtml, url, error) {
			$(".loading-image").hide();
		}

	});
}


