/*
	**************************
	2022.05
	유저 등록 폼
	**************************
*/

$(document).ready(function() {
	
});

$(function(){
	
	
})

function popupProject(v, i){
	
//	var url = "/MLA_VIDEO";
	var url = "";
	url += CONTEXT_PATH + "/manager/project.popup.do"
	if(v == 0){
		url += "?manager=Y&index="+i;
	}else if(v == 1){
		url += "?manager=N&index="+i;
	}
		
	openPopup(url, "700", "500", "POPUP_USER_SEARCH", "yes", "yes", "");
	
}

function popupTask(v, i){
	
	var projCd = $("#projCdChange").val();
	
//	var url = "/MLA_VIDEO";
	var url = "";
	url += CONTEXT_PATH + "/manager/task.popup.do"
	if(v == 0){
//		url += "?manager=Y&index=" +i;
		url += "?manager=Y&index=" +i + "&projCd=" + projCd ;
	}else if(v == 1){
//		url += "?manager=N&index="+i;
		url += "?manager=N&index="+i + "&projCd=" + projCd ;
	}
	
	openPopup(url, "700", "500", "POPUP_USER_SEARCH", "yes", "yes", "");
	
}

function addManager(obj){
	
	$(obj).closest("tr").clone(true).appendTo("#taskManagerTableBody");
}

/*
function addProject(obj){
	
	$(obj).closest("tr").clone(true).appendTo("#userProjectTableBody");
}
*/

/*
function remove(obj){
	var projCdVal = $('.remove_user').parent().parent()[0].querySelector('.projCd').querySelector('input').value;
	var projCdVal = $('.remove_user').parent().parent()[0].querySelector('.projCd').querySelector('input').value;
	alert("validation Chk : " + projCdVal + " START");
	
	var url = CONTEXT_PATH + "/manager/user.project.validation.do";

	var data = new Object();

	var JsonObject = new Object();
	
	var async = false;

	JsonObject.projCd = projCdVal;
	JsonObject.projCd = projCdVal;
	
	callAjax(url, data, async, function(json){
    	var row = json.rows;
      
    	$("#psg_cnt").text(row[0].psg_cnt);
	});
	
	alert("validation Chk : " + projCdVal + " END");
	
	$(obj).closest("tr").remove();
}
*/

/*
function addManagerRow(){

	var reg_userNm  = $("#regUserNm").val();
	
	var date = new Date();
	var today = date.getFullYear() + "-" + ("0"+(date.getMonth()+1)).slice(-2) + "-" + ("0"+(date.getDate())).slice(-2);
	
	var trCnt = $("#userManagerTableBody tr").length;
	
	var html = "";
	
	html += '<tr class="manager_clone" index="'+trCnt+'">';
	html += '<td><button class="add_manager" onclick="addManager(this);"></button></td>';
	html += '<td class="manager_id"><input type="text" class="input_text" onclick="popupProject(0, '+trCnt+')" readOnly/></td>';
	html += '<td class="manager_name"><input type="text" class="input_text" readOnly/></td>';
	html += '<td>'+today+'</td>';
	html += '<td class="reg_user">'+reg_userNm+'</td>';
	html += '<td class="manager_expt"><select name="is_expt" class="is_expt"><option value="N">N</option><option value="Y">Y</option></select></td>';
	html += '<td><button class="remove_manager" onclick="remove(this);"></button></td>';
	html += '</tr>';

	$("#userManagerTableBody").append(html);
	
}
*/

/*
function addProjectRow(){
	
	var reg_userNm  = $("#regUserNm").val();
	
	var date = new Date();
	var today = date.getFullYear() + "-" + ("0"+(date.getMonth()+1)).slice(-2) + "-" + ("0"+(date.getDate())).slice(-2);
	
	var trCnt = $("#userProjectTableBody tr").length;
	
	var html = "";
	
	html += '<tr class="user_clone" index="'+trCnt+'">';
	html += '<td><button class="add_user" onclick="addProject(this);"></button></td>';
	html += '<td class="projCd"><input type="text" class="input_text" onclick="popupProject(1, '+trCnt+')" readOnly/></td>';
	html += '<td class="projNm""><input type="text" class="input_text" readOnly/></td>';
	html += '<td>'+today+'</td>';
	html += '<td class="reg_user">'+reg_userNm+'</td>';
	html += '<td><button class="remove_user" onclick="remove(this);"></button></td>';
	html += '</tr>';
	
	
	$("#userProjectTableBody").append(html);
	
}
*/

function fnSaveData(){
	
	var bool = validation('');
	if(!bool){
		return false;
	}
	
	var user_array = new Array();
	var JsonObject = new Object();
	
	JsonObject.projCd = $("#projCdChange").val();
	JsonObject.projNm = $("#projNmChange").val();
	JsonObject.taskCd = $("#taskCdChange").val();
	JsonObject.taskNm = $("#taskNmChange").val();
	JsonObject.caseNo = $("#caseNo").val();
	JsonObject.memo = $("#memo").val();
	JsonObject.age = $("#age").val();
	JsonObject.gen = $("#gen").val();
	JsonObject.regId = $("#regId").val();
	JsonObject.regDt = $("#regDt").val();
	
	var user_tr = $(".user_clone").length;
	
	var users = [];
	for(var j = 0; j < user_tr; j++){
		if($(".user_clone:eq("+j+")").find(".projCd").find(".input_text").val() == ""){
			alert("입력되지 않은 항목이 있습니다.");
			$(".user_clone:eq("+j+")").find(".projCd").find(".input_text").focus();
			return false;
		}else{
			users.push($(".user_clone:eq("+j+")").find(".projCd").find(".input_text").val());
		}
	}
	
	JsonObject.taskCase = JSON.stringify(users);
	
	$.ajax({
		url : CONTEXT_PATH + "/manager/taskCase.insert.do",
		type :"POST",
		async : false,
		dataType : "json",
		data : JsonObject
	})
	.done(function(data){
		
		var msg = data.p_ret_msg;
		var code = data.p_ret_code;
		
		if(code == 0){
			alert(msg);
		}else{
			alert(msg);
			return false;
		}
		
		opener.parent.location.reload();
		self.close();
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
//		alert(msg);
	});

	
	opener.parent.location.reload();
	self.close();
}


function fnUpdateData(updateYn){
	
//	var msg = confirm("현재 검수 작업 중인 검수자를 삭제할 경우\n작업이 중지되오니 반드시 확인 후 변경해주세요!");
	var msg = "";
//	if(msg){
		var bool = validation(updateYn);
		
		
		if(!bool){
			return false;
		}

		var user_array = new Array();
		var JsonObject = new Object();
		
		JsonObject.projCd = $("#projCd").val();
		JsonObject.projNm = $("#projNm").val();
		JsonObject.projCd = $("#taskCd").val();
		JsonObject.projNm = $("#taskNm").val();
		JsonObject.caseNo = $("#caseNo").val();
		JsonObject.memo = $("#memo").val();
		JsonObject.regId = $("#regId").val();
		JsonObject.regDt = $("#regDt").val();
		
		var user_tr = $(".user_clone").length;
		
		var users = [];
		for(var j = 0; j < user_tr; j++){
			if($(".user_clone:eq("+j+")").find(".projCd").find(".input_text").val() == ""){
				alert("입력되지 않은 항목이 있습니다.");
				$(".user_clone:eq("+j+")").find(".projCd").find(".input_text").focus();
				return false;
			}else{
				users.push($(".user_clone:eq("+j+")").find(".projCd").find(".input_text").val());
			}
		}
		
		JsonObject.tasks = JSON.stringify(users);
		
		$.ajax({
			url : CONTEXT_PATH + "/manager/taskCase.update.do",
			type :"POST",
			async : false,
			dataType : "json",
			data : JsonObject
		})
		.done(function(data){
			var msg="정상적으로 수정되었습니다.";
			
			var msg = data.p_ret_msg;
			var code = data.p_ret_code;
			
			if(code == 0){
				alert(msg);
			}else{
				alert(msg);
				return false;
			}
			
			self.close();
		})
		.fail(function(jqXHR, textStatus, errorThrown){
			var msg="처리에 실패 하였습니다.";
			msg += "\n관리자에게 문의 하세요.";
			
//			alert(msg);
		});
		
		opener.parent.location.reload();
		self.close();
//	}else{
//	    return false;
//	}
	
}


function validation(updateYn){
	
	if(updateYn != 'Y'){
		if($("#caseNo").val() == ""){
			alert("케이스 No는 필수 입력 사항입니다.");
			$("#caseNo").focus();
			return false;
		}
	}
	
	if($("#projNm").val() == ""){
		alert("프로그램 이름은 필수 입력 사항입니다.");
		$("#projNm").focus();
		return false;
	}
	
	if($("#taskNm").val() == ""){
		alert("태스크 이름은 필수 입력 사항입니다.");
		$("#taskNm").focus();
		return false;
	}
	return true;
}

$("#projCdChange,#projNmChange").on("mouseover",function(){
	
	if($("#projCdChange").val() == ''){
		
		$("#projCdChange").click();
//		alert("projCdChange");
		
	}
});

var eventCnt = 0;

$("#taskCdChange,#taskNmChange").on("mouseover",function(){
	
	if($("#projCdChange").val() != '' || !eventCnt ){
		if($("#taskCdChange").val() == ''){
			$("#taskCdChange").click();
//			alert("projCdChange");
			eventCnt++;
		}
	}
	
});











