$(document).ready(function() {
	
});

$(function(){
	fnSearch();
	
})

/** 선택한 요소의 결과를 부모창에 전달 **/
var saveItem = function(){
	
	var projCd = "";
	var projNm = "";
	
	if($(".selectBox span").length < 1){
		alert("선택된 정보가 없습니다. \n최소 하나 이상 선택해주세요.");
		return false;
	}
	
	$(".selectBox span.selectedBox").each(function(i){
		var id = $(this).attr("id").trim();
		var nm = $(this).find("input[type=hidden]").val();
		projCd = id;
		projNm = nm;
	})
	
	var manager = $("#manager").val();
	var index = $("#index").val();
	
	if(manager == 'Y'){
		$(".manager_clone[index="+index+"] .manager_id .input_text", parent.opener.document).val(projCd);
		$(".manager_clone[index="+index+"] .manager_name .input_text", parent.opener.document).val(projNm);
	}else if(manager == 'N'){
		var cnt = 0;
		$(parent.opener.document).find("#projectUserTableBody tr").each(function(i){
			if($(this).find(".projCd").find("input[type=text]").val() == projCd){
				alert("이미 추가되어 있습니다.");
				cnt += 1;
			}
		})
		
		if(cnt == 0){
			$(".user_clone[index="+index+"] .projCd .input_text", parent.opener.document).val(projCd);
			$(".user_clone[index="+index+"] .projNm .input_text", parent.opener.document).val(projNm);
		}
		
	}
	
	self.close();
	
}

var listPage = function(pageNo){
	var url = CONTEXT_PATH + "/manager/project.popup.search.do";
	
	var data = new Object();
	data.projCd = $("#projCd").val();
	data.projNm = $("#projNm").val();
	data.page_no = pageNo;
	data.row_size = 5;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRowPage("projectTable", json, pageNo, 5, "listPage");
	});
	
	var ids = new Array();
	$(".selectBox span.selectedBox").each(function(){
		var id = $(this).attr("id").trim();
		$("#projectTableBody tr").each(function(){
			var text = $(this).find("td:eq(1)").text().trim();
			if(text == id){
				$(this).find("td:eq(0) .checkbox").prop("checked", true);
			}
		})
	})
	
}

function fnSearch(){
	listPage(1);
}

/** row checkbox 선택 이벤트 **/
function addItem(obj){
	var attr = $(obj).find(".checkbox").is(":checked");
	var projCd = $(obj).parents("td").next().text().trim();
	var projNm = $(obj).parents("td").next().next().text().trim();
	
	if(attr){
		if($("#"+projCd+"").length == 0){
			// 한 명만 선택
			if(checkItem("row") == "excess"){
				$(".selectBox").find("#"+projCd+"").remove();
				$(".selectBox").find("#del_"+projCd+"").remove();
				$(obj).find(".checkbox").prop("checked", false);
			}else{
				$(".selectBox").append("<span id="+projCd+" class='selectedBox'>"+projCd+"<input type='hidden' value='"+projNm+"'/></span>");
				$(".selectBox").append("<span id='del_"+projCd+"' class='del_icon'><i class='btn btn-del' onclick='delItem(this)'>&nbsp;&nbsp;&nbsp;&nbsp;</i></span>");
			}
			
		}
		
	}else{
		$(".selectBox").find("#"+projCd+"").remove();
		$(".selectBox").find("#del_"+projCd+"").remove();
	}

}

/** 선택 개수 제한하기 위함 **/
function checkItem(row){
	if(row == "row"){
		if($(".selectBox span").length >= 1){
			alert("한 명만 선택 가능합니다.");
			return "excess";
		}
	}
	
}

/** selectedBox에서 지우기 **/
function delItem(obj){
	var id = $(obj).parents("span").attr("id");
	id = id.replace("del_", "");
	
	$(".selectBox").find("#"+id+"").remove();
	$(".selectBox").find("#del_"+id+"").remove();
	
	$("#projectTableBody tr").each(function(){
		var text = $(this).find("td:eq(1)").text().trim();
		if(text == id){
			$(this).find("td:eq(0) .checkbox").prop("checked", false);
		}
	})
	
}









