/*
	**************************
	2022.05. 
	태스크 관리 - 태스크 관리
	**************************
*/
$(".input_text").keydown(function (key) {
	if (key.keyCode == 13) {
		$("#search").click();
	}
});

$(function () {
	// Init
	setProjectList();
	setTaskTable();
});

/** 검색버튼 이벤트 */
$("#search").parent().click(function () {
	setTaskTable();
});

/** 태스크 수정 팝업 */
function popupModifyForm(val1, val2, val3, val4, val5) {
	var url = CONTEXT_PATH + "/manager/task/modifyForm.do"
	url += "?projCd=" + val1 + "&statYn=" + val2 + "&taskCd=" + val3 + "&taskNm=" + val4 + "&dataDir=" + val5;
	openPopup(url, "1024", "500", "POPUP_PROJECT_VIEW", "yes", "yes", "");

}

/** 태스크 등록 팝업 */
function popupRegistForm() {
//	var url = CONTEXT_PATH + "/manager/task/registForm.do?mode=regist";
	var url = CONTEXT_PATH + "/manager/task/registForm.do";
	openPopup(url, "1024", "500", "POPUP_USER_WRITE", "yes", "yes", "");
}

/** 프로젝트 select 박스 */
function setProjectList(obj) {
	var url = CONTEXT_PATH + "/work/crossValidation/getProjectList.do";
	var async = false;
	callAjax(url, null, async, function (json) {
		console.log("setProjectList RESPONSE");
		console.log(json);
		
		var rows = json.projectList;

		var html = "";
		html += "<tr><td><select name='projCdSelect' id='projCdSelect' class='projCdSelect' onchange='selectProject(this)'> ";
		for (i in rows) {
			const projCdSharing = getProjCdSharingCookie();
			if (rows[i].projCd == projCdSharing) {
			   html += "<option value='" + rows[i].projCd + "' style='font-size:16px;' selected>" + rows[i].projNm + "</option>";
			} else {
			   html += "<option value='" + rows[i].projCd + "' style='font-size:16px;'>" + rows[i].projNm + "</option>";
			}
		 }
		 html += " </select></td></tr>"
		 $("#tb_project2").html(html);
   
		 $("#projCdSelect").on("change", function () {
			setProjCdSharingCookie($("#projCdSelect").val());
		 });
	});
}

/** 프로젝트 선택 이벤트 */
function selectProject(obj) {
	setTaskTable();
	$("#search").click();
}

/** 테이블 데이터 */
function setTaskTable() {
	const data = {
		projCd: $("#projCdSelect").val(),
		projNmParam: $("#projCdSelect").val()
	}

	if (data.projCd != '') {
		$("#projCd_hide").val(data.projCd);
		$("#projCd").val(data.projCd);

		// 2022-07-19 모델에 저장된 선택 프로젝트 값 불러와서 셀렉트 하기
		//		$("#projCdSelect").val("2022B1").prop("selected",true)

		//		$("#projCd").val($("#projCd_hide").val());
	} else {
		$("#projCd_hide").val($('#projCd').val());
		//		$("#projCd").val($("#projCd_hide").val());
	}

	$("#taskCd_hide").val($('#taskCd').val());
	$("#taskNm_hide").val($('#taskNm').val());
	//	$("#userNm_hide").val($('#userNm').val());
	//	$("#dataDir_hide").val($('#dataDir').val());
	//	$("#dataRegYmd_hide").val($('#dataRegYmd').val());
	//	$("#statYn_hide").val($('#statYn option:selected').val());
	//	$("#regId_hide").val($('#regId option:selected').val());	

	const sendData = {
		projCd: $("#projCdSelect").val(),
		taskCd: $('#taskCd').val(),
		taskNm: $('#taskNm').val()
	}
	console.log("setTaskTable PARAM");
	console.log(sendData);

	// 2022-09-06 하드코딩 :: 폐음(2022B2) vs 나머지
	let userNm = "userNm";
	if (sendData.projCd == "2022B2") {
		userNm = "userNmFg";
	}
	
    $.jgrid.gridUnload("grid"); // 필수
	$("#grid").jqGrid({
		url: CONTEXT_PATH + "/manager/task/getTaskList.do",
		mtype: "POST",
		datatype: 'json',
		jsonReader: {
			root: "taskList",
		},
		postData: sendData,
		colNames: ['프로젝트 코드', '태스크 코드', '태스크 명', '진단자 및 검수자 명', '데이터 경로', '데이터셋 등록일', '통계 여부', '생성자 아이디', '등록 일자'],
		//	    colNames:['태스크 코드','태스크 명','진단자 및 검수자 명','데이터 경로','데이터셋 등록일','통계 여부','생성자 아이디','등록 일자'],
		colModel: [
			{ name: 'projCd', index: 'projCd', width: 150, align: "center", hidden: true },
			{ name: 'taskCd', index: 'taskCd', width: 180, align: "center", frozen: true },
			{ name: 'taskNm', index: 'taskNm', width: 180, align: "left", frozen: true },
			{ name: userNm, index: userNm, width: 180, align: "left" },
			{ name: 'dataDir', index: 'dataDir', width: 175, align: "center" },
			{ name: 'dataRegYmd', index: 'dataRegYmd', width: 175, align: "center" },
			{ name: 'statYn', index: 'statYn', width: 150, align: "center" },
			{ name: 'regId', index: 'regId', width: 150, align: "center" },
			{ name: 'regDt', index: 'regDt', width: 170, align: "center" },
		],
		rowNum: 9999,
		//	    rowList: [10,20,30],
		height: 400,
		loadonce: true,
		autowidth: true,    	 // jQgrid width 자동100% 채워지게
		shrinkToFit: false,  // width를 자동설정 해주는 기능
		gridview: true,
		cmTemplate: { sortable: false },
		rownumbers: true,
		//	    pager: '#pager',
		onCellSelect: function (rowid, icol, cellcontent, e) {
			var rowData = $(this).jqGrid("getRowData", rowid);
			popupModifyForm(rowData.projCd, rowData.statYn, rowData.taskCd, rowData.taskNm, rowData.dataDir);
		},
		viewrecords: true,
		loadComplete: function (response) {
			console.log("setTaskTable RESPONSE");
			console.log(response);

			var total = $("#grid").getGridParam("records");
			$("#list_num").text(total);
		},
		caption: " "
	});
	$("#grid").jqGrid("setFrozenColumns");
}

/** 엑셀 다운로드 */
function excelDown() {
	var url = CONTEXT_PATH + "/manager/task/excelTaskList.do";

	var data = new Object();
	data.projCd = $("#projCdSelect").prop("selected", true).val();
	data.taskCd = $('#taskCd').val();
	data.taskNm = $('#taskNm').val();

	$(".loading-image").show();

	$.fileDownload(url, {
		httpMethod: "POST",
		data: data,
		successCallback: function (url) {
			$(".loading-image").hide();
		},
		failCallback: function (responseHtml, url, error) {
			$(".loading-image").hide();
		}

	});

}


