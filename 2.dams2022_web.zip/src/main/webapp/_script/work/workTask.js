// ------------------------------------------------------------
// GLOBAL VARIABLE
// ------------------------------------------------------------

var taskCaseListSwiper; // TaskList Swiper.
var processMode;        // regist | modify
var projectType;        // A I S etc..

var curProjCd;
var curTaskCaseList;
var curTaskCase;

// check icon : label, cause, insp_res
const check_img_src = CONTEXT_PATH + "/_icon/check_white.png";
const check_img_html = format('<span class="check_mark"><img src="{0}"></span>', check_img_src);

// ------------------------------------------------------------
// UTIL
// ------------------------------------------------------------
function nullToNot(val) {
    return val == null || val == undefined || val == '' || val == 'null' || Number.isNaN(val) ? "<span style='color: red;'>없음</span>" : val; // 너무 야매다.
}

// ------------------------------------------------------------
// EVENT
// ------------------------------------------------------------
// 첫 로딩시. taskList 불러와서 마지막 작업한 case 열기.
init();
function init() {
    new Promise(function(resolve, reject) {
        resolve(getTaskList());
    }).then(function(result) {
        getLastWorkTask();
    });
}

setTaskCaseListSwiper();

$("#work_form_save_button").click(function() {
    const _workType = $(this).data("workType");
    const _mode = $(this).data("mode");
    console.log("work_form_save_button CLICKED");
    console.log("workType :: " + _workType);
    console.log("mode :: " + _mode);
    if (_workType == "diag") {
        processDiagnose(_mode);
    } else if (_workType == "insp") {
        processInspect(_mode);
    }
});

// 케이스 변경시 화면 전환 인지시켜주기 위한 기능. workForm hide, show
function workFormHide() {
    $("#main_section_body").stop(false, true);
    $("#work_form_div").stop(false, true);
    $("#main_section_body").hide();
    $("#work_form_div").hide();
}

function workFormShow() {
    $("#main_section_body").fadeIn(350);
    $("#work_form_div").fadeIn(350);
}

$("#search_task_form").submit(function(e) { // 검색.
    e.preventDefault();
    getTaskList();
});

function setWorkTaskSaveButton(workType, mode) {
    $("#work_form_save_button").data("workType", workType);
    $("#work_form_save_button").data("mode", mode);
}

$(document).on("click", ".task", function() {
    const sendData = {
        projCd: $(this).data("projCd"),
        taskCd: $(this).data("taskCd")
    }
    workFormHide();
    new Promise(function(resolve, reject) {
        resolve(getTaskCaseList(sendData));
    }).then(res => {
        const _caseNo = $(this).data("lastWorkCaseNo");
        clickCaseNo(_caseNo);
        swipeCheckedCase();
    });
    $("#work_form_div").empty();
    $("#case_no_div").text('');
});

$(document).on("click", ".task_case", function() {
    const sendData = {
        projCd: $(this).data("projCd"),
        taskCd: $(this).data("taskCd"),
        caseNo: $(this).data("caseNo")
    }
    curTaskCase = sendData;
    setTaskCaseResultOne(sendData);
});

// Work Side :: Task List 열고닫기.
$("#work_side_button").click(toggleWorkSide);
$(document).keydown(function(e) {
    if (e.key == "Escape") {
        toggleWorkSide();
    }
});

function toggleWorkSide() {
    if ($("#work_side").css("left") == "-260px") {
        // Open
        $("#work_side").css("left", "0px");
        $("#work_main").css("margin-left", "260px");
        $("#work_main").css("width", "calc(100% - 260px)");

        $("#work_footer").css("left", "260px");
        $("#work_footer").css("width", "calc(100% - 260px)");

        $("#work_side_button").text("TASK 목록 닫기");
    } else {
        // Close
        $("#work_side").css("left", "-260px");
        $("#work_main").css("margin-left", "0px");
        $("#work_main").css("width", "100%");

        $("#work_footer").css("left", "0");
        $("#work_footer").css("width", "100%");

        $("#work_side_button").text("TASK 목록 열기");
    }
}

/**
 * Toggle :: 원래 .checked 하는것보단 input=checkbox + label 로 하는게 좋지 않나?
 */
function clickCheckedEvent(selectorStr) {
    $(document).on("click", selectorStr, function() {
        $(selectorStr).removeClass("checked");
        $(this).addClass("checked");
    });
}
clickCheckedEvent(".task");
clickCheckedEvent(".task_case");
clickCheckedEvent(".label");
$(document).on("click", ".cause", function() {
    $(this).toggleClass("checked");
});

// Swiper Event
$(document).on("click", ".slide-start", function() {
    taskCaseListSwiper.slideTo(0, 300);

});
$(document).on("click", ".slide-left", function() {
    const swiperWidth = $("#task_case_swiper").width();
    const moveWidth = parseInt(swiperWidth / 86 - 1);
    taskCaseListSwiper.slideTo(taskCaseListSwiper.realIndex - moveWidth, 300);
});
$(document).on("click", ".slide-right", function() {
    const swiperWidth = $("#task_case_swiper").width();
    const moveWidth = parseInt(swiperWidth / 86 - 1);
    taskCaseListSwiper.slideTo(taskCaseListSwiper.realIndex + moveWidth, 300);
});
$(document).on("click", ".slide-end", function() {
    taskCaseListSwiper.slideTo(999, 300);
});

function swipeToIndex(index) {
    taskCaseListSwiper.slideTo(index, 0);
}

/**
 * 현재 선택되어 있는 케이스를 중앙으로 오게 스와이프 이동.
 */
function swipeCheckedCase() {
    const swiperWidth = $("#task_case_swiper").width();
    const moveWidth = parseInt(swiperWidth / 86 - 1);
    const halfIndex = parseInt(moveWidth / 2);
    const checkedCaseIndex = $(".task_case.checked").parent().index();
    taskCaseListSwiper.slideTo(checkedCaseIndex - halfIndex, 0);
}



// ------------------------------------------------------------
// 2022-09-14. 어쩔수 없음. 수면(2022A1) + 폐음(2022B2) waveSurfer 사운드 강제 삭제.
// ------------------------------------------------------------
// destroyWave 함수는 수면/폐음 폼마다 오버라이드 됨.
function destroWave() {}

// waveSurfer 강제 제거
$(document).on("submit", "#epoch_form", function () {
    destroyWave();
});
$(document).on("click", ".task", function () {
    destroyWave(); 
});
$(document).on("click", ".task_case", function () {
    destroyWave();
});
// 교차검증, 케이스 등록관리.
$(document).on("click", "tr[role=row]", function () {
    destroyWave();
});

// ------------------------------------------------------------
// FUNCTION (AJAX + SET)
// ------------------------------------------------------------
// 첫 응답시 최근 타스크 찾아감. 수정해야함.
function getLastWorkTask() {
    $.ajax({
        type: "post",
        url: CONTEXT_PATH + "/work/workTask/getLastWorkTask.do",
        async: false,
        dataType: "json",
        success: function(response) {
            console.log("getLastWorkTask RESPONSE");
            console.log(response);
            setLastWorkTask(response.lastWorkTask);
        },
        error: function(e) {
            console.log(e);
            alert("getInitData error");
        }
    });
}

function setLastWorkTask(data) {
    // TASK 가 아예 없을때
    if ($(".task").length < 1) {
        alert("작업할 Task가 없습니다.");
        return;
    }

    let _projCd = null;
    let _taskCd = null;
    let _caseNo = null;
    if (data == null || data == undefined) {
        _projCd = $(".task:first-child").data("projCd");
        _taskCd = $(".task:first-child").data("taskCd");
        _caseNo = null;
    } else {
        _projCd = data.projCd;
        _taskCd = data.taskCd;
        _caseNo = data.lastWorkCaseNo; // null일수도 있음.
    }
    new Promise(function(resolve, reject) {
        if (data == null) {
            const $task = $(".task:first-child");
            $task.addClass("checked");
            const sendData = {
                projCd: $task.data("projCd"),
                taskCd: $task.data("taskCd")
            }
            resolve(getTaskCaseList(sendData));
        } else {
            const $task = $(".task[data-proj-cd=" + _projCd + "][data-task-cd=" + _taskCd + "]");
            $task.addClass("checked");
            $("#task_list_div").scrollTop($task.index() * 72); // 72 한칸 고정값.
            const sendData = {
                projCd: _projCd,
                taskCd: _taskCd
            }
            resolve(getTaskCaseList(sendData));
            
        }
    }).then((result) => {
        if (_caseNo == null) {
            const $taskCase = $("#task_case_swiper .swiper-slide:first-child > .task_case");
            $taskCase.click();
        } else {
            const $taskCase = $(".task_case[data-case-no=" + _caseNo + "]");
            $taskCase.click();
        }
        console.log("SWIPE MONKEY");
        swipeCheckedCase();
    });
}

function clickCaseNo(caseNo) {
    if (caseNo == null || caseNo == undefined || caseNo == '' || caseNo == 'null') {
        const $taskCase = $("#task_case_swiper .swiper-slide:first-child > .task_case");
        $taskCase.click();
    } else {
        const $taskCase = $(".task_case[data-case-no=" + caseNo + "]");
        $taskCase.click();
    }
}

// Task 검색. : 많이 수정해야함.
function getTaskList() {
    sendData = {
        taskCd: $("#search_task_form > input[name=searchTask]").val(),
        taskNm: $("#search_task_form > input[name=searchTask]").val(),
        isSearch: "Y"
    };
    console.log(sendData);
    $.ajax({
        type: "post",
        url: CONTEXT_PATH + "/work/workTask/getTaskList.do",
        async: false,
        data: sendData,
        dataType: "json",
        success: function(response) {
            console.log(response);
            const taskList = response.taskList;
            setTaskList(taskList);
        },
        error: function(e) {
            console.log(e);
            alert("error");
        }
    });
}


function setTaskList(taskList) {
    console.log("setTaskList PARAM");
    console.log(taskList);
    const $div = $("#task_list_div");
    if (taskList.length < 1) {
        $div.html("<p class='text_center'>검색결과가 없습니다.</p>");
        return;
    }
    // 색상 속성값 : 시작전('':gray) | 진행중('ongoing':yellow) | 완료('completed':green)
    let _inputHtml = "<ul>"
    for (let i in taskList) {
        const _taskOne = taskList[i];
        let _percentage = Math.round(Number(_taskOne.workCnt) / Number(_taskOne.caseCnt) * 10 * 100) / 10;
        _percentage = isNaN(_percentage) ? 0 : _percentage;
        let colorClass = ''
        if (0 < _percentage && _percentage < 100) {
            colorClass = 'ongoing';
        } else if (_percentage == 100) {
            colorClass = 'completed';
        }
        _inputHtml += format('<li class="task {0}" data-proj-cd="{1}" data-task-cd="{2}" data-last-work-case-no="{3}">', colorClass, _taskOne.projCd, _taskOne.taskCd, _taskOne.lastWorkCaseNo);
        _inputHtml += format('<span class="task_cd">{0}</span>', _taskOne.taskCd);
        _inputHtml += format('<span class="progress">{0}/{1}({2}%)</span><br><p class="task_nm">{3}</p></li>', _taskOne.workCnt, _taskOne.caseCnt, _percentage, _taskOne.taskNm);
    }
    _inputHtml += "</ul>";
    $div.html(_inputHtml);

}


// CaseList 불러옴.
function getTaskCaseList(sendData) {
    if (sendData == null) {
        sendData = {
            projCd: $(".task.checked").data("projCd"),
            taskCd: $(".task.checked").data("taskCd")
        }
    }
    console.log(sendData);
    $.ajax({
        type: "post",
        url: CONTEXT_PATH + "/work/workTask/getTaskCaseList.do",
        data: sendData,
        async: false,
        dataType: "json",
        success: function(response) {
            console.log("getTaskCaseList RESPONSE");
            console.log(response);
            curTaskCaseList = response;
            new Promise(function(resolve, reject) {
                resolve(loadProjectFormHtml(sendData.projCd));
            }).then(res => {
                const taskCaseResultList = response.data;
                setTaskCaseList(taskCaseResultList);
                setTaskCaseListSwiper();
            });
        },
        error: function(e) {
            console.log(e);
            alert("error");
        }
    });
}

function getTaskCaseList2(sendData) {
    $.ajax({
        type: "post",
        url: CONTEXT_PATH + "/work/workTask/getTaskCaseList.do",
        data: sendData,
        async: false,
        dataType: "json",
        success: function (response) {
            const taskCaseResultList = response.data;
            setTaskCaseList(taskCaseResultList);
            setTaskCaseListSwiper();
        },
        error: function(e) {
            console.log(e);
            alert("error");
        }
    });
}

// 프로젝트 폼 로드
function loadProjectFormHtml(projCd) {
    // 이벤트 누적 방지
    $("#task_case_list_div").off();
    $("#main_section_body").off();

    // 캐시 누적 방지 + url 생성
    const date = new Date().toISOString().replaceAll("-", "").replaceAll("T", "_").replaceAll(":", "");
    const date2 = date.substring(0, date.indexOf("."));
    const _htmlUrl = CONTEXT_PATH + "/_html/workTask/" + projCd + ".html?dt=" + date2;
    console.log("loadProject URL");
    console.log(_htmlUrl);
    
    // 애니메이션 정지
    const $body = $("#main_section_body");
    $body.stop(false, true);
    $body.fadeOut(0);
    $body.empty();
    $.ajax({
        type: "get",
        url: _htmlUrl,
        async: false,
        dataType: "text",
        success: function(response) {
            // console.log(response); // 너무 김.
            $body.html(response);
            curProjCd = projCd;
        }
    });
}

// TaskCaseList 색상 정하기
/*
    색상 지정

    총 경우의 수.
    [1] 미진행 - gray - diag_regist
    [2] 진단 완료, 내가 라벨링함. - yellow - diag_modify
    [3] 진단 완료, 검수 해야됨. - orange - insp_regist
    [4] 진단 완료, 검수 나만 완료. - blue - insp_modify
    [5] 검수 완료 pass. - green - insp_modify
    [6] 검수 완료 fail. - red - insp_modify

    칼라. 내기준.
    [1] 미진행 - gray
    [2] 검수 해야함 - yellow
    [3] 진단/검수 완료 - green
*/
function setTaskCaseList(caseList) {
    $("#task_case_swiper .swiper-wrapper").stop(false, true);
    $("#task_case_swiper .swiper-wrapper").fadeOut(0);
    $("#task_case_swiper .swiper-wrapper").empty();
    $("#task_case_swiper .swiper-wrapper").css("transform", "");
    let _inputHtml = "";
    for (i in caseList) {
        const _caseOne = caseList[i];
        const _statusCd = _caseOne.statusCd;
        let statusClass = "";
        if (_statusCd == "yellow") {
            statusClass = 'to_inspect';
        } else if (_statusCd == "green") {
            statusClass = "completed";
        }

        // (2) 라벨 보여주기.
        let lblDisp = _caseOne.lblDisp;
        lblDisp = lblDisp != null && lblDisp != undefined ? "<br>" + lblDisp : "";
        _inputHtml += format('<div class="swiper-slide"><div class="task_case {0}" data-proj-cd="{1}" data-task-cd="{2}" data-case-no="{3}">{4}{5}</div></div>', statusClass, _caseOne.projCd, _caseOne.taskCd, _caseOne.caseNo, Number(i) + 1, lblDisp);
    }
    $("#task_case_swiper .swiper-wrapper").html(_inputHtml);
    $("#task_case_swiper .swiper-wrapper").fadeIn(750);
}

// TaskCaseList Swiper
function setTaskCaseListSwiper() {
    taskCaseListSwiper = new Swiper("#task_case_swiper", {
        slidesPerView: 'auto',
        spaceBetween: 0
    });
}

// TaskResult, Label, Cause
function setTaskCaseResultOne(sendData) {
    if (sendData == null) {
        sendData = {
            projCd: $(".task_case.checked").data("projCd"),
            taskCd: $(".task_case.checked").data("taskCd"),
            caseNo: $(".task_case.checked").data("caseNo")
        }
    }
    console.log("setTaskCaseResultOne PARAM");
    console.log(sendData);
    $.ajax({
        type: "post",
        url: CONTEXT_PATH + "/work/workTask/getTaskCaseResultOne.do",
        data: sendData,
        async: false,
        dataType: "json",
        success: function(response) {
            console.log("setTaskCaseResultOne RESPONSE")
            console.log(response);
            curTaskCase = response.data;
            setCaseWorkForm(response);
            $("#case_no_div").html("(Case No: " + sendData.caseNo + ")");
        },
        error: function(e) {
            console.log(e);
            alert("error");
        }
    });
}

// ------------------------------------------------------------
// Work Form
// ------------------------------------------------------------
/*
기존: diagProcess - diagForm | inspProcess - inspForm :: 1대1대응
변경: process - diag, insp
      labelCauseForm, passFailForm :: 프로젝트 코드에 따라서 진단검수 배치가 다름.(이제 1대1대응 아님.)


*/

// Case WorkForm 세팅.
function setCaseWorkForm(response) {
    /*
    (1) progress(진행상황)
    (2) labelList(라벨)
    (3) causeList(원인)
    */
    $("#main_section_body").stop(false, true);
    workFormHide();

    const statusCd = response.statusCd;
    console.log("stateCd", statusCd);

    // [1] data One
    // 기능 삭제함. 일단 주석처리만. 0630
    // setTaskResult(response.dataList); // 진행상황

    const _labelList = response.labelList;
    const _causeList = response.causeList;
    // [2] workTask
    if (statusCd == "D") {
        processMode = "diag";
        setDiagRegistForm(_labelList, _causeList);
        setWorkTaskSaveButton("diag", "regist");
    } else if (statusCd == "DC") {
        processMode = "diag";
        setDiagModifyForm(response.data, _labelList, _causeList);
        setWorkTaskSaveButton("diag", "modify");
    } else if (statusCd == "DCB") {
        processMode = "diag";
        setDiagModifyBlockForm(response.data, _labelList, _causeList);
        setWorkTaskSaveButton("diag", "block");
    } else if (statusCd == "I") {
        processMode = "insp";
        setInspRegistForm(_causeList);
        setWorkTaskSaveButton("insp", "regist");
    } else if (statusCd == "IC") {
        processMode = "insp";
        setInspModifyForm(response.data, _causeList);
        setWorkTaskSaveButton("insp", "modify");
    } else if (statusCd == "IB") {
        processMode = "insp";
        setInspBlockForm(response.data, _causeList);
        setWorkTaskSaveButton("insp", "block");
    } else if (statusCd == "C") {
        // 완전 끝나고 수정 못하게 막을때. 필요한가?
    }
    workFormShow();
}


// 진단 등록 폼.
function setDiagRegistForm(labelList, causeList) {
    const $div = $("#work_form_div");
    let _inputHtml = "";
    _inputHtml += '<div id="diag_form_div">';
    _inputHtml += '    <div class="work_title_div">';
    _inputHtml += '        <h3 class="work_title">진단 등록</h3>';
    _inputHtml += '    </div>';
    _inputHtml += '    <div class="work_separate"></div>';
    _inputHtml += '    <div class="form_div">';
    _inputHtml += '        <table>';
    _inputHtml += '            <tbody>';
    _inputHtml += '                <tr>';
    _inputHtml += '                    <th>라벨</th>';
    _inputHtml += '                    <td class="label_td">';
    _inputHtml += '                        <div class="label_list_div"></div>';
    // _inputHtml += '                        <button id="regist_diag_button" class="work_save_button">저장</button>';
    _inputHtml += '                        <div id="work_form_block_msg"></div>';
    _inputHtml += '                    </td>';
    _inputHtml += '                </tr>';
    _inputHtml += '                <tr>';
    _inputHtml += '                    <th>원인</th>';
    _inputHtml += '                    <td class="cause_td">';
    _inputHtml += '                        <div class="cause_list_div"></div>';
    _inputHtml += '                    </td>';
    _inputHtml += '                </tr>';
    _inputHtml += '                <tr>';
    _inputHtml += '                    <th>메모</th>';
    _inputHtml += '                    <td class="memo_td">';
    _inputHtml += '                        <textarea placeholder="메모" name="memo"></textarea>';
    _inputHtml += '                    </td>';
    _inputHtml += '                </tr>';
    _inputHtml += '            </tbody>';
    _inputHtml += '        </table>';
    _inputHtml += '    </div>';
    _inputHtml += '</div>';

    $div.html(_inputHtml);
    
    // 라벨 그리기.
    const $diagLabel = $("#diag_form_div .label_list_div");
    $diagLabel.stop(false, true);
    $diagLabel.empty();
    _inputHtml = "<ul>";
    for (let i in labelList) {
        const label = labelList[i];
        _inputHtml += format('<li class="label" data-lbl-cd="{0}" data-lbl-disp="{1}">{2}{1}</li>', label.lblCd, label.lblDisp, check_img_html);
    }
    _inputHtml += "</ul>";
    $diagLabel.html(_inputHtml);

    // 원인 그리기.
    const $diagCause = $("#diag_form_div .cause_list_div");
    $diagCause.stop(false, true);
    $diagCause.empty();
    _inputHtml = "<ul>";
    for (let i in causeList) {
        const cause = causeList[i];
        _inputHtml += format('<li class="cause" data-fail-caus-cd="{0}" data-fail-caus-nm="{1}">{2}{1}</li>', cause.failCausCd, cause.failCausNm, check_img_html);
    }
    _inputHtml += "</ul>";
    $diagCause.html(_inputHtml);

    $("#work_title").text("진단");

    // 폐음 진단
    if (curProjCd == '2022B2') {
        $("#work_title").text("데이터확인(디스크립션)");
        $(".memo_td").prev().text("Desciption");
        $(".memo_td > [name=memo]").attr("placeholder", "Description");
    }

    return true;
}

// 진단 수정 폼.
function setDiagModifyForm(data, labelList, causeList) {
    new Promise(function(resolve, reject) {
        resolve(setDiagRegistForm(labelList, causeList));
    }).then((result) => {
        const $labelList = $("#diag_form_div .label_list_div > ul > li");
        for (let i = 0; i < $labelList.length; i++) {
            if ($labelList[i].dataset.lblCd == data.lblCd) {
                $labelList[i].classList.add("checked");
            }
        }
        if (data.failCausList != undefined) {
            const causeList = data.failCausList.split("/");
            const $causeList = $("#diag_form_div .cause_list_div > ul > li");
            for (let i = 0; i < $causeList.length; i++) {
                for (let k = 0; k < causeList.length; k++) {
                    if ($causeList[i].dataset.failCausNm == causeList[k]) {
                        $causeList[i].classList.add("checked");
                    }
                }
            }
        }
        if (data.memo != undefined) {
            $("#diag_form_div textarea[name=memo]").val(data.memo);
        }

        $("#regist_diag_button").attr("id", "modify_diag_button");
        $("#diag_form_div .work_title").text("진단 수정");
    });
}

// 진단 수정 블락 폼.
function setDiagModifyBlockForm(data, labelList, causeList) {
    new Promise(function(resolve, reject) {
        resolve(setDiagRegistForm(labelList, causeList));
    }).then((result) => {
        const $labelList = $("#diag_form_div .label_list_div > ul > li");
        for (let i = 0; i < $labelList.length; i++) {
            if ($labelList[i].dataset.lblCd == data.lblCd) {
                $labelList[i].classList.add("checked");
            }
        }
        if (data.failCausList != undefined) {
            const causeList = data.failCausList.split("/");
            const $causeList = $("#diag_form_div .cause_list_div > ul > li");
            for (let i = 0; i < $causeList.length; i++) {
                for (let k = 0; k < causeList.length; k++) {
                    if ($causeList[i].dataset.failCausNm == causeList[k]) {
                        $causeList[i].classList.add("checked");
                    }
                }
            }
        }
        if (data.memo != undefined) {
            $("#diag_form_div textarea[name=memo]").val(data.memo);
        }

        // $("#regist_diag_button").parent().append("<span style='color: red; font-size: 11px;'> 검수가 진행되어 진단수정이 불가능합니다.</span>");
        $("#work_form_block_msg").html("<span style='color: red; font-size: 11px;'> 검수가 진행되어 진단수정이 불가능합니다.</span>");
        $("#regist_diag_button").remove();
        $("#diag_form_div .work_title").text("진단 수정");
    });
}


// 검수 등록 폼.
function setInspRegistForm(causeList) {
    const $div = $("#work_form_div");
    let _inputHtml = "";
    _inputHtml += '<div id="insp_form_div">';
    _inputHtml += '    <div class="work_title_div">';
    _inputHtml += '        <h3 class="work_title">검수 등록</h3>';
    _inputHtml += '    </div>';
    _inputHtml += '    <div class="work_separate"></div>';
    _inputHtml += '    <div class="form_div">';
    _inputHtml += '        <table>';
    _inputHtml += '            <tbody>';
    _inputHtml += '                <tr>';
    _inputHtml += '                    <th>결과</th>';
    _inputHtml += '                    <td class="res_td">';
    _inputHtml += '                        <div class="insp_res_div">';
    _inputHtml += '                            <input type="radio" id="insp_res_pass" name="inspRes" value="Y"><label for="insp_res_pass">'+check_img_html+'Pass</label>';
    _inputHtml += '                            <input type="radio" id="insp_res_fail" name="inspRes" value="N"><label for="insp_res_fail">'+check_img_html+'Fail</label>';
    _inputHtml += '                        </div>';
    // _inputHtml += '                        <button id="regist_insp_button" class="work_save_button">저장</button>';
    _inputHtml += '                        <div id="work_form_block_msg"></div>';
    _inputHtml += '                    </td>';
    _inputHtml += '                </tr>';
    _inputHtml += '                <tr>';
    _inputHtml += '                    <th>원인</th>';
    _inputHtml += '                    <td class="cause_td">';
    _inputHtml += '                        <div class="cause_list_div"></div>';
    _inputHtml += '                    </td>';
    _inputHtml += '                </tr>';
    _inputHtml += '                <tr>';
    _inputHtml += '                    <th>메모</th>';
    _inputHtml += '                    <td class="memo_td">';
    _inputHtml += '                        <textarea placeholder="메모" name="memo"></textarea>';
    _inputHtml += '                    </td>';
    _inputHtml += '                </tr>';
    _inputHtml += '            </tbody>';
    _inputHtml += '        </table>';
    _inputHtml += '    </div>';
    _inputHtml += '</div>';
    $div.html(_inputHtml);

    // 원인 그리기.
    const $inspCause = $("#insp_form_div .cause_list_div");
    $inspCause.stop(false, true);
    $inspCause.empty();
    _inputHtml = "<ul>";
    for (let i in causeList) {
        const cause = causeList[i];
        _inputHtml += format('<li class="cause" data-fail-caus-cd="{0}" data-fail-caus-nm="{1}">{2}{1}</li>', cause.failCausCd, cause.failCausNm, check_img_html);
    }
    _inputHtml += "</ul>";
    $inspCause.html(_inputHtml);

    $("#work_title").text("검수");

    return true;
}

// 검수 수정 폼.
function setInspModifyForm(data, causeList) {
    new Promise(function(resolve, reject) {
        resolve(setInspRegistForm(causeList));
    }).then((result) => {
        if (data.inspRes != undefined) {
            if (data.inspRes == 'Pass') {
                $("#insp_form_div input[name=inspRes][value=Y]").attr("checked", "checked");
            } else {
                $("#insp_form_div input[name=inspRes][value=N]").attr("checked", "checked");
            }
        }
    
        if (data.inspFailCausList != undefined) {
            const causeList = data.inspFailCausList.split("/");
            const $causeList = $("#insp_form_div .cause_list_div > ul > li");
            for (let i = 0; i < $causeList.length; i++) {
                for (let k = 0; k < causeList.length; k++) {
                    if ($causeList[i].dataset.failCausNm == causeList[k]) {
                        $causeList[i].classList.add("checked");
                    }
                }
            }
        }
        if (data.inspMemo != undefined) {
            $("#insp_form_div textarea[name=memo]").val(data.inspMemo);
        }

        $("#regist_insp_button").attr("id", "modify_insp_button");
        
        $("#insp_form_div .work_title").text("검수 수정");
    });
}

// 검수 블락 폼
function setInspBlockForm(data, causeList) {
    new Promise(function(resolve, reject) {
        resolve(setInspRegistForm(causeList));
    }).then((result) => {
        if (data.inspRes != undefined) {
            if (data.inspRes == 'Pass') {
                $("#insp_form_div input[name=inspRes][value=Y]").attr("checked", "checked");
            } else {
                $("#insp_form_div input[name=inspRes][value=N]").attr("checked", "checked");
            }
        }
    
        if (data.inspFailCausList != undefined) {
            const causeList = data.inspFailCausList.split("/");
            const $causeList = $("#insp_form_div .cause_list_div > ul > li");
            for (let i = 0; i < $causeList.length; i++) {
                for (let k = 0; k < causeList.length; k++) {
                    if ($causeList[i].dataset.failCausNm == causeList[k]) {
                        $causeList[i].classList.add("checked");
                    }
                }
            }
        }
        if (data.inspMemo != undefined) {
            $("#insp_form_div textarea[name=memo]").val(data.inspMemo);
        }
        // $("#regist_insp_button").parent().append("<span style='color: red; font-size: 11px;'> 아직 진단이 완료되지 않아 검수가 불가능합니다.</span>")
        $("#work_form_block_msg").html("<span style='color: red; font-size: 11px;'> 아직 진단이 완료되지 않아 검수가 불가능합니다.</span>");
        $("#regist_insp_button").remove();
        $("#insp_form_div .work_title").text("검수 등록");
    });
}


// 삭제된 기능.
function setTaskResult(taskResultList) {
    const $div = $("#user_work_result_div");
    // [1] 진단 전, 진단자/검수자 구분. 검수했냐?
    // diagUserId가 있냐?, usernm과 diag_user_nm이 같냐?
    let _inputHtml = "";
    if (taskResultList[0].diagUserId == null) {
        _inputHtml += "<table><tbody><tr>";
        _inputHtml += "<th>담당자 : </th>";
        _inputHtml += "<td>";
        for (i in taskResultList) {
            if (i != 0) {
                _inputHtml += ", ";
            }
            _inputHtml += format("<span>{0}({1})</span>", taskResultList[i].userNm, taskResultList[i].userId);
        }
        _inputHtml += "</td></tr><tr>";
        _inputHtml += "</th colspan='2'>현재 진행된 사항 없음</th>";
        _inputHtml += "</tr></tbody></table>";
        $div.html(_inputHtml);
        return;
    }

    let _diagRow = ""; // 1개
    let _inspRowList = []; // 2개
    for (i in taskResultList) {
        const _one = taskResultList[i];
        if (_one.userId == _one.diagUserId) {
            _diagRow = _one;
        } else {
            _inspRowList.push(_one);
        }
    }

    _inputHtml = "<table>";
    _inputHtml += format("<tr>");
    _inputHtml += format("<th>구분</th>");
    _inputHtml += format("<th>담당자</th>");
    _inputHtml += format("<th>결과</th>");
    _inputHtml += format("<th>원인</th>");
    _inputHtml += format("<th>메모</th>");
    _inputHtml += format("<tr>");

    _inputHtml += format("<tr>");
    _inputHtml += format("<td>진단자</td>");
    _inputHtml += format("<td>{0}({1})</td>", nullToNot(_diagRow.userNm), nullToNot(_diagRow.userId));
    _inputHtml += format("<td>{0}</td>", nullToNot(_diagRow.lblDisp));
    _inputHtml += format("<td>{0}</td>", nullToNot(_diagRow.failCausList));
    _inputHtml += format("<td>{0}</td>", nullToNot(_diagRow.memo));
    _inputHtml += format("<tr>");
    for (i in _inspRowList) {
        _inputHtml += format("<tr>");
        if (i == 0) {
            _inputHtml += format("<td rowspan='3'>검수자</td>");
        }
        _inputHtml += format("<td>{0}({1})</td>", nullToNot(_inspRowList[i].userNm), nullToNot(_inspRowList[i].userId));
        if (_inspRowList[i].inspRes == null || _inspRowList[i] == undefined) {
            _inputHtml += format("<td colspan='3'>미진행</td>");
        } else {
            _inputHtml += format("<td>{0}</td>", nullToNot(_inspRowList[i].inspRes));
            _inputHtml += format("<td>{0}</td>", nullToNot(_inspRowList[i].inspFailCausList));
            _inputHtml += format("<td>{0}</td>", nullToNot(_inspRowList[i].inspMemo));
        }
        _inputHtml += format("<tr>");
    }
    _inputHtml += "</table>";
    $div.html(_inputHtml);
}


// ------------------------------------------------------------
// Work Form Process
// ------------------------------------------------------------
// Diagnose
function processDiagnose(mode, param) {
    // MODE = regist | modify
    let _sendUrl;
    if (mode == "regist") {
        _sendUrl = "/work/workTask/registDiagnose.do"
    } else if (mode == "modify") {
        _sendUrl = "/work/workTask/modifyDiagnose.do"
    } else {
        return;
    }

    // valid 1. 라벨 선택 필수.
    if ($("#diag_form_div .label.checked").length < 1) {
        alert("라벨을 선택해 주세요.");
        return;
    }
    // valid 2. Drop 선택했으면 cause나 memo 둘중하나는 필수.
    if ($(".label[data-lbl-disp='Drop'].checked").length > 0) {
        const _causeLength = $(".cause.checked").length;
        const _memoLength = $("textarea[name=memo]").val().length;
        if (_causeLength + _memoLength < 1) {
            alert("Drop을 원하시면 원인을 1개 이상 선택하시거나 메모를 입력해주세요.");
            return;
        }
    }

    // SEND DATA
    let failCausCdList = []
    let causeCheckedList = document.querySelectorAll("#diag_form_div .cause.checked");
    for (let i = 0; i < causeCheckedList.length; i++) {
        failCausCdList.push(causeCheckedList[i].dataset.failCausCd)
    }
    let sendData = {
        projCd: $("#task_case_list_div .task_case.checked").data("projCd"),
        taskCd: $("#task_case_list_div .task_case.checked").data("taskCd"),
        caseNo: $("#task_case_list_div .task_case.checked").data("caseNo"),
        lblCd: $('#diag_form_div .label.checked').data("lblCd"),
        memo: $('#diag_form_div textarea[name=memo]').val(),
        failCausCdList: JSON.stringify(failCausCdList)
    };
    if (param != null && param != undefined) {
        sendData = Object.assign(sendData, param);
    }

    // 폐음
    if (sendData.projCd == '2022B2') {
        if ($("#diag_form_div .label.checked").data("lblDisp") == 'Pass') {
            const _goodLength = $(".good_best_div .good.checked").length;
            if (_goodLength != 4) {
                if (_goodLength < 4) {
                    alert("Good을 4개 선택해 주십시오.");
                    return;
                } else {
                    alert("Good을 4개까지만 선택해 주십시오.");
                    return;
                }
            } else if ($(".good_best_div .best.checked").length < 1) {
                alert("Best를 선택해 주십시오.");
                return;
            }
        }

        const _memo = sendData.memo;
        if (_memo == null || _memo == undefined || _memo == '') {
            alert("Description을 입력해 주십시오.");
            return;
        }

        let lungGoodList = []
        let $goodCheckedList = $(".good_best_div .good.checked");
        for (let i=0; i<$goodCheckedList.size(); i++) {
            lungGoodList.push($goodCheckedList[i].dataset.loc);
        }
    
        let lungSoundParam = {
            lungGoodList: JSON.stringify(lungGoodList),
            lungBest: $(".good_best_div .best.checked").data("loc")
        }
        sendData = Object.assign(sendData, lungSoundParam);
    }
    console.log("processDiagnose PARAM");
    console.log(sendData);

    showLoading();

    // REQUEST
    $.ajax({
        type: "post",
        url: CONTEXT_PATH + _sendUrl,
        data: sendData,
        dataType: "json",
        success: function(response) {
            console.log("processDiagnose RESPONSE");
            console.log(response);
            if (response.success) {
                procRefresh(sendData);
                if (mode == "regist") {
                    // $("#regist_diag_button").attr("id", "modify_diag_button");
                    setWorkTaskSaveButton("diag", "modify");
                    $("#diag_form_div .work_title").text("진단 수정");
                    changeNextCase();
                }
            } else {
                if (response.msg != null && response.msg != undefined) {
                    alert(response.msg);
                } else {
                    alert("no msg");
                }
                procRefresh(sendData);
            }
        },
        error: function(e) {
            console.log(e);
            alert("error");
        },
        complete: function() {
            hideLoading();
        }
    });
}

// Inspect
function processInspect(mode, param) {
    // MODE
    let _sendUrl;
    if (mode == "regist") {
        _sendUrl = "/work/workTask/registInspect.do"
    } else if (mode == "modify") {
        _sendUrl = "/work/workTask/modifyInspect.do"
    } else {
        return;
    }

    // valid 1. 결과 선택 필수.
    if ($("#insp_form_div input[name=inspRes]:checked").length < 1) {
        alert("결과를 선택해 주세요.");
        return;
    }
    // valid 2. Fail 선택했으면 cause나 memo 둘중하나는 필수.
    if ($("#insp_res_fail:checked").length > 0) {
        const _causeLength = $(".cause.checked").length;
        const _memoLength = $("textarea[name=memo]").val().length;
        if (_causeLength + _memoLength < 1) {
            alert("Fail을 원하시면 원인을 1개 이상 선택하시거나 메모를 입력해주세요.");
            return;
        }
    }

    // SEND DATA
    let failCausCdList = []
    let causeCheckedList = document.querySelectorAll("#insp_form_div .cause.checked");
    for (let i = 0; i < causeCheckedList.length; i++) {
        failCausCdList.push(causeCheckedList[i].dataset.failCausCd)
    }
    const sendData = {
        projCd: $("#task_case_list_div .task_case.checked").data("projCd"),
        taskCd: $("#task_case_list_div .task_case.checked").data("taskCd"),
        caseNo: $("#task_case_list_div .task_case.checked").data("caseNo"),
        inspRes: $('#insp_form_div input[name=inspRes]:checked').val(),
        memo: $('#insp_form_div textarea[name=memo]').val(),
        failCausCdList: JSON.stringify(failCausCdList)
    };
    if (param != null && param != undefined) {
        sendData = Object.assign(sendData, param);
    }
    console.log("processInspect PARAM");
    console.log(sendData);

    showLoading();

    // REQUSET
    $.ajax({
        type: "post",
        url: CONTEXT_PATH + _sendUrl,
        data: sendData,
        dataType: "json",
        success: function(response) {
            console.log("processInspect RESPONSE");
            console.log(response);
            if (response.success) {
                // 케이스 새로고침.
                procRefresh(sendData);
                if (mode == "regist") {
                    // $("#regist_insp_button").attr("id", "modify_insp_button");
                    setWorkTaskSaveButton("insp", "modify");
                    $("#insp_form_div .work_title").text("검수 수정");
                    changeNextCase();
                }
            } else {
                if (response.msg != null && response.msg != undefined) {
                    alert(response.msg);
                } else {
                    alert("no msg");
                }
                procRefresh(sendData);
            }
        },
        error: function(e) {
            console.log(e);
            alert("error");
        },
        complete: function() {
            hideLoading();
        }
    });
}

function procRefresh(sendData) {
    if (sendData == null || sendData == undefined) {
        sendData = {
            projCd: $("#task_case_list_div .task_case.checked").data("projCd"),
            taskCd: $("#task_case_list_div .task_case.checked").data("taskCd"),
            taskCd: $("#task_case_list_div .task_case.checked").data("caseNo")
        }
    }
    const _caseNo = sendData.caseNo;
    sendData.caseNo = undefined;
    // task refresh

    let _caseSwiperIndex = 0  // case 기존 위치. caseList 새로고침되도 위치 유지되도록 하기 위한 변수.

    // 기존
    // new Promise(function(resolve1, reject1) {
    //     new Promise(function(resolve2, reject2) {
    //         resolve2(getTaskList());
    //     }).then(res => {
    //         const $task = $(format(".task[data-proj-cd={0}][data-task-cd={1}]", sendData.projCd, sendData.taskCd));
    //         $task.addClass("checked");
    //         // case refresh
    //         _caseSwiperIndex = taskCaseListSwiper.realIndex;
    //         resolve1(getTaskCaseList2(sendData));
    //     });
    // }).then(res => {
    //     const $case = $(format(".task_case[data-proj-cd={0}][data-task-cd={1}][data-case-no={2}]", sendData.projCd, sendData.taskCd, _caseNo));
    //     $case.addClass("checked");
    //     swipeToIndex(_caseSwiperIndex);
    // });

    // NEW (promise 다 없앰 굳이 안해도 잘 되는듯 비동기 처리되는건 ajax 하나만 그런거라 ajax하나만 다시 동기처리해주면 나머지는 알아서 동기처리 되서 promise 굳이 안써도 된다. 아마? 착각하고 있었음.) 
    getTaskList()
    const $task = $(format(".task[data-proj-cd={0}][data-task-cd={1}]", sendData.projCd, sendData.taskCd));
    $task.addClass("checked");
    // case refresh
    _caseSwiperIndex = taskCaseListSwiper.realIndex;
    getTaskCaseList2(sendData)
    
    const $case = $(format(".task_case[data-proj-cd={0}][data-task-cd={1}][data-case-no={2}]", sendData.projCd, sendData.taskCd, _caseNo));
    $case.addClass("checked");
    swipeToIndex(_caseSwiperIndex);
}


/**
 * 
 */
var abcBanana;
let abcBanana2;
function changeNextCase() {
    /*
    caseList 는 refresh 된 상태.
    여기서 한칸씩 오른쪽으로 가면서 검사. 오른쪽이 모두 완료 되었으면 처음으로 돌아와서 검사 시작.
    일단 현재 위치 저장. 한바퀴 돌고 현재 위치로 다시 오게 된다면 alert("case를 모두 완료 하였습니다.");
    */
    let $curCase = $(".task_case.checked");
    let initCaseNo = $curCase.data("caseNo");
    while (true) {
        let $nextCase = $curCase.parent().next().find(".task_case");
        if ($nextCase.length > 0) {
            // pass
        } else {
            $nextCase = $("div:first-child > .task_case");
        }
        
        // valid 1. 한바퀴 모두 돌았나?
        const nextCaseNo = $nextCase.data("caseNo");
        if (initCaseNo == nextCaseNo) {
            // alert("더 이상 작업할 case가 없습니다.");
            return;
        }

        // 완료 유무 검사.
        let isComplete = $nextCase.hasClass("completed");
        if (isComplete) {
            $curCase = $nextCase;
        } else {
            $nextCase.click();
            swipeCheckedCase();
            return nextCaseNo; // 사용은 안함.
        }
    }

}