// -------------------------------------------------------
// UTIL
// -------------------------------------------------------
function nullToNot(val) {
	return val == null || val == undefined || val == '' || val == 'null' || Number.isNaN(val) ? "<span style='color: red;'>없음</span>" : val; // 너무 야매다.
}

function clickCheckedEvent(selectorStr) {
	$(document).on("click", selectorStr, function () {
		$(selectorStr).removeClass("checked");
		$(this).addClass("checked");
	});
}

function showProjectForm() {
	$("#main_section_body").show();
}

function hideProjectForm() {
	$("#main_section_body").hide();
}

// -------------------------------------------------------
// GLOBAL VARIABLE
// -------------------------------------------------------
// 폐음관련 임의 설정.
var processMode = "insp";

// 현재 케이스 {projCd, taskCd, caseNo}
var curTaskCase;


// -------------------------------------------------------
// EVENT
// -------------------------------------------------------
// Click :: #project_select
$(document).on("change", "#project_select", function () {
	$("#grid").empty();
	hideProjectForm();
	const _projCd = $(this).val();
	loadProjectFormHtml(_projCd);

	$($(".task")[0]).click(); // 위에 로드하고 첫번째 요소 클릭.

	$("#inspResSelect").val('');
});

// Task :: Toggle, Click
clickCheckedEvent(".task");
$(document).on("click", ".task", function () {
	// task 선택시 프로젝트 폼 안보이게..
	hideProjectForm();
});

// Click :: Task
$(document).on("click", ".task", function () {
	var data = {
		projCd: $(this).data('projCd'),
		taskCd: $(this).data('taskCd'),
		inspRes: '',
	}

	// $("#task_cd").val(data.taskCd);

	var html = "";
	html += format("<span class='fail_cnt'>완료 : <strong>{0}</strong>건</span>", $(this).data("compCnt"));
	html += format("<span class='pass_cnt'>Pass : <strong>{0}</strong>건</span>", $(this).data("passCnt"));
	html += format("<span class='fail_cnt'>Fail : <strong>{0}</strong>건</span>", $(this).data("failCnt"));
	$("#task_stat").html(html);

	// $("#projCdExcel").val($("#project_select").val());
	// $("#taskCdExcel").val($(this).data('taskCd'));

	createGrid(data);

	$("#inspResSelect").val('');
});

// Click :: Case
$(document).on("click", "tr[role=row]", function () {
	const sendData = {
		projCd: $(".task.checked").data("projCd"),
		taskCd: $(".task.checked").data("taskCd"),
		caseNo: $(this).children("td[aria-describedby=grid_caseNo]").attr("title"),
	}
	curTaskCase = sendData;
	console.log("case click PARAM");
	console.log(sendData);
	getCaseDataItemAll(sendData);
	showProjectForm();

	// 2022-09-08 수면(2022A1) 하드코딩 
	$("#epoch_input").val("1");
});

// Change :: #inspResSelect
$(document).on("change", "#inspResSelect", function () {
	const sendData = {
		projCd: $(".task.checked").data("projCd"),
		taskCd: $(".task.checked").data("taskCd"),
		inspRes: $("#inspResSelect").val(),
	}

	createGrid(sendData);
});


// -------------------------------------------------------
// FUNCTION
// -------------------------------------------------------
// Init :: Project, Task 세팅
$(function () {
	// promise 처리 해줘야 함. 일단 잘 되니까 보류.
	setProjectList();
	setTaskList();
	initProjectFrom();
	// TaskStat 에서 넘어온 경우 분기처리.
	if ($("#taskStatYn2").val() == 'Y') {
		const _taskStatTaskCd = $("#taskStatTaskCd").val();
		$(".task[data-task-cd=" + _taskStatTaskCd + "]").click();
	} else {
		$("#task_list_ul > li.task:first-child").click();
	}

	if ($("#taskSelCd").val() != '') {
		var taskCd = $("#taskSelCd").val();
		$(".task[data-task-cd=[" + taskCd + "]").click();
	}
});

/** 첫 로딩시 프로젝트 폼 불러오기  */
function initProjectFrom() {
	const _projCd = $("#project_select").val();
	console.log("initProjctForm PROJCD");
	console.log(_projCd);
	loadProjectFormHtml(_projCd);
}

// Load :: Project Form
function loadProjectFormHtml(projCd) {
	// 이벤트 누적 방지
	$("#main_section_body").off();

	// 캐시 누적 방지 + url 생성
	const date = new Date().toISOString().replaceAll("-", "").replaceAll("T", "_").replaceAll(":", "");
	const date2 = date.substring(0, date.indexOf("."));
	const _htmlUrl = CONTEXT_PATH + "/_html/workTask/" + projCd + ".html?dt=" + date2;
	console.log("loadProject URL");
	console.log(_htmlUrl);

	// 애니메이션 정지
	const $body = $("#main_section_body");
	$body.stop(false, true);
	$body.fadeOut(0);
	$body.empty();
	$.ajax({
		type: "get",
		url: _htmlUrl,
		async: false,
		dataType: "text",
		success: function (response) {
			// console.log(response); // 너무 김.
			$body.html(response);
			curProjCd = projCd;
		}
	});
}

// Set :: Project List
function setProjectList() {
	var url = CONTEXT_PATH + "/work/crossValidation/getProjectList.do";
	var async = false;
	callAjax(url, null, async, function (json) {
		console.log("setProjectList RESPONSE");
		console.log(json);

		var rows = json.projectList;
		var html = "";
		html += "<select name='projectSelect' id='project_select' onchange='setTaskList()'>";
		for (i in rows) {
			const projCdSharing = getProjCdSharingCookie();
			if (rows[i].projCd == projCdSharing) {
				html += format("<option value='{0}' selected >{1}</option>", rows[i].projCd, rows[i].projNm);
			} else {
				html += format("<option value='{0}'>{1}</option>", rows[i].projCd, rows[i].projNm);
			}
		}
		html += "</select>";
		$("#project_div").html(html);

		$("#project_select").on("change", function () {
			setProjCdSharingCookie($("#project_select").val());
		});
	});
}


// Set :: Task List
function setTaskList() {
	var url = CONTEXT_PATH + "/work/crossValidation/getTaskList.do";
	var projCd = $("#project_select").val();

	// Task Stat 에서 넘어온 경우.
	if ($("#taskStatYn").val() != '') {
		projCd = $("#taskStatProjCd").val();
		$("#project_select").prop("selected", true).val(projCd);
		$("#taskStatYn").val('');
	}
	var data = {
		projCd: projCd
	}
	console.log("setTaskList PARAM");
	console.log(data);

	var async = false;
	callAjax(url, data, async, function (json) {
		console.log("setTaskList RESPONSE");
		console.log(json);

		var rows = json.taskList;
		var html = "";
		for (var i = 0; i < rows.length; i++) {
			const _taskOne = rows[i];
			let _percentage = Math.round(Number(_taskOne.compCnt) / Number(_taskOne.caseCnt) * 10 * 100) / 10;
			_percentage = isNaN(_percentage) ? 0 : _percentage;
			let colorClass = ''
			if (0 < _percentage && _percentage < 100) {
				colorClass = 'ongoing';
			} else if (_percentage == 100) {
				colorClass = 'completed';
			}
			html += format("<li class='task {7}' data-proj-cd='{0}' data-task-cd='{1}' data-pass-cnt='{2}' data-fail-cnt='{3}' data-comp-cnt='{4}' data-case-cnt='{5}' data-percentage='{6}'><span>{1}</span><span class='stat'>{4}/{5}({6}%)</span></li>", projCd, rows[i].taskCd, _taskOne.passCnt, _taskOne.failCnt, _taskOne.compCnt, _taskOne.caseCnt, _percentage, colorClass);
		}
		$("#task_list_ul").html(html);
	});
}


// Get+Set :: CrossChkList
function createGrid(sendData) {
	var colNames = [];
	var colModels = [];
	var rows;
	var row_size;
	var keys;
	var indexName;

	$.ajax({
		type: "post",
		url: CONTEXT_PATH + "/work/crossValidation/getCrossChkList.do",
		async: false,
		data: sendData,
		dataType: "json",
	}).done(function (jsonData) {
		console.log("createGrid RESPONSE");
		console.log(jsonData);

		if (!isEmpty(jsonData.crossList)) {
			rows = jsonData.crossList;

			keys = Object.keys(rows[0]);
			row_size = jsonData.crossList.length;

			// A1 수면
			// B1 폐기능
			// B2 폐음
			// 0701 projCd value값 찾아서 컬럼 안넣기 ( A2 / B1, B2 구분 )
			values = Object.values(rows[0]);

			var AprojChkCnt = 0;
			var BprojChkCnt = 0;
			var CprojChkCnt = 0;

			for (var i = 0; i < keys.length; i++) {
				if (keys[i] == "projCd") {
					if (values[i] == "2022A1") {
						// alert("rows : " +  Object.values(rows[1]));
						AprojChkCnt++;
					} else if (values[i] == "2022B1") {
						// alert("rows : " +  Object.values(rows[1]));
						BprojChkCnt++;
					} else if (values[i] == "2022B2") {
						// alert("rows : " +  Object.values(rows[1]));
						CprojChkCnt++;
					}
				}
			}

			for (var i = 0; i < keys.length; i++) {

				// 컬럼 명칭 수정
				if (keys[i] == "caseNo") indexName = "케이스 No";
				else if (keys[i] == "lblDisp") indexName = "라벨명";
				else if (keys[i] == "diagUserNm") indexName = "진단자명";
				else if (keys[i] == "diagFailCausList") indexName = "DROP 사유";
				else if (keys[i] == "diagMemo") indexName = "메모";
				else if (keys[i] == "inspRes") indexName = "최종 결과";
				else if (keys[i] == "user1Info") indexName = "검수자1";
				else if (keys[i] == "user2Info") indexName = "검수자2";
				else if (keys[i] == "user3Info") indexName = "검수자3";
				else if (keys[i] == "user1Memo") indexName = "검수자1 메모";
				else if (keys[i] == "user2Memo") indexName = "검수자2 메모";
				else if (keys[i] == "user3Memo") indexName = "검수자3 메모";
				else if (keys[i] == "assignUsers") indexName = "미진단 할당 진단/검수자";
				else if (keys[i] == "inspUserIdList") indexName = "검수자 ID 목록";
				else if (keys[i] == "inspUserNmList") indexName = "검수자 이름 목록";
				else if (keys[i] == "inspResList") indexName = "검수자별 검수 결과 목록";

				var model = { name: keys[i], index: keys[i], width: 100, align: "center" };

				// width 조정
				// AprojChkCnt = 0; 수면
				// BprojChkCnt = 0; 폐기능
				// CprojChkCnt = 0; 폐음
				if (keys[i] == "caseNo") {
					if (AprojChkCnt > 0) {
						model.width = 160;
					} else if (BprojChkCnt > 0) {
						model.width = 250;
					} else if (CprojChkCnt > 0) {
						model.width = 120;
					}
				} else if (keys[i] == "lblDisp") {
					if (AprojChkCnt > 0) {
						model.width = 90;
					} else if (BprojChkCnt > 0) {
						model.width = 125;
					} else if (CprojChkCnt > 0) {
						model.width = 100;
					}
				} else if (keys[i] == "user1Info") {
					if (AprojChkCnt > 0) {
						model.width = 125;
					} else if (BprojChkCnt > 0) {
						model.width = 160;
					} else if (CprojChkCnt > 0) {
						model.width = 125;
					}
				} else if (keys[i] == "user2Info") {
					if (AprojChkCnt > 0) {
						model.width = 125;
					} else if (BprojChkCnt > 0) {
						model.width = 175;
					} else if (CprojChkCnt > 0) {
						model.width = 125;
					}
				} else if (keys[i] == "user3Info") {
					model.width = 75;
				} else if (keys[i] == "assignUsers") {
					if (AprojChkCnt > 0) {
						model.width = 140;
					} else if (BprojChkCnt > 0) {
						model.width = 170;
					} else if (CprojChkCnt > 0) {
						model.width = 140;
					}
				} else if (keys[i] == "diagMemo") {
					model.width = 70;
				} else if (keys[i] == "diagUserNm") {
					model.width = 80;
				} else if (keys[i] == "inspRes") {
					if (AprojChkCnt > 0) {
						model.width = 80;
					} else if (BprojChkCnt > 0) {
						model.width = 140;
					} else if (CprojChkCnt > 0) {
						model.width = 140;
					}
				} else if (keys[i] == "diagFailCausList") {
					if (AprojChkCnt > 0) {
						model.width = 90;
					} else if (BprojChkCnt > 0) {
						model.width = 120;
					} else if (CprojChkCnt > 0) {
						model.width = 90;
					}
				} else if (keys[i] == "user1Memo") {
					if (AprojChkCnt > 0) {
						model.width = 80;
					} else if (BprojChkCnt > 0) {
						model.width = 195;
					} else if (CprojChkCnt > 0) {
						model.width = 130;
					}
				} else if (keys[i] == "user2Memo") {
					if (AprojChkCnt > 0) {
						model.width = 80;
					} else if (BprojChkCnt > 0) {
						model.width = 195;
					} else if (CprojChkCnt > 0) {
						model.width = 135;
					}
				} else if (keys[i] == "user3Memo") {
					if (AprojChkCnt > 0) {
						model.width = 100;
					} else if (BprojChkCnt > 0) {
						model.width = 170;
					} else if (CprojChkCnt > 0) {
						model.width = 100;
					}
				}

				// A1 수면 ACount
				// B1 폐기능 BCount
				// B2 폐음 CCount
				// 프로젝트 별로 화면에 보여줄지 말지 결정
				// (all) 1 케이스 번호 6 최종결과 7 검수자1 8 검수자2 9 검수자1 메모 10 검수자2 메모
				if (keys[i] == "lblDisp" && BprojChkCnt > 0) {// 2 라벨명 ( 수면 A1 폐음 B2 )

				} else if (keys[i] == "diagUserNm" && BprojChkCnt > 0) {// 3 진단자명 ( 수면 A1 폐음 B2 )

				} else if (keys[i] == "diagFailCausList" && BprojChkCnt > 0) {// 4 드랍사유( 수면 A1 폐음 B2 )

				} else if (keys[i] == "diagMemo" && BprojChkCnt > 0) {// 5 메모 ( 수면 A1 폐음 B2 )

				} else if (keys[i] == "assignUsers" && (BprojChkCnt > 0 || CprojChkCnt > 0)) {// 11 미진당 할당 진단/검수자 목록 ( 수면 A1 )

				} else if (keys[i] == "inspUserIdList" && (AprojChkCnt > 0 || BprojChkCnt > 0 || CprojChkCnt > 0)) {// 12 검수자 ID 목록 (NO disp)
				} else if (keys[i] == "inspUserNmList" && (AprojChkCnt > 0 || BprojChkCnt > 0 || CprojChkCnt > 0)) {// 13 검수자 이름 목록 (NO disp)
				} else if (keys[i] == "inspResList" && (AprojChkCnt > 0 || BprojChkCnt > 0 || CprojChkCnt > 0)) {// 14 검수자별 검수 결과 목록 (NO disp)
				} else if (keys[i] == "projCd" && (AprojChkCnt > 0 || BprojChkCnt > 0 || CprojChkCnt > 0)) {// 15 제품코드 (NO disp)

				} else {
					colModels.push(model);
					colNames.push(indexName);
				}
			}
		} else {
			colModels.push(
				{ name: "케이스 No", index: "케이스 No", width: 120, align: "center" }, { name: "라벨명", index: "라벨명", width: 100, align: "center" },
				{ name: "진단자 이름", index: "진단자 이름", width: 100, align: "center" }, { name: "진단자 DROP 사유", index: "진단자 DROP 사유", width: 100, align: "center" },
				{ name: "진단자 메모", index: "진단자 메모", width: 100, align: "center" }, { name: "검수 최종 결과", index: "검수 최종 결과", width: 100, align: "center" },
				{ name: "검수자1", index: "검수자1", width: 100, align: "center" }, { name: "검수자2", index: "검수자2", width: 100, align: "center" },
				//    {name:"검수자3",index:"검수자3",width:100, align:"center"},
				{ name: "검수자1 메모", index: "검수자1 메모", width: 100, align: "center" },
				{ name: "검수자2 메모", index: "검수자2 메모", width: 100, align: "center" },
				//    {name:"검수자3 메모",index:"검수자3 메모",width:100, align:"center"},
				{ name: "미진단 할당 진단/검수자", index: "미진단 할당 진단/검수자", width: 100, align: "center" }
			);
		}
	}).fail(function (jqXHR, textStatus, errorThrown) {
		alert("처리에 실패했습니다. 관리자에게 문의해 주십시오.");

		colModels.push({ name: "케이스 No", index: "케이스 No", width: 120, align: "center" }, { name: "라벨명", index: "라벨명", width: 100, align: "center" },
			{ name: "진단자 이름", index: "진단자 이름", width: 100, align: "center" }, { name: "진단자 DROP 사유", index: "진단자 DROP 사유", width: 100, align: "center" },
			{ name: "진단자 메모", index: "진단자 메모", width: 100, align: "center" }, { name: "검수 최종 결과", index: "검수 최종 결과", width: 100, align: "center" },
			{ name: "검수자1", index: "검수자1", width: 100, align: "center" }, { name: "검수자2", index: "검수자2", width: 100, align: "center" },
			{ name: "검수자3", index: "검수자3", width: 100, align: "center" }, { name: "검수자1 메모", index: "검수자1 메모", width: 100, align: "center" },
			{ name: "검수자2 메모", index: "검수자2 메모", width: 100, align: "center" }, { name: "검수자3 메모", index: "검수자3 메모", width: 100, align: "center" },
			{ name: "미진단 할당 진단/검수자", index: "미진단 할당 진단/검수자", width: 100, align: "center" }
		);
	});

	$.jgrid.gridUnload("grid");

	$("#grid").jqGrid({
		data: rows,
		datatype: "local",
		colNames: colNames,
		colModel: colModels,
		rowNum: row_size,
		//	    rowNum: parseInt($("#page_cnt1").val()),
		//	    rowList: [50,100,150, 200],
		height: "453", // 500 - 40 - 5(왜생기는지 모르겠음) - 2(border) = 453 || 100%로 깔끔할것 같은데 그렇게 하면 스크롤이 안생김.
		loadonce: true,
		autowidth: true,    	 // jQgrid width 자동100% 채워지게
		shrinkToFit: false,  // width를 자동설정 해주는 기능
		gridview: true,
		cmTemplate: { sortable: false },
		rownumbers: true,
		//	    pager: '#pager',
		onCellSelect: function (rowId, iCol, cellcontent, e) { },
		onSelectRow: function (rowId, status, e) { },
		ondbClickRow: function (rowId, iRow, iCol, e) { },
		viewrecords: true,
		loadComplete: function (data) {
			var ids = $("#grid").getDataIDs();
			var total = $("#grid").getGridParam("records");
			$("#list_num").text(total);

			$.each(ids, function (idx, rowId) {
				rowData = $("#grid").getRowData(rowId);

				if (rowData.검수일치여부 == 'X') {
					// $("#grid").setRowData(rowId, false, {background:"#1191d033"});
					$("#grid").jqGrid('setCell', rowId, '검수일치여부', '', { 'background': "#1191d033" });
				}
				if (rowData.검수일치결과 == 'Fail') {
					$("#grid").jqGrid('setCell', rowId, '검수일치결과', '', { 'color': "#ff0505", 'font-weight': 'bold' });
				}

			})

		},
		caption: " "
	})

	$("#event_chk_list").css("display", "none");

}

// excel
function excelDown() {
	var url = CONTEXT_PATH + "/work/crossValidation/excelCrossChkList.do";

	var data = {
		projCd: $("#project_select").val(),
		taskCd: $(".task.checked").data("taskCd"),
		inspRes: $("#inspResSelect").val(),
	}

	$(".loading-image").show();

	$.fileDownload(url, {
		httpMethod: "POST",
		data: data,
		successCallback: function (url) {
			$(".loading-image").hide();

		},
		failCallback: function (responseHtml, url, error) {
			$(".loading-image").hide();
		}
	});
}


// excel
function excelDown2() {
	var url = CONTEXT_PATH + "/work/crossValidation/excelCrossChkList.do";

	var data = {
		projCd: $("#project_select").val(),
		// taskCd: $(".task.checked").data("taskCd"), // 타스크는 넘어가면 안됨
		inspRes: $("#inspResSelect").val(),
		mode: "all"
	}

	$(".loading-image").show();

	$.fileDownload(url, {
		httpMethod: "POST",
		data: data,
		successCallback: function (url) {
			$(".loading-image").hide();

		},
		failCallback: function (responseHtml, url, error) {
			$(".loading-image").hide();
		}
	});
}

function destroyWave() {console.log("destroyWave BLACK");}

// waveSurfer 강제 제거
$(document).on("submit", "#epoch_form", function () {
    destroyWave();
});
$(document).on("click", ".task", function () {
    destroyWave(); 
});
$(document).on("click", ".task_case", function () {
    destroyWave();
});
// 교차검증, 케이스 등록관리.
$(document).on("click", "tr[role=row]", function () {
    destroyWave();
});