/**
 * @File Name : kasmJqgrid.js
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 1. 20.   엄소현         최초생성
 * @ 2020. 1. 22.   류경흠         그리드 표시 수정
 *
 * @author : USH
 * @since : 2020. 1. 20.
 * @version : 1.0
 * 
 */

var customPageInfo = ""; // 페이지 정보를 나타낼 것인지 / boolean / 생략시 false
var customPageInfoType = ""; // 페이지 정보의 종류
var pageCount = 5; // 한 페이지에 보여줄 페이지 수 (ex:1 2 3 4 5)
var totalPage;


function initPage(gridId, pagerId, pI, pit, tfTable){
	if(pI == null || pI == ""){
		customPageInfo = false;
	}else{
		customPageInfo = true;
	}
	  
	if(pit != "TOTP" && pit != "PSE"){
		customPageInfoType = "TOT";
	}else{
		customPageInfoType = pit;
	}
	  
	 // 현재 페이지
	var currentPage = $('#'+gridId).getGridParam('page');
	 // 전체 리스트 수
	  
	var totalSize = $('#'+gridId).getGridParam('records');
	 // 그리드 데이터 전체의 페이지 수
	totalPage = Math.ceil(totalSize/$('#'+gridId).getGridParam('rowNum'));
	//전체 페이지 수를 한화면에 보여줄 페이지로 나눈다.
	var totalPageList = Math.ceil(totalPage/pageCount);
	 // 페이지 리스트가 몇번째 리스트인지
	var pageList=Math.ceil(currentPage/pageCount);
	//alert("currentPage="+currentPage+"/ totalRow="+totalSize);
	//alert("pageCount="+pageCount+"/ pageList="+pageList);
	  
	  
	  
	 // 페이지 리스트가 1보다 작으면 1로 초기화
	if(pageList<1) pageList=1;
	 // 페이지 리스트가 총 페이지 리스트보다 커지면 총 페이지 리스트로 설정
	if(pageList>totalPageList) pageList = totalPageList;
	 // 시작 페이지
	var startPageList=((pageList-1)*pageCount)+1;
	 // 끝 페이지
	var endPageList=startPageList+pageCount-1;
	  
	 //alert("startPageList="+startPageList+"/ endPageList="+endPageList);
	  
	 // 시작 페이지와 끝페이지가 1보다 작으면 1로 설정
	 // 끝 페이지가 마지막 페이지보다 클 경우 마지막 페이지값으로 설정
	if(startPageList<1) startPageList=1;
	if(endPageList>totalPage) endPageList=totalPage;
	if(endPageList<1) endPageList=1;
	  
	 // 페이징 DIV에 넣어줄 태그 생성변수
	var pageInner="";
	//alert("pageList:"+pageList);
	 // 페이지 리스트가 1이나 데이터가 없을 경우 (링크 빼고 흐린 이미지로 변경)
	if(pageList<2){
		if(currentPage > 1){
			// 1 페이지가 아니면 첫페이지로 이동할수있게 
			var titleFirstPage = "첫 페이지로 이동";
			pageInner+="<a class='direction first' href='javascript:firstPage(\""+ gridId +"\");' title='"+ titleFirstPage +"'></a>";
		}
		//pageInner+="<a class='direction prev'>이전페이지</a>";
	}
	 // 이전 페이지 리스트가 있을 경우 (링크넣고 뚜렷한 이미지로 변경)
	if(pageList>1){
		var titleFirstPage = "첫 페이지로 이동";
		var titlePrePage = (startPageList-pageCount) + "페이지에서 " + (startPageList-1) + "페이지까지 이동";
	   
		pageInner+="<a class='direction first' href='javascript:firstPage(\""+ gridId +"\");' title='"+ titleFirstPage +"'></a>";
		pageInner+="<a class='direction prev' href='javascript:prePage(\""+ gridId +"\");' title='"+ titlePrePage +"'></a>";
		//pageInner+="<span class='customPageMoveBtn'><a class='first' href='javascript:firstPage(\""+ gridId +"\");' title='"+ titleFirstPage +"'><i class='direction first'></i></a>";
		//pageInner+="<span class='customPageMoveBtn'><a class='pre' href='javascript:prePage(\""+ gridId +"\");' title='"+ titlePrePage +"'><i class='direction prev'></i></a>";
	 }
	// 총 페이지수 지정에 맞게 빈칸채워 모양 유지
	// if( pageCount> ....
	var makePage = 0;
	
	// 페이지 숫자를 찍으며 태그생성 (현재페이지는 강조태그)
	 for(var i=startPageList; i<=endPageList; i++){
		 var titleGoPage = i + "페이지로 이동";
	   
		 if(i==currentPage){
			 //pageInner = pageInner +"<a href='javascript:goPage(\""+ gridId +"\", "+(i)+");' id='"+(i)+"' class='active' title='"+ titleGoPage +"'><strong>"+(i)+"</strong></a>";
			 pageInner = pageInner +"<strong>"+(i)+"</strong>";
			 //pageInner = pageInner +"<span class='customPageNumberBtn'><a href='javascript:goPage(\""+ gridId +"\", "+(i)+");' id='"+(i)+"' title='"+ titleGoPage +"'><strong>"+(i)+"</strong></a>";
		 }else{
			 pageInner = pageInner +"<a href='javascript:goPage(\""+ gridId +"\", "+(i)+");' id='"+(i)+"' title='"+ titleGoPage +"'>"+(i)+"</a>";
			 //pageInner = pageInner +"<span class='customPageNumberBtn'><a href='javascript:goPage(\""+ gridId +"\", "+(i)+");' id='"+(i)+"' title='"+ titleGoPage +"'>"+(i)+"</a>";
		 }
		 makePage++;
	   
	 }
	 /*if(pageCount > makePage){
		 for(var i = makePage ; i < pageCount; i++){
			 pageInner = pageInner +"<a>&nbsp;</a>";
		 }
	 }*/
	 
	 //alert("총페이지 갯수"+totalPageList);
	 //alert("현재페이지리스트 번호"+pageList);
	  
	 // 다음 페이지 리스트가 있을 경우
	 if(totalPageList>pageList){
		 var titleNextPage = (startPageList+pageCount) + "페이지에서 " + (endPageList+pageCount) + "페이지까지 이동";
		 
		 if(totalPage < endPageList+pageCount){
			 // 마지막 페이지가 다 채워지지 않는 경우 페이지를 최종 페이지까지만 타이틀로 보이게
			 titleNextPage = (startPageList+pageCount) + "페이지에서 " + (totalPage) + "페이지까지 이동";
		 }
		 pageInner+="<a class='direction next' href='javascript:nextPage(\""+ gridId +"\");' title='"+ titleNextPage +"'></a>";
		 
	    
		 var titleLastPage = "마지막 페이지로 이동";
		 pageInner+="<a class='direction last' href='javascript:lastPage(\""+ gridId +"\", \""+totalPage+"\");' title='"+ titleLastPage +"'></a>";
	 }
	  
	 // 현재 페이지리스트가 마지막 페이지 리스트일 경우
	 if(totalPageList==pageList){
		 var titleLastPage = "마지막 페이지로 이동";
		 //pageInner+="<a class='direction next'>다음페이지</a>";
		 if( totalPage > currentPage){
			 pageInner+="<a class='direction last' href='javascript:lastPage(\""+ gridId +"\", \""+totalPage+"\");' title='"+ titleLastPage +"'></a>";
		 }
		 
	 }  
	 //alert(pageInner);
	  
	 // 페이지 정보 셋팅
	 var pageInfoText = ""; // 페이지 정보를 담을 변수
	 if(customPageInfo){
	  //////////////////////////////////////////////////////////////////////////////////////////
		 var base = parseInt($('#'+gridId).getGridParam('page'),10)-1 ;
		 if(base < 0) { base = 0; }
		 base = base*parseInt($('#'+gridId).getGridParam('rowNum'),10);
		 var from = base+1;
		 var to = base + $('#'+gridId).getGridParam('reccount') ;
	  //////////////////////////////////////////////////////////////////////////////////////////
	   
		 if(totalSize == 0){
			 //pageInfoText = "데이터가 없습니다";
			 $('#dataSize').val(0);
		 }else{
			 $('#dataSize').val(1);
			 var totpTxt = "총 " + totalPage + " 페이지" + " / " + totalSize + " 개";
			 var pseTxt = "( " + from + " ~ " + to + " )";
			 var totTxt = totpTxt+ " 중 " + pseTxt;
			 if(customPageInfoType == "TOTP"){
				 pageInfoText = totpTxt;
			 }else if(customPageInfoType == "PSE"){
				 pageInfoText = pseTxt;
			 }else{
				 //pageInfoText = totTxt;
			 }
		 }
	 }
	 
	 var table = "";
	 
	 if(totalSize == 0){
		 table = "<p style='text-align:center; font-size:13px; margin-top: 10px;'>조회된 결과가 없습니다.</p>";
	 }
	 if(tfTable == null || tfTable == ""){
	 table+= "<table width='830px'  class='bd_pagination'>";
	 table+= "<tr style='height:40px !important; margin: 0px;'>";
	 table+= "<td width='20%'>";
	 table+= "</td>";
	 table+= "<td align='center'>";
	 table+= pageInner;
	 table+= "</td>";
	 table+= "<td id='pageInfoText' width='20%' align='right'>";
	 //table += customPageInfo ? pageInfoText + " " : "" ;
	 table+= "</td>";
	 table+= "</tr>";
	 table+= "</table>";
	 }
	 /*table = "<div class='bd_pagination'>";
	 table+= pageInner;
	 table += ""+customPageInfo ? pageInfoText + " " : "" ;
	 table+= "</div>";*/
	   
	 //alert(table);
	  
	 // 페이징할 DIV태그에 우선 내용을 비우고 페이징 태그삽입
	 $("#"+pagerId).html("");
	 // 너비 조정
	 var w = $('#'+gridId).width()+18;
	 $("#"+pagerId).width(w);
	 // 페이징 html 추가
	 $("#"+pagerId).append(table);
	 // 페이징 클래스 추가
	 $("#"+pagerId).addClass("customPaginateBar");
	 
	 
	 goPage(gridId, $('#page').val());
}

function goPage(gridId, num){
	$('#page').val(num);
	$('#'+gridId).jqGrid('setGridParam',{page:num}).trigger("reloadGrid");
}

// 첫페이지(1페이지)로 이동
function firstPage(gridId){
	$('#page').val(1);
	$('#'+gridId).jqGrid('setGridParam',{page:1}).trigger("reloadGrid");
}

// 마지막페이지로 이동
function lastPage(gridId,totalSize){
	//alert(totalSize);
	$('#page').val(totalSize);
	$('#'+gridId).jqGrid('setGridParam',{page:totalSize}).trigger("reloadGrid");
}

// 앞 페이지 목록으로 이동
function prePage(gridId){
	var currentPage = $('#'+gridId).getGridParam('page');
	$('#page').val((Math.ceil((currentPage-pageCount)/pageCount)*pageCount));
	$('#'+gridId).jqGrid('setGridParam',{page:(Math.ceil((currentPage-pageCount)/pageCount)*pageCount)}).trigger("reloadGrid");
}

// 뒷 페이지 목록으로 이동
function nextPage(gridId){
	var currentPage = $('#'+gridId).getGridParam('page');
	//alert(currentPage);
	//  (Math.ceil(currentPage/pageCount)*pageCount)+1
	if( totalPage >= (Math.ceil(currentPage/pageCount)*pageCount)+1){
		$('#page').val((Math.ceil(currentPage/pageCount)*pageCount)+1);
		$('#'+gridId).jqGrid('setGridParam',{page:(Math.ceil(currentPage/pageCount)*pageCount)+1}).trigger("reloadGrid");
	}
	
}

