package com.ubizit.dams.manager.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.model.UserVO;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.manager.service.TaskManagerService;
import com.ubizit.dams.manager.service.UserManagerService;
import com.ubizit.dams.work.model.PlvTaskUserPlanVO;

@Controller
@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST})
public class TaskManagerController {

	@Resource(name="taskManagerService")
	private TaskManagerService taskManagerService;
	
	@Resource(name="userManagerService")
	private UserManagerService userManagerService;
	
	private final static Logger logger = LogManager.getLogger(TaskManagerController.class);
	
	/**
	 * 기본 페이지
	 * @param model
	 * @param request
	 * @param taskVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/task.do")
	public String getPage(Model model, HttpServletRequest request, @ModelAttribute PlvTaskUserPlanVO taskVO) throws Exception {
		logger.info(">>>>>> taskManagerController.getPage >>>>>>");

		return "manager/taskManagerList";
	}
	
	/**
	 * 태스크 테이블 데이터
	 * @param taskVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/manager/task/getTaskList.do", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> getTaskList(@ModelAttribute PlvTaskUserPlanVO taskVO) throws Exception {
		logger.info(">>>>>> taskManagerController.getTaskList >>>>>>");

		List<PlvTaskUserPlanVO> taskList = taskManagerService.getTaskList(taskVO);

		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("taskList", taskList);
		return resultMap;
	}

	/**
	 * 태스크 등록 폼. ?mode=regist 붙여서 등록폼으로만 사용하고 있음.
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/task/registForm.do")
	public String getRegistForm(Model model) throws Exception {
		logger.info(">>>>>> taskManagerController.getRegistForm >>>>>>");
		
		String regDt = StringUtil.getSimpleDateFormat("yyyy-MM-dd");
		model.addAttribute("regDt" , regDt );
		
		return "manager/taskManagerForm";
	}
	
	/**
	 * 태스크 수정 폼
	 * @param model
	 * @param request
	 * @param session
	 * @param taskVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/manager/task/modifyForm.do")
	public String getModifyForm(Model model, HttpServletRequest request, HttpSession session, @ModelAttribute PlvTaskUserPlanVO taskVO) throws Exception {
		logger.info(">>>>>> taskManagerController.getModifyForm >>>>>>");
		
		PlvTaskUserPlanVO _taskVO = taskManagerService.getTaskOne(taskVO);

		if (StringUtil.isNotBlank(_taskVO.getProjCd())) {
			model.addAttribute("projCd", _taskVO.getProjCd());
		}
		if (StringUtil.isNotBlank(_taskVO.getTaskCd())) {
			model.addAttribute("taskCd", _taskVO.getTaskCd());
		}
		if (StringUtil.isNotBlank(_taskVO.getTaskNm())) {
			model.addAttribute("taskNm", _taskVO.getTaskNm());
		}
		if (StringUtil.isNotBlank(_taskVO.getDataDir())) {
			model.addAttribute("dataDir", _taskVO.getDataDir());
		}
		if (StringUtil.isNotBlank(_taskVO.getDataRegYmd())) {
			model.addAttribute("dataRegYmd", _taskVO.getDataRegYmd());
		}
		if (StringUtil.isNotBlank((CharSequence) _taskVO.getStatYn())) {
			model.addAttribute("statYn", _taskVO.getStatYn());
		}
		if (StringUtil.isNotBlank(_taskVO.getRegId())) {
			model.addAttribute("regId", _taskVO.getRegId());
		}
		if (StringUtil.isNotBlank(_taskVO.getRegDt())) {
			model.addAttribute("regDt", _taskVO.getRegDt());
		}
		
		getReadUser(request,session,model);
		model.addAttribute("modifyYn", "Y");
		
		return "manager/taskManagerForm";
	}

	/**
	 * 태스크 등록 프로세스
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/manager/task/registTask.do", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> registTask(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> UserManagerController.registTask >>>>>>");

		Map<?, ?> paramMap = request.getParameterMap();

		String projCd = request.getParameter("projCd");
		String taskCd = request.getParameter("taskCd");
		String taskNm = request.getParameter("taskNm");
		String dataDir = request.getParameter("dataDir");
		String dataRegYmd = request.getParameter("dataRegYmd");
		String statYn = request.getParameter("statYn");
//		String regId = request.getParameter("regId");
		String regId = request.getParameter("regUserNm");

		// 태스크 등록 리스트
		String[] userList = new Gson().fromJson(((String[]) paramMap.get("users"))[0], String[].class);
		String[] userDiList = new Gson().fromJson(((String[]) paramMap.get("userdi"))[0], String[].class);

		Map<String, Object> reqestMap = new HashMap<String, Object>();
		reqestMap.put("PROJ_CD", projCd);
		reqestMap.put("TASK_CD", taskCd);
		reqestMap.put("TASK_NM", taskNm);
		reqestMap.put("DATA_DIR", dataDir);
		reqestMap.put("DATA_REG_YMD", dataRegYmd);
		reqestMap.put("STAT_YN", statYn);
		reqestMap.put("USER_LIST", userList);
		reqestMap.put("USERDI_LIST", userDiList);
		reqestMap.put("REG_USER_ID", regId);

		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(reqestMap));
		System.out.println("registTask PARAM");
		System.out.println(new Gson().toJson(reqestMap));
		taskManagerService.registTask(procMap);

		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("code", procMap.get("retCode"));
		resultMap.put("msg", procMap.get("retMsg"));
		return resultMap;
	}
	
	/**
	 * 태스크 수정 프로세스
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/manager/task/modifyTask.do", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> modifyTask(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> TaskManagerController.modifyTask >>>>>>");
		
		Map<?, ?> paramMap = request.getParameterMap();
		
		String projCd = request.getParameter("projCd");
		String taskCd = request.getParameter("taskCd");
		String taskNm = request.getParameter("taskNm");
		String dataDir = request.getParameter("dataDir");
		String statYn = request.getParameter("statYn");
		String regId = request.getParameter("regId");

		String[] userList = new Gson().fromJson(((String[]) paramMap.get("users"))[0], String[].class);
		String[] userDiList = new Gson().fromJson(((String[]) paramMap.get("userdi"))[0], String[].class);

		Map<String, Object> reqestMap = new HashMap<String, Object>();
		reqestMap.put("PROJ_CD", projCd);
		reqestMap.put("TASK_CD", taskCd);
		reqestMap.put("TASK_NM", taskNm);
		reqestMap.put("DATA_DIR", dataDir);
		reqestMap.put("STAT_YN", statYn);
		reqestMap.put("USER_LIST", userList);
		reqestMap.put("USERDI_LIST", userDiList);
		reqestMap.put("REG_USER_ID", regId);
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(reqestMap));
		System.out.println("modifyTask PARAM");
		System.out.println(new Gson().toJson(reqestMap));
		taskManagerService.modifyTask(procMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("code", procMap.get("retCode"));
		resultMap.put("msg", procMap.get("retMsg"));
		return resultMap;
	}
	
	/**
	 * 태스크 삭제 프로세스
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/manager/task/removeTask.do", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> removeTask(@RequestParam Map<String, Object> paramMap) throws Exception {
		logger.info(">>>>>> TaskManagerController.removeTask >>>>>>");

		String rcvJson = new Gson().toJson(paramMap);
		System.out.println("removeTask PARAM");
		System.out.println(rcvJson);

		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		taskManagerService.removeTask(procMap);

		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("code", procMap.get("retCode"));
		resultMap.put("msg", procMap.get("retMsg"));
		return resultMap;
	}

	// 2022-06-20
	@RequestMapping(value="/manager/user.popup.do")
	public String userSearchPopup(ModelMap model, HttpServletRequest request,
									@RequestParam(value="userId", defaultValue="") String userId,
									@RequestParam(value="manager", defaultValue="") String manager,
									@RequestParam(value="index", defaultValue="") String index) throws Exception{
		logger.info(">>>>>> TaskController.userSearchPopup >>>>>>");
		
		if(StringUtil.isNotBlank(userId)) {
			model.addAttribute("userId" , userId);
		}
		if(StringUtil.isNotBlank(manager)) {
			model.addAttribute("manager" , manager);
		}
		if(StringUtil.isNotBlank(index)) {
			model.addAttribute("index" , index);
		}
		
		return "manager/userSearchPopup";
	}

	// 2022-06-20
	@RequestMapping(value="/manager/user.popup.search.do")
	@ResponseBody
	public Map<String, Object> getUserPopList(HttpServletRequest request) throws Exception{
		logger.info(">>>>>> taskManagerController.getUserPopList >>>>>>");
		
		
		// PARAM
		String projCd = request.getParameter("projCd");
		String userId = request.getParameter("userId");
		int page_no = Integer.parseInt(request.getParameter("page_no"));
		int row_size = Integer.parseInt(request.getParameter("row_size"));

		// List
		UserVO _userVO = new UserVO();
		_userVO.setProjCd(projCd);
		_userVO.setUserId(userId);
		List<UserVO> userList = userManagerService.getuserProjList(_userVO);
		int originalSize = userList.size();

		// Paging
		if (originalSize > 0) {
			int start = Math.min(originalSize, Math.abs((page_no - 1) * row_size));

			if (page_no == 1 && originalSize > row_size) {
				userList.subList(row_size, originalSize).clear();
			} else if (page_no == 1 && originalSize <= row_size) {
			} else if (page_no != 1) {
				userList.subList(0, start).clear();

				int size = userList.size();
				int end = Math.min(row_size, size);
				userList.subList(end, size).clear();
			}
		} else {
			originalSize = 1;
		}
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("total", originalSize);
		resultMap.put("rows", userList);
		return resultMap;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value="/manager/user.read.do")
	@ResponseBody
	public Map<String, Object> getReadUser(HttpServletRequest request, HttpSession session, Model model) throws Exception {
		logger.info(">>>>>> TaskManagerController.getReadUser >>>>>>");
		
		String projCd = request.getParameter("projCd");
		String taskCd = request.getParameter("taskCd");
		
		Map<String, Object> reqestMap = new HashMap<String, Object>();
		reqestMap.put("PROJ_CD", projCd);
		reqestMap.put("TASK_CD", taskCd);
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("p_rcv_json", new Gson().toJson(reqestMap));		
		taskManagerService.getTaskToUserList(procMap);

		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = new Gson().fromJson((String) procMap.get("p_ret_json"), Map.class);
		resultMap.put("p_ret_msg", procMap.get("p_ret_msg"));
		resultMap.put("p_ret_code", procMap.get("p_ret_code"));
		resultMap.put("rows", resultMap.get("userList"));

		model.addAttribute("userList" , resultMap.get("userList"));
		return resultMap;
	}

	/**
	 * 테이블 데이터 엑셀 다운로드
	 * @param request
	 * @param response
	 * @param session
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/task/excelTaskList.do")
	@ResponseBody
	public Map<String, Object> excelTaskList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> TaskManagerController.excelTaskList >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		String projCd = request.getParameter("projCd");
		String taskCd = request.getParameter("taskCd");
		String taskNm = request.getParameter("taskNm");
		
		resultMap.put("projCd", projCd);
		resultMap.put("taskCd", taskCd);
		resultMap.put("taskNm", taskNm);
		
		// 엑셀에 담을 데이터 조회
		List<Map<String,Object>> dbList = taskManagerService.taskExcelDL(resultMap);
		
		if(dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8"); 
			PrintWriter out = response.getWriter();
			out.println("<script>alert('"+failMsg+"');</script>");
			out.flush();
			return null;
		}
		
		// 컬럼정보
		List<String> colList = new ArrayList<String>();
		// 8
		colList.add("태스크 코드");
		colList.add("태스크 명");
		colList.add("진단자 및 검수자 명");
		colList.add("데이터 경로");
		colList.add("데이터셋 등록일");
		colList.add("통계 여부");
		colList.add("생성자 아이디");
		colList.add("등록 일자");
		
		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		bodyList.add("TASK_CD");
		bodyList.add("TASK_NM");
		bodyList.add("USER_NM");
		bodyList.add("DATA_DIR");
		bodyList.add("DATA_REG_YMD");
		bodyList.add("STAT_YN");
		bodyList.add("REG_ID");
		bodyList.add("REG_DT");
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;

		String downFileName = "태스크_현황_" + StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);

		int[] widths = new int[colNames.length];

		for(int i = 0; i < colNames.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);
		
		resultMap.put("result", "Y");
		
		return resultMap;
	}
}
