package com.ubizit.dams.manager.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.model.ProjectVO;
import com.ubizit.dams.common.model.UserVO;
import com.ubizit.dams.common.utils.BCriptUtil;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.manager.service.ProjectManagerService;
import com.ubizit.dams.manager.service.UserManagerService;

@Controller
public class UserManagerController {

	@Resource(name="userManagerService")
	private UserManagerService userManagerService;
	
	@Resource(name="projectManagerService")
	private ProjectManagerService projectManagerService;
	
	private final static Logger logger = LogManager.getLogger(UserManagerController.class);

	/**
	 * 기본 페이지
	 * @param model
	 * @param userVO
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/user.do")
	public String getPage(Model model, @ModelAttribute UserVO userVO, HttpServletRequest request) throws Exception {
		logger.info(">>>>>> userManagerController.getPage >>>>>>");
		
		return "manager/userManagerList";
	}
	
	/**
	 * 유저 테이블 데이터
	 * @param model
	 * @param request
	 * @param userVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/user/getUserList.do")
	@ResponseBody
	public Map<String, Object> getUserList(HttpServletRequest request, @ModelAttribute UserVO userVO) throws Exception {
		logger.info(">>>>>> userManagerController.getUserList >>>>>>");
		
		List<UserVO> userList = userManagerService.getuserList(userVO);
		
		Map<String, Object> resultMap = new HashMap<String, Object>(); 
		resultMap.put("userList", userList);
		return resultMap;
	}
		
	/**
	 * 사용자 생성폼 팜업
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/user/registForm.do")
	public String getRegistForm(Model model) throws Exception {
		logger.info(">>>>>> userManagerController.getRegistForm >>>>>>");
		
		String regDt = StringUtil.getSimpleDateFormat("yyyy-MM-dd");
		model.addAttribute("regDt" , regDt );
		
		return "manager/userManagerForm";
	}
	
	/**
	 * 사용자 수정폼 팝업
	 * @param request
	 * @param session
	 * @param model
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/user/modifyForm.do")
	public String getModifyForm(HttpServletRequest request, HttpSession session, Model model, UserVO paramVo) throws Exception {
		logger.info(">>>>>> UserManagerController.getModifyForm >>>>>>");

		UserVO _userVO = userManagerService.getuserOne(paramVo);

		if (StringUtil.isNotBlank(_userVO.getUserId())) {
			model.addAttribute("userId", _userVO.getUserId());
		}
		if (StringUtil.isNotBlank(_userVO.getUserNm())) {
			model.addAttribute("userNm", _userVO.getUserNm());
		}
		if (StringUtil.isNotBlank(_userVO.getPswd())) {
			model.addAttribute("pswd", _userVO.getPswd());
		}
		if (StringUtil.isNotBlank(_userVO.getUseYn())) {
			model.addAttribute("useYn", _userVO.getUseYn());
		}
		if (StringUtil.isNotBlank(_userVO.getSysMgrYn())) {
			model.addAttribute("sysMgrYn", _userVO.getSysMgrYn());
		}
		if (StringUtil.isNotBlank(_userVO.getRegId())) {
			model.addAttribute("regId", _userVO.getRegId());
		}
		if (StringUtil.isNotBlank(_userVO.getRegDt())) {
			model.addAttribute("regDt", _userVO.getRegDt());
		}

		getReadProject(request, session, model);
		
		return "manager/userManagerForm";
	}
	
	/**
	 * 사용자 신규생성
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/user/registUser.do")
	@ResponseBody
	public Map<String, Object> registUser(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> UserManagerController.registUser >>>>>>");
		
		Map<?, ?> paramMap = request.getParameterMap();
		
		String userId = request.getParameter("userId");
		String userNm = request.getParameter("userNm");
		String useYn = request.getParameter("useYn");
		String sysMgrYn = request.getParameter("sysMgrYn");
		String regId = request.getParameter("regId");
		String pswd = request.getParameter("pswd");
		
		String[] projList = new Gson().fromJson(((String[]) paramMap.get("projs"))[0], String[].class);
		String[] mgrYnList = new Gson().fromJson(((String[]) paramMap.get("mgrs"))[0], String[].class);
		
		// rcvMap
		Map<String, Object> rcvMap = new HashMap<String, Object>();
		rcvMap.put("USER_ID", userId);
		rcvMap.put("USER_NM", userNm);
		rcvMap.put("USE_YN", useYn);
		rcvMap.put("SYS_MGR_YN", sysMgrYn);
		rcvMap.put("REG_ID", regId);
		rcvMap.put("PSWD", BCriptUtil.encodePswd(pswd));
		rcvMap.put("PROJECT_LIST", projList);
		rcvMap.put("MGR_YN_LIST", mgrYnList);
		rcvMap.put("REG_USER_ID", regId);
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(rcvMap));
		System.out.println("registUser PARAM");
		System.out.println(new Gson().toJson(rcvMap));
		userManagerService.registUser(procMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("code", procMap.get("retCode"));
		resultMap.put("msg", procMap.get("retMsg"));
		return resultMap;
	}

	/**
	 * 사용자 정보 수정
	 * @param request
	 * @return resultMap
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/user/modifyUser.do")
	@ResponseBody
	public Map<String, Object> modifyUser(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> UserManagerController.modifyUser >>>>>>");
		
		Map<?, ?> paramMap = request.getParameterMap();
		
		// 유저정보
		String userId = request.getParameter("userId");
		String userNm = request.getParameter("userNm");
		String useYn = request.getParameter("useYn");
//		String pswd = request.getParameter("pswd");  2022-09-19
		String sysMgrYn = request.getParameter("sysMgrYn");
		String regId = request.getParameter("regId");

		// 프로젝트 등록 리스트
		String[] projList = new Gson().fromJson(((String[])paramMap.get("projs"))[0], String[].class);
		String[] mgrYNList = new Gson().fromJson(((String[])paramMap.get("mgrs"))[0], String[].class);
		
		// rcvMap
		Map<String, Object> rcvMap = new HashMap<String, Object>();
		rcvMap.put("USER_ID", userId);
		rcvMap.put("USER_NM", userNm);
		rcvMap.put("USE_YN", useYn);
//		rcvMap.put("PSWD", BCriptUtil.encodePswd(pswd));  2022-09-19 패스워드는 따로 초기화.
		rcvMap.put("SYS_MGR_YN", sysMgrYn);
		rcvMap.put("PROJECT_LIST", projList);
		rcvMap.put("MGR_YN_LIST", mgrYNList);
		rcvMap.put("REG_USER_ID", regId);
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(rcvMap));
		System.out.println("modifyUser PARAM");
		System.out.println(new Gson().toJson(rcvMap));
		userManagerService.modifyUser(procMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("code", procMap.get("retCode"));
		resultMap.put("msg", procMap.get("retMsg"));
		return resultMap;
	}
	
	/**
	 * 유저 삭제
	 * 프로젝트 권한 삭제 -> 유저 삭제
	 * @param userId 1개
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/user/removeUser.do")
	@ResponseBody
	public Map<String, Object> removeUser(@RequestParam Map<String, Object> paramMap) throws Exception {
		logger.info(">>>>>> UserManagerController.removeUser >>>>>>");

		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(paramMap));
		userManagerService.removeUser(procMap);

		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("code", procMap.get("retCode"));
		resultMap.put("msg", procMap.get("retMsg"));
		return resultMap;
	}
	
	/**
	 * 사용자 수정폼 - 사용자 비밀번호 초기화
	 * @param request
	 * @return Map<String, Object>
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/user/initPswd.do")
	@ResponseBody
	public Map<String, Object> initPswd(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> UserManagerController.initPswd >>>>>>");
	
		// PARAM
		String userId = request.getParameter("userId");
		String pswd = request.getParameter("pswd");
		String encodedPswd = BCriptUtil.encodePswd(pswd);
		
		// paramMap
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("userId", userId);
		paramMap.put("pswd", encodedPswd);
		System.out.println("initPswd PARAM");
		System.out.println(new Gson().toJson(paramMap));
		int result = userManagerService.modifyPswd(paramMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		if (result > 0) {
			resultMap.put("code", 0);
		} else {
			resultMap.put("code", -1);
			resultMap.put("msg", "실패했습니다.");
		}
		return resultMap;
	}

	// 아래 두개 메서드 프로젝트 선택 팝업창 같은데.. 두개 차이가 뭐지
	// 2022-06-14
	@RequestMapping(value="/manager/project.popup.do")
	public String projectSearchPopup(ModelMap model, HttpServletRequest request,
									@RequestParam(value="projCd", defaultValue="") String projCd,
									@RequestParam(value="manager", defaultValue="") String manager,
									@RequestParam(value="index", defaultValue="") String index) throws Exception{
		logger.info(">>>>>> UserController.projectSearchPopup >>>>>>");
		
		if(StringUtil.isNotBlank(projCd)) {
			model.addAttribute("projCd" , projCd);
		}
		if(StringUtil.isNotBlank(manager)) {
			model.addAttribute("manager" , manager);
		}
		if(StringUtil.isNotBlank(index)) {
			model.addAttribute("index" , index);
		}
		
		return "manager/projectSearchPopup";
	}
	
	// 2022-06-14
	@RequestMapping(value="/manager/project.popup.search.do")
	@ResponseBody
	public Map<String, Object> getProjectPopList(HttpServletRequest request) throws Exception{
		logger.info(">>>>>> userManagerController.getProjectPopList >>>>>>");

		Map<?, ?> paramMap = request.getParameterMap();

		String projCd = ((String[]) paramMap.get("projCd"))[0];
		ProjectVO _projVO = new ProjectVO();
		_projVO.setProjCd(projCd);

		int page_no = Integer.parseInt(((String[]) paramMap.get("page_no"))[0]);
		int row_size = Integer.parseInt(((String[]) paramMap.get("row_size"))[0]);

		List<ProjectVO> projList = projectManagerService.getprojectList(_projVO);

		int originalSize = projList.size();

		if (originalSize > 0) {
			int start = Math.min(originalSize, Math.abs((page_no - 1) * row_size));

			if (page_no == 1 && originalSize > row_size) {
				projList.subList(row_size, originalSize).clear();

			} else if (page_no == 1 && originalSize <= row_size) {

			} else if (page_no != 1) {
				projList.subList(0, start).clear();

				int size = projList.size();
				int end = Math.min(row_size, size);
				projList.subList(end, size).clear();
			}
		} else {
			originalSize = 1;
		}

		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("total", originalSize);
		resultMap.put("rows", projList);
		return resultMap;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/manager/project.read.do")
	@ResponseBody
	public Map<String, Object> getReadProject(HttpServletRequest request, HttpSession session, Model model) throws Exception {
		logger.info(">>>>>> UserManagerController.getReadProject >>>>>>");
		
		// PARAM
		String userId = request.getParameter("userId");

		// rcvMap
		Map<String, Object> rcvMap = new HashMap<String, Object>();
		rcvMap.put("USER_ID", userId);

		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("p_rcv_json", new Gson().toJson(rcvMap));
		userManagerService.getUserToProjectList(procMap);

		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = new Gson().fromJson((String) procMap.get("p_ret_json"), Map.class);
		resultMap.put("p_ret_msg", procMap.get("p_ret_msg"));
		resultMap.put("p_ret_code", procMap.get("p_ret_code"));
		resultMap.put("rows", resultMap.get("projectList"));

		model.addAttribute("projList" , resultMap.get("projectList"));
		
		return resultMap;
	}
	
	/**
	 * 당장 프로젝트 (-) 눌렀을때 검수체크인가?
	 * @param request
	 * @param projectVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/user.project.validation.do")
	@ResponseBody
	public Map<String, Object> getuserProjectValidation(ProjectVO projectVo) throws Exception {
		logger.info(">>>>>> UserManagerController.getReadProject >>>>>>");
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Map<String, Object> searchMap = new HashMap<String, Object>();
		
		searchMap.put("userId", projectVo.getUserId());
		searchMap.put("projCd", projectVo.getProjCd());

		int result = userManagerService.userProjectValidation(searchMap);
		if (result == 0) {
			// 삭제 가능
//			System.out.println("삭제 가능 합니다.");
		} else {
			// 삭제 불가능
			System.out.println("해당 프로젝트 Task에 진단자 및 검수자 등록된 유저는 삭제 불가능 합니다.");
		}

		return resultMap;
	}

	/**
	 * 유저리스트 엑셀 다운로드
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/user/excelUserList.do")
	@ResponseBody
	public Map<String, Object> excelUserList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> UserManagerController.excelUserList >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		String userId = request.getParameter("userId");
		String userNm = request.getParameter("userNm");
		
		resultMap.put("userId", userId);
		resultMap.put("userNm", userNm);
		
		// 엑셀에 담을 데이터 조회
		List<Map<String,Object>> dbList = userManagerService.userExcelDL(resultMap);

		if (dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('" + failMsg + "');</script>");
			out.flush();
			return null;
		}
		
		// 컬럼정보
		List<String> colList = new ArrayList<String>();
		// 7
		colList.add("사용자 아이디");
		colList.add("사용자명");
		colList.add("등록 프로젝트 목록");
		colList.add("사용여부");
		colList.add("시스템 관리자 여부");
		colList.add("등록자");
		colList.add("등록일자");
		
		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		bodyList.add("USER_ID");
		bodyList.add("USER_NM");
		bodyList.add("PROJ_MAPPING");
		bodyList.add("USE_YN");
		bodyList.add("SYS_MGR_YN");
		bodyList.add("REG_ID");
		bodyList.add("REG_DT");
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "사용자_현황_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);
		
		int[] widths = new int[colNames.length];

		for(int i = 0; i < colNames.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);
		
		resultMap.put("result", "Y");
		return resultMap;
	}
	
}
