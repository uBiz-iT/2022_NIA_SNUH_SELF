package com.ubizit.dams.manager.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.model.TaskCaseVO;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.manager.service.TaskCaseManagerService;
import com.ubizit.dams.manager.service.TaskManagerService;
import com.ubizit.dams.work.model.PlvTaskUserPlanVO;
import com.ubizit.dams.work.service.CrossValidationService;

@Controller
@RequestMapping
public class TaskCaseManagerController {

	@Resource(name="taskCaseManagerService")
	protected TaskCaseManagerService taskCaseManagerService;
	
	@Resource(name="taskManagerService")
	protected TaskManagerService taskManagerService;
	
	@Resource(name="crossValidationService")
	protected CrossValidationService crossValidationService;

	private final static Logger logger = LogManager.getLogger(TaskCaseManagerController.class);

	/**
	 * 기본 페이지
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/taskCase.do")
	public String getPage() throws Exception {
		logger.info(">>>>>> taskCaseManagerController.getPage >>>>>>");
		
		return "manager/taskCaseManagerList";
	}

	/**
	 * 태스크 리스트
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/taskCaseManager/getTaskList.do")
	@ResponseBody
	public Map<String, Object> getTaskList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> TaskCaseManagerController.getTaskList >>>>>>");
		
		// PARAM
		String projCd = request.getParameter("projCd");
		
		// Task List
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("projCd", projCd);
		List<?> taskList = taskCaseManagerService.getTaskList(paramMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("taskList", taskList);
		return resultMap;
	}

	// Deprecated 2022-10-04
	@RequestMapping(value="/manager/taskCaseManagerForm.do")
	public String getTaskCaseFormList(Model model) throws Exception {
		logger.info(">>>>>> TaskCaseManagerController.getTaskCaseFormList >>>>>>");
		
		String regDt = StringUtil.getSimpleDateFormat("yyyy-MM-dd");
		model.addAttribute("regDt" , regDt );
		
		return "manager/taskCaseManagerForm";
	}
	
	// Deprecated 2022-10-04
	@RequestMapping(value="/manager/task.popup.do")
	public String taskSearchPopup(ModelMap model, HttpServletRequest request,
									@RequestParam(value="taskCd", defaultValue="") String taskCd,
									@RequestParam(value="manager", defaultValue="") String manager,
									@RequestParam(value="index", defaultValue="") String index) throws Exception{
		logger.info(">>>>>> TaskCaseManagerController.taskSearchPopup >>>>>>");
		
		if(StringUtil.isNotBlank(taskCd)) {
			model.addAttribute("taskCd" , taskCd);
		}
		if(StringUtil.isNotBlank(manager)) {
			model.addAttribute("manager" , manager);
		}
		if(StringUtil.isNotBlank(index)) {
			model.addAttribute("index" , index);
		}
		
		return "manager/taskSearchPopup";
	}

	// Deprecated 2022-10-04
	@RequestMapping(value="/manager/task.popup.search.do")
	@ResponseBody
	public Map<String, Object> getTaskPopList(HttpServletRequest request) throws Exception{
		logger.info(">>>>>> taskCaseManagerController.getTaskPopList >>>>>>");
		
		Map<?, ?> paramMap = request.getParameterMap();
		
		String projCd = ((String[]) paramMap.get("projCd"))[0];
		String taskCd = ((String[]) paramMap.get("taskCd"))[0];

		PlvTaskUserPlanVO _taskVO = new PlvTaskUserPlanVO();

		_taskVO.setProjCd(projCd);
		_taskVO.setTaskCd(taskCd);

		int page_no = Integer.parseInt(((String[]) paramMap.get("page_no"))[0]);
		int row_size = Integer.parseInt(((String[]) paramMap.get("row_size"))[0]);

		List<PlvTaskUserPlanVO> taskList = taskManagerService.getTaskList(_taskVO);

		int originalSize = taskList.size();

		if (originalSize > 0) {
			int start = Math.min(originalSize, Math.abs((page_no - 1) * row_size));

			if (page_no == 1 && originalSize > row_size) {
				taskList.subList(row_size, originalSize).clear();

			} else if (page_no == 1 && originalSize <= row_size) {

			} else if (page_no != 1) {
				taskList.subList(0, start).clear();

				int size = taskList.size();
				int end = Math.min(row_size, size);
				taskList.subList(end, size).clear();
			}
		} else {
			originalSize = 1;
		}
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("total", originalSize);
		resultMap.put("rows", taskList);
		return resultMap;
	}
	
	// taskCase 직접 등록은 안함. 미사용
	@RequestMapping(value="/manager/taskCase.insert.do")
	@ResponseBody
	public Map<String, Object> insertTaskCase(TaskCaseVO paramVo) throws Exception {
		logger.info(">>>>>> TaskCaseManagerController.insertTaskCase >>>>>>");

		int result = taskCaseManagerService.registTaskCase(paramVo);
		if (result == 0) {
			System.out.println("신규 유저 등록에 실패하였습니다.");
		} else {
			System.out.println("신규 유저 등록이 완료되었습니다.");
		}

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_ret_msg", resultMap.get("p_ret_msg"));
		resultMap.put("p_ret_code", resultMap.get("p_ret_code"));

		return resultMap;
	}
		
	// 2022-06-29 최초등록
	// 2022-10-04 직접 삭제 안함. 미사용
	@RequestMapping(value="/manager/taskCase.delete.do")
	@ResponseBody
	public Map<String, Object> deleteTaskCase(HttpServletRequest request, HttpSession session, Model model, TaskCaseVO paramVo) throws Exception {
		logger.info(">>>>>> TaskCaseManagerController.deleteTaskCase >>>>>>");
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		// paramVO {projCd, taskCd, caseNo}
		int result = taskCaseManagerService.removeTaskCase(paramVo);
		if(result == 0) {
			resultMap.put("result", true);
		}else {
			resultMap.put("result", false);
		}
		
		return resultMap;
	}

	/**
	 * 태스크 케이스 테이블 데이터
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/manager/taskCaseManager/getTaskCaseStepList.do")
	@ResponseBody
	public Map<String, Object> getTaskCaseStepList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> TaskCaseManager.getTaskCaseStepList >>>>>>");
		
		// PARAM
		String projCd = request.getParameter("projCd");
		String taskCd = request.getParameter("taskCd");

		// CrossCheckList
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("projCd", projCd);
		paramMap.put("taskCd", taskCd);
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(paramMap));
		taskCaseManagerService.getTaskCaseStepList(procMap);
		List<Map<String, Object>> crossListMap = (List<Map<String, Object>>) new Gson().fromJson((String) procMap.get("retJson"), Map.class).get("taskCaseStepList");	
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("rows", crossListMap);
		resultMap.put("total", crossListMap.size());
		return resultMap;
	}

	/**
	 * 태스크 케이스 테이블 데이터 엑셀 다운로드
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/taskCaseExcelDown.do")
	@ResponseBody
	public Map<String, Object> taskCaseExcelDL(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> UserManagerController.userExcelDL >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		String projCd = request.getParameter("projCd");
		String taskCd = request.getParameter("taskCd");
		
		resultMap.put("projCd", projCd);
		resultMap.put("taskCd", taskCd);
		
		// 엑셀에 담을 데이터 조회
		List<Map<String,Object>> dbList = taskCaseManagerService.taskCaseExcelDL(resultMap);

		if(dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('"+failMsg+"');</script>");
			out.flush();
			return null;
		}
		
		// 컬럼정보
		List<String> colList = new ArrayList<String>();
		// 4
		colList.add("케이스 No");
		colList.add("나이");
		colList.add("성별");
		colList.add("등록 일자");
		
		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		bodyList.add("CASE_NO");
		bodyList.add("AGE");
		bodyList.add("GEN");
		bodyList.add("REG_DT");
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String excel_subName = "";
		if("2022A1".equals(projCd)){
			excel_subName += "자가수면_검사_데이터_";
		}else if("2022B1".equals(projCd)){
			excel_subName += "자가_폐기능_검사_데이터_";
		}else if("2022B2".equals(projCd)){
			excel_subName += "폐음_검사_데이터_구축_";
		}
		excel_subName += "태스크_케이스_현황_";
		
		String downFileName = excel_subName+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);
		
		int[] widths = new int[colNames.length];

		for(int i = 0; i < colNames.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);
		
		resultMap.put("result", "Y");
		return resultMap;
	}
	
}
