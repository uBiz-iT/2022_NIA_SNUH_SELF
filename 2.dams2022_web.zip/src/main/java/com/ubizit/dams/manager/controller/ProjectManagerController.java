package com.ubizit.dams.manager.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.model.LabelVO;
import com.ubizit.dams.common.model.ProjectVO;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.manager.service.LabelManagerService;
import com.ubizit.dams.manager.service.ProjectManagerService;

@Controller
@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST})
public class ProjectManagerController {

	@Resource(name="projectManagerService")
	private ProjectManagerService projectManagerService;
	
	@Resource(name="labelManagerService")
	private LabelManagerService labelManagerService;
	
	private final static Logger logger = LogManager.getLogger(ProjectManagerController.class);

	/**
	 * 기본페이지
	 * @param model
	 * @param projectVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/project.do")
	public String getPage(Model model, @ModelAttribute ProjectVO projectVO) throws Exception {
		logger.info(">>>>>> projectManagerController.getPage >>>>>>");
		
		return "manager/projectManagerList";
	}

	/**
	 * 프로젝트 테이블 데이터
	 * @param model
	 * @param projectVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/project/getProjectList.do")
	@ResponseBody
	public Map<String, Object> getProjectList(Model model, @ModelAttribute ProjectVO projectVO) throws Exception {
		logger.info(">>>>>> projectManagerController.getProjectList >>>>>>");
		
		List<ProjectVO> projectList = projectManagerService.getprojectList(projectVO);
		
		for (int i = 0; i < projectList.size(); i++) {
			if (projectList.get(i).getWeekRepoStdDayw() == 1) {
				projectList.get(i).setWeekRepoStdDaywStr("월요일");
			} else if (projectList.get(i).getWeekRepoStdDayw() == 2) {
				projectList.get(i).setWeekRepoStdDaywStr("화요일");
			} else if (projectList.get(i).getWeekRepoStdDayw() == 3) {
				projectList.get(i).setWeekRepoStdDaywStr("수요일");
			} else if (projectList.get(i).getWeekRepoStdDayw() == 4) {
				projectList.get(i).setWeekRepoStdDaywStr("목요일");
			} else if (projectList.get(i).getWeekRepoStdDayw() == 5) {
				projectList.get(i).setWeekRepoStdDaywStr("금요일");
			} else if (projectList.get(i).getWeekRepoStdDayw() == 6) {
				projectList.get(i).setWeekRepoStdDaywStr("토요일");
			} else if (projectList.get(i).getWeekRepoStdDayw() == 7) {
				projectList.get(i).setWeekRepoStdDaywStr("일요일");
			}
		}
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("projectList", projectList);
		return resultMap;
	}
	
	/**
	 * 프로젝트 등록폼
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/project/registForm.do")
	public String getRegistForm(Model model) throws Exception {
		logger.info(">>>>>> projectManagerController.getRegistForm >>>>>>");
		
		return "manager/projectManagerForm";
	}

	/**
	 * 프로젝트 수정폼
	 * @param request
	 * @param session
	 * @param model
	 * @param projectVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/project/modifyForm.do")
	public String getModifyForm(HttpServletRequest request, HttpSession session, Model model, ProjectVO projectVO) throws Exception {
		logger.info(">>>>>> ProjectManagerController.getModifyForm >>>>>>");

		ProjectVO _projVO = projectManagerService.getprojectOne(projectVO);
		
		if(StringUtil.isNotBlank(_projVO.getProjCd())) {
			model.addAttribute("projCd" , _projVO.getProjCd());
		}
		if(StringUtil.isNotBlank(_projVO.getProjNm())) {
			model.addAttribute("projNm" , _projVO.getProjNm());
		}
		if(StringUtil.isNotBlank(_projVO.getUseYn())) {
			model.addAttribute("useYn" , _projVO.getUseYn());
		}
		if(projectVO.getWeekRepoStdDayw() != null && StringUtil.isNotEmptyInt(_projVO.getWeekRepoStdDayw())) {
			model.addAttribute("weekRepoStdDayw" , _projVO.getWeekRepoStdDayw());
		}
		if(projectVO.getPlanDsetQty() != null && StringUtil.isNotEmptyInt(_projVO.getPlanDsetQty())) {
			model.addAttribute("planDsetQty" , _projVO.getPlanDsetQty());
		}
		if(StringUtil.isNotBlank(_projVO.getProjBegYmd())) {
			model.addAttribute("projBegYmd" , _projVO.getProjBegYmd());
		}
		if(StringUtil.isNotBlank(_projVO.getProjEndYmd())) {
			model.addAttribute("projEndYmd" , _projVO.getProjEndYmd());
		}
		if(StringUtil.isNotBlank(_projVO.getRegId())) {
			model.addAttribute("regId" , _projVO.getRegId());
		}
		if(StringUtil.isNotBlank(_projVO.getRegDt())) {
			model.addAttribute("regDt" , _projVO.getRegDt());
		}
		
		model.addAttribute("updateYn", "Y");
		model.addAttribute("modifyYn", "Y");
		model.addAttribute("projectVO", projectVO);
		
		return "manager/projectManagerForm";
	}

	/**
	 * 프로젝트 등록 프로세스
	 * @param request
	 * @param session
	 * @param model
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/project/registProject.do")
	@ResponseBody
	public Map<String, Object> registProject(HttpServletRequest request, HttpSession session, Model model, ProjectVO paramVo) throws Exception {
		logger.info(">>>>>> ProjectManagerController.registProject >>>>>>");
		
		Map<?, ?> paramMap = request.getParameterMap();
		
		String projCd = request.getParameter("projCd");
		String projNm = request.getParameter("projNm");
		String useYn = request.getParameter("useYn");
		String weekRepoStdDayw = request.getParameter("weekRepoStdDayw");
		String planDsetQty = request.getParameter("planDsetQty");
		String projBegYmd = request.getParameter("projBegYmd");
		String projEndYmd = request.getParameter("projEndYmd");
		String regId = request.getParameter("regId");

		// 프로젝트 등록 리스트
		String[] labelCdList = new Gson().fromJson(((String[])paramMap.get("lblCds"))[0], String[].class);
		String[] labelNmList = new Gson().fromJson(((String[])paramMap.get("lblNms"))[0], String[].class);
		String[] labelDispList = new Gson().fromJson(((String[])paramMap.get("lblDisps"))[0], String[].class);
		String[] labelUseYnList = new Gson().fromJson(((String[])paramMap.get("lblUseYns"))[0], String[].class);
		String[] labelDispSeqList = new Gson().fromJson(((String[])paramMap.get("lblDispSeqs"))[0], String[].class);

		Map<String, Object> reqestMap = new HashMap<String, Object>();
		reqestMap.put("PROJ_CD", projCd);
		reqestMap.put("PROJ_NM", projNm);
		reqestMap.put("USE_YN", useYn);
		reqestMap.put("WEEK_REPO_STD_DAYW", weekRepoStdDayw);
		reqestMap.put("PLAN_DSET_QTY", planDsetQty);
		reqestMap.put("PROJ_BEG_YMD", projBegYmd);
		reqestMap.put("PROJ_END_YMD", projEndYmd);
		reqestMap.put("LABELCd_LIST", labelCdList);
		reqestMap.put("LABELNm_LIST", labelNmList);
		reqestMap.put("LABELDisp_LIST", labelDispList);
		reqestMap.put("LABELUseYn_LIST", labelUseYnList);
		reqestMap.put("LABELDispSeq_LIST", labelDispSeqList);
//		reqestMap.put("LABEL_LIST", labelList);
		reqestMap.put("REG_USER_ID", regId);
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(reqestMap));
		System.out.println("registProject PARAM");
		System.out.println(new Gson().toJson(reqestMap));
		projectManagerService.registProject(procMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("code", procMap.get("retCode"));
		resultMap.put("msg", procMap.get("retMsg"));
		return resultMap;
	}

	/**
	 * 프로젝트 수정 프로세스
	 * @param request
	 * @param session
	 * @param model
	 * @param projectVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/project/modifyProject.do")
	@ResponseBody
	public Map<String, Object> modifyProject(HttpServletRequest request, HttpSession session, Model model, ProjectVO projectVO) throws Exception {
		logger.info(">>>>>> ProjectManagerController.modifyProject >>>>>>");
		
		Map<?, ?> paramMap = request.getParameterMap();
		
		String projCd = request.getParameter("projCd");
		String projNm = request.getParameter("projNm");
		String useYn = request.getParameter("useYn");
		String weekRepoStdDayw = request.getParameter("weekRepoStdDayw");
		String planDsetQty = request.getParameter("planDsetQty");
		String projBegYmd = request.getParameter("projBegYmd");
		String projEndYmd = request.getParameter("projEndYmd");
		String regId = request.getParameter("regId");
		
		String[] labelCdList = new Gson().fromJson(((String[])paramMap.get("lblCds"))[0], String[].class);
		String[] labelNmList = new Gson().fromJson(((String[])paramMap.get("lblNms"))[0], String[].class);
		String[] labelDispList = new Gson().fromJson(((String[])paramMap.get("lblDisps"))[0], String[].class);
		String[] labelUseYnList = new Gson().fromJson(((String[])paramMap.get("lblUseYns"))[0], String[].class);
		String[] labelDispSeqList = new Gson().fromJson(((String[])paramMap.get("lblDispSeqs"))[0], String[].class);
		
		Map<String, Object> reqestMap = new HashMap<String, Object>();
		reqestMap.put("PROJ_CD", projCd);
		reqestMap.put("PROJ_NM", projNm);
		reqestMap.put("USE_YN", useYn);
		reqestMap.put("WEEK_REPO_STD_DAYW", weekRepoStdDayw);
		reqestMap.put("PLAN_DSET_QTY", planDsetQty);
		reqestMap.put("PROJ_BEG_YMD", projBegYmd);
		reqestMap.put("PROJ_END_YMD", projEndYmd);
		reqestMap.put("LABELCd_LIST", labelCdList);
		reqestMap.put("LABELNm_LIST", labelNmList);
		reqestMap.put("LABELDisp_LIST", labelDispList);
		reqestMap.put("LABELUseYn_LIST", labelUseYnList);
		reqestMap.put("LABELDispSeq_LIST", labelDispSeqList);
		reqestMap.put("REG_USER_ID", regId);
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(reqestMap));
		System.out.println("modifyProject PARAM");
		System.out.println(new Gson().toJson(reqestMap));
		projectManagerService.modifyProject(procMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("code", procMap.get("retCode"));
		resultMap.put("msg", procMap.get("retMsg"));
		return resultMap;
	}

	/**
	 * 프로젝트 삭제 프로세스
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/project/removeProject.do")
	@ResponseBody
	public Map<String, Object> removeProject(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> ProjectManagerController.removeProject >>>>>>");

		String projCd = request.getParameter("projCd");

		// paramMap
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("projCd", projCd);
		String rcvJson = new Gson().toJson(paramMap);

		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		projectManagerService.removeProject(procMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("msg", procMap.get("retMsg"));
		resultMap.put("code", procMap.get("retCode"));
		return resultMap;
	}

	/**
	 * 라벨 리스트
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/manager/project/getLabelList.do")
	@ResponseBody
	public Map<String, Object> getReadLabel(HttpServletRequest request, Model model) throws Exception {
		logger.info(">>>>>> ProjectManagerController.getReadLabel >>>>>>");

		String projCd = request.getParameter("projCd");

		Map<String, Object> procParamMap = new HashMap<String, Object>();
		procParamMap.put("PROJ_CD", projCd);

		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("p_rcv_json", new Gson().toJson(procParamMap));
		projectManagerService.getProjectToLabelList(procMap);

		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = new Gson().fromJson((String) procMap.get("p_ret_json"), Map.class);
		resultMap.put("p_ret_msg", procMap.get("p_ret_msg"));
		resultMap.put("p_ret_code", procMap.get("p_ret_code"));
		resultMap.put("rows", resultMap.get("labelList"));
		return resultMap;
	}
	
	/**
	 * 프로젝트 테이블 데이터 엑셀 다운로드
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/project/excelProjectList.do")
	@ResponseBody
	public Map<String, Object> excelProjectList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> ProjectManagerController.excelProjectList >>>>>>");
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
			
		String projCd = request.getParameter("projCd");
		String projNm = request.getParameter("projNm");
		resultMap.put("projCd", projCd);
		resultMap.put("projNm", projNm);
		List<Map<String,Object>> dbList = projectManagerService.projectExcelDL(resultMap);

		if(dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('"+failMsg+"');</script>");
			out.flush();
			return null;
		}
				
		// 컬럼정보
		List<String> colList = new ArrayList<String>();
		// 9
		colList.add("프로젝트 코드");
		colList.add("프로젝트명");
		colList.add("사용여부");
		colList.add("주간보고 요일");
		colList.add("목표 데이터셋 수량");
		colList.add("시작일자");
		colList.add("종료일자");
		colList.add("프로젝트 생성자");
		colList.add("프로젝트 생성일자");
		
		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		bodyList.add("PROJ_CD");
		bodyList.add("PROJ_NM");
		bodyList.add("USE_YN");
		bodyList.add("WEEK_REPO_STD_DAYW");
		bodyList.add("PLAN_DSET_QTY");
		bodyList.add("PROJ_BEG_YMD");
		bodyList.add("PROJ_END_YMD");
		bodyList.add("REG_ID");
		bodyList.add("REG_DT");
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "프로젝트_현황_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);
		
		int[] widths = new int[colNames.length];

		for(int i = 0; i < colNames.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);
		
		resultMap.put("result", "Y");
		return resultMap;
	}
}
