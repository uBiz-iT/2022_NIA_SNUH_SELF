package com.ubizit.dams.manager.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.mapper.UserMapper;
import com.ubizit.dams.common.model.UserVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("userManagerService")
public class UserManagerService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserManagerService.class);

	@Resource(name = "userMapper")
	private UserMapper userMapper;

	public UserVO getuserOne(UserVO userVO) throws Exception {
		LOGGER.info(">>>>>> UserManagerService.getuserOne >>>>>>");

		return userMapper.selectUserOne(userVO);
	}

	public void getuserOneMap(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> userManagerService.getuserOneMap >>>>>>");

		userMapper.callGetUserOneMap(map);
	}

	public List<UserVO> getuserList(UserVO userVO) throws Exception {
		LOGGER.info(">>>>>> userManagerService.getuserList >>>>>>");

		return userMapper.selectUserList(userVO);
	}

	public List<UserVO> getuserProjList(UserVO userVO) throws Exception {
		LOGGER.info(">>>>>> userManagerService.getuserProjList >>>>>>");

		return userMapper.selectUserProjList(userVO);
	}

	public List<UserVO> getuserList() throws Exception {
		LOGGER.info(">>>>>> userManagerService.getuserList >>>>>>");

		return userMapper.selectUserList();
	}

	public void registUser(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> userManagerService.registUser >>>>>>");

		userMapper.callRegistUser(map);
	}

	public void modifyUser(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> userManagerService.updateUser >>>>>>");

		userMapper.callModifyUser(map);
	}

	public void removeUser(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> userManagerService.removeUser >>>>>>");

		userMapper.callRemoveUser(map);
	}
	
	public int modifyPswd(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> userManagerService.initPswd >>>>>>");

		return userMapper.updatePswd(map);
	}

	public int userProjectValidation(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> userManagerService.userProjectValidation >>>>>>");

		int result = userMapper.userProjectValidation(map);
		return result;
	}

	public void getUserToProjectList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> userManagerService.getUserToProjectList >>>>>>");

		userMapper.callGetUserToProject(map);
	}

	public List<Map<String, Object>> userExcelDL(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> userManagerService.userExcelDL >>>>>>");

		return userMapper.userExcelDL(map);
	}

}
