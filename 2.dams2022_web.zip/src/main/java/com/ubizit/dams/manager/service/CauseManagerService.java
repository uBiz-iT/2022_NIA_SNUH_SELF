package com.ubizit.dams.manager.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.mapper.CauseMapper;
import com.ubizit.dams.common.model.FailCauseVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("causeManagerService")
public class CauseManagerService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(CauseManagerService.class);

	@Resource(name = "causeMapper")
	private CauseMapper causeMapper;

	public FailCauseVO getcauseOne(FailCauseVO failCauseVO) throws Exception {
		LOGGER.info(">>>>>> causeManagerService.getcauseOne >>>>>>");

		return causeMapper.selectCauseOne(failCauseVO);
	}

	public List<FailCauseVO> getcauseList(FailCauseVO failCauseVO) throws Exception {
		LOGGER.info(">>>>>> causeManagerService.getcauseList >>>>>>");

		return causeMapper.selectCauseList(failCauseVO);
	}

	public int registCause(FailCauseVO paramVo) throws Exception {
		LOGGER.info(">>>>>> causeManagerService.getcauseList >>>>>>");

		int result = causeMapper.insertCause(paramVo);
		return result;
	}

	public int modifyCause(FailCauseVO cause) throws Exception {
		LOGGER.info(">>>>>> causeManagerService.updateCause >>>>>>");

		int result = causeMapper.updateCause(cause);
		return result;
	}

	public int removeCause(FailCauseVO paramVo) throws Exception {
		LOGGER.info(">>>>>> causeManagerService.deleteCause >>>>>>");

		int result = causeMapper.deleteCause(paramVo);
		return result;
	}

	public void getCauseToProjectList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> causeManagerService.getCauseToProjectList >>>>>>");

		causeMapper.getCauseToProjectList(map);
	}

	public int causeProjectValidation(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> causeManagerService.causeProjectValidation >>>>>>");

		int result = causeMapper.causeProjectValidation(map);
		return result;
	}

	public List<Map<String, Object>> causeExcelDL(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> CauseManagerService.causeExcelDL >>>>>>");

		return causeMapper.causeExcelDL(map);
	}

}
