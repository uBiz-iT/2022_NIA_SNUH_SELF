package com.ubizit.dams.manager.service;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.mapper.LabelMapper;
import com.ubizit.dams.common.model.LabelVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("labelManagerService")
public class LabelManagerService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(LabelManagerService.class);

	@Resource(name = "labelMapper")
	private LabelMapper labelMapper;

	public List<LabelVO> getlabelList(LabelVO labelVO) throws Exception {
		LOGGER.info(">>>>>> labelManagerService.getlabelList >>>>>>");

		return labelMapper.selectlabelList(labelVO);
	}

	public List<LabelVO> getlabelList() throws Exception {
		LOGGER.info(">>>>>> labelManagerService.getlabelList >>>>>>");

		return labelMapper.selectlabelList();
	}

	public LabelVO getlabelOne(LabelVO labelVO) throws Exception {
		LOGGER.info(">>>>>> labelManagerService.getlabelOne >>>>>>");

		return labelMapper.selectlabelOne(labelVO);
	}

}
