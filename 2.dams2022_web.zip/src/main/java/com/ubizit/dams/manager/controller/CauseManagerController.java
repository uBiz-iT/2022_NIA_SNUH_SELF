package com.ubizit.dams.manager.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.gson.Gson;
import com.ubizit.dams.common.model.ProjectVO;
import com.ubizit.dams.common.model.FailCauseVO;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.manager.service.CauseManagerService;
import com.ubizit.dams.manager.service.ProjectManagerService;

import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST})
public class CauseManagerController {

	@Resource(name = "causeManagerService")
	protected CauseManagerService causeManagerService;

	@Resource(name = "projectManagerService")
	private ProjectManagerService projectManagerService;
	
	private final static Logger logger = LogManager.getLogger(CauseManagerController.class);

	/**
	 * 기본 페이지
	 * @param model
	 * @param FailCauseVO
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/cause.do")
	public String getPage(Model model, @ModelAttribute FailCauseVO FailCauseVO, HttpServletRequest request) throws Exception {
		logger.info(">>>>>> causeManagerController.getPage >>>>>>");

		return "manager/causeManagerList";
	}
	
	/**
	 * 사유 테이블 데이터
	 * @param request
	 * @param session
	 * @param FailCauseVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/cause/getCauseList.do")
	@ResponseBody
	public Map<String, Object> getCauseList(HttpServletRequest request, HttpSession session, @ModelAttribute FailCauseVO FailCauseVO) throws Exception {
		logger.info(">>>>>> causeManagerController.getCauseList >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 검색결과.
		List<FailCauseVO> causeList = causeManagerService.getcauseList(FailCauseVO);
		List<FailCauseVO> causeNmList = new ArrayList<FailCauseVO>();

		for (int i = 0; i < causeList.size(); i++) {
			FailCauseVO failVo = new FailCauseVO();
			String diagInspNm = "";
			failVo.setProjCd(causeList.get(i).getProjCd());
			failVo.setFailCausCd(causeList.get(i).getFailCausCd());
			failVo.setFailCausNm(causeList.get(i).getFailCausNm());

			if ("D".equals(causeList.get(i).getDiagInspFg())) {
				diagInspNm = "진단";
			} else if ("I".equals(causeList.get(i).getDiagInspFg())) {
				diagInspNm = "검수";
			} else if ("A".equals(causeList.get(i).getDiagInspFg())) {
				diagInspNm = "진단 및 검수";
			}
			failVo.setDiagInspFg(diagInspNm);
			failVo.setUseYn(causeList.get(i).getUseYn());
			failVo.setDispSeq(causeList.get(i).getDispSeq());
			failVo.setRegId(causeList.get(i).getRegId());
			failVo.setRegDt(causeList.get(i).getRegDt());

			causeNmList.add(i, failVo);
		}
		resultMap.put("causeList", causeNmList);
		
		return resultMap;
	}
	
	/**
	 * 등록폼
	 * @param model
	 * @param FailCauseVO
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/cause/registForm.do")
	public String getCauseFormList(Model model, @ModelAttribute FailCauseVO FailCauseVO, HttpServletRequest request) throws Exception {
		logger.info(">>>>>> causeManagerController.getPage >>>>>>");

		FailCauseVO _FailCauseVO = causeManagerService.getcauseOne(FailCauseVO);
		
		if(StringUtil.isNotBlank(_FailCauseVO.getProjCd())) {
			model.addAttribute("projCd" , _FailCauseVO.getProjCd());
		}
		if(StringUtil.isNotEmptyInt(_FailCauseVO.getFailCausCd())) {
			model.addAttribute("failCausCd" , _FailCauseVO.getFailCausCd());
		}
		if(StringUtil.isNotBlank(_FailCauseVO.getFailCausNm())) {
			model.addAttribute("failCausNm" , _FailCauseVO.getFailCausNm());
		}
		if(StringUtil.isNotBlank(_FailCauseVO.getDiagInspFg())) {
			model.addAttribute("diagInspFg" , _FailCauseVO.getDiagInspFg());
		}
		if(StringUtil.isNotBlank(_FailCauseVO.getUseYn())) {
			model.addAttribute("useYn" , _FailCauseVO.getUseYn());
		}
		if(StringUtil.isNotEmptyInt(_FailCauseVO.getDispSeq())) {
			model.addAttribute("dispSeq" , _FailCauseVO.getDispSeq());
		}
		if(StringUtil.isNotBlank(_FailCauseVO.getRegId())) {
			model.addAttribute("regId" , _FailCauseVO.getRegId());
		}
		if(StringUtil.isNotBlank(_FailCauseVO.getRegDt())) {
			model.addAttribute("regDt" , _FailCauseVO.getRegDt());
		}
		
//		String regDt = StringUtil.getSimpleDateFormat("yyyy-MM-dd");
//		model.addAttribute("regDt" , regDt );
		
		return "manager/causeManagerForm";
	}
	
	
	@RequestMapping(value="/manager/cause/modifyForm.do")
	public String updateCauseForm(HttpServletRequest request, HttpSession session, Model model, FailCauseVO paramVo) throws Exception {
		logger.info(">>>>>> causeManagerController.updateCauseForm >>>>>>");

		FailCauseVO _FailCauseVO = causeManagerService.getcauseOne(paramVo);

		if (StringUtil.isNotBlank(_FailCauseVO.getProjCd())) {
			model.addAttribute("projCd", _FailCauseVO.getProjCd());
		}
		if (StringUtil.isNotEmptyInt(_FailCauseVO.getFailCausCd())) {
			model.addAttribute("failCausCd", _FailCauseVO.getFailCausCd());
		}
		if (StringUtil.isNotBlank(_FailCauseVO.getFailCausNm())) {
			model.addAttribute("failCausNm", _FailCauseVO.getFailCausNm());
		}
		if (StringUtil.isNotBlank(_FailCauseVO.getDiagInspFg())) {
			model.addAttribute("diagInspFg", _FailCauseVO.getDiagInspFg());
		}
		if (StringUtil.isNotBlank(_FailCauseVO.getUseYn())) {
			model.addAttribute("useYn", _FailCauseVO.getUseYn());
		}
		if (StringUtil.isNotEmptyInt(_FailCauseVO.getDispSeq())) {
			model.addAttribute("dispSeq", _FailCauseVO.getDispSeq());
		}
		if (StringUtil.isNotBlank(_FailCauseVO.getRegId())) {
			model.addAttribute("regId", _FailCauseVO.getRegId());
		}
		if (StringUtil.isNotBlank(_FailCauseVO.getRegDt())) {
			model.addAttribute("regDt", _FailCauseVO.getRegDt());
		}
		
		model.addAttribute("modifyYn", "Y");

		return "manager/causeManagerForm";
	}
	
	
	@RequestMapping(value="/manager/cause/registCause.do")
	@ResponseBody
	public Map<String, Object> registCause(HttpServletRequest request, HttpSession session, Model model, FailCauseVO paramVo) throws Exception {
		logger.info(">>>>>> causeManagerController.registCause >>>>>>");
		
		String p_ret_msg = "";
		int p_ret_code = 0;
		
		int result = causeManagerService.registCause(paramVo);
		if(result == 0) {
			p_ret_msg = "Fail Cause 등록에 실패하였습니다.";
			p_ret_code = 0;
		}else {
			p_ret_msg = "Fail Cause 등록이 완료되었습니다.";
			p_ret_code = -1;
		}
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_ret_msg", p_ret_msg);
		resultMap.put("p_ret_code", p_ret_code);
		return resultMap;
	}
	
	@RequestMapping(value="/manager/cause/modifyCause.do")
	@ResponseBody
	public Map<String, Object> modifyCause(HttpServletRequest request, HttpSession session, Model model, FailCauseVO paramVo) throws Exception {
		logger.info(">>>>>> causeManagerController.modifyCause >>>>>>");
		
		String p_ret_msg = "";
//		int p_ret_code = 0;
		
		int result = causeManagerService.modifyCause(paramVo);
		if (result == 0) {
			System.out.println("Fail Cause 수정에 실패하였습니다.");
			p_ret_msg = "Fail Cause 수정에 실패하였습니다.";
		} else {
			System.out.println("Fail Cause 수정이 완료되었습니다.");
			p_ret_msg = "Fail Cause 수정이 완료되었습니다.";
		}
		
//		p_ret_msg = (String) resultMap.get("p_ret_msg");
//		p_ret_code = (int) resultMap.get("p_ret_code");

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_ret_msg", p_ret_msg);
//		resultMap.put("p_ret_code", p_ret_code);
		
		return resultMap;
	}
	
	/**
	 * 사유 삭제
	 * @param request
	 * @param session
	 * @param model
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/cause/removeCause.do")
	@ResponseBody
	public Map<String, Object> removeCause(HttpServletRequest request, HttpSession session, Model model, FailCauseVO paramVo) throws Exception {
		logger.info(">>>>>> causeManagerController.removeCause >>>>>>");
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		int result = causeManagerService.removeCause(paramVo);
		if(result == 0) {
			System.out.println("Fail Cause 삭제에 실패하였습니다.");
		}else {
			System.out.println("Fail Cause 삭제가 완료되었습니다.");
		}
		
		return resultMap;
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/manager/causeProject.read.do")
	@ResponseBody
	public Map<String, Object> getReadCauseProject(HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> causeManagerController.getReadProject >>>>>>");

		Map<String, Object> reqestMap = new HashMap<String, Object>();
		String failCausCd = request.getParameter("failCausCd");
		reqestMap.put("FAIL_CAUS_CD", failCausCd);
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("p_rcv_json", new Gson().toJson(reqestMap));
		causeManagerService.getCauseToProjectList(procMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = new Gson().fromJson((String) procMap.get("p_ret_json"), Map.class);
		
		resultMap.put("p_ret_msg", procMap.get("p_ret_msg"));
		resultMap.put("p_ret_code", procMap.get("p_ret_code"));
		resultMap.put("rows", resultMap.get("causeList"));
		return resultMap;
		
	}

	@RequestMapping(value="/manager/cause.project.validation.do")
	@ResponseBody
	public Map<String, Object> getcauseProjectValidation(HttpServletRequest request, HttpSession session, ProjectVO projectVo ) throws Exception {
		logger.info(">>>>>> causeManagerController.getReadProject >>>>>>");

		request.getParameterMap();
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Map<String, Object> searchMap = new HashMap<String, Object>();
		
		searchMap.put("projCd", projectVo.getProjCd());
		
		int result = causeManagerService.causeProjectValidation(searchMap);
		if(result == 0) {
//			System.out.println("삭제 가능 합니다.");
		}else {
//			System.out.println("해당 프로젝트 Task에 진단자 및 검수자 등록된 유저는 삭제 불가능 합니다.");
		}
		
		return resultMap;
	}
	
	/**
	 * 사유 엑셀 다운로드
	 * @param request
	 * @param response
	 * @param session
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/manager/cause/excelCauseList.do")
	@ResponseBody
	public Map<String, Object> excelCauseList(HttpServletRequest request, HttpServletResponse response, HttpSession session , Model model) throws Exception {
		logger.info(">>>>>> causeManagerController.excelCauseList >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		String projCd = request.getParameter("projCd");
		String failCausCd = request.getParameter("failCausCd");
		String failCausNm = request.getParameter("failCausNm");
		
		resultMap.put("projCd", projCd);
		resultMap.put("failCausCd", failCausCd);
		resultMap.put("failCausNm", failCausNm);
		
		// 엑셀에 담을 데이터 조회
		List<Map<String,Object>> dbList = causeManagerService.causeExcelDL(resultMap);

		if(dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8"); 
			PrintWriter out = response.getWriter();
			out.println("<script>alert('"+failMsg+"');</script>");
			out.flush();
			return null;
		}
		
		// 컬럼정보
		List<String> colList = new ArrayList<String>();
		// 7
		colList.add("Fail Cause 코드");
		colList.add("Fail Cause 내용");
		colList.add("진단 검수 사용여부");
		colList.add("사용여부");
		colList.add("표시 순번");
		colList.add("등록자");
		colList.add("등록 일자");
		
		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		bodyList.add("FAIL_CAUS_CD");
		bodyList.add("FAIL_CAUS_NM");
		bodyList.add("DIAG_INSP_FG");
		bodyList.add("USE_YN");
		bodyList.add("DISP_SEQ");
		bodyList.add("REG_ID");
		bodyList.add("REG_DT");
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "Fail Cause_현황_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);
		
		int[] widths = new int[colNames.length];

		for(int i = 0; i < colNames.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);
		
		resultMap.put("result", "Y");
		return resultMap;
	}
}
