package com.ubizit.dams.manager.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.mapper.ProjectMapper;
import com.ubizit.dams.common.model.ProjectVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("projectManagerService")
public class ProjectManagerService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProjectManagerService.class);
	
	@Resource(name="projectMapper")
	private ProjectMapper projectMapper;
	
	public ProjectVO getprojectOne(ProjectVO projectVO) throws Exception {
		LOGGER.info(">>>>>> ProjectManagerService.getprojectOne >>>>>>");
		
		return projectMapper.selectProjectOne(projectVO);
	}

	public void getprojectOneMap(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> projectManagerService.getprojectOneMap >>>>>>");
		
		projectMapper.callGetProjectMap(map);
	}
	
	public List<ProjectVO> getprojectList(ProjectVO projectVO) throws Exception {
		LOGGER.info(">>>>>> projectManagerService.getprojectList >>>>>>");
		
		return projectMapper.selectProjectList(projectVO);
	}
	
	public void registProject(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> projectManagerService.registProject >>>>>>");

		projectMapper.callRegistProject(map);
	}

	public void modifyProject(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> projectManagerService.updateProject >>>>>>");

		projectMapper.callModifyProject(map);
	}
	
	public void removeProject(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> projectManagerService.removeProject >>>>>>");

		projectMapper.callRemoveProject(map);
	}

	public void getProjectToLabelList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> projectManagerService.getProjectToLabelList >>>>>>");
		
		projectMapper.getProjectToLabelList(map);
	}
	
	public void getProjectReadLabel(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> projectManagerService.getProjectReadLabel >>>>>>");
		
		projectMapper.getProjectReadLabel(map);
	}
	
	public List<Map<String, Object>> projectExcelDL(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProjectService.projectExcelDL >>>>>>");
		
		return projectMapper.projectExcelDL(map);
	}

}
