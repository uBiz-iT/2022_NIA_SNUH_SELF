package com.ubizit.dams.manager.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.mapper.TaskMapper;
import com.ubizit.dams.work.model.PlvTaskUserPlanVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("taskManagerService")
public class TaskManagerService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(TaskManagerService.class);

	@Resource(name = "taskMapper")
	private TaskMapper taskMapper;

	public PlvTaskUserPlanVO getTaskOne(PlvTaskUserPlanVO taskVO) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.getTaskOne >>>>>>");

		return taskMapper.selectTaskOne(taskVO);
	}

	public List<PlvTaskUserPlanVO> getTaskList(PlvTaskUserPlanVO taskVO) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.getTaskList >>>>>>");

		return taskMapper.selectTaskList(taskVO);
	}

	public void getTaskToUserList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.getTaskToUserList >>>>>>");

		taskMapper.callGetTaskToUserList(map);
	}

	public void registTask(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.registTask >>>>>>");

		taskMapper.callRegistTask(map);
	}

	public void modifyTask(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.modifyTask >>>>>>");

		taskMapper.callModifyTask(map);
	}

	public void removeTask(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.removeTask >>>>>>");

		taskMapper.callRemoveTask(map);
	}

	public List<Map<String, Object>> taskExcelDL(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.taskExcelDL >>>>>>");

		return taskMapper.taskExcelDL(map);
	}
}
