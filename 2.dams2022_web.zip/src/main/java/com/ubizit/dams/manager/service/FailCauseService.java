package com.ubizit.dams.manager.service;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.mapper.FailCauseMapper;
import com.ubizit.dams.common.model.FailCauseVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("failCauseManagerService")
public class FailCauseService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(FailCauseService.class);
	
	@Resource(name="failCauseMapper")
	private FailCauseMapper failCauseMapper;

	public List<FailCauseVO> getfailCauseList(FailCauseVO failCauseVO) throws Exception {
		LOGGER.info(">>>>>> failCauseManagerService.getfailCauseList >>>>>>");
		
		return failCauseMapper.selectFailCauseList(failCauseVO);
	}
	
	public List<FailCauseVO> getfailCauseList() throws Exception {
		LOGGER.info(">>>>>> failCauseManagerService.getfailCauseList >>>>>>");
		
		return failCauseMapper.selectFailCauseList();
	}
	
	public FailCauseVO getfailCauseOne(FailCauseVO failCauseVO) throws Exception {
		LOGGER.info(">>>>>> failCauseManagerService.getfailCauseOne >>>>>>");
		
		return failCauseMapper.selectFailCauseOne(failCauseVO);
	}

}
