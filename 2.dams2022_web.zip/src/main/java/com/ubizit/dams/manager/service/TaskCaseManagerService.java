package com.ubizit.dams.manager.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.mapper.TaskCaseMapper;
import com.ubizit.dams.common.model.TaskCaseVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("taskCaseManagerService")
public class TaskCaseManagerService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(TaskCaseManagerService.class);

	@Resource(name = "taskCaseMapper")
	private TaskCaseMapper taskCaseMapper;

	public List<Map<String, Object>> getTaskList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskCaseManagerService.getTaskList >>>>>>");

		return taskCaseMapper.selectTaskList(map);
	}

	public void getTaskCaseStepList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskCaseManagerService.getTaskCaseStepList >>>>>>");

		taskCaseMapper.callGetTaskCaseStepList(map);
	}

	// 미사용
	public int registTaskCase(TaskCaseVO vo) throws Exception {
		LOGGER.info(">>>>>> userManagerService.registTaskCase >>>>>>");

		int result = taskCaseMapper.insertTaskCase(vo);
		return result;
	}

	// 미사용
	public int modifyTaskCase(TaskCaseVO vo) throws Exception {
		LOGGER.info(">>>>>> userManagerService.deleteTaskCase >>>>>>");

		int result = taskCaseMapper.deleteTaskCase(vo);
		return result;
	}

	// 미사용
	public int removeTaskCase(TaskCaseVO vo) throws Exception {
		LOGGER.info(">>>>>> userManagerService.deleteTaskCase >>>>>>");

		int result = taskCaseMapper.deleteTaskCase(vo);
		return result;
	}

	public List<Map<String, Object>> taskCaseExcelDL(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskCaseManagerService.taskCaseExcelDL >>>>>>");

		return taskCaseMapper.taskCaseExcelDL(map);
	}
}
