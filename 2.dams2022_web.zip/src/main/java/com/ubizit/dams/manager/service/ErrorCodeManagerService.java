package com.ubizit.dams.manager.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.mapper.ErrorCodeMapper;
import com.ubizit.dams.common.mapper.UserMapper;
import com.ubizit.dams.common.model.ProjectVO;
import com.ubizit.dams.common.model.UserVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("errorCodeManagerService")
public class ErrorCodeManagerService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(ErrorCodeManagerService.class);
	
	@Resource(name="errorCodeMapper")
	private ErrorCodeMapper errorCodeMapper;


}
