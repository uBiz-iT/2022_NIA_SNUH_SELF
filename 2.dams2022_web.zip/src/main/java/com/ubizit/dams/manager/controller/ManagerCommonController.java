package com.ubizit.dams.manager.controller;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;

import com.ubizit.dams.manager.service.ProjectManagerService;
import com.ubizit.dams.manager.service.UserManagerService;

@Controller
public class ManagerCommonController {

	@Resource(name="userManagerService")
	protected UserManagerService userManagerService;
	
	@Resource(name="projectManagerService")
	private ProjectManagerService projectManagerService;
	
	private final static Logger logger = LogManager.getLogger(ManagerCommonController.class);

	
	
}

