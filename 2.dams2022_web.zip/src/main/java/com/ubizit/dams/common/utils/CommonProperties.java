/**
 * 
 */
package com.ubizit.dams.common.utils;

import java.io.IOException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;import org.apache.logging.log4j.Logger;


/**
 * @Class Name : CommonProperties.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 22.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 22.
 * @version : 1.0
 * 
 */
public class CommonProperties {

	private final static Logger logger = LogManager.getLogger(CommonProperties.class);
	
	/** instance */
	private static CommonProperties instance;
	
	/** 설정파일 이름 */
	private static final String propertiesPath = "/conf/common.properties";
	
	/** 개발 properties */
	private static Properties prop;
	
	/** logger */
	private CommonProperties() {
		logger.debug(">>>>>>>>>> CommonProperties constructed! >>>>>>>>>>");
	}
	
	/** @return instance */
	public static CommonProperties getinstance(){
		init();
		return instance;
	}
	
	/** 초기화 */
	private static void init(){
		try {
			if (instance == null) {
				instance = new CommonProperties();
			}
			
			try{
				prop = new Properties();
    			prop.load(CommonProperties.class.getResourceAsStream(propertiesPath));
			} catch (IOException e){
				prop = null;
			}
			
		} catch (Exception e){
			instance =  null;
			e.printStackTrace();
		}
	}
	
	
	public static String load(String property) {
		String res = null;
		
		if(prop == null) {
			init();
		}
		
		if(StringUtil.isBlank(res)) {
			res = prop.getProperty(property);
		}
		
		if(res != null) {
			res = res.trim();
		}
		
		return res;
	}
	
	public static String load2(String property) {
		if (prop == null) init();
		
		String result = prop.getProperty(property);
		return result != null ? result.trim() : null;
	}
	
	/** jdbc.driveName **/
	public static String getDriveName(){
		return load("jdbc.driverName");
	}
	
	/** jdbc.conURL **/
	public static String getConUrl(){
		return load("jdbc.conURL");
	}
	
	/** jdbc.userName **/
	public static String getUserName(){
		return load("jdbc.userName");
	}
	
	/** jdbc.password **/
	public static String getPassword(){
		return load("jdbc.password");
	}
	
}
