package com.ubizit.dams.common.listener;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.ubizit.dams.common.model.UserVO;

public class SessionListener implements HttpSessionListener {
	
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		// TODO Auto-generated method stub
	}
	
	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		HttpSession session = se.getSession();
		
		// 1. 아이디 체크
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		if (loginUser == null) {
			// 나중에
		}
		
	}
	
}
