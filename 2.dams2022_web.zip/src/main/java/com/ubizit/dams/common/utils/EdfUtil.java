package com.ubizit.dams.common.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ubizit.dams.common.edfutils.UEdfInterpolationData;
import com.ubizit.dams.common.edfutils.UEdfModule;
 
 
public class EdfUtil {
    
	// TEST
	public static void main(String[] args) {
		String path = "D:\\data\\snuh2022\\sleep\\A1001\\A0001\\S2022-01-001-01.edf";
		Map<String, Object> edfResult = EdfUtil.readEdf(path, 30, 21, 1, 2, 30);
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String edfJson = gson.toJson(edfResult);
		System.out.println(edfJson);
	}
	
	public static Map<String, Object> readEdf(String path, int epochSize, int signalNo, int epochNo, int epochCount, int targetSamplingRate) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
    	UEdfModule edf = new UEdfModule(path, epochSize);
        // 수면
        // actiX:21, actiY:22, actiZ: 23, ecg(ekg): 8
        List<UEdfInterpolationData> iDataList2 = edf.getInterpolationData(signalNo, targetSamplingRate, epochNo, epochCount);
        
        resultMap.put("data", iDataList2);
        return resultMap;
    }
	

    
    
}