package com.ubizit.dams.common.model;

/**
 * @Description: 로그인 vo 가 따로 필요한가?
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.05.11 - 박성욱 - 최초생성
 *
 * @author: PSW
 * @since: 2022.05.11
 */
public class ProjectVO {

	// DB
    private String projCd;
    private String projNm;
    private String useYn;
    private Integer weekRepoStdDayw;
    private Integer planDsetQty;
    private String projBegYmd;
    private String projEndYmd;
    private String regId;
    private String regDt;
    private String diagInspFg;
    private Integer passRate;

    // 2022-06-14 유저가 등록된 프로젝트 조회시 필요
    private String userId;
    private String userNm;
    // 2022-07-11 요일 표시 한글로
    private String weekRepoStdDaywStr;
    // 프로젝트 등록화면 리스트 조회조건 추가 useYn 조건 없앰
    private String projYn;
    
	@Override
	public String toString() {
		return "ProjectVO [projCd=" + projCd + ", projNm=" + projNm + ", useYn=" + useYn + ", weekRepoStdDayw="
				+ weekRepoStdDayw + ", planDsetQty=" + planDsetQty + ", projBegYmd=" + projBegYmd + ", projEndYmd="
				+ projEndYmd + ", regId=" + regId + ", regDt=" + regDt + ", diagInspFg=" + diagInspFg + ", passRate="
				+ passRate + ", userId=" + userId + ", userNm=" + userNm + "]";
	}
	
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getProjNm() {
		return projNm;
	}
	public void setProjNm(String projNm) {
		this.projNm = projNm;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public Integer getWeekRepoStdDayw() {
		return weekRepoStdDayw;
	}
	public void setWeekRepoStdDayw(Integer weekRepoStdDayw) {
		this.weekRepoStdDayw = weekRepoStdDayw;
	}
	public Integer getPlanDsetQty() {
		return planDsetQty;
	}
	public void setPlanDsetQty(Integer planDsetQty) {
		this.planDsetQty = planDsetQty;
	}
	public String getProjBegYmd() {
		return projBegYmd;
	}
	public void setProjBegYmd(String projBegYmd) {
		this.projBegYmd = projBegYmd;
	}
	public String getProjEndYmd() {
		return projEndYmd;
	}
	public void setProjEndYmd(String projEndYmd) {
		this.projEndYmd = projEndYmd;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getDiagInspFg() {
		return diagInspFg;
	}
	public void setDiagInspFg(String diagInspFg) {
		this.diagInspFg = diagInspFg;
	}
	public Integer getPassRate() {
		return passRate;
	}
	public void setPassRate(Integer passRate) {
		this.passRate = passRate;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public String getWeekRepoStdDaywStr() {
		return weekRepoStdDaywStr;
	}

	public void setWeekRepoStdDaywStr(String weekRepoStdDaywStr) {
		this.weekRepoStdDaywStr = weekRepoStdDaywStr;
	}

	public String getProjYn() {
		return projYn;
	}

	public void setProjYn(String projYn) {
		this.projYn = projYn;
	}
    
}
