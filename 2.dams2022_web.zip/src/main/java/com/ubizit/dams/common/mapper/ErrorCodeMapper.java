package com.ubizit.dams.common.mapper;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("errorCodeMapper")
public class ErrorCodeMapper extends EgovAbstractMapper {
	
	
}
