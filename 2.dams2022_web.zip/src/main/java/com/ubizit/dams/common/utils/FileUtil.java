package com.ubizit.dams.common.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.FileCopyUtils;

public class FileUtil {
	
	public static void main(String[] args) {
		// TEST
		
		
		
	}

	// 1 way
	public static void download(String sourceUrl, String targetFilename) {
		FileOutputStream fos = null;
		InputStream is = null;
		try {
			fos = new FileOutputStream("download/" + targetFilename);

			URL url = new URL(sourceUrl);
			URLConnection urlConnection = url.openConnection();
			is = urlConnection.getInputStream();
			byte[] buffer = new byte[1024];
			int readBytes;
			while ((readBytes = is.read(buffer)) != -1) {
				fos.write(buffer, 0, readBytes);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fos != null) {
					fos.close();
				}
				if (is != null) {
					is.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	// 2 way
	public static void filDown(HttpServletRequest request, HttpServletResponse response, String filePath,
			String realFilNm, String viewFileNm) throws IOException {

		File file = new File(filePath + realFilNm);
		System.out.println("root = " + filePath + realFilNm);
		if (file.exists() && file.isFile()) {
			response.setContentType("application/octet-stream; charset=utf-8");
			response.setContentLength((int) file.length());
			String browser = getBrowser(request);
			String disposition = getDisposition(viewFileNm, browser);
			response.setHeader("Content-Disposition", disposition);
			response.setHeader("Content-Transfer-Encoding", "binary");
			OutputStream out = response.getOutputStream();
			FileInputStream fis = null;
			fis = new FileInputStream(file);
			FileCopyUtils.copy(fis, out);
			if (fis != null)
				fis.close();
			out.flush();
			out.close();
		}
	}

	private static String getBrowser(HttpServletRequest request) {
		String header = request.getHeader("User-Agent");
		if (header.indexOf("MSIE") > -1 || header.indexOf("Trident") > -1)
			return "MSIE";
		else if (header.indexOf("Chrome") > -1)
			return "Chrome";
		else if (header.indexOf("Opera") > -1)
			return "Opera";
		return "Firefox";
	}

	private static String getDisposition(String filename, String browser) throws UnsupportedEncodingException {
		String dispositionPrefix = "attachment;filename=";
		String encodedFilename = null;
		if (browser.equals("MSIE")) {
			encodedFilename = URLEncoder.encode(filename, "UTF-8").replaceAll("\\+", "%20");
		} else if (browser.equals("Firefox")) {
			encodedFilename = "\"" + new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		} else if (browser.equals("Opera")) {
			encodedFilename = "\"" + new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		} else if (browser.equals("Chrome")) {
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < filename.length(); i++) {
				char c = filename.charAt(i);
				if (c > '~') {
					sb.append(URLEncoder.encode("" + c, "UTF-8"));
				} else {
					sb.append(c);
				}
			}
			encodedFilename = sb.toString();
		}
		return dispositionPrefix + encodedFilename;
	}

	// 파일 여러개 압축후 다운로드 예시
	public static void compressedDownload(HttpServletResponse response, String zipFileName, List<String> sourceFileList) {

		/** 압축된 ZIP파일 이름 */
		String zipFile = "E:/test.zip";
		
		String downloadFileName = "result";

		List<String> sourceFiles = new ArrayList<String>();
		sourceFiles.add("E:/file1.txt");
		sourceFiles.add("E:/file2.txt");
		sourceFiles.add("E:/file3.txt");

		try {

			// ZipOutputStream을 FileOutputStream 으로 감쌈
			FileOutputStream fout = new FileOutputStream(zipFile);
			ZipOutputStream zout = new ZipOutputStream(fout);

			for (int i = 0; i < sourceFiles.size(); i++) {

				// 본래 파일명 유지, 경로제외 파일압축을 위해 new File로
				ZipEntry zipEntry = new ZipEntry(new File(sourceFiles.get(i)).getName());
				zout.putNextEntry(zipEntry);

				// 경로포함 압축
				// zout.putNextEntry(new ZipEntry(sourceFiles.get(i)));

				FileInputStream fin = new FileInputStream(sourceFiles.get(i));
				byte[] buffer = new byte[1024];
				int length;

				// input file을 1024바이트로 읽음, zip stream에 읽은 바이트를 씀
				while ((length = fin.read(buffer)) > 0) {
					zout.write(buffer, 0, length);
				}

				zout.closeEntry();
				fin.close();
			}

			zout.close();

			response.setContentType("application/zip");
			response.addHeader("Content-Disposition", "attachment; filename=" + downloadFileName + ".zip");

			FileInputStream fis = new FileInputStream(zipFile);
			BufferedInputStream bis = new BufferedInputStream(fis);
			ServletOutputStream so = response.getOutputStream();
			BufferedOutputStream bos = new BufferedOutputStream(so);

			byte[] data = new byte[2048];
			int input = 0;

			while ((input = bis.read(data)) != -1) {
				bos.write(data, 0, input);
				bos.flush();
			}

			if (bos != null)
				bos.close();
			if (bis != null)
				bis.close();
			if (so != null)
				so.close();
			if (fis != null)
				fis.close();

		} catch (IOException ioe) {

		}
	}

}