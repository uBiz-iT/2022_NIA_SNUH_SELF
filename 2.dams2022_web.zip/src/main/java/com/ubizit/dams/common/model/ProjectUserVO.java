package com.ubizit.dams.common.model;

/**
 * @Description: 
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.06
 *
 * @author: PSW
 * @since: 2022
 */

import java.io.Serializable;

public class ProjectUserVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4105211337511814509L;
	
	private String projCd;
	private String projNm;
	private String userId;
	private String mgrYn;
	private String regId;
	private String regDt;
	
	@Override
	public String toString() {
		return "ProjectUserVO [projCd=" + projCd + ", userId=" + userId + ", mgrYn=" + mgrYn + ", regId=" + regId
				+ ", regDt=" + regDt + "]";
	}
	
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	
	public String getProjNm() {
		return projNm;
	}

	public void setProjNm(String projNm) {
		this.projNm = projNm;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getMgrYn() {
		return mgrYn;
	}
	public void setMgrYn(String mgrYn) {
		this.mgrYn = mgrYn;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

}
