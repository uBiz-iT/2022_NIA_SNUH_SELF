package com.ubizit.dams.common.edfutils;

import java.time.LocalDateTime;

public class UEdfBaseInfo {
	public LocalDateTime startDateTime;
    public String patient;
    public int signalCount;
    public long recordCount;
    public double recordDuration;
    public long totalDuration;
    public int epochSize;
    public long totalEpochCount;
}
