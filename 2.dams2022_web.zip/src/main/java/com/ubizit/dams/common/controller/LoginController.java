package com.ubizit.dams.common.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubizit.dams.common.model.UserVO;
import com.ubizit.dams.common.service.LoginService;
import com.ubizit.dams.common.utils.BCriptUtil;

@Controller
public class LoginController {

	@Resource(name = "loginService")
	private LoginService loginService;
	
	private final static Logger LOGGER = LogManager.getLogger(LoginController.class);
	
	/**
	 * 로그인 페이지
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/login.do")
	public String getLoginPage(HttpServletRequest request, ModelMap model) throws Exception {
		LOGGER.info(">>>>>> LoginController.getLoginPage >>>>>>");
		Cookie[] cookies = request.getCookies();
		
		try {
			String rememberId = "";
			String autoLogin = "";
			for (Cookie ck : cookies) {
				if (ck != null) {
					if ("rememberId".equals(ck.getName())) {
						rememberId = ck.getValue();
					}
					if ("autoLogin".equals(ck.getName())) {
						autoLogin = "Y";
					}
				}
			}
			model.addAttribute("rememberId", rememberId);
			model.addAttribute("autoLogin", autoLogin);
			model.addAttribute("mode", "login");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "login";
	}
	
	/**
	 * 로그인 요청
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/loginProcess.do", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> loginProcess(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.info(">>>>>> LoginController.loginProcess >>>>>>");

		Map<String, Object> resultMap = new HashMap<String, Object>();
		HttpSession session = request.getSession();

		String loginId = request.getParameter("loginId");
		String loginPass = request.getParameter("loginPass");
		String rememberId = request.getParameter("rememberId");
		String autoLogin = request.getParameter("autoLogin");

		if (loginId == null || loginPass == null) {
			resultMap.put("result", false);
			return resultMap;
		}
		// 로그인 아이디 확인 && 비밀번호 확인
		UserVO user = loginService.getUserByLogin(loginId);
		if (user != null && BCriptUtil.isMatch(loginPass, user.getPswd())) {
			session.setAttribute("LOGIN_USER", user);
			resultMap.put("result", true);
			// ------------------
			//     rememberId
			// ------------------
			Cookie cookie = new Cookie("rememberId", loginId);
			if ("Y".equals(rememberId)) {
				response.addCookie(cookie);
			} else {
				cookie.setMaxAge(0);
				response.addCookie(cookie);
			}
			// -----------------
			//     autoLogin
			// -----------------
			String autoLoginString = loginId + "|"+ loginPass;
			Cookie cookie2 = new Cookie("autoLogin", autoLoginString);
			if ("Y".equals(autoLogin)) {
				response.addCookie(cookie2);
			} else {
				cookie2.setMaxAge(0);
				response.addCookie(cookie2);
			}
		} else {
			resultMap.put("result", false);
		}
		return resultMap;
	}
	
	/**
	 * 로그아웃 요청
	 * 마지막수정일 : 2022-10-04 psw
	 * @param session
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/logout.do")
	public String logOut(HttpSession session, Model model) throws Exception {
		LOGGER.info(">>>>>> LoginController.logout >>>>>>");

		session.removeAttribute("LOGIN_USER");
		model.addAttribute("mode", "logout");
		return "login";
	}

	/**
	 * 비밀번호 변경 팝업 창
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/pswdChange.do")
	public String getPswdChangePage() throws Exception {
		LOGGER.info(">>>>>> LoginController.getPswdChangePage >>>>>>");
		
		return "pswdChange";
	}
	
	/**
	 * 비밀번호 변경 요청
	 * @param session
	 * @param userVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/pswdChange/modifyPswd.do", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> modifyPswd(HttpSession session , UserVO userVO) throws Exception {
		LOGGER.info(">>>>>> LoginController.modifyPswd >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		
		// 1. 비밀번호 확인
		if (!BCriptUtil.isMatch(userVO.getPswd(), loginUser.getPswd())) {
			resultMap.put("result", false);
			return resultMap;
		}
		
		// changePswd Result
		UserVO paramVO = new UserVO();
		paramVO.setUserId(loginUser.getUserId());
		String encodedChangePswd = BCriptUtil.encodePswd(userVO.getChangePswd());
		paramVO.setChangePswd(encodedChangePswd);
		int result = loginService.modifyPswd(paramVO);

		if (result > 0) {
			// 세션 업데이트
			loginUser.setPswd(encodedChangePswd);
			session.setAttribute("LOGIN_USER", loginUser);
			resultMap.put("result", true);
		} else {
			resultMap.put("result", false);
		}
		return resultMap;
	}
	
}
