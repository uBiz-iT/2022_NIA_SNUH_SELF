package com.ubizit.dams.common.model;

public class UserVO {
	
	private String userId;
	private String userNm;
	private String pswd;
	private String useYn;
	private String sysMgrYn;
	private String regId;
	private String regDt;
	
	// 사용자 비밀번호 직접 변경
	private String changePswd;
	
	// 프로젝트 관리자 권한
	private String mgrYn;
	
	// 유저팝업 검색 조건 프로젝트 코드 추가
	private String projCd;
	
	// 22-07-06 등록 프로젝트 목록
	private String projMapping;
	
	// 22-07-12 진단 검수자 종류
	private String diagInspFg;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getPswd() {
		return pswd;
	}
	public void setPswd(String pswd) {
		this.pswd = pswd;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getSysMgrYn() {
		return sysMgrYn;
	}
	public void setSysMgrYn(String sysMgrYn) {
		this.sysMgrYn = sysMgrYn;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

	public String getMgrYn() {
		return mgrYn;
	}

	public void setMgrYn(String mgrYn) {
		this.mgrYn = mgrYn;
	}

	public String getProjCd() {
		return projCd;
	}

	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}

	public String getProjMapping() {
		return projMapping;
	}

	public void setProjMapping(String projMapping) {
		this.projMapping = projMapping;
	}

	public String getDiagInspFg() {
		return diagInspFg;
	}

	public void setDiagInspFg(String diagInspFg) {
		this.diagInspFg = diagInspFg;
	}

	public String getChangePswd() {
		return changePswd;
	}

	public void setChangePswd(String changePswd) {
		this.changePswd = changePswd;
	}

}
