package com.ubizit.dams.common.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class StringUtil extends StringUtils {

	public static boolean isNotEmpty(String str) {
		return str != null && str.length() != 0;
	}
	
	public static boolean isEmpty(String str) {
		return !isNotEmpty(str);
	}
	
	public static boolean isNotEmptyInt(int num) {
		return num != 0;
	}

	/**
	 * Method : getSimpleDateFormat
	 * 최초작성일 : 2022 . 6
	 * 작성자 : 
	 * 변경이력 :
	 * @param time
	 * @return
	 * Method 설명 : 날짜형식을 인자값으로 원하는 형식으로 날짜 반환하는 메서드
	 */
	public static String getSimpleDateFormat(String time){
		SimpleDateFormat format = new SimpleDateFormat(time);
		Calendar cal = Calendar.getInstance();
		String formatTime = format.format(cal.getTime());
		return formatTime;
	}

	public static void printMapToJson(Map<String, Object> map) {
		String json = new Gson().toJson(map);
		System.out.println(json);
	}

	public static void printMapToJsonPretty(Map<String, Object> map) {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(map);
		System.out.println(json);
	}

	public static void printMapToJsonPretty(Object ob) {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(ob);
		System.out.println(json);
	}
	
	public static String parseJsonObjectToString (JSONObject jsonObject){
		String jsonData = "";
		if(jsonObject != null && jsonObject.size() > 0){
			try{
				ObjectMapper mapper = new ObjectMapper();
				jsonData = mapper.writeValueAsString(jsonObject);
				
			} catch (Exception e) {
				System.out.println("Connection Exception occurred");
			}
		}
		
		return jsonData;
	}
	
	public static boolean isNumber(String str) {
		if (str == null || "".equals(str)) return false;
        return str.matches("[+-]?\\d*(\\.\\d+)?");
	}
	
	public static double roundToSignificantFigures(double num, int n) {
	    if(num == 0) {
	        return 0;
	    }

	    final double d = Math.ceil(Math.log10(num < 0 ? -num: num));
	    final int power = n - (int) d;

	    final double magnitude = Math.pow(10, power);
	    final long shifted = Math.round(num*magnitude);
	    return shifted/magnitude;
	}
	
}
