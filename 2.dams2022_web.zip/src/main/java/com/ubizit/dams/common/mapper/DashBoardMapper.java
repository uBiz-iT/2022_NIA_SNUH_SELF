package com.ubizit.dams.common.mapper;

import java.util.Map;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("dashboardMapper")
public class DashBoardMapper extends EgovAbstractMapper {

	public void callGetMainProgressCnt(Map<String, Object> map) throws Exception {
		selectList("DASHBOARD_MAPPER.callGetMainProgressCnt", map);
	}

	public void callGetMonthChart(Map<String, Object> map) throws Exception {
		selectList("DASHBOARD_MAPPER.callGetMonthChart", map);
	}

	public void callGetMonthAcmChart(Map<String, Object> map) throws Exception {
		selectList("DASHBOARD_MAPPER.callGetMonthAcmChart", map);
	}

	public void callGetMainUserChart(Map<String, Object> map) throws Exception {
		selectList("DASHBOARD_MAPPER.callGetMainUserChart", map);
	}

}
