package com.ubizit.dams.common.service;

import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.mapper.LoginMapper;
import com.ubizit.dams.common.mapper.UserMapper;
import com.ubizit.dams.common.model.UserVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : LoginServiceImpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 28.
 * @version : 1.0
 * 
 */
@Service("loginService")
public class LoginService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginService.class);
	
	@Resource(name="userMapper")
	private UserMapper userMapper;
	
	@Resource(name="loginMapper")
	private LoginMapper loginMapper;

	public UserVO getUserByLogin(String loginId) throws Exception {
		LOGGER.info(">>>>>> LoginService.getUserByLogin >>>>>>");
		
		UserVO loginUser = new UserVO();
		loginUser.setUserId(loginId);
//		loginUser.setPswd(loginPass); // 암호화 후에 필요 없음. 2022-09-19
		return loginMapper.selectUserByLogin(loginUser);
		
	}
	
	public UserVO getUserInfo(String loginId) throws Exception {
		LOGGER.info(">>>>>> LoginService.getUserLoginResult >>>>>>");
		
		UserVO loginUser = new UserVO();
		loginUser.setUserId(loginId);
		return userMapper.selectUserOne(loginUser);
		
	}

//	public void getPswdModify(Map<String, Object> map) throws Exception {
//		LOGGER.info(">>>>>> LoginService.getUserLoginResult >>>>>>");
//		
//		userMapper.updatePswd(map);
//	}
	
	public int modifyPswd(UserVO vo) throws Exception {
		LOGGER.info(">>>>>> LoginService.modifyPswd >>>>>>");
		
		return loginMapper.updatePswd(vo);
	}

}
