package com.ubizit.dams.common.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
 
 
public class CsvUtil {
	
//	public static String readText(String filePath) {
//    	String result;
//        try {
//        	new FileReader(new File(filePath), "UTF-8");
//            String[] s;
//            while ((s = reader.readNext()) != null) {
//                data.add(s);
//            }
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return result;
//    }
	
	public static List<String[]> readCsv(String filePath) {
    	List<String[]> data = new ArrayList<String[]>();
        try {
        	CSVReader reader = new CSVReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
            String[] s;
            while ((s = reader.readNext()) != null) {
                data.add(s);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (CsvValidationException e) {
        	e.printStackTrace();
        }
        return data;
    }
    
	public static String readSeek(String filePath, long cursorPos, int size) {
		String result = "";
		byte[] byteResult = new byte[size];
		try (RandomAccessFile file = new RandomAccessFile(filePath, "r")) {
			long fileLength = file.length();
			if (cursorPos + size > fileLength) {
				cursorPos = fileLength - size;
				System.out.println("apple");
			}
			// 1. 커서 위치 지정.
        	file.seek(cursorPos);
        	// 2. 바이트에 데이터 담아오기.
        	file.read(byteResult);
        	result = new String(byteResult);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } 
        return result;
    }
	
	public static String[] readSeekCsvArr(String filePath, int cursorPos, int size) {
		return readSeek(filePath, cursorPos, size).split(",");
	}
    
    
    
}