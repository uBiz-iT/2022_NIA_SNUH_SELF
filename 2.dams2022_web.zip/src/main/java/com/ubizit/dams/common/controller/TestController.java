package com.ubizit.dams.common.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.service.TestService;

@Controller
public class TestController {

	private final static Logger logger = LogManager.getLogger(TestController.class);

	@Resource(name="testService")
	private TestService testService;

	@RequestMapping(value = "/test/getCursorTest.do")
	@ResponseBody
	public Map<String, Object> getCursorTest() throws Exception {
		logger.info(">>>>>> TestController.getCursorTest >>>>>>");
		
		// paramMap
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("projCd", "2022A1");
		String rcvJson = new Gson().toJson(paramMap);

		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		testService.getCursorTest(procMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("code", procMap.get("retCode"));
		resultMap.put("msg", procMap.get("retMsg"));
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> rows = (List<Map<String, Object>>) procMap.get("retJson");
		resultMap.put("rows", rows);
		return resultMap;
	}
	
	@RequestMapping(value = "/test/getCursorTest")
	@ResponseBody
	public Map<String, Object> getCursorTest2() throws Exception {
		logger.info(">>>>>> TestController.getCursorTest2 >>>>>>");
		
		// paramMap
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("projCd", "2022A1");
		String rcvJson = new Gson().toJson(paramMap);

		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		testService.getCursorTest(procMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("code", procMap.get("retCode"));
		resultMap.put("msg", procMap.get("retMsg"));
		
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> rows = (List<Map<String, Object>>) procMap.get("retJson");
		resultMap.put("rows", rows);
		return resultMap;
	}

}
