package com.ubizit.dams.common.mapper;

import java.util.List;

import com.ubizit.dams.common.model.LabelVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("labelMapper")
public class LabelMapper extends EgovAbstractMapper {

	public List<LabelVO> selectlabelList(LabelVO labelVO) throws Exception {
		return selectList("LABEL_MAPPER.selectLabel", labelVO);
	}

	public List<LabelVO> selectlabelList() throws Exception {
		return selectList("LABEL_MAPPER.selectLabel", null);
	}

	public LabelVO selectlabelOne(LabelVO labelVO) throws Exception {
		return selectOne("LABEL_MAPPER.selectLabel", labelVO);
	}

	public int updatelabel(LabelVO labelVO) throws Exception {
		return update("LABEL_MAPPER.updateLabel", labelVO);
	}

	public int insertlabel(LabelVO labelVO) throws Exception {
		return update("LABEL_MAPPER.insertLabel", labelVO);
	}

}
