package com.ubizit.dams.common.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionController {
	
	// 2022-10-11 Controller Exception 일괄 처리. 일단 보류.
//	private static final Logger logger = LoggerFactory.getLogger(ExceptionController.class);
//	
//	@ExceptionHandler({Exception.class})
//	public String exceptionAll(Exception e) {
//		
//		logger.error("ExceptionController :: " + e.getMessage());
//		e.printStackTrace();
//		
//		return "error";
//	}
}
