package com.ubizit.dams.common.model;

/**
 * @Description: TASK
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.05.11 - 박성욱 - 최초생성
 *
 * @author: PSW
 * @since: 2022.05.11
 */
public class FailCauseVO {

	private String projCd;
    private Integer failCausCd;
    private String failCausNm;
    private String diagInspFg;
    private String useYn;
    private Integer dispSeq;
    private String regId;
    private String regDt;
 // 콤보박스 조회값 20220721
    private String projNmParam;
    
	@Override
	public String toString() {
		return "FailCauseVO [projCd=" + projCd + ", failCausCd=" + failCausCd + ", failCausNm=" + failCausNm
				+ ", diagInspFg=" + diagInspFg + ", useYn=" + useYn + ", dispSeq=" + dispSeq + ", regId=" + regId
				+ ", regDt=" + regDt + "]";
	}
	
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public Integer getFailCausCd() {
		return failCausCd;
	}
	public void setFailCausCd(Integer failCausCd) {
		this.failCausCd = failCausCd;
	}
	public String getFailCausNm() {
		return failCausNm;
	}
	public void setFailCausNm(String failCausNm) {
		this.failCausNm = failCausNm;
	}
	public String getDiagInspFg() {
		return diagInspFg;
	}
	public void setDiagInspFg(String diagInspFg) {
		this.diagInspFg = diagInspFg;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public Integer getDispSeq() {
		return dispSeq;
	}
	public void setDispSeq(Integer dispSeq) {
		this.dispSeq = dispSeq;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getProjNmParam() {
		return projNmParam;
	}
	public void setProjNmParam(String projNmParam) {
		this.projNmParam = projNmParam;
	}
}
