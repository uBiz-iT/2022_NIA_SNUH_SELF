package com.ubizit.dams.common.service;

import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.mapper.TestMapper;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("testService")
public class TestService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(TestService.class);
	
	@Resource(name="testMapper")
	private TestMapper testMapper;
	
	public void getCursorTest(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> CommonService.getCursorTest >>>>>>");
		
		testMapper.callCursorTest(map);
	}
	

}
