package com.ubizit.dams.common.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;

import org.apache.commons.io.IOUtils;

public class AudioFileProcessor {
	public static void main(String[] args) {
		
//		copyAudio("D:\\data\\snuh2022\\A2\\A2001\\2022-A2-0001-01\\test_wav.wav",
//				"D:\\data\\snuh2022\\A2\\A2001\\2022-A2-0001-01\\test_copy_slice_wav.wav", 2, 10);
		
//		String filePath = "D:\\data\\snuh2022\\A2\\A2001\\2022-A2-0001-01\\wav_7h.wav";
		String filePath = "D:\\data\\snuh2022\\A2\\A2001\\2022-A2-0001-01\\wav_2h.wav";
		byte[] a = getAudioByte(filePath, 100, 30);
		System.out.println(a);
		for (byte ab : a) {
			System.out.println(ab);
		}
	}

	// 원본 : 신규 파일 생성.
	public static void copyAudio(String sourceFileName, String destinationFileName, int startSecond,
			int secondsToCopy) {
		AudioInputStream inputStream = null;
		AudioInputStream shortenedStream = null;
		try {
			File file = new File(sourceFileName);
			AudioFileFormat fileFormat = AudioSystem.getAudioFileFormat(file);
			AudioFormat format = fileFormat.getFormat();
			inputStream = AudioSystem.getAudioInputStream(file);
			int bytesPerSecond = format.getFrameSize() * (int) format.getFrameRate();
			inputStream.skip(startSecond * bytesPerSecond);
			long framesOfAudioToCopy = secondsToCopy * (int) format.getFrameRate();
			shortenedStream = new AudioInputStream(inputStream, format, framesOfAudioToCopy);
			File destinationFile = new File(destinationFileName);
			AudioSystem.write(shortenedStream, fileFormat.getType(), destinationFile);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (Exception e) {
					System.out.println(e);
				}
			}
			if (shortenedStream != null) {
				try {
					shortenedStream.close();
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		}
	}

	// 수정 : 바이트 전송.
	public static byte[] getAudioByte(String sourceFileName, int startSecond, int secondsToCopy) {
		AudioInputStream inputStream = null;
		AudioInputStream shortenedStream = null;
		try {
			File file = new File(sourceFileName);
			AudioFileFormat fileFormat = AudioSystem.getAudioFileFormat(file);
			AudioFormat format = fileFormat.getFormat();
			inputStream = AudioSystem.getAudioInputStream(file);
			int bytesPerSecond = format.getFrameSize() * (int) format.getFrameRate();
			inputStream.skip(startSecond * bytesPerSecond);
			long framesOfAudioToCopy = secondsToCopy * (int) format.getFrameRate();
			shortenedStream = new AudioInputStream(inputStream, format, framesOfAudioToCopy);
			
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			IOUtils.copy(shortenedStream, os);
			os.flush();
			os.close();
			byte[] ba = os.toByteArray();
			return ba;
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (Exception e) {
					System.out.println(e);
				}
			}
			if (shortenedStream != null) {
				try {
					shortenedStream.close();
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		}
		return null;
	}
}