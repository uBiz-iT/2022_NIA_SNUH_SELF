package com.ubizit.dams.common.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.model.DashBoardCountVO;
import com.ubizit.dams.common.model.UserVO;
import com.ubizit.dams.common.service.DashBoardService;

@Controller
public class DashBoardController {

	@Resource(name="dashBoardService")
	private DashBoardService dashBoardService;
	
	private final static Logger logger = LogManager.getLogger(DashBoardController.class);
	
	// Page + modelData(userList + projectUserList)
	@RequestMapping(value="/dashBoard.do")
	public String getPage(ModelMap model, HttpSession session) throws Exception {
		logger.debug(">>> DashBoardController.getPage >>>");
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		String loginId = loginUser.getUserId();
		
		// 1. 그래프 통계 유저?
		List<?> userList = dashBoardService.getUser();
		model.addAttribute("userList", userList);
		
		
		// 여기도 지금 jsp model 로 내보내 <c:forEach> 로 굴리는거. 이렇게 하니까 Map으로 넘어는걸 또 다시 vo로 바꿔줘야 하잖아.
		// 그래야 jspl에서 getter setter 간편 사용 가능. map으로 하면 까다로움.
		
		// 2. 대시보드 화면 정보
		// 진행률
		Map<String, Object> projUserListMap = getProgressCounts(loginId);
		
		// 결과 리스트
		List<DashBoardCountVO> projectUserList = new ArrayList<DashBoardCountVO>();
		for (int i = 0; i < ((List<?>)projUserListMap.get("rows")).size(); i++) {
			projectUserList.add(new Gson().fromJson(new Gson().toJson(((List<?>)projUserListMap.get("rows")).get(i)), DashBoardCountVO.class));
		}
		model.addAttribute("projectUserList", projectUserList);
		
		return "dashBoard/dashBoard";
	}
	
	// 대쉬보드 통계
	private Map<String, Object> getProgressCounts(String userId) throws Exception {
		logger.info(">>> DashBoardController.getProgressCounts >>>");
		
		// PROC
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("userId", userId);
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(paramMap));
		dashBoardService.getProgressCounts(procMap);
		
		@SuppressWarnings("unchecked")
		Map<String, Object> resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		return resultMap;
	}

	// 월 차트 (사용처: 대쉬보드, 주월간실적 - 나중에 stat/weekMonth로 이민.)
	@RequestMapping(value="/dashBoard/getMonthChartData.do")
	@ResponseBody
	public Map<String, Object> getMonthChartData(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> DashBoardController.getMonthChartData >>>>>>");
		
		// PARAM
		String projCd = request.getParameter("projCd");
		
		// PROC
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("projCd", projCd);
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(paramMap));
		dashBoardService.getMonthChartData(procMap);

		@SuppressWarnings("unchecked")
		Map<String, Object> resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		return resultMap;
	}
	
	// 월 누적 차트 (사용처: 주월간실적 - 그럼 여기 있는게 이상한데?)
	@RequestMapping(value="/dashBoard/getMonthAcmChartData.do")
	@ResponseBody
	public Map<String, Object> getMonthAcmChartData(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> DashBoardController.getMonthAcmChartData >>>>>>");
		
		// PARAM
		String projCd = request.getParameter("projCd");

		// PROC
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("projCd", projCd);
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(paramMap));
		dashBoardService.getMonthAcmChartData(procMap);

		@SuppressWarnings("unchecked")
		Map<String, Object> resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		return resultMap;
	}
	
	@RequestMapping(value="/dashBoard/main.user.chart.do")
	@ResponseBody
	public Map<String, Object> getUserCharts(HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> DashBoardController.getUserCharts() >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		String loginId = loginUser.getUserId();
		
		// PROC
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("USER_ID", loginId);
		paramMap.put("PROJ_CD", request.getParameter("projCd"));
		resultMap.put("p_rcv_json", new Gson().toJson(paramMap));
		dashBoardService.getUserCharts(resultMap);
		
		Object lineList = null;
		if((int)resultMap.get("p_ret_code") == 0) {
			lineList = new Gson().fromJson((String) resultMap.get("p_ret_json"), Map.class).get("lineList");
		}
		resultMap.put("lineList", lineList);
		return resultMap;
	}
	
	
}
