package com.ubizit.dams.common.edfutils;

/*
 *****************************************************************************
 *
 * Copyright (c) 2020 Teunis van Beelen
 * All rights reserved.
 *
 * Email: teuniz@protonmail.com
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the copyright holder nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************
 */


import java.io.*;
import java.math.BigDecimal;
import java.nio.*;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;


public class UEdfReadTest_2022061501
{

    @SuppressWarnings("static-access")
    public static void main(String[] args)
    {
        EDFreader hdl;

        if(args.length == 0)
        {
            System.out.println("아규먼트에 파일명을 추가하세요.\n");

            return;
        }

        try
        {
            hdl = new EDFreader(args[0]);
        }
        catch(IOException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }
        catch(EDFException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }

        
        // ----------------------------------------------------------------------------------------------------
        // 파일의 헤더 정보에 있는 기본 정보를 출력해보자
        // ----------------------------------------------------------------------------------------------------
        printHeaderInfo(hdl);
        
        // ----------------------------------------------------------------------------------------------------
        // 시그널 목록 출력해보자
        // ----------------------------------------------------------------------------------------------------
        printSignals(hdl);
        
        // ----------------------------------------------------------------------------------------------------
        // annotation(주석, 이벤트 정보)이 있는 경우 출력해보자
        // ----------------------------------------------------------------------------------------------------
        printAnnotation(hdl);

        // ----------------------------------------------------------------------------------------------------
        // 실제 원하는 시그널의 특정 위치의 데이터를 특정 크기만큼 읽어보자 
        // ----------------------------------------------------------------------------------------------------

        System.out.println("------------------------------------------------------------------");
        System.out.println("특정 시그널 정보 뽑아 보기");
        System.out.println("------------------------------------------------------------------");

        // 측정 시작 시각 읽어오기
        int startDateYear = hdl.getStartDateYear();
        int startDateMonth = hdl.getStartDateMonth();
        int startDateDay = hdl.getStartDateDay();
        int startDateHour = hdl.getStartTimeHour();
        int startDateMinute = hdl.getStartTimeMinute();
        int startDateSecond = hdl.getStartTimeSecond();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS").withLocale(Locale.US);
        LocalDateTime startDateTime = LocalDateTime.of(startDateYear, startDateMonth, startDateDay, startDateHour, startDateMinute, startDateSecond);

        System.out.printf("Test start date time : %s\n", startDateTime.format(formatter));
        
        // 한번에 가져올때 얼마큼의 데이터를 가져올지 변수 정의. 단위 : 초. 기본적으로 PSG 검사 1 epoch 단위가 30초이므로 해당 값으로 설정
        // epoch : 일정한 단위(주로 화면에서 분석하는 그래프의 시간축 크기를 의미함. 수면쪽 데이터 분석은 주로 1 epoch이 30초이다.
        // 30초 단위를 1 epoch이라고 하며,  1부터 30초 단위로 epoch 번호를 부여한다.
        int epochSize = 30;

        // --------------------------------------------------------------------------------------------------------
        // epoch no, signal no 설정
        // --------------------------------------------------------------------------------------------------------
        int epochNo = 475;      // 읽고자 하는 epoch 번호 설정. 1이면 첫번째 epoch
        int epochCount = 1;     // 몇개의 epoch 데이터를 가져올 것인지. ex) 1이면 30초, 2이면 60초
        int signalNo = 4;       // 시그널 번호 4에 대한 정보 가져오기
        
        // 해당 시그널에 대한 여러가지 정보 출력하기
        printSignalInfo(hdl, signalNo);

        // --------------------------------------------------------------------------------------------------------
        // 파일로부터 저장된 데이터 가져오기
        // --------------------------------------------------------------------------------------------------------
        // 초당 샘플링 건수 변수 정의. 
        int freq = 1;    

        // 초당 샘플링수 가져오기
        try {
            freq = (int) hdl.getSampleFrequency(signalNo);
        } 
        catch (EDFException e) {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
        }

        // epoch size만큼 데이터 읽어오기
        double[] buf = getData(hdl, signalNo, freq, epochNo, epochSize, epochCount); 

        // 읽어온 데이터 출력
        // --------------------------------------------------------------------------------------------------------

        // buffer에 들어온 데이터들의 실제 포인터
        long realPosition = 0;

        // 파일의 첫번째 데이터의 시간을 0초로 놓고 경과 시간
        double absoluteSeconds = 0;
        
        // buffer의 첫번째 데이터의 시간을 0초로 놓고 경과 시간
        double relativeSeconds = 0;

        long bufStartPosition = (long) ((epochNo - 1) * epochSize * freq);   // 읽어온 데이터의 첫번째 데이터의 포인터

        System.out.println("Read Data");
        System.out.println("------------------------------------------------------------------");
        
        
        long startSeconds = (epochNo - 1) * epochSize;                      // 읽어온 데이터의 첫번째 데이터 시간 구하기(초)
        LocalDateTime sampleDateTime = startDateTime;                       // 현실 시간 값 저장용, 기본 값은 헤더에서 읽어온 측정 시작 시각

        for(int i=0; i < buf.length; i++)
        {
            realPosition = bufStartPosition + i;
            relativeSeconds = (double)Math.round(((double)i/(long)freq) * 1000) / 1000;     // 읽은 데이터 처음부터의 경과 시간
            absoluteSeconds = startSeconds + relativeSeconds;                               // 측정 시각부터 경과 시간

            // 측정 시작 시간부터 경과 시간을 더하여 샘플링 데이터의 시간을 구함
            sampleDateTime = startDateTime.plusNanos(BigDecimal.valueOf(absoluteSeconds).multiply(BigDecimal.valueOf(1000000000)).longValue());            
            System.out.printf("%5d: %12.3f: %8d: %12.3f: %s: %.10f\n", i, relativeSeconds, realPosition, absoluteSeconds, sampleDateTime.format(formatter), buf[i]);
        }


        // --------------------------------------------------------------------------------------------------------
        // 보간 데이터 가져오기(실제로 이 데이터를 가져다 화면에서 사용해야 함)
        // --------------------------------------------------------------------------------------------------------
        // 초당 30개의 데이터만 뽑아내고 싶을 경우
        int samplingRate = 30;

        double[] y = getInterporlationData(buf, freq, samplingRate, epochSize, epochCount);
        
        /*
        // 읽어온 데이터 출력
        // --------------------------------------------------------------------------------------------------------
        System.out.println("Interporalation Data");
        System.out.println("------------------------------------------------------------------");
        
        for(int i=0; i < y.length; i++) {
            
            relativeSeconds = (double)Math.round(((double)i/(long)samplingRate) * 1000) / 1000; // 읽은 데이터 처음부터의 경과 시간
            absoluteSeconds = startSeconds + relativeSeconds;                                   // 측정 시각부터 경과 시간

            // 측정 시작 시간부터 경과 시간을 더하여 샘플링 데이터의 시간을 구함
            sampleDateTime = startDateTime.plusNanos(BigDecimal.valueOf(absoluteSeconds).multiply(BigDecimal.valueOf(1000000000)).longValue());            
            System.out.printf("%5d: %12.3f: %12.3f: %s: %20.10f\n", i, relativeSeconds, absoluteSeconds, sampleDateTime.format(formatter), y[i]);
        }
        */
        
        // 아래는 추가로 읽거나 위치 이동, 시간으로 데이터 읽어오기 등 테스트한 내용임
        // --------------------------------------------------------------------------------------------------------
        // 위에서 읽은 데이터 그 다음부터 데이터 가져와 보기
        // --------------------------------------------------------------------------------------------------------
        try
        {
            // readPhysicalSamples 메소드는 마지막 읽은 바로 다음 위치로 포인터가 이동됨
            // 위에서 buffer에 1개를 더 가져오도록 했으므로 앞으로 1만큼 이동 후 가져오기
            hdl.fseek(signalNo, -1, hdl.EDFSEEK_CUR);    
            
            // 현재 포인터 위치 가져오기
            bufStartPosition = hdl.ftell(signalNo);
            startSeconds = bufStartPosition / freq;
                    
            Arrays.fill(buf, 0);
            hdl.readPhysicalSamples(signalNo, buf);

            System.out.printf("샘플링 데이터의 시작 위치 : %d\n", bufStartPosition);

        }
        catch(IOException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }
        catch(EDFException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }

        for(int i=0; i < buf.length; i++)
        {
            realPosition = bufStartPosition + i;
            relativeSeconds = (double)Math.round(((double)i/(long)freq) * 1000) / 1000;     // 읽은 데이터 처음부터의 경과 시간
            absoluteSeconds = startSeconds + relativeSeconds;                               // 측정 시각부터 경과 시간

            // 측정 시작 시간부터 경과 시간을 더하여 샘플링 데이터의 시간을 구함
            sampleDateTime = startDateTime.plusNanos(BigDecimal.valueOf(absoluteSeconds).multiply(BigDecimal.valueOf(1000000000)).longValue());            
            System.out.printf("%5d: %12.3f: %8d: %12.3f: %s: %.10f\n", i, relativeSeconds, realPosition, absoluteSeconds, sampleDateTime.format(formatter), buf[i]);
        }

        // --------------------------------------------------------------------------------------------------------
        // fseek 테스트 (포인터 이동)
        // --------------------------------------------------------------------------------------------------------
        try {
            //hdl.fseek(signalNo, 5, hdl.EDFSEEK_SET);    // 5번 위치로 이동
            //hdl.fseek(signalNo, 5, hdl.EDFSEEK_CUR);    // 현재 위치에서 앞으로 5만큼 이동
            //hdl.fseek(signalNo, buf.length * -1, hdl.EDFSEEK_CUR);    // 현재 위치에서 버퍼사이즈만큼 거꾸로 이동
            hdl.fseek(signalNo, -5, hdl.EDFSEEK_CUR);    // 현재 위치에서 뒤로 5 만큼 이동

            bufStartPosition = hdl.ftell(signalNo);
            startSeconds = bufStartPosition / freq;
            
            // 한번 읽을때마다 샘플링 데이터 포인터가 이동됨.
            Arrays.fill(buf, 0);
            hdl.readPhysicalSamples(signalNo, buf);

            System.out.printf("Start position       :   %d\n", bufStartPosition);
            System.out.println("------------------------------------------------------------------");

        } 
        catch(IOException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }
        catch(EDFException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }

        for(int i=0; i < buf.length; i++)
        {
            realPosition = bufStartPosition + i;
            relativeSeconds = (double)Math.round(((double)i/(long)freq) * 1000) / 1000;     // 읽은 데이터 처음부터의 경과 시간
            absoluteSeconds = startSeconds + relativeSeconds;                               // 측정 시각부터 경과 시간

            // 측정 시작 시간부터 경과 시간을 더하여 샘플링 데이터의 시간을 구함
            sampleDateTime = startDateTime.plusNanos(BigDecimal.valueOf(absoluteSeconds).multiply(BigDecimal.valueOf(1000000000)).longValue());            
            System.out.printf("%5d: %12.3f: %8d: %12.3f: %s: %.10f\n", i, relativeSeconds, realPosition, absoluteSeconds, sampleDateTime.format(formatter), buf[i]);
        }

        // ------------------------------------------------------------------------
        // 여기서부터는 특정 시간(현실 시간) 에 해당하는 데이터 가져오는 것 테스트
        // ------------------------------------------------------------------------

        // 원하는 년월일시분초
        LocalDateTime queryDateTime = LocalDateTime.of(2020, 2, 21, 2, 27, 42);

        // 시작시간과의 차이(초로 환산)
        Duration duration = Duration.between(startDateTime, queryDateTime);
        long seconds = duration.getSeconds();

        // 원하는 위치 계산. 경과 시간(초) * 샘플링 rate
        long queryPosition = seconds * freq;

        System.out.printf("시작, 쿼리, 차이(초), 위치 : %s, %s, %d, %d\n", startDateTime.format(formatter), queryDateTime.format(formatter), seconds, queryPosition);

        try {
            hdl.fseek(signalNo, queryPosition, hdl.EDFSEEK_SET);    
            bufStartPosition = hdl.ftell(signalNo);
            startSeconds = bufStartPosition / freq;
            
            // 한번 읽을때마다 샘플링 데이터 포인터가 이동됨.
            Arrays.fill(buf, 0);
            hdl.readPhysicalSamples(signalNo, buf);

            System.out.printf("Start position       :   %d\n", bufStartPosition);
            System.out.println("------------------------------------------------------------------");

        } 
        catch(IOException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }
        catch(EDFException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }

        for(int i=0; i < buf.length; i++)
        {
            realPosition = bufStartPosition + i;
            relativeSeconds = (double)Math.round(((double)i/(long)freq) * 1000) / 1000;     // 읽은 데이터 처음부터의 경과 시간
            absoluteSeconds = seconds + relativeSeconds;                                    // 측정 시각부터 경과 시간

            // 측정 시작 시간부터 경과 시간을 더하여 샘플링 데이터의 시간을 구함
            sampleDateTime = startDateTime.plusNanos(BigDecimal.valueOf(absoluteSeconds).multiply(BigDecimal.valueOf(1000000000)).longValue());            
            System.out.printf("%5d: %12.3f: %8d: %12.3f: %s: %.10f\n", i, relativeSeconds, realPosition, absoluteSeconds, sampleDateTime.format(formatter), buf[i]);
        }
        

    } // main 끝


    // --------------------------------------------------------------------------------------------------------
    // 헤더에 있는 기본 정보들 출력해보기
    // --------------------------------------------------------------------------------------------------------
    public static void printHeaderInfo(EDFreader hdl) {
        
        // 측정 일자, 측정 시작 시간 등 출력
        System.out.printf("Startdate            : %02d-%02d-%02d\n", hdl.getStartDateDay(), hdl.getStartDateMonth(), hdl.getStartDateYear());
        System.out.printf("Starttime            : %02d:%02d:%02d\n", hdl.getStartTimeHour(), hdl.getStartTimeMinute(), hdl.getStartTimeSecond());
        int filetype = hdl.getFileType();

        // 파일 타입 출력
        System.out.printf("hdl.getFileType()    : %d\n", filetype);

        // 파일의 타입에 따라 파일의 헤더에 있는 정보를 읽어와서 화면에 출력. edf 파일이냐 edf plus 파일이냐.. 
        if((filetype == EDFreader.EDFLIB_FILETYPE_EDF)  || (filetype == EDFreader.EDFLIB_FILETYPE_BDF))
        {
            System.out.printf("Patient              : %s\n", hdl.getPatient());
            System.out.printf("Recording            : %s\n", hdl.getRecording());
        }
        else
        {
            System.out.printf("Patient code         : %s\n", hdl.getPatientCode());
            System.out.printf("Gender               : %s\n", hdl.getPatientGender());
            System.out.printf("Birthdate            : %s\n", hdl.getPatientBirthDate());
            System.out.printf("Patient name         : %s\n", hdl.getPatientName());
            System.out.printf("Patient additional   : %s\n", hdl.getPatientAdditional());
            System.out.printf("Admin. code          : %s\n", hdl.getAdministrationCode());
            System.out.printf("Technician           : %s\n", hdl.getTechnician());
            System.out.printf("Equipment            : %s\n", hdl.getEquipment());
            System.out.printf("Recording additional : %s\n", hdl.getRecordingAdditional());
        }

        System.out.printf("Reserved             : %s\n", hdl.getReserved());
        System.out.printf("Number of signals    : %d\n", hdl.getNumSignals());

        double durPerRecord = (double)(hdl.getLongDataRecordDuration()) / 10000000.0;
        long numberOfRecords = hdl.getNumDataRecords();
        
        System.out.printf("Number of datarecords: %d\n", numberOfRecords);
        System.out.printf("Datarecord duration  : %f\n", durPerRecord);
        System.out.printf("Total Duration(sec)  : %f\n", durPerRecord * numberOfRecords);
        
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 어노테이션 정보 출력해보기
    // --------------------------------------------------------------------------------------------------------
    public static void printAnnotation(EDFreader hdl) {
        
        for(int i=0; i<hdl.annotationslist.size(); i++)
        {
            System.out.printf("annotation: onset    : %d:%02d:%02d    description: %s    duration: %d\n",
                                (hdl.annotationslist.get(i).onset / 10000000) / 3600,
                                ((hdl.annotationslist.get(i).onset / 10000000) % 3600) / 60,
                                (hdl.annotationslist.get(i).onset / 10000000) % 60,
                                hdl.annotationslist.get(i).description,
                                hdl.annotationslist.get(i).duration / 1000000);
        }
        
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 시그널 정보 출력하기
    // --------------------------------------------------------------------------------------------------------
    public static void printSignals(EDFreader hdl) {
        
        System.out.println("------------------------------------------------------------------");
        System.out.println("저장된 시그널 목록 및 정보");
        System.out.println("------------------------------------------------------------------");
        
        // 시그널 수량만큼 시그널 정보 출력 
        for(int i=0; i < hdl.getNumSignals(); i++)
        {
            // 해당 시그널에 대한 여러가지 정보 출력하기
            printSignalInfo(hdl, i);
        }

    }
    
    // --------------------------------------------------------------------------------------------------------
    // 시그널 목록 및 정보 출력 하기
    // --------------------------------------------------------------------------------------------------------
    public static void printSignalInfo(EDFreader hdl, int signalNo) {
        
        // 해당 시그널에 대한 여러가지 정보 출력하기
        try {
            System.out.printf("Signal No            : %d\n", signalNo);
            System.out.printf("Signal Label         : %s\n", hdl.getSignalLabel(signalNo));
            System.out.printf("Sample frequency     : %f Hz\n", hdl.getSampleFrequency(signalNo));
            System.out.printf("Transducer           : %s\n", hdl.getTransducer(signalNo));
            System.out.printf("Physical dimension   : %s\n", hdl.getPhysicalDimension(signalNo));
            System.out.printf("Physical minimum     : %.10f\n", hdl.getPhysicalMinimum(signalNo));
            System.out.printf("Physical maximum     : %.10f\n", hdl.getPhysicalMaximum(signalNo));
            System.out.printf("Digital minimum      : %d\n", hdl.getDigitalMinimum(signalNo));
            System.out.printf("Digital maximum      : %d\n", hdl.getDigitalMaximum(signalNo));
            System.out.printf("Prefilter            : %s\n", hdl.getPreFilter(signalNo));
            System.out.printf("Samples per record   : %d\n", hdl.getSampelsPerDataRecord(signalNo));
            System.out.printf("Total samples in file: %d\n", hdl.getTotalSamples(signalNo));
            System.out.printf("Reserved             : %s\n\n", hdl.getReserved(signalNo));
        }
        catch(EDFException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 원본 데이터에서 원하는 샘플링 레이트로 데이터 추출하기
    // 단순하게 선형 보간법 사용, 특정한 보간 방법이 필요한 경우 해당 보간 알고리즘 구현 필요
    // --------------------------------------------------------------------------------------------------------
    @SuppressWarnings("static-access")
    public static double[] getData(EDFreader hdl, int signalNo, int freq, int epochNo, int epochSize, int epochCount)  
    {
        // 1 epoch에 해당하는 샘플링 수량 = 시간(초) * Sampling Rate
        int epochSamplingSize = freq * epochSize * epochCount;

        // 정해진 시간만큼을 가져오기 위한 버퍼 정의. 버퍼 크기는 epochSamplingSize + 1(1개를 더 읽어옴)
        double[] buf = new double[epochSamplingSize + 1];

        System.out.println("------------------------------------------------------------------");
        System.out.printf("Epoch No             : %d\n", epochNo);
        System.out.printf("Sampling rate        : %d\n", freq);
        System.out.printf("1 Epoch size(seconds): %d\n", epochSize);
        System.out.printf("Buffer size          : %d\n", buf.length);
        
        // 읽어올 위치 계산하기 : (에폭번호 - 1) * 하나의 epoch에 표현될 크기(초) * 초당샘플링건수
        long bufStartPosition = (epochNo - 1) * epochSize * freq;

        System.out.printf("Start position       : %d\n", bufStartPosition);
        System.out.println("------------------------------------------------------------------");
        
        try
        {
            // 파일의 해당 위치로 포인터 이동
            hdl.fseek(signalNo, bufStartPosition, hdl.EDFSEEK_SET);
            
            // 현재 포인터로부터 데이터를 버퍼 크기만큼 읽어옴
            hdl.readPhysicalSamples(signalNo, buf);
        }
        catch(IOException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
        }
        catch(EDFException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
        }

        return buf;
    }


    // --------------------------------------------------------------------------------------------------------
    // 원본 데이터에서 원하는 샘플링 레이트로 데이터 추출하기
    // 단순하게 선형 보간법 사용, 특정한 보간 방법이 필요한 경우 해당 보간 알고리즘 구현 필요
    // --------------------------------------------------------------------------------------------------------
    public static double[] getInterporlationData(double[] source, int sourceSamplingRate, int targetSamplingRate, int epochSize, int epochCount)  
    {   
        int x1, x2;
        double y1, y2, xn, yn, a, xZeroBase;
        double[] y = new double[targetSamplingRate*epochSize*epochCount + 1];
        
        double samplingOffset = (double)sourceSamplingRate / (double)targetSamplingRate;
                
        for(int i=0; i < y.length; i++) {
            
            xn = samplingOffset * i;        // 원하는 x 좌표값 구하기
            x1 = (int) xn;                    // xPos보다 작거나 같은 정수 구하기
            x2 = (int) Math.ceil(xn);        // xPos보다 크거나 같은 정수 구하기, x2는 x1과 동일하거나 1만큼 큼
            yn = 0;
            
            if (x1 < source.length && x2 < source.length) {
                if (x1 == x2) {
                    yn = source[x1];
                }
                else {
                    y1 = source[x1];
                    y2 = source[x2];
                    a = y2 - y1;        // 기울기
                    xZeroBase = xn - x1;        // 소숫점만 남기기
                    yn = a * xZeroBase + y1;    // y값 구하기
                }
                
            }
            y[i] = yn;
        }
        
        return y;
    }

} // 클래스 끝




