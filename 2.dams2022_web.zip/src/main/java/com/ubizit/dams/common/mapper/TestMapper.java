package com.ubizit.dams.common.mapper;

import java.util.Map;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("testMapper")
public class TestMapper extends EgovAbstractMapper {
	
	public void callCursorTest(Map<String, Object> map) throws Exception {	
		selectList("TEST_MAPPER.callCursorTest", map);
	}
	
}
