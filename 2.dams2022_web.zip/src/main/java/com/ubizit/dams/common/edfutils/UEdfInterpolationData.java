package com.ubizit.dams.common.edfutils;

import java.time.LocalDateTime;

public class UEdfInterpolationData {
    public double relativeSeconds;         // buffer의 첫번째 데이터의 시간을 0초로 놓고 경과 시간
    public double absoluteSeconds;         // 파일의 첫번째 데이터의 시간을 0초로 놓고 경과 시간
    public LocalDateTime sampleDateTime;   // 현실 시간 값 저장용, 기본 값은 헤더에서 읽어온 측정 시작 시각
    public double value;  
}
