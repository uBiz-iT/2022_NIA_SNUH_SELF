package com.ubizit.dams.common.mapper;

import java.util.List;
import java.util.Map;

import com.ubizit.dams.common.model.TaskCaseVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("taskCaseMapper")
public class TaskCaseMapper extends EgovAbstractMapper {

	public List<Map<String, Object>> selectTaskList(Map<String, Object> map) throws Exception {
		return selectList("TASKCASE_MAPPER.selectTask", map);
	}
	
	public void callGetTaskCaseStepList(Map<String, Object> map) throws Exception {
		selectList("TASKCASE_MAPPER.callGetTaskCaseStep", map);
	}
	
	public int insertTaskCase(TaskCaseVO vo) throws Exception {
		return insert("TASKCASE_MAPPER.insertTaskCase", vo);
	}

	public int updateTaskCase(TaskCaseVO vo) throws Exception {
		return delete("TASKCASE_MAPPER.updateTaskCase", vo);
	}

	public int deleteTaskCase(TaskCaseVO vo) throws Exception {
		return delete("TASKCASE_MAPPER.deleteTaskCase", vo);
	}

	public List<Map<String, Object>> taskCaseExcelDL(Map<String, Object> map) throws Exception {
		return selectList("TASKCASE_MAPPER.taskCaseExcelDL", map);
	}
}
