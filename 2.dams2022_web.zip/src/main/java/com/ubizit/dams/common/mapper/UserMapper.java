package com.ubizit.dams.common.mapper;

import java.util.List;
import java.util.Map;

import com.ubizit.dams.common.model.ProjectUserVO;
import com.ubizit.dams.common.model.UserVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("userMapper")
public class UserMapper extends EgovAbstractMapper {

	public List<UserVO> selectUserList(UserVO user) throws Exception {
		return selectList("USER_MAPPER.selectUser", user);
	}

	public List<UserVO> selectUserProjList(UserVO user) throws Exception {
		return selectList("USER_MAPPER.selectProjectUser", user);
	}

	public List<UserVO> selectUserList() throws Exception {
		return selectList("USER_MAPPER.selectUser", null);
	}

	public List<ProjectUserVO> selectProjUserList(ProjectUserVO puVo) throws Exception {
		return selectList("USER_MAPPER.selectProjUser", puVo);
	}

	public UserVO selectUserOne(UserVO user) throws Exception {
		return selectOne("USER_MAPPER.selectUserOne", user);
	}

	public void callGetUserOneMap(Map<String, Object> map) throws Exception {
		selectOne("USER_MAPPER.callGetUserOneMap", map);
	}

	public void callRegistUser(Map<String, Object> map) throws Exception {
		insert("USER_MAPPER.callRegistUser", map);
	}

	public void callModifyUser(Map<String, Object> map) throws Exception {
		update("USER_MAPPER.callModifyUser", map);
	}

	public void callRemoveUser(Map<String, Object> map) throws Exception {
		selectList("USER_MAPPER.callRemoveUser", map);
	}

	public int userProjectValidation(Map<String, Object> map) throws Exception {
		List<Object> listSizeChk = selectList("USER_MAPPER.userProjectValidation", map);
		int result = listSizeChk.size();
		return result;
	}

	public void callGetUserToProject(Map<String, Object> map) throws Exception {
		selectList("USER_MAPPER.callGetUserToProject", map);
	}
	
	public int updatePswd(Map<String, Object> map) throws Exception {
		return update("USER_MAPPER.updatePswd", map);
	}

	public List<Map<String, Object>> userExcelDL(Map<String, Object> map) throws Exception {
		return selectList("USER_MAPPER.userExcelDL", map);
	}
	
}
