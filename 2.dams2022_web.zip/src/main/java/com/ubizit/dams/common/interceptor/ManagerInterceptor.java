package com.ubizit.dams.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.ubizit.dams.common.model.UserVO;


public class ManagerInterceptor extends HandlerInterceptorAdapter {

	private final static Logger logger = LoggerFactory.getLogger(ManagerInterceptor.class);
	   
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		logger.info(">>> ManagerInterceptor >>>");
		HttpSession session = request.getSession();
        // return true  ->  요청 uri 그대로 진행.
        // return false ->  출입금지.
		
        // 로그인 유무 확인.
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		String sysMgrYn = loginUser.getSysMgrYn();
		String projMgrYn = loginUser.getMgrYn();
        if ("Y".equals(sysMgrYn) || "Y".equals(projMgrYn)) {
        	return true;
        } else {
        	response.sendRedirect(request.getContextPath() + "/managerAuth.do");
            return false;	
        }
        
	}
	
}
