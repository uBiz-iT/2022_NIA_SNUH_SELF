package com.ubizit.dams.common.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ErrorController {

	private final static Logger logger = LogManager.getLogger(ErrorController.class);

	@RequestMapping(value = "/error.do")
	public String error(HttpServletRequest request, Model model) throws Exception {
		logger.info(">>>>>> ErrorController.error >>>>>>");
		
		model.addAttribute("code", "ERROR");
		return "error/error";
	}
	
	@RequestMapping(value = "/error404.do")
	public String error404(HttpServletRequest request, Model model) throws Exception {
		logger.info(">>>>>> ErrorController.error404 >>>>>>");
		
		model.addAttribute("code", "ERROR_404");
		return "error/error404";
	}

	@RequestMapping(value = "/error500.do")
	public String error500(HttpServletRequest request, Model model) throws Exception {
		logger.info(">>>>>> ErrorController.error500 >>>>>>");
		
		model.addAttribute("code", "ERROR_500");
		return "error/error500";
	}

	@RequestMapping(value = "/managerAuth.do")
	public String managerAuth(HttpServletRequest request, Model model) throws Exception {
		logger.info(">>>>>> ErrorController.error500 >>>>>>");
		
		model.addAttribute("code", "managerAuth");
		return "error/managerAuth";
	}

}
