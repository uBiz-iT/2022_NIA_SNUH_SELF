package com.ubizit.dams.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.ubizit.dams.common.model.UserVO;


public class Interceptor extends HandlerInterceptorAdapter {

	private final static Logger logger = LoggerFactory.getLogger(Interceptor.class);
	   
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		logger.info(">>> Interceptor >>>");
		HttpSession session = request.getSession();
        // return true  ->  요청 uri 그대로 진행.
        // return false ->  출입금지.
		
        // 로그인 유무 확인.
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
        if (loginUser == null) {
        	response.sendRedirect(request.getContextPath() + "/login.do");
            return false;
        } else {
        	return true;	
        }
        
	}
	
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		super.postHandle(request, response, handler, modelAndView);
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		super.afterCompletion(request, response, handler, ex);
	}
	
	@Override
	public void afterConcurrentHandlingStarted(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// TODO Auto-generated method stub
		super.afterConcurrentHandlingStarted(request, response, handler);
	}
	
	
	
}
