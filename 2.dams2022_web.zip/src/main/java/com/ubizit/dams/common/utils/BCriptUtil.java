package com.ubizit.dams.common.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class BCriptUtil {

	public static void main(String[] args) {

		// 1. 인코딩 테스트
		System.out.println("BANANA");
		String pswd = "1111";
		String bcPswd = encodePswd(pswd);
		System.out.println(pswd + " :: " + bcPswd);
		
		String pswd2 = "2222";
		String bcPswd2 = encodePswd(pswd2);
		System.out.println(pswd2 + " :: " + bcPswd2);
		
		
		// 2. 매칭 테스트
		boolean matTest1 = isMatch("1111", "$2a$10$y4qD6W.Hu9xkXaavg7nduuoUTZ4xhGSRe4fXp.IFLWpqVXFNJOAqG");
		boolean matTest2 = isMatch("1111", "$2a$10$ek20rZ0NOBd7KlkTNFLnXuRbbrW4kSpK2pLH.kKwkOkYOkACnOLFe");
		boolean matTest3 = isMatch("1111", "$2a$10$XqnTxQqeHbLomCC7BGLx1.PJwb24tezU/XFpe1E5pZRzR.xekltpW");
		boolean matTest4 = isMatch("1111", "$2a$10$SrVfJ4kCsoJlg.ROXs8or.7BjMsb9xu14OKYljwiAVLewM3kOh786");
		
		System.out.println(matTest1);
		System.out.println(matTest2);
		System.out.println(matTest3);
		System.out.println(matTest4);
		
		// 3. DB 실전
		System.out.println("---------------------");
		System.out.println(encodePswd("2906"));
		System.out.println(encodePswd("1492"));
		System.out.println(encodePswd("3606"));
		System.out.println("---------------------");
		System.out.println(encodePswd("7308"));
		System.out.println(encodePswd("1111"));
		System.out.println(encodePswd("dbqlwmwjdqhrltnf"));
		
	}
	
	
	public static String encodePswd(String pswd) {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String encodedPswd = encoder.encode(pswd);
		return encodedPswd;
	}


	public static boolean isMatch(String rawPswd, String encodedPswd) {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		return encoder.matches(rawPswd, encodedPswd);
	}
	
}

