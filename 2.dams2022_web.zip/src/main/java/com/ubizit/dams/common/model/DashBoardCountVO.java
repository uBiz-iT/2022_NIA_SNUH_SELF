package com.ubizit.dams.common.model;

/**
 * @Description: 
 * @Modification: 
 * 2022.06 
 *
 * @author
 * @since: 2022.06
 */
public class DashBoardCountVO {
	
	private Integer regCnt; // 등록 수량
	private Integer regAccord; 
	private Integer assnCnt; // 할당 수량
	private Integer diagWorkCnt; // 진단완료 수량
	private Integer inspWorkCnt; // 검수완료 수량
	private Integer sameCnt; //
	private Integer passCnt; // Pass 수량
	private Integer workCnt; // 진단완료+검수완료 수량

	private Integer planDsetCnt; // 목표 수량
	
	private String projCd;
	private String projNm;
	private String userId;
	private String userNm;
	
	private float totalPercent; // 진행률
	private float regPercent; // 등록률
	private float assnPercent; // 할당률
	private float diagPercent; // 진단완료율
	private float inspPercent; // 검수완료율
	private float samePercent; // 현재 사용 안함 일치율
	private float passPercent; // Pass율
	
	// chart용 추가
	private String wm;
	private String month;
	private String weekStart;
	private String weekEnd;
	private String weekOfMonth;
	
	public Integer getRegCnt() {
		return regCnt;
	}
	public void setRegCnt(Integer regCnt) {
		this.regCnt = regCnt;
	}
	public Integer getRegAccord() {
		return regAccord;
	}
	public void setRegAccord(Integer regAccord) {
		this.regAccord = regAccord;
	}
	public Integer getAssnCnt() {
		return assnCnt;
	}
	public void setAssnCnt(Integer assnCnt) {
		this.assnCnt = assnCnt;
	}
	public Integer getdiagWorkCnt() {
		return diagWorkCnt;
	}
	public void setdiagWorkCnt(Integer diagWorkCnt) {
		this.diagWorkCnt = diagWorkCnt;
	}
	public Integer getinspWorkCnt() {
		return inspWorkCnt;
	}
	public void setinspWorkCnt(Integer inspWorkCnt) {
		this.inspWorkCnt = inspWorkCnt;
	}
	public Integer getSameCnt() {
		return sameCnt;
	}
	public void setSameCnt(Integer sameCnt) {
		this.sameCnt = sameCnt;
	}
	public Integer getPassCnt() {
		return passCnt;
	}
	public void setPassCnt(Integer passCnt) {
		this.passCnt = passCnt;
	}
	
	public Integer getDiagWorkCnt() {
		return diagWorkCnt;
	}
	public void setDiagWorkCnt(Integer diagWorkCnt) {
		this.diagWorkCnt = diagWorkCnt;
	}
	public Integer getInspWorkCnt() {
		return inspWorkCnt;
	}
	public void setInspWorkCnt(Integer inspWorkCnt) {
		this.inspWorkCnt = inspWorkCnt;
	}
	public Integer getWorkCnt() {
		return workCnt;
	}
	public void setWorkCnt(Integer workCnt) {
		this.workCnt = workCnt;
	}
	public Integer getPlanDsetCnt() {
		return planDsetCnt;
	}
	public void setPlanDsetCnt(Integer planDsetCnt) {
		this.planDsetCnt = planDsetCnt;
	}
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getProjNm() {
		return projNm;
	}
	public void setProjNm(String projNm) {
		this.projNm = projNm;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getWm() {
		return wm;
	}
	public void setWm(String wm) {
		this.wm = wm;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getWeekStart() {
		return weekStart;
	}
	public void setWeekStart(String weekStart) {
		this.weekStart = weekStart;
	}
	public String getWeekEnd() {
		return weekEnd;
	}
	public void setWeekEnd(String weekEnd) {
		this.weekEnd = weekEnd;
	}
	public String getWeekOfMonth() {
		return weekOfMonth;
	}
	public void setWeekOfMonth(String weekOfMonth) {
		this.weekOfMonth = weekOfMonth;
	}
	public float getTotalPercent() {
		return totalPercent;
	}
	public void setTotalPercent(float totalPercent) {
		this.totalPercent = totalPercent;
	}
	public float getRegPercent() {
		return regPercent;
	}
	public void setRegPercent(float regPercent) {
		this.regPercent = regPercent;
	}
	public float getAssnPercent() {
		return assnPercent;
	}
	public void setAssnPercent(float assnPercent) {
		this.assnPercent = assnPercent;
	}
	public float getDiagPercent() {
		return diagPercent;
	}
	public void setDiagPercent(float diagPercent) {
		this.diagPercent = diagPercent;
	}
	public float getInspPercent() {
		return inspPercent;
	}
	public void setInspPercent(float inspPercent) {
		this.inspPercent = inspPercent;
	}
	public float getSamePercent() {
		return samePercent;
	}
	public void setSamePercent(float samePercent) {
		this.samePercent = samePercent;
	}
	public float getPassPercent() {
		return passPercent;
	}
	public void setPassPercent(float passPercent) {
		this.passPercent = passPercent;
	}
    
}
