package com.ubizit.dams.common.mapper;

import java.util.List;
import java.util.Map;

import com.ubizit.dams.common.model.ProjectVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("projectMapper")
public class ProjectMapper extends EgovAbstractMapper {

	public List<ProjectVO> selectProjectList(ProjectVO project) throws Exception {
		return selectList("PROJECT_MAPPER.selectProject", project);
	}
	
	public ProjectVO selectProjectOne(ProjectVO project) throws Exception {
		return selectOne("PROJECT_MAPPER.selectProjectOne", project);
	}

	public void callGetProjectMap(Map<String, Object> map) throws Exception {
		selectList("PROJECT_MAPPER.callGetProjectMap", map);
	}

	public void callRegistProject(Map<String, Object> map) throws Exception {
		selectList("PROJECT_MAPPER.callRegistProject", map);
	}

	public void callModifyProject(Map<String, Object> map) throws Exception {
		selectList("PROJECT_MAPPER.callModifyProject", map);
	}
	
	public void callRemoveProject(Map<String, Object> map) throws Exception {
		selectList("PROJECT_MAPPER.callRemoveProject", map);
	}

	public void getProjectToLabelList(Map<String, Object> map) throws Exception {
		selectList("PROJECT_MAPPER.projectToLabelList", map);
	}

	public void getProjectReadLabel(Map<String, Object> map) throws Exception {
		selectList("PROJECT_MAPPER.projectReadLabel", map);
	}

	public List<Map<String, Object>> projectExcelDL(Map<String, Object> map) throws Exception {
		return selectList("PROJECT_MAPPER.projectExcelDL", map);
	}
}
