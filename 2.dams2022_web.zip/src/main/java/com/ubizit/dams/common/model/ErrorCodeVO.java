package com.ubizit.dams.common.model;

/**
 * @Description: 
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.06
 *
 * @author: 
 * @since: 2022.06
 */

import java.io.Serializable;

public class ErrorCodeVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7745577074745958623L;
	
	private String occrId;
	private String pgmNm;
	private String errCd;
	private String errMsg;
	private String errData;
	
	@Override
	public String toString() {
		return "ErrorCodeVO [occrId=" + occrId + ", pgmNm=" + pgmNm + ", errCd=" + errCd + ", errMsg=" + errMsg
				+ ", errData=" + errData + "]";
	}

	public String getOccrId() {
		return occrId;
	}

	public void setOccrId(String occrId) {
		this.occrId = occrId;
	}

	public String getPgmNm() {
		return pgmNm;
	}

	public void setPgmNm(String pgmNm) {
		this.pgmNm = pgmNm;
	}

	public String getErrCd() {
		return errCd;
	}

	public void setErrCd(String errCd) {
		this.errCd = errCd;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public String getErrData() {
		return errData;
	}

	public void setErrData(String errData) {
		this.errData = errData;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
