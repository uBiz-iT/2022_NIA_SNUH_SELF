package com.ubizit.dams.common.mapper;

import java.util.List;
import java.util.Map;

import com.ubizit.dams.common.model.FailCauseVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("causeMapper")
public class CauseMapper extends EgovAbstractMapper {

	public List<FailCauseVO> selectCauseList(FailCauseVO cause) throws Exception {
		return selectList("CAUSE_MAPPER.selectCause", cause);
	}

	public FailCauseVO selectCauseOne(FailCauseVO cause) throws Exception {
		return selectOne("CAUSE_MAPPER.selectCauseOne", cause);
	}

	public int insertCause(FailCauseVO cause) throws Exception {
		return insert("CAUSE_MAPPER.insertCause", cause);
	}

	public int updateCause(FailCauseVO cause) throws Exception {
		return update("CAUSE_MAPPER.updateCause", cause);
	}

	public int deleteCause(FailCauseVO cause) throws Exception {
		return delete("CAUSE_MAPPER.deleteCause", cause);
	}

	public int causeProjectValidation(Map<String, Object> map) throws Exception {
		List<Object> listSizeChk = selectList("CAUSE_MAPPER.causeProjectValidation", map);
		int result = listSizeChk.size();
		return result;
	}

	public void getCauseToProjectList(Map<String, Object> map) throws Exception {
		selectList("CAUSE_MAPPER.callGetCauseToProject", map);
	}

	public List<Map<String, Object>> causeExcelDL(Map<String, Object> map) throws Exception {
		return selectList("CAUSE_MAPPER.causeExcelDL", map);
	}
}
