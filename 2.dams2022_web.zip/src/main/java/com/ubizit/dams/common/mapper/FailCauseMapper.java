package com.ubizit.dams.common.mapper;

import java.util.List;

import com.ubizit.dams.common.model.FailCauseVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("failCauseMapper")
public class FailCauseMapper extends EgovAbstractMapper {

	public List<FailCauseVO> selectFailCauseList(FailCauseVO failCauseVO) throws Exception {
		return selectList("FAIL_CAUSE_MAPPER.selectFailCause", failCauseVO);
	}

	public List<FailCauseVO> selectFailCauseList() throws Exception {
		return selectList("FAIL_CAUSE_MAPPER.selectFailCause", null);
	}

	public FailCauseVO selectFailCauseOne(FailCauseVO failCauseVO) throws Exception {
		return selectOne("FAIL_CAUSE_MAPPER.selectFailCause", failCauseVO);
	}

	public int updateFailCause(FailCauseVO failCauseVO) throws Exception {
		return update("FAIL_CAUSE_MAPPER.updateFailCause", failCauseVO);
	}

	public int insertFailCause(FailCauseVO failCauseVO) throws Exception {
		return update("FAIL_CAUSE_MAPPER.insertFailCause", failCauseVO);
	}

}
