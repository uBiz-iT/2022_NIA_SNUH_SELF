package com.ubizit.dams.common.mapper;

import com.ubizit.dams.common.model.UserVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("loginMapper")
public class LoginMapper extends EgovAbstractMapper {

	public UserVO selectUserByLogin(UserVO user) throws Exception {
		return selectOne("LOGIN_MAPPER.selectUserByLogin", user);
	}

	public int updatePswd(UserVO vo) throws Exception {
		return update("LOGIN_MAPPER.updatePswd", vo);
	}

}
