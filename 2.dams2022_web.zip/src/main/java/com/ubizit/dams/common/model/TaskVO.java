package com.ubizit.dams.common.model;

/**
 * @Description: TASK
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.05.11 - 박성욱 - 최초생성
 *
 * @author: PSW
 * @since: 2022.05.11
 */
public class TaskVO {
	
    private String projCd;
    private String taskCd;
    private String taskNm;
    private String dataDir;
    private String dataRegYmd;
    private Object statYn;
    private String regId;
    private String regDt;
    
	@Override
	public String toString() {
		return "TaskVO [projCd=" + projCd + ", taskCd=" + taskCd + ", taskNm=" + taskNm + ", dataDir=" + dataDir
				+ ", dataRegYmd=" + dataRegYmd + ", statYn=" + statYn + ", regId=" + regId + ", regDt=" + regDt + "]";
	}
	
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getTaskNm() {
		return taskNm;
	}
	public void setTaskNm(String taskNm) {
		this.taskNm = taskNm;
	}
	public String getDataDir() {
		return dataDir;
	}
	public void setDataDir(String dataDir) {
		this.dataDir = dataDir;
	}
	public String getDataRegYmd() {
		return dataRegYmd;
	}
	public void setDataRegYmd(String dataRegYmd) {
		this.dataRegYmd = dataRegYmd;
	}
	public Object getStatYn() {
		return statYn;
	}
	public void setStatYn(Object statYn) {
		this.statYn = statYn;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
 
    
}
