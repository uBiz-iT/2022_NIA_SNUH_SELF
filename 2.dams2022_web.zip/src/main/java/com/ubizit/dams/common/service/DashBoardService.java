package com.ubizit.dams.common.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.mapper.DashBoardMapper;
import com.ubizit.dams.common.mapper.UserMapper;
import com.ubizit.dams.common.model.ProjectUserVO;
import com.ubizit.dams.common.model.UserVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("dashBoardService")
public class DashBoardService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(DashBoardService.class);

	@Resource(name = "userMapper")
	private UserMapper userMapper;

	@Resource(name = "dashboardMapper")
	private DashBoardMapper dashboardMapper;

	public List<UserVO> getUser() throws Exception {
		LOGGER.info(">>>>>> DashBoardService.getUser >>>>>>");

		return userMapper.selectUserList();
	}

	public List<ProjectUserVO> getProjUser(ProjectUserVO puVo) throws Exception {
		LOGGER.info(">>>>>> DashBoardService.getProjUser >>>>>>");

		return userMapper.selectProjUserList(puVo);
	}

	public void getProgressCounts(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> DashBoardService.getProgressCounts >>>>>>");

		dashboardMapper.callGetMainProgressCnt(map);
	}

	// Chart 1. 월 차트
	public void getMonthChartData(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> DashBoardService.getMonthChartData >>>>>>");

		dashboardMapper.callGetMonthChart(map);
	}

	// Chart 2. 월 누적 차트
	public void getMonthAcmChartData(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> DashBoardService.getMonthAcmChartData >>>>>>");

		dashboardMapper.callGetMonthAcmChart(map);
	}

	public void getUserCharts(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MainServiceImpl.getUserCharts >>>>>>");

		dashboardMapper.callGetMainUserChart(map);
	}

}
