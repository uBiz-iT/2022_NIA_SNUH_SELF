package com.ubizit.dams.common.controller;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ubizit.dams.common.utils.CommonProperties;

@Controller
public class CommonController {

	private final static Logger LOGGER = LogManager.getLogger(CommonController.class);
	
	/**
	 * 기본 페이지인데 안먹는듯. 2022-10-04
	 * web.xml -> <welcome-file-list> index.jsp -> dashboard.jsp -> intercepter -> login.jsp
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/")
	public String getPage(HttpServletRequest request, ModelMap model) throws Exception {
		LOGGER.info(">>>>>> CommonController.getPage >>>>>>");
		
		return "login";
	}
	
	/**
	 * 미사용 2022-10-04
	 * 
	 * @param fileNM
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value="/common/getImg.do", method=RequestMethod.GET)
	public void getImg(@RequestParam(value = "fileNM") String fileNM, HttpServletResponse response) throws Exception {
		String DIR = CommonProperties.load2("Globals.dir");
		String filePath = DIR + fileNM;

		getImage(filePath, response);
	}

	public void getImage(String filePath, HttpServletResponse response) throws Exception {

		File file = new File(filePath);
		if (!file.isFile()) {
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.write("<script type='text/javascript'>alert('조회된 정보가 없습니다.'); self.close();</script>");
			out.flush();
			return;
		}

		FileInputStream fis = null;
		new FileInputStream(file);

		BufferedInputStream in = null;
		ByteArrayOutputStream bStream = null;
		try {
			fis = new FileInputStream(file);
			in = new BufferedInputStream(fis);
			bStream = new ByteArrayOutputStream();
			int imgByte;
			while ((imgByte = in.read()) != -1) {
				bStream.write(imgByte);
			}

			String type = "";
			String ext = FilenameUtils.getExtension(file.getName());
			if (ext != null && !"".equals(ext)) {
				if ("jpg".equals(ext.toLowerCase())) {
					type = "image/jpeg";
				} else {
					type = "image/" + ext.toLowerCase();
				}

			} else {
				LOGGER.debug("Image fileType is null.");
			}

			response.setHeader("Content-Type", type);
			response.setContentLength(bStream.size());

			bStream.writeTo(response.getOutputStream());

			response.getOutputStream().flush();
			response.getOutputStream().close();

		} catch (Exception e) {
			LOGGER.debug("{}", e);
		} finally {
			if (bStream != null) {
				try {
					bStream.close();
				} catch (Exception est) {
					LOGGER.debug("IGNORED: {}", est.getMessage());
				}
			}
			if (in != null) {
				try {
					in.close();
				} catch (Exception ei) {
					LOGGER.debug("IGNORED: {}", ei.getMessage());
				}
			}
			if (fis != null) {
				try {
					fis.close();
				} catch (Exception efis) {
					LOGGER.debug("IGNORED: {}", efis.getMessage());
				}
			}
		}
	}

}
