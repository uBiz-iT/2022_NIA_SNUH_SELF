package com.ubizit.dams.common.mapper;

import java.util.List;
import java.util.Map;

import com.ubizit.dams.work.model.PlvTaskUserPlanVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("taskMapper")
public class TaskMapper extends EgovAbstractMapper {

	public PlvTaskUserPlanVO selectTaskOne(PlvTaskUserPlanVO task) throws Exception {
		return selectOne("TASK_MAPPER.selectTaskBase", task);
	}
	
	public List<PlvTaskUserPlanVO> selectTaskList(PlvTaskUserPlanVO task) throws Exception {
		return selectList("TASK_MAPPER.selectTask", task);
	}

	public void callGetTaskToUserList(Map<String, Object> map) throws Exception {
		selectList("TASK_MAPPER.callGetTaskToUser", map);
	}

	public void callRegistTask(Map<String, Object> map) throws Exception {
		insert("TASK_MAPPER.callRegistTask", map);
	}

	public void callModifyTask(Map<String, Object> map) throws Exception {
		selectOne("TASK_MAPPER.callModifyTask", map);
	}

	public void callRemoveTask(Map<String, Object> map) throws Exception {
		selectList("TASK_MAPPER.callRemoveTask", map);
	}

	public List<Map<String, Object>> taskExcelDL(Map<String, Object> map) throws Exception {
		return selectList("TASK_MAPPER.taskExcelDL", map);
	}
	
}
