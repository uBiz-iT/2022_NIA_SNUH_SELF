package com.ubizit.dams.common.model;

/**
 * @Description: TASK
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.05.11 - 박성욱 - 최초생성
 *
 * @author: PSW
 * @since: 2022.05.11
 */
public class LabelVO {
    private String projCd;
    private String lblCd;
    private String lblDisp;
    private String lblNm;
    private String useYn;
    private Integer dispSeq;
    private String regId;
    private String regDt;
	
    @Override
	public String toString() {
		return "LabelVO [projCd=" + projCd + ", lblCd=" + lblCd + ", lblDisp=" + lblDisp + ", lblNm=" + lblNm
				+ ", useYn=" + useYn + ", dispSeq=" + dispSeq + ", regId=" + regId + ", regDt=" + regDt + "]";
	}
	
    public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getLblCd() {
		return lblCd;
	}
	public void setLblCd(String lblCd) {
		this.lblCd = lblCd;
	}
	public String getLblDisp() {
		return lblDisp;
	}
	public void setLblDisp(String lblDisp) {
		this.lblDisp = lblDisp;
	}
	public String getLblNm() {
		return lblNm;
	}
	public void setLblNm(String lblNm) {
		this.lblNm = lblNm;
	}
	public String getUseYn() {
		return useYn;
	}

	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public Integer getDispSeq() {
		return dispSeq;
	}
	public void setDispSeq(Integer dispSeq) {
		this.dispSeq = dispSeq;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}


}
