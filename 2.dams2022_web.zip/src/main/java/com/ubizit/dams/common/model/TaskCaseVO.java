package com.ubizit.dams.common.model;

/**
 * @Description: TASKCASE
 * @Modification: 
 * 2022.06
 *
 * @author: 
 * @since: 2022.06
 */
public class TaskCaseVO {
	
    private String projCd;
    private String projNm;
    private String taskCd;
    private String taskNm;
    private String caseNo;
    private int age;
    private String gen;
    private String regId;
    private String regDt;
    private String userId;
    private String userNm;
    private String lblCd;
    private String lblDisp;
    private String lblNm;
    private String memo;
    private String workYmd;
    private String failCausList;
	
    @Override
	public String toString() {
		return "TaskCaseVO [projCd=" + projCd + ", taskCd=" + taskCd + ", taskNm=" + taskNm + ", caseNo=" + caseNo
				+ ", age=" + age + ", gen=" + gen + ", regId=" + regId + ", regDt=" + regDt + ", userId=" + userId
				+ ", userNm=" + userNm + ", lblCd=" + lblCd + ", lblDisp=" + lblDisp + ", lblNm=" + lblNm + ", memo="
				+ memo + ", workYmd=" + workYmd + ", failCausList=" + failCausList + "]";
	}
    
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getProjNm() {
		return projNm;
	}
	public void setProjNm(String projNm) {
		this.projNm = projNm;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getTaskNm() {
		return taskNm;
	}
	public void setTaskNm(String taskNm) {
		this.taskNm = taskNm;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGen() {
		return gen;
	}
	public void setGen(String gen) {
		this.gen = gen;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getLblCd() {
		return lblCd;
	}
	public void setLblCd(String lblCd) {
		this.lblCd = lblCd;
	}
	public String getLblDisp() {
		return lblDisp;
	}
	public void setLblDisp(String lblDisp) {
		this.lblDisp = lblDisp;
	}
	public String getLblNm() {
		return lblNm;
	}
	public void setLblNm(String lblNm) {
		this.lblNm = lblNm;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getWorkYmd() {
		return workYmd;
	}
	public void setWorkYmd(String workYmd) {
		this.workYmd = workYmd;
	}
	public String getFailCausList() {
		return failCausList;
	}
	public void setFailCausList(String failCausList) {
		this.failCausList = failCausList;
	}
    
}
