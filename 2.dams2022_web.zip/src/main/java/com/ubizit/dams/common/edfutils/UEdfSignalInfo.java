package com.ubizit.dams.common.edfutils;

public class UEdfSignalInfo {
    public int signalNo = -1;
    public String signalLabel = "";
    public String dimension = "";
    public double freq = 0;
    public String transducer = "";
    public double physicalMin = 0;
    public double physicalMax = 0;
    public int digitalMin = 0;
    public int digitalMax = 0;
    public String preFilter = "";
    public int sampelsPerDataRecord = 0;
    public long totalSamples = 0;
    public String reserved = "";
    public long totalEpochCount = 0;
}
