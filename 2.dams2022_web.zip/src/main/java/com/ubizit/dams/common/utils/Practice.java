package com.ubizit.dams.common.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Practice {
	
	public static void main(String[] args) {
		
		// 1. 
		String apple = "2.2";
		System.out.println(Math.round(Double.parseDouble(apple)));
		
		// 2. 
//		String apple2 = "a.b";
//		System.out.println(Math.round(Double.parseDouble(apple2)));
		 
		// 3.
		System.out.println("< 3 >");
		Map<String, String> weekMap = new HashMap<String, String>();
		weekMap.put("1", "월요일");
		System.out.println(weekMap.get("1"));
		
		System.out.println(weekMap.get("2"));
		
		
		// 4. 맵 null 로 자연스레 되나?
		System.out.println("< 4 >");
//		Object testStr = null;	// 이건 testMap도 null 뜨는데
//		Object testStr = "1234"; // 이건 에러뜨네
		Object testStr = "[]";
		
		List<Map<String, Object>> testMap = (List<Map<String, Object>>) testStr;
		System.out.println(testMap);
		
		
		
		
	}
}
