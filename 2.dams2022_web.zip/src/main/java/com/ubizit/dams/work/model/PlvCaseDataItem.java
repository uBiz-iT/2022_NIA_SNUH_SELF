package com.ubizit.dams.work.model;

public class PlvCaseDataItem {

    private String projCd;
    private String taskCd;
    private String caseNo;
    private String dataGrpCd;
    private String dataGrpNm;
    private String dataItemCd;
    private String dataItemNm;
    private String dataItemVal;
    private String dataItemNote;
    private String testYmd;
    
	@Override
	public String toString() {
		return "PlvCaseDataItem [projCd=" + projCd + ", taskCd=" + taskCd + ", caseNo=" + caseNo + ", dataGrpCd="
				+ dataGrpCd + ", dataGrpNm=" + dataGrpNm + ", dataItemCd=" + dataItemCd + ", dataItemNm=" + dataItemNm
				+ ", dataItemVal=" + dataItemVal + ", dataItemNote=" + dataItemNote + ", testYmd=" + testYmd + "]";
	}
	
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public String getDataGrpCd() {
		return dataGrpCd;
	}
	public void setDataGrpCd(String dataGrpCd) {
		this.dataGrpCd = dataGrpCd;
	}
	public String getDataGrpNm() {
		return dataGrpNm;
	}
	public void setDataGrpNm(String dataGrpNm) {
		this.dataGrpNm = dataGrpNm;
	}
	public String getDataItemCd() {
		return dataItemCd;
	}
	public void setDataItemCd(String dataItemCd) {
		this.dataItemCd = dataItemCd;
	}
	public String getDataItemNm() {
		return dataItemNm;
	}
	public void setDataItemNm(String dataItemNm) {
		this.dataItemNm = dataItemNm;
	}
	public String getDataItemVal() {
		return dataItemVal;
	}
	public void setDataItemVal(String dataItemVal) {
		this.dataItemVal = dataItemVal;
	}
	public String getDataItemNote() {
		return dataItemNote;
	}
	public void setDataItemNote(String dataItemNote) {
		this.dataItemNote = dataItemNote;
	}
	public String getTestYmd() {
		return testYmd;
	}
	public void setTestYmd(String testYmd) {
		this.testYmd = testYmd;
	}

    
    
}
