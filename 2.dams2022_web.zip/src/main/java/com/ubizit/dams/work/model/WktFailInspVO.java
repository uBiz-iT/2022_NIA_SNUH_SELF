package com.ubizit.dams.work.model;

/**
 * @Description: 로그인 vo 가 따로 필요한가?
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.05.11 - 박성욱 - 최초생성
 *
 * @author: PSW
 * @since: 2022.05.11
 */
public class WktFailInspVO {
	
	private String projCd;
    private String taskCd;
    private String caseNo;
    private String userId;
    private Integer failCausCd;
    
	@Override
	public String toString() {
		return "WktFailDiagVO [projCd=" + projCd + ", taskCd=" + taskCd + ", caseNo=" + caseNo + ", userId=" + userId
				+ ", failCausCd=" + failCausCd + "]";
	}
	
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Integer getFailCausCd() {
		return failCausCd;
	}
	public void setFailCausCd(Integer failCausCd) {
		this.failCausCd = failCausCd;
	}

	
    
    
}
