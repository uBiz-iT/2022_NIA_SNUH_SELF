package com.ubizit.dams.work.model;

public class WkvGoodLungsoundVO {
	
    private String projCd;
    private String taskCd;
    private String caseNo;
    private String testLoc;
    private String userId;
    private Object bestYn;
    private String lblCd;
    
	@Override
	public String toString() {
		return "WkvGoodLungsoundVO [projCd=" + projCd + ", taskCd=" + taskCd + ", caseNo=" + caseNo + ", testLoc="
				+ testLoc + ", userId=" + userId + ", bestYn=" + bestYn + ", lblCd=" + lblCd + "]";
	}

	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public String getTestLoc() {
		return testLoc;
	}
	public void setTestLoc(String testLoc) {
		this.testLoc = testLoc;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Object getBestYn() {
		return bestYn;
	}
	public void setBestYn(Object bestYn) {
		this.bestYn = bestYn;
	}
	public String getLblCd() {
		return lblCd;
	}
	public void setLblCd(String lblCd) {
		this.lblCd = lblCd;
	}

}
