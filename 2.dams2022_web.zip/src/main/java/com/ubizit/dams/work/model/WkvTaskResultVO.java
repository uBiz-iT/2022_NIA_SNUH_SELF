package com.ubizit.dams.work.model;

/**
 * @Description: 로그인 vo 가 따로 필요한가?
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.05.11 - 박성욱 - 최초생성
 *
 * @author: PSW
 * @since: 2022.05.11
 */
public class WkvTaskResultVO {
	
	// DB
    private String projCd;
    private String taskCd;
    private String caseNo;
    private String userId;
    private String dataRegYmd;
    private String diagInspFgPlan;
    private String diagInspFgWork;
    private String assnYmd;
    private String userNm;
    private String diagUserId;
    private String diagUserNm;
    private String lblCd;
    private String lblDisp;
    private String lblNm;
    private String failCausList;
    private String memo;
    private String diagWorkYmd;
    private String inspRes;
    private String inspFailCausList;
    private String inspMemo;
    private String inspWorkYmd;
    
    // getTaskCaseList statusCd
    private String statusCd;

	@Override
	public String toString() {
		return "WkvTaskResultVO [projCd=" + projCd + ", taskCd=" + taskCd + ", caseNo=" + caseNo + ", userId=" + userId
				+ ", dataRegYmd=" + dataRegYmd + ", diagInspFgPlan=" + diagInspFgPlan + ", diagInspFgWork="
				+ diagInspFgWork + ", assnYmd=" + assnYmd + ", userNm=" + userNm + ", diagUserId=" + diagUserId
				+ ", diagUserNm=" + diagUserNm + ", lblCd=" + lblCd + ", lblDisp=" + lblDisp + ", lblNm=" + lblNm
				+ ", failCausList=" + failCausList + ", memo=" + memo + ", diagWorkYmd=" + diagWorkYmd + ", inspRes="
				+ inspRes + ", inspFailCausList=" + inspFailCausList + ", inspMemo=" + inspMemo + ", inspWorkYmd="
				+ inspWorkYmd + ", statusCd=" + statusCd + "]";
	}

	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDataRegYmd() {
		return dataRegYmd;
	}
	public void setDataRegYmd(String dataRegYmd) {
		this.dataRegYmd = dataRegYmd;
	}
	public String getDiagInspFgPlan() {
		return diagInspFgPlan;
	}
	public void setDiagInspFgPlan(String diagInspFgPlan) {
		this.diagInspFgPlan = diagInspFgPlan;
	}
	public String getDiagInspFgWork() {
		return diagInspFgWork;
	}
	public void setDiagInspFgWork(String diagInspFgWork) {
		this.diagInspFgWork = diagInspFgWork;
	}
	public String getAssnYmd() {
		return assnYmd;
	}
	public void setAssnYmd(String assnYmd) {
		this.assnYmd = assnYmd;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getDiagUserId() {
		return diagUserId;
	}
	public void setDiagUserId(String diagUserId) {
		this.diagUserId = diagUserId;
	}
	public String getDiagUserNm() {
		return diagUserNm;
	}
	public void setDiagUserNm(String diagUserNm) {
		this.diagUserNm = diagUserNm;
	}
	public String getLblCd() {
		return lblCd;
	}
	public void setLblCd(String lblCd) {
		this.lblCd = lblCd;
	}
	public String getLblDisp() {
		return lblDisp;
	}
	public void setLblDisp(String lblDisp) {
		this.lblDisp = lblDisp;
	}
	public String getLblNm() {
		return lblNm;
	}
	public void setLblNm(String lblNm) {
		this.lblNm = lblNm;
	}
	public String getFailCausList() {
		return failCausList;
	}
	public void setFailCausList(String failCausList) {
		this.failCausList = failCausList;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getDiagWorkYmd() {
		return diagWorkYmd;
	}
	public void setDiagWorkYmd(String diagWorkYmd) {
		this.diagWorkYmd = diagWorkYmd;
	}
	public String getInspRes() {
		return inspRes;
	}
	public void setInspRes(String inspRes) {
		this.inspRes = inspRes;
	}
	public String getInspFailCausList() {
		return inspFailCausList;
	}
	public void setInspFailCausList(String inspFailCausList) {
		this.inspFailCausList = inspFailCausList;
	}
	public String getInspMemo() {
		return inspMemo;
	}
	public void setInspMemo(String inspMemo) {
		this.inspMemo = inspMemo;
	}
	public String getInspWorkYmd() {
		return inspWorkYmd;
	}
	public void setInspWorkYmd(String inspWorkYmd) {
		this.inspWorkYmd = inspWorkYmd;
	}
	public String getStatusCd() {
		return statusCd;
	}
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
    
}
