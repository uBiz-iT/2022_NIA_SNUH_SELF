package com.ubizit.dams.work.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.model.FailCauseVO;
import com.ubizit.dams.common.model.LabelVO;
import com.ubizit.dams.common.model.UserVO;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.work.model.PlvTaskUserPlanVO;
import com.ubizit.dams.work.model.WkvTaskResultVO;
import com.ubizit.dams.work.service.WorkTaskService;

@Controller
public class WorkTaskController {
	
	@Resource(name="workTaskService")
	private WorkTaskService workTaskService;
	
	private final static Logger logger = LogManager.getLogger(WorkTaskController.class);

	/**
	 * 기본 페이지
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/workTask.do")
	public String getPage() throws Exception {
		logger.info(">>> WorkTaskController.getPage >>>");
		
		return "work/workTask";
	}

	/**
	 * 태스크 리스트
	 * @param session
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/workTask/getTaskList.do", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> getTaskList(HttpSession session, HttpServletRequest request) throws Exception {
		logger.info(">>> WorkTaskController.getTaskList >>>");
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		
		// list
		Map<String, Object> rcvMap = new HashMap<String, Object>();
//		rcvMap.put("projCd", request.getParameter("projCd"));
		rcvMap.put("taskCd", request.getParameter("taskCd"));
		rcvMap.put("taskNm", request.getParameter("taskNm"));
		rcvMap.put("isSearch", request.getParameter("isSearch"));
		rcvMap.put("userId", loginUser.getUserId());
		List<Map<String, Object>> taskList = workTaskService.getTaskList(rcvMap); 
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("taskList", taskList);
		return resultMap;
	}
	
	/**
	 * 마지막으로 작업한 태스크
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/workTask/getLastWorkTask.do", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> getLastWorkTask(HttpSession session) throws Exception {
		logger.info(">>> WorkTaskController.getLastWorkTask >>>");
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		
		// resultVO
		PlvTaskUserPlanVO paramVO = new PlvTaskUserPlanVO();
		paramVO.setUserId(loginUser.getUserId());
		paramVO.setWorkStsFg("S");	// W: waiting, S: 진행중 :: 진행중인 값만 가져오기.
		PlvTaskUserPlanVO resultVO = workTaskService.getTaskUserPlanOne(paramVO);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("lastWorkTask", resultVO);
		return resultMap;
	}

	/**
	 * 태스크 케이스 리스트
	 * @param session
	 * @param taskResultVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/workTask/getTaskCaseList.do", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> getTaskCaseList(HttpSession session, @ModelAttribute WkvTaskResultVO taskResultVO) throws Exception {
		logger.info(">>> workController.getTaskCaseList >>>");
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		String loginId = loginUser.getUserId();
		
		// list
		taskResultVO.setUserId(loginId);
		List<WkvTaskResultVO> taskCaseList = workTaskService.getTaskCaseResultList(taskResultVO);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("data", taskCaseList);
		return resultMap;
	}

	/**
	 * 해당 케이스 결과(+ 라벨, 원인리스트)
	 * @param session
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/workTask/getTaskCaseResultOne.do", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> getTaskCaseOne(HttpSession session, @RequestParam Map<String, Object> paramMap) throws Exception {
		logger.info(">>> WorkTaskController.getTaskCaseOne >>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		String loginId = loginUser.getUserId();
		
		// paramMap으로 받아오는 값: projCd, taskCd, caseNo
		String projCd = (String) paramMap.get("projCd");
		
		// CaseResultOne
		paramMap.put("loginId", loginId);
		resultMap = workTaskService.getTaskCaseResultOne(paramMap);
		
		// Label
		LabelVO labelVO = new LabelVO();
		labelVO.setProjCd(projCd);
		List<LabelVO> labelList = workTaskService.getLabelUse(labelVO);
		resultMap.put("labelList", labelList);
		
		// Cause
		FailCauseVO failCauseVO = new FailCauseVO();
		failCauseVO.setProjCd(projCd);
		List<FailCauseVO> failCauseList = workTaskService.getFailCauseUse(failCauseVO);
		resultMap.put("causeList", failCauseList);
		
		return resultMap;
	}

	/**
	 * 해당 케이스 아이템(진단검수 판독데이터)
	 * @param session
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/workTask/getCaseDataItemAll.do", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> getCaseDataItemAll(HttpSession session, @RequestParam Map<String, Object> paramMap) throws Exception {
		logger.info(">>> WorkTaskController.getCaseDataItemAll >>>");
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		String loginId = loginUser.getUserId();
		
		// paramMap 넘어오는 값 : (projCd, taskCd, caseNo)
		paramMap.put("userId", loginId);
		System.out.println("getCaseDataItemAll PARAM");
		StringUtil.printMapToJson(paramMap);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = workTaskService.getCaseDataItemAll(paramMap); 
		return resultMap;
	}
	
	// -----------------------------------------------------------------
	//      진단 검수 작업 (나중에 4개 2개로 간소화)(regist + modify = process)
	// -----------------------------------------------------------------
	/**
	 * 진단 등록
	 * @param session
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/workTask/registDiagnose.do", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> registDiagnose(HttpSession session, @RequestParam Map<String, Object> paramMap) throws Exception {
		logger.info(">>> WorkController.registDiagnose >>>");
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		String loginId = loginUser.getUserId();

		// 1. PARAM 가공: 덮어씌우기
		// cause
		if (paramMap.get("failCausCdList") != null) {
			@SuppressWarnings("unchecked")
			List<String> failCausCdList = new Gson().fromJson((String) paramMap.get("failCausCdList"), ArrayList.class);			
			paramMap.put("failCausCdList", failCausCdList);
		}
		// 폐음 lung
		if (paramMap.get("lungGoodList") != null) {
			@SuppressWarnings("unchecked")
			List<String> lungGoodList = new Gson().fromJson((String) paramMap.get("lungGoodList"), ArrayList.class);
			paramMap.put("lungGoodList", lungGoodList);
		}
		
		// 2. paramMap 그대로 프로시저 파라미터로 활용.
		paramMap.put("userId", loginId);
		String rcvJson = new Gson().toJson(paramMap);
		System.out.println("registDiagnose PARAM");
		System.out.println(rcvJson);
		
		// 3. procMap: retJson에 결과 받아옴.
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		workTaskService.registDiagnose(procMap);
		
		@SuppressWarnings("unchecked")
		Map<String, Object> resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		return resultMap;
	}
	
	/**
	 * 검수 등록
	 * @param session
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/workTask/registInspect.do", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> registInspect(HttpSession session, @RequestParam Map<String, Object> paramMap) throws Exception {
		logger.info(">>> WorkController.registInspect >>>");
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		String loginId = loginUser.getUserId();

		// 1. PARAM 가공: 덮어씌우기
		// cause
		if (paramMap.get("failCausCdList") != null) {
			@SuppressWarnings("unchecked")
			List<String> failCausCdList = new Gson().fromJson((String) paramMap.get("failCausCdList"), ArrayList.class);			
			paramMap.put("failCausCdList", failCausCdList);
		}
		
		// 2. paramMap 그대로 프로시저 파라미터로 활용.
		paramMap.put("userId", loginId);
		String rcvJson = new Gson().toJson(paramMap);
		System.out.println("registInspect PARAM");
		System.out.println(rcvJson);
		
		// 3. procMap: retJson에 결과 받아옴.
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		workTaskService.registInspect(procMap);
		
		@SuppressWarnings("unchecked")
		Map<String, Object> resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		return resultMap;
	}
	
	/**
	 * 진단 수정
	 * @param session
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/workTask/modifyDiagnose.do", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> modifyDiagnose(HttpSession session, @RequestParam Map<String, Object> paramMap) throws Exception {
		logger.info(">>> WorkController.modifyDiagnose >>>");
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		String loginId = loginUser.getUserId();

		// 1. PARAM 가공: 덮어씌우기
		// cause
		if (paramMap.get("failCausCdList") != null) {
			@SuppressWarnings("unchecked")
			List<String> failCausCdList = new Gson().fromJson((String) paramMap.get("failCausCdList"), ArrayList.class);			
			paramMap.put("failCausCdList", failCausCdList);
		}
		// 폐음 lung
		if (paramMap.get("lungGoodList") != null) {
			@SuppressWarnings("unchecked")
			List<String> lungGoodList = new Gson().fromJson((String) paramMap.get("lungGoodList"), ArrayList.class);
			paramMap.put("lungGoodList", lungGoodList);
		}
		
		// 2. paramMap 그대로 프로시저 파라미터로 활용.
		paramMap.put("userId", loginId);
		String rcvJson = new Gson().toJson(paramMap);
		System.out.println("modifyDiagnose PARAM");
		System.out.println(rcvJson);
		
		// 3. procMap: retJson에 결과 받아옴.
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		workTaskService.modifyDiagnose(procMap);
		
		@SuppressWarnings("unchecked")
		Map<String, Object> resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		return resultMap;
	}
	
	/**
	 * 검수 수정
	 * @param session
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/workTask/modifyInspect.do", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> modifyInspect(HttpSession session, @RequestParam Map<String, Object> paramMap) throws Exception {
		logger.info(">>> WorkController.modifyInspect >>>");
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		String loginId = loginUser.getUserId();

		// 1. PARAM 가공: 덮어씌우기
		// cause
		if (paramMap.get("failCausCdList") != null) {
			@SuppressWarnings("unchecked")
			List<String> failCausCdList = new Gson().fromJson((String) paramMap.get("failCausCdList"), ArrayList.class);			
			paramMap.put("failCausCdList", failCausCdList);
		}
		
		// 2. paramMap 그대로 프로시저 파라미터로 활용.
		paramMap.put("userId", loginId);
		String rcvJson = new Gson().toJson(paramMap);
		System.out.println("modifyInspect PARAM");
		System.out.println(rcvJson);

		// 3. procMap: retJson에 결과 받아옴.
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		workTaskService.modifyInspect(procMap);
		
		@SuppressWarnings("unchecked")
		Map<String, Object> resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		return resultMap;
	}
		
}
