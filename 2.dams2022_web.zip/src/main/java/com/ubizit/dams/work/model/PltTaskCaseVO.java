package com.ubizit.dams.work.model;

public class PltTaskCaseVO {

	private String projCd;
    private String taskCd;
    private String caseNo;
    private Integer age;
    private Object gen;
    private String regId;
    private String regDt;
    
	@Override
	public String toString() {
		return "PltTaskCaseVO [projCd=" + projCd + ", taskCd=" + taskCd + ", caseNo=" + caseNo + ", age=" + age
				+ ", gen=" + gen + ", regId=" + regId + ", regDt=" + regDt + "]";
	}
	
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Object getGen() {
		return gen;
	}
	public void setGen(Object gen) {
		this.gen = gen;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

    
}
