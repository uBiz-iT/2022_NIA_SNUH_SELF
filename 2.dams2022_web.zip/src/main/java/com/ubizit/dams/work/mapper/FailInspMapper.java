package com.ubizit.dams.work.mapper;

import java.util.List;

import com.ubizit.dams.work.model.WktFailInspVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("failInspMapper")
public class FailInspMapper extends EgovAbstractMapper {

	public List<WktFailInspVO> selectFailInspList(WktFailInspVO failInspVO) throws Exception {
		return selectList("FAIL_INSP_MAPPER.selectFailInsp", failInspVO);
	}

	public WktFailInspVO selectFailInspOne(WktFailInspVO failInspVO) throws Exception {
		return selectOne("FAIL_INSP_MAPPER.selectFailInsp", failInspVO);
	}

	public int insertFailInspList(WktFailInspVO failInspVO) throws Exception {
		return insert("FAIL_INSP_MAPPER.insertFailInsp", failInspVO);
	}

}
