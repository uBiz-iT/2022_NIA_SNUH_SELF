package com.ubizit.dams.work.service;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.common.edfutils.UEdfInterpolationData;
import com.ubizit.dams.common.edfutils.UEdfModule;
import com.ubizit.dams.common.model.FailCauseVO;
import com.ubizit.dams.common.model.LabelVO;
import com.ubizit.dams.common.model.ProjectVO;
import com.ubizit.dams.common.utils.CommonProperties;
import com.ubizit.dams.common.utils.CsvUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.work.mapper.WorkTaskMapper;
import com.ubizit.dams.work.model.PltTaskCaseVO;
import com.ubizit.dams.work.model.PlvCaseSoundImage;
import com.ubizit.dams.work.model.PlvTaskUserPlanVO;
import com.ubizit.dams.work.model.WkvTaskResultVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;


@Service("workTaskService")
public class WorkTaskService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(WorkTaskService.class);
	
	@Resource(name="workTaskMapper")
	private WorkTaskMapper workTaskMapper;
	
	// --------------------
	//     Label, Cause
	// --------------------
	public List<LabelVO> getLabelUse(LabelVO labelVO) throws Exception {
		return workTaskMapper.selectLabelUseList(labelVO);
	}
	
	public List<FailCauseVO> getFailCauseUse(FailCauseVO failCauseVO) throws Exception {
		return workTaskMapper.selectFailCauseUseList(failCauseVO);
	}

	// --------------------
	//       Task
	// --------------------
	public PlvTaskUserPlanVO getTaskUserPlanOne(PlvTaskUserPlanVO plvTaskUserPlanVO) throws Exception {
		LOGGER.info(">>> workTaskService.getTaskUserPlanOne >>>");
		return workTaskMapper.selectTaskUserPlanOne(plvTaskUserPlanVO);
	}
	
	public List<Map<String, Object>> getTaskList(Map<String, Object> paramMap) throws Exception {
		LOGGER.info(">>> workTaskService.getTaskList >>>");
		return workTaskMapper.getTaskList(paramMap);
	}
	
	// -------------------
	//      Task Case
	// -------------------
	public List<WkvTaskResultVO> getTaskCaseResultList(WkvTaskResultVO taskResultVO) throws Exception {
		LOGGER.info(">>> workTaskService.getTaskCaseResultList >>>");
		
		String projCd = taskResultVO.getProjCd();
		ProjectVO paramVO = new ProjectVO();
		paramVO.setProjCd(projCd);
		ProjectVO projectVO = workTaskMapper.selectProjectUseOne(paramVO);

		String loginId = taskResultVO.getUserId();
		String projectType = projectVO.getDiagInspFg();

		List<WkvTaskResultVO> resultList = workTaskMapper.selectTaskResultList(taskResultVO);
		for (WkvTaskResultVO vo : resultList) {
			String diagUserId = vo.getDiagUserId();
			String lblCd = vo.getLblCd();
			String inspRes = vo.getInspRes();
			String statusCd = null;
			// 상태 정의
			// StatusCd = gray:미진행  |  yellow:진단완료,검수필요  |  green:진행완료
			// projectType =  A(진단 + 검수)  |  D(진단만)  |  I(검수만)  |  S(진단 + 검수 + 담당자 선 지정)
			if ("A".equals(projectType)) {
				// 수면.
				statusCd = "gray";
				if (diagUserId != null) {
					// 진단 완료.
					statusCd = "yellow"; // 검수자 검수 안함.
					if (diagUserId.equals(loginId)) {
						// 진단자.
						statusCd = "green";
					} else if (inspRes != null) {
						// 검수자 검수 완료.
						statusCd = "green";
					}
				}
			} else if ("D".equals(projectType)) {
				// no project. 그리고 이건 아직 db:view로 구현이 안됨. 다른 방식.
			} else if ("I".equals(projectType)) {
				// 폐기능
				statusCd = "gray";
				if (inspRes != null) {
					statusCd = "green";
				}
			} else if ("S".equals(projectType)) {
				// 폐음
				statusCd = "gray";
				if (diagUserId.equals(loginId)) {
					// 진단자.
					if (lblCd != null) {
						statusCd = "green";	
					}
				} else {
					// 검수자.
					if (inspRes != null) {
						statusCd = "green";
					} else if (lblCd != null) {
						statusCd = "yellow";
					}
				}
			}
			vo.setStatusCd(statusCd);
		}
		return resultList;
	}
	
	// depressesd
	public PltTaskCaseVO getTaskCaseOneInfo(PltTaskCaseVO pltTaskCaseVO) throws Exception {
		LOGGER.info(">>> workTaskService.getTaskCaseOneInfo >>>");
		
		return workTaskMapper.selectTaskCaseInfo(pltTaskCaseVO);
	}
	
	public Map<String, Object> getTaskCaseResultOne(Map<String, Object> paramMap) throws Exception {
		LOGGER.info(">>> workTaskService.getTaskCaseResultOne >>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 1. PARAM SET
		String projCd = (String) paramMap.get("projCd");
		String taskCd = (String) paramMap.get("taskCd");
		String caseNo = (String) paramMap.get("caseNo");
		String loginId = (String) paramMap.get("loginId");
		
		// 2. TaskResult
		WkvTaskResultVO paramResultVO = new WkvTaskResultVO();
		paramResultVO.setProjCd(projCd);
		paramResultVO.setTaskCd(taskCd);
		paramResultVO.setCaseNo(caseNo);
		List<WkvTaskResultVO> taskCaseResultList = workTaskMapper.selectTaskResultList(paramResultVO);
		resultMap.put("dataList", taskCaseResultList);
		
		// 2-1. ProjectType A 에서 검수가 진행됐는가?
		Boolean isInsp = false;
		for (WkvTaskResultVO vo : taskCaseResultList) {
			if (vo.getInspRes() != null) {
				isInsp = true;
				break;
			}
		}		
		
		// 3. TaskResult One
		WkvTaskResultVO resultOne = null;
		for (WkvTaskResultVO vo : taskCaseResultList) {
			if (vo.getUserId().equals(loginId)) {
				resultOne = vo; 
				break;
			}
		}
		resultMap.put("data", resultOne);

		// 4. Work Form 상태 정의
		// StatusCd = D:diag  |  I:insp  |  DC:diag-complete(modify)  |  IC:insp-complete(modify)
		// 		   |  IB:insp-block(아직 못함)  |  DCB:diag-block(진단 완료했고 검수가 진행됐으면 진단 수정 불가)
		// projectType =  A(진단 + 검수)  |  D(진단만)  |  I(검수만)  |  S(진단 + 검수 + 담당자 선 지정)
		ProjectVO paramVO = new ProjectVO();
		paramVO.setProjCd(projCd);
		ProjectVO projectVO = workTaskMapper.selectProjectUseOne(paramVO);
		String projectType = projectVO.getDiagInspFg();
		
		String diagUserId = resultOne.getDiagUserId();
		String lblCd = resultOne.getLblCd();
		String inspRes = resultOne.getInspRes();
		String statusCd = null;
		if ("A".equals(projectType)) {
			// 수면.
			statusCd = "D"; // 기본값 진단.
			if (diagUserId != null) {
				statusCd = "I"; // 진단 완료. 검수.
				if (diagUserId.equals(loginId)) {
					statusCd = "DC"; // 진단자 진단 완료.
					if (isInsp) {
						statusCd = "DCB"; // 검수 진행되어 진단 수정 불가
					}
				} else if (inspRes != null) {
					statusCd = "IC"; // 검수자 검수 완료.
				}
			}
		} else if ("D".equals(projectType)) {
			// no project
		} else if ("I".equals(projectType)) {
			// 폐기능
			statusCd = "I"; // 기본 검수
			if (inspRes != null) {
				statusCd = "IC"; // 검수자 검수 완료.
			}
		} else if ("S".equals(projectType)) {
			//폐음.
			String diagInspFgPlan = resultOne.getDiagInspFgPlan();	// 담당자 선 지정.
			if ("D".equals(diagInspFgPlan)) {
				if (lblCd != null) { // 진단자이면서 진단 등록을 한 상태 : 수정.
					statusCd = "DC";
					if (isInsp) {
						statusCd = "DCB"; // 검수 진행되어 진단 수정 불가
					}
				} else {
					statusCd = "D"; // 진단자 진단 등록 전.
				}
			} else if ("I".equals(diagInspFgPlan)) {
				if (lblCd == null || "".equals(lblCd)) {
					statusCd = "IB"; // 검수자. 진단 진행 안됨.
				} else {
					if (inspRes != null) {
						statusCd = "IC"; // 검수자 검수 완료.
					} else {
						statusCd = "I";	// 검수자 검수 전.
					}					
				}
			}
		} 
		resultMap.put("statusCd", statusCd);
		
		
		return resultMap;
	}

	// --------------------
	//     Case Item
	// --------------------
	@SuppressWarnings("unchecked")
	private Map<String, Object> getCsvData(String projCd, String filePath) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<String[]> csv = CsvUtil.readCsv(filePath);
		if (csv.size() < 1) {
			System.out.println("csv no data");
			return null;
		}
		// 여기서는 원래 프로젝트 조건 이후에 itemCd 조건 한번 더 거쳐야함. 그냥 생략.
		
		// 전체 차트
		if ("2022A1".equals(projCd)) {
			csv = csv.subList(2, csv.size());	// 2 row 생략.
			String[] colList = new String[]{"ekg", "actix", "actiy", "actiz"};
			for (String col : colList) {
				resultMap.put(col, new ArrayList<String>());
			}
			for (int i=0; i<csv.size(); i++) {
				for (int k=0; k<colList.length; k++) {
					String csvVal = csv.get(i)[k+1];	// k+1 : 첫번째 col 점프.
					((List<String>) resultMap.get(colList[k])).add(csvVal);
				}
			}		
		}
		
		// 폐기능 측정 데이터
		if ("2022B1".equals(projCd)) {
			// 데이터 첫줄 colName 나옴.
			String[] colList = new String[]{"time", "flow", "volume"};
			// 1. col값마다 리스트 선언.
			for (String col : colList) {
				resultMap.put(col, new ArrayList<String>());
			}
			// 2. 기존 csv 파일 역치 및 colName 부여. (1부터 시작 = 첫줄(컬럼이름) 무시.)
			for (int i=1; i<csv.size(); i++) {
				for (int k=0; k<colList.length; k++) {
					String csvVal = csv.get(i)[k];
					((List<String>) resultMap.get(colList[k])).add(csvVal);	// unchecked
				}
			}
		}

		return resultMap;
	}
	
	private byte[] getAudioData(String projCd, String filePath, int epoch) {
		
		// 보류. 망함.
//		if ("2022A1".equals(projCd)) {
//			int SIZE = 30;	// 30초.
//			byte[] byteArr = AudioFileProcessor.getAudioByte(filePath, epoch, SIZE);
//			return byteArr;
//		}
		return null;
	}
	
	
	private Map<String, Object> getEdfData(String projCd, String filePath, int epoch) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		// 여기서 바이너리 (EDF) 읽어오기. 프로젝트 수면만 일단 하드코딩.
		if ("2022A1".equals(projCd)) {
	        // signalNo = actiX:0  |  actiY:1  |  actiZ:2  |  ecg(ekg): 3
			final int RATE = 10; // 초당 10건.
			final int SIZE = 300; // 300초(5분).
			UEdfModule edf = new UEdfModule(filePath, SIZE);
			try {
				List<UEdfInterpolationData> actiX = edf.getInterpolationData(0, RATE, epoch, 1);
				List<UEdfInterpolationData> actiY = edf.getInterpolationData(1, RATE, epoch, 1);
				List<UEdfInterpolationData> actiZ = edf.getInterpolationData(2, RATE, epoch, 1);
				List<UEdfInterpolationData> ekg = edf.getInterpolationData(3, RATE, epoch, 1);
				Map<String, List<UEdfInterpolationData>> forMap = new HashMap<String, List<UEdfInterpolationData>>();
				Timestamp stamp = Timestamp.valueOf(edf.baseInfo.startDateTime);
				long stampLong = stamp.getTime();
				LocalDateTime timeBack = stamp.toLocalDateTime();
				resultMap.put("fullStartDateTime", stampLong);
				forMap.put("actix", actiX);
				forMap.put("actiy", actiY);
				forMap.put("actiz", actiZ);
				forMap.put("ekg", ekg);
				for (String key : forMap.keySet()) {
					List<Double> valueList = new ArrayList<Double>();
					for (UEdfInterpolationData data : forMap.get(key)) {
						valueList.add(StringUtil.roundToSignificantFigures(data.value, 3));
					}
					resultMap.put(key, valueList);
				}
				
				// Total Epoch Count
				long totalEpochCount = edf.baseInfo.totalEpochCount;
				resultMap.put("totalEpochCount", totalEpochCount);
				resultMap.put("recordDuration", edf.baseInfo.recordDuration);
				resultMap.put("totalDuration", edf.baseInfo.totalDuration);

				// Start Time ~ End Time
				LocalDateTime startTime = actiX.get(0).sampleDateTime;
				LocalDateTime endTime = startTime.plusSeconds(SIZE);
				DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
				resultMap.put("startTime", startTime.format(f));
				resultMap.put("endTime", endTime.format(f));
				
				resultMap.put("dataPerSecond", RATE);
			} catch (Exception e) {
				System.out.println("getEdfData ERROR");
				e.printStackTrace();
			}
		}
		
		return resultMap;
	}
	
	
	public Map<String, Object> getCaseDataItemAll(Map<String, Object> paramMap) throws Exception {
		LOGGER.info(">>> workTaskService.getCaseDataItemAll >>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		// PARAM
		String projCd = (String) paramMap.get("projCd");
		String taskCd = (String) paramMap.get("taskCd");
		String caseNo = (String) paramMap.get("caseNo");
		
		int epoch = 0;
		if (StringUtil.isNumber((String) paramMap.get("epoch"))) {
			epoch = Integer.parseInt((String) paramMap.get("epoch"));
		}
		
		/*
			dataTp = I:Integer(정수)  |  S:String(문자열)  |  D:Decimal(실수)  |  L:Link (웹서버 기준 파일 경로)  |  J : JSON OBJECT인 경우
			if (dataTp == L) 인경우
			fileTp = A:AUDIO  |  V:VIDEO  |  B:BINARY  |  C:CSV 등 TEXT 파일	 기타 등등 정의
			
		*/
		paramMap.remove("itemSeq");
		paramMap.remove("epoch");
		List<Map<String, Object>> itemAll = workTaskMapper.selectCaseDataItemAll(paramMap);
		List<Map<String, Object>> newItemAll = new ArrayList<Map<String,Object>>();
		
		String localDataPath = CommonProperties.load2("LOCAL_DATA_PATH").replaceAll("/", Matcher.quoteReplacement(File.separator));
		for (Map<String, Object> itemOne : itemAll) {
			String dataTp = (String) itemOne.get("dataTp");
			if ("L".equals(dataTp)) {
				String itemDiv = (String) itemOne.get("itemDiv");
				String fileTp = (String) itemOne.get("fileTp");
				String dataItemVal = (String) itemOne.get("dataItemVal");
				String filePath = localDataPath + dataItemVal.replaceAll("/", Matcher.quoteReplacement(File.separator));
				if ("ITEM".equals(itemDiv)) {
					if ("C".equals(fileTp)) {
						itemOne.put("csvData", getCsvData(projCd, filePath));
					} else if ("B".equals(fileTp)) {
						itemOne.put("edfData", getEdfData(projCd, filePath, epoch));
					} else if ("A".equals(fileTp)) {
						itemOne.put("audioData", getAudioData(projCd, filePath.replaceAll(".mp3", ".wav"), epoch));
					} else if ("J".equals(fileTp)) {
						// 그냥 텍스트 파일로 읽어들이고 json 파싱.
					}
					newItemAll.add(itemOne);
				} else if ("ITEM_LIST".equals(itemDiv)) {
					int itemSeq = ((BigDecimal) itemOne.get("itemSeq")).intValue();
//					if (itemSeq == paramItemSeq) {
					if (itemSeq == epoch) {
						if ("C".equals(fileTp)) {
							itemOne.put("csvData", getCsvData(projCd, filePath));
						} else if ("B".equals(fileTp)) {
							itemOne.put("edfData", getEdfData(projCd, filePath, epoch));
						} else if ("A".equals(fileTp)) {
							itemOne.put("audioData", getAudioData(projCd, filePath.replaceAll(".mp3", ".wav"), epoch));
						} else if ("J".equals(fileTp)) {
							// 그냥 텍스트 파일로 읽어들이고 json 파싱.
						}
						newItemAll.add(itemOne);
					} else if (epoch == 0) {
						newItemAll.add(itemOne);
					}
				}
			} else {
				newItemAll.add(itemOne);
			}
		}
		resultMap.put("itemAll", newItemAll);
		
		// Spectrogram Image
		if ("2022A1".equals(projCd)) {
			PlvCaseSoundImage paramVO2 = new PlvCaseSoundImage();
			paramVO2.setProjCd(projCd);
			paramVO2.setTaskCd(taskCd);
			paramVO2.setCaseNo(caseNo);
			List<PlvCaseSoundImage> soundImageList = workTaskMapper.selectCaseSpectrogram(paramVO2);
			List<Integer> soundEpochList = new ArrayList<Integer>();
			for (int i=0; i<10; i++) {
				int start = (epoch - 1) * 10 + 1;
				soundEpochList.add(i + start);
			}
			
			List<PlvCaseSoundImage> newList = new ArrayList<PlvCaseSoundImage>();
			for (PlvCaseSoundImage one : soundImageList) {
				int imgSeq = one.getImgSeq();
				if (soundEpochList.contains(imgSeq)) {
					newList.add(one);
				}
			}
			resultMap.put("soundImage", newList);
		}
		
		// lungGoodSound
		if ("2022B2".equals(projCd)) {
			// lungGoodSound
			List<Map<String, Object>> goodLungSoundList = workTaskMapper.selectGoodLungSoundList(paramMap);
			Map<String, Object> goodLungSoundResult = new HashMap<String, Object>();
			List<String> lungGoodList = new ArrayList<String>();
			String lungBest = null;
			for (Map<String, Object> one : goodLungSoundList) {
				lungGoodList.add((String) one.get("testLoc"));
				if ("Y".equals((String)one.get("bestYn"))) {
					lungBest = (String) one.get("testLoc");
				}
			}
			goodLungSoundResult.put("lungGoodList", lungGoodList);
			goodLungSoundResult.put("lungBest", lungBest);
			resultMap.put("goodLungSound", goodLungSoundResult);
			
		}
	
		// diagResult
		WkvTaskResultVO diagResultParamVO = new WkvTaskResultVO();
		diagResultParamVO.setProjCd(projCd);
		diagResultParamVO.setTaskCd(taskCd);
		diagResultParamVO.setCaseNo(caseNo);
		List<WkvTaskResultVO> diagResultList = workTaskMapper.selectTaskResultList(diagResultParamVO);
		if (diagResultList.size() > 0) {
			resultMap.put("diagResult", diagResultList.get(0));				
		} else {
			resultMap.put("diagResult", null);
		}
		
		return resultMap;
	}


	// --------------------
	//     Work Process
	// --------------------
	// 진단 등록
	public void registDiagnose(Map<String, Object> map) throws Exception {
		LOGGER.info(">>> workTaskService.registDiagnose >>>");
		workTaskMapper.callRegistDiagnose(map);
	}
	// 검수 등록
	public void registInspect(Map<String, Object> map) throws Exception {
		LOGGER.info(">>> workTaskService.registInspect >>>");
		workTaskMapper.callRegistInspect(map);
	}
	// 진단 수정
	public void modifyDiagnose(Map<String, Object> map) throws Exception {
		LOGGER.info(">>> workTaskService.modifyDiagnose >>>");
		workTaskMapper.callModifyDiagnose(map);
	}
	// 검수 수정
	public void modifyInspect(Map<String, Object> map) throws Exception {
		LOGGER.info(">>> workTaskService.modifyInspect >>>");
		workTaskMapper.callModifyInspect(map);
	}
	
}
