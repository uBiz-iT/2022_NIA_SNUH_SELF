package com.ubizit.dams.work.mapper;

import java.util.List;

import com.ubizit.dams.work.model.WktFailDiagVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("failDiagMapper")
public class FailDiagMapper extends EgovAbstractMapper {

	public List<WktFailDiagVO> selectFailDiagList(WktFailDiagVO FailDiagVO) throws Exception {
		return selectList("FAIL_DIAG_MAPPER.selectFailDiag", FailDiagVO);
	}

	public WktFailDiagVO selectFailDiagOne(WktFailDiagVO FailDiagVO) throws Exception {
		return selectOne("FAIL_DIAG_MAPPER.selectFailDiag", FailDiagVO);
	}

	public int insertFailDiagList(WktFailDiagVO FailDiagVO) throws Exception {
		return insert("FAIL_DIAG_MAPPER.insertFailDiag", FailDiagVO);
	}

}
