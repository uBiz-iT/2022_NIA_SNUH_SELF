package com.ubizit.dams.work.model;

/**
 * @Description: 로그인 vo 가 따로 필요한가?
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.05.11 - 박성욱 - 최초생성
 *
 * @author: PSW
 * @since: 2022.05.11
 */
public class WktTaskDiagVO {
	
    private String projCd;
    private String taskCd;
    private String caseNo;
    private String userId;
    private String lblCd;
    private String memo;
    private String workYmd;
    private String regDt;
    private String mdfDt;
    
	@Override
	public String toString() {
		return "WktTaskDiagVO [projCd=" + projCd + ", taskCd=" + taskCd + ", caseNo=" + caseNo + ", userId=" + userId
				+ ", lblCd=" + lblCd + ", memo=" + memo + ", workYmd=" + workYmd + ", regDt=" + regDt + ", mdfDt="
				+ mdfDt + "]";
	}
	
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLblCd() {
		return lblCd;
	}
	public void setLblCd(String lblCd) {
		this.lblCd = lblCd;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getWorkYmd() {
		return workYmd;
	}
	public void setWorkYmd(String workYmd) {
		this.workYmd = workYmd;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getMdfDt() {
		return mdfDt;
	}
	public void setMdfDt(String mdfDt) {
		this.mdfDt = mdfDt;
	}
    
}
