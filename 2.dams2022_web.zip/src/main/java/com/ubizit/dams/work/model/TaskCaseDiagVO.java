package com.ubizit.dams.work.model;

/**
 * @Description: 로그인 vo 가 따로 필요한가?
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.05.11 - 박성욱 - 최초생성
 *
 * @author: PSW
 * @since: 2022.05.11
 */
public class TaskCaseDiagVO {

    private String projCd;
    private String projNm;
    private String useYn;
    private int weekRepoStdDayw;
    private int planDsetQty;
    private String projBegYmd;
    private String projEndYmd;
    private String regId;
    private String regDt;
    
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getProjNm() {
		return projNm;
	}
	public void setProjNm(String projNm) {
		this.projNm = projNm;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public int getWeekRepoStdDayw() {
		return weekRepoStdDayw;
	}
	public void setWeekRepoStdDayw(int weekRepoStdDayw) {
		this.weekRepoStdDayw = weekRepoStdDayw;
	}
	public int getPlanDsetQty() {
		return planDsetQty;
	}
	public void setPlanDsetQty(int planDsetQty) {
		this.planDsetQty = planDsetQty;
	}
	public String getProjBegYmd() {
		return projBegYmd;
	}
	public void setProjBegYmd(String projBegYmd) {
		this.projBegYmd = projBegYmd;
	}
	public String getProjEndYmd() {
		return projEndYmd;
	}
	public void setProjEndYmd(String projEndYmd) {
		this.projEndYmd = projEndYmd;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
    
}
