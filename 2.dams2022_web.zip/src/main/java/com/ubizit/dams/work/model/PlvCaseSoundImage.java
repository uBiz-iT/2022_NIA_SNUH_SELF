package com.ubizit.dams.work.model;

public class PlvCaseSoundImage {

    private String projCd;
    private String taskCd;
    private String caseNo;
    private String dataGrpCd;
    private String dataGrpNm;
    private String dataItemCd;
    private String dataItemNm;
    private Integer itemSeq;
    private Integer imgSeq;
    private String imgFileNm;
    private String imgFilePath;
    private String imgFileFullPath;
    
	@Override
	public String toString() {
		return "PltCaseSoundImage [projCd=" + projCd + ", taskCd=" + taskCd + ", caseNo=" + caseNo + ", dataGrpCd="
				+ dataGrpCd + ", dataGrpNm=" + dataGrpNm + ", dataItemCd=" + dataItemCd + ", dataItemNm=" + dataItemNm
				+ ", itemSeq=" + itemSeq + ", imgSeq=" + imgSeq + ", imgFileNm=" + imgFileNm + ", imgFilePath="
				+ imgFilePath + ", imgFileFullPath=" + imgFileFullPath + "]";
	}
	
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public String getDataGrpCd() {
		return dataGrpCd;
	}
	public void setDataGrpCd(String dataGrpCd) {
		this.dataGrpCd = dataGrpCd;
	}
	public String getDataGrpNm() {
		return dataGrpNm;
	}
	public void setDataGrpNm(String dataGrpNm) {
		this.dataGrpNm = dataGrpNm;
	}
	public String getDataItemCd() {
		return dataItemCd;
	}
	public void setDataItemCd(String dataItemCd) {
		this.dataItemCd = dataItemCd;
	}
	public String getDataItemNm() {
		return dataItemNm;
	}
	public void setDataItemNm(String dataItemNm) {
		this.dataItemNm = dataItemNm;
	}
	public Integer getItemSeq() {
		return itemSeq;
	}
	public void setItemSeq(Integer itemSeq) {
		this.itemSeq = itemSeq;
	}
	public Integer getImgSeq() {
		return imgSeq;
	}
	public void setImgSeq(Integer imgSeq) {
		this.imgSeq = imgSeq;
	}
	public String getImgFileNm() {
		return imgFileNm;
	}
	public void setImgFileNm(String imgFileNm) {
		this.imgFileNm = imgFileNm;
	}
	public String getImgFilePath() {
		return imgFilePath;
	}
	public void setImgFilePath(String imgFilePath) {
		this.imgFilePath = imgFilePath;
	}
	public String getImgFileFullPath() {
		return imgFileFullPath;
	}
	public void setImgFileFullPath(String imgFileFullPath) {
		this.imgFileFullPath = imgFileFullPath;
	}

    
}