package com.ubizit.dams.work.model;

import java.util.ArrayList;
import java.util.List;

import com.ubizit.dams.common.model.TaskVO;

/**
 * @Description: 로그인 vo 가 따로 필요한가?
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.05.11 - 박성욱 - 최초생성
 *
 * @author: PSW
 * @since: 2022.05.11
 */
public class PlvTaskUserPlanVO {
	
	// DB
    private String projCd;
    private String taskCd;
    private String userId;
    private String dataDir;
    private String dataRegYmd;
    private String statYn;
    private Integer caseCnt;
    private String diagInspFg;
    private String assnYmd;
    private String workStsFg;
    private String lastWorkCaseNo;
    private String taskNm;
    private String userNm;
    
    private String userIdFg;
    private String userNmFg;

    
    // taskVO VO값 추가 20220603
    private String regId;
    private String regDt;
    
    // 콤보박스 값 20220719
    private String projNmHid;
    // 콤보박스 조회값 20220721
    private String projNmParam;
    
    private List<PlvTaskUserPlanVO> userList = new ArrayList<PlvTaskUserPlanVO>();
    
	// SEARCH
    private boolean isSearch = false;
    
	@Override
	public String toString() {
		return "PlvTaskUserPlanVO [projCd=" + projCd + ", taskCd=" + taskCd + ", userId=" + userId + ", dataDir="
				+ dataDir + ", dataRegYmd=" + dataRegYmd + ", statYn=" + statYn + ", caseCnt=" + caseCnt
				+ ", diagInspFg=" + diagInspFg + ", assnYmd=" + assnYmd + ", workStsFg=" + workStsFg
				+ ", lastWorkCaseNo=" + lastWorkCaseNo + ", taskNm=" + taskNm + ", userNm=" + userNm + "]";
	}
	
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDataDir() {
		return dataDir;
	}
	public void setDataDir(String dataDir) {
		this.dataDir = dataDir;
	}
	public String getDataRegYmd() {
		return dataRegYmd;
	}
	public void setDataRegYmd(String dataRegYmd) {
		this.dataRegYmd = dataRegYmd;
	}
	public Object getStatYn() {
		return statYn;
	}
	public void setStatYn(String statYn) {
		this.statYn = statYn;
	}
	public Integer getCaseCnt() {
		return caseCnt;
	}
	public void setCaseCnt(Integer caseCnt) {
		this.caseCnt = caseCnt;
	}
	public Object getDiagInspFg() {
		return diagInspFg;
	}
	public void setDiagInspFg(String diagInspFg) {
		this.diagInspFg = diagInspFg;
	}
	public String getAssnYmd() {
		return assnYmd;
	}
	public void setAssnYmd(String assnYmd) {
		this.assnYmd = assnYmd;
	}
	public Object getWorkStsFg() {
		return workStsFg;
	}
	public void setWorkStsFg(String workStsFg) {
		this.workStsFg = workStsFg;
	}
	public String getLastWorkCaseNo() {
		return lastWorkCaseNo;
	}
	public void setLastWorkCaseNo(String lastWorkCaseNo) {
		this.lastWorkCaseNo = lastWorkCaseNo;
	}
	public String getTaskNm() {
		return taskNm;
	}
	public void setTaskNm(String taskNm) {
		this.taskNm = taskNm;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public boolean isSearch() {
		return isSearch;
	}
	public void setSearch(boolean isSearch) {
		this.isSearch = isSearch;
	}

	public String getRegId() {
		return regId;
	}

	public void setRegId(String regId) {
		this.regId = regId;
	}

	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

	public List<PlvTaskUserPlanVO> getUserList() {
		return userList;
	}

	public void setUserList(List<PlvTaskUserPlanVO> userList) {
		this.userList = userList;
	}

	public String getProjNmHid() {
		return projNmHid;
	}

	public void setProjNmHid(String projNmHid) {
		this.projNmHid = projNmHid;
	}

	public String getProjNmParam() {
		return projNmParam;
	}

	public void setProjNmParam(String projNmParam) {
		this.projNmParam = projNmParam;
	}

	public String getUserIdFg() {
		return userIdFg;
	}

	public void setUserIdFg(String userIdFg) {
		this.userIdFg = userIdFg;
	}

	public String getUserNmFg() {
		return userNmFg;
	}

	public void setUserNmFg(String userNmFg) {
		this.userNmFg = userNmFg;
	}
	
	
}
