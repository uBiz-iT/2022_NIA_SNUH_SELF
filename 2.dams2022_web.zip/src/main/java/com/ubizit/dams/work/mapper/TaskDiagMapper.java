package com.ubizit.dams.work.mapper;

import java.util.List;

import com.ubizit.dams.work.model.WktTaskDiagVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("taskDiagMapper")
public class TaskDiagMapper extends EgovAbstractMapper {

	public List<WktTaskDiagVO> selectTaskDiagList(WktTaskDiagVO taskDiagVO) throws Exception {
		return selectList("TASK_DIAG_MAPPER.selectTaskDiag", taskDiagVO);
	}

	public WktTaskDiagVO selectTaskDiagOne(WktTaskDiagVO taskDiagVO) throws Exception {
		return selectOne("TASK_DIAG_MAPPER.selectTaskDiag", taskDiagVO);
	}

	public int insertTaskDiagList(WktTaskDiagVO taskDiagVO) throws Exception {
		return insert("TASK_DIAG_MAPPER.insertTaskDiag", taskDiagVO);
	}

}
