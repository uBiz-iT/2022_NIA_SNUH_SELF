package com.ubizit.dams.work.mapper;

import java.util.List;

import com.ubizit.dams.work.model.WktTaskInspVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("taskInspMapper")
public class TaskInspMapper extends EgovAbstractMapper {

	public List<WktTaskInspVO> selectTaskInspList(WktTaskInspVO taskInspVO) throws Exception {
		return selectList("TASK_INSP_MAPPER.selectTaskInsp", taskInspVO);
	}

	public WktTaskInspVO selectTaskInspOne(WktTaskInspVO taskInspVO) throws Exception {
		return selectOne("TASK_INSP_MAPPER.selectTaskInsp", taskInspVO);
	}

	public int insertTaskInspList(WktTaskInspVO taskInspVO) throws Exception {
		return insert("TASK_INSP_MAPPER.insertTaskInsp", taskInspVO);
	}

}
