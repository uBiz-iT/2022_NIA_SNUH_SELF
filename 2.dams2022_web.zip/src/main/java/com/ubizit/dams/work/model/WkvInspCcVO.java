package com.ubizit.dams.work.model;

/**
 * @Description: 로그인 vo 가 따로 필요한가?
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.05.11 - 박성욱 - 최초생성
 *
 * @author: PSW
 * @since: 2022.05.11
 */
public class WkvInspCcVO {

	private String projCd;
    private String taskCd;
    private String caseNo;
    private String lblCd;
    private String lblDisp;
    private String lblNm;
    private String diagUserId;
    private String diagUserNm;
    private String diagWorkYmd;
    private String diagFailCausList;
    private String diagMemo;
    private Integer inspPlanCnt;
    private String inspRes;
    private String inspWorkYmd;
    private Integer inspWorkCnt;
    private Integer inspResCnt;
    private String inspUserIdList;
    private String inspUserNmList;
    private String inspResList;
    private String inspFailCausList;
    private String inspMemoList;
    private String allUserIdList;
    private String allUserNmList;
    
	@Override
	public String toString() {
		return "WkvInspCcVO [projCd=" + projCd + ", taskCd=" + taskCd + ", caseNo=" + caseNo + ", lblCd=" + lblCd
				+ ", lblDisp=" + lblDisp + ", lblNm=" + lblNm + ", diagUserId=" + diagUserId + ", diagUserNm="
				+ diagUserNm + ", diagWorkYmd=" + diagWorkYmd + ", diagFailCausList=" + diagFailCausList + ", diagMemo="
				+ diagMemo + ", inspPlanCnt=" + inspPlanCnt + ", inspRes=" + inspRes + ", inspWorkYmd=" + inspWorkYmd
				+ ", inspWorkCnt=" + inspWorkCnt + ", inspResCnt=" + inspResCnt + ", inspUserIdList=" + inspUserIdList
				+ ", inspUserNmList=" + inspUserNmList + ", inspResList=" + inspResList + ", inspFailCausList="
				+ inspFailCausList + ", inspMemoList=" + inspMemoList + ", allUserIdList=" + allUserIdList
				+ ", allUserNmList=" + allUserNmList + "]";
	}
	
	public String getProjCd() {
		return projCd;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public String getLblCd() {
		return lblCd;
	}
	public void setLblCd(String lblCd) {
		this.lblCd = lblCd;
	}
	public String getLblDisp() {
		return lblDisp;
	}
	public void setLblDisp(String lblDisp) {
		this.lblDisp = lblDisp;
	}
	public String getLblNm() {
		return lblNm;
	}
	public void setLblNm(String lblNm) {
		this.lblNm = lblNm;
	}
	public String getDiagUserId() {
		return diagUserId;
	}
	public void setDiagUserId(String diagUserId) {
		this.diagUserId = diagUserId;
	}
	public String getDiagUserNm() {
		return diagUserNm;
	}
	public void setDiagUserNm(String diagUserNm) {
		this.diagUserNm = diagUserNm;
	}
	public String getDiagWorkYmd() {
		return diagWorkYmd;
	}
	public void setDiagWorkYmd(String diagWorkYmd) {
		this.diagWorkYmd = diagWorkYmd;
	}
	public String getDiagFailCausList() {
		return diagFailCausList;
	}
	public void setDiagFailCausList(String diagFailCausList) {
		this.diagFailCausList = diagFailCausList;
	}
	public String getDiagMemo() {
		return diagMemo;
	}
	public void setDiagMemo(String diagMemo) {
		this.diagMemo = diagMemo;
	}
	public Integer getInspPlanCnt() {
		return inspPlanCnt;
	}
	public void setInspPlanCnt(Integer inspPlanCnt) {
		this.inspPlanCnt = inspPlanCnt;
	}
	public String getInspRes() {
		return inspRes;
	}
	public void setInspRes(String inspRes) {
		this.inspRes = inspRes;
	}
	public String getInspWorkYmd() {
		return inspWorkYmd;
	}
	public void setInspWorkYmd(String inspWorkYmd) {
		this.inspWorkYmd = inspWorkYmd;
	}
	public Integer getInspWorkCnt() {
		return inspWorkCnt;
	}
	public void setInspWorkCnt(Integer inspWorkCnt) {
		this.inspWorkCnt = inspWorkCnt;
	}
	public Integer getInspResCnt() {
		return inspResCnt;
	}
	public void setInspResCnt(Integer inspResCnt) {
		this.inspResCnt = inspResCnt;
	}
	public String getInspUserIdList() {
		return inspUserIdList;
	}
	public void setInspUserIdList(String inspUserIdList) {
		this.inspUserIdList = inspUserIdList;
	}
	public String getInspUserNmList() {
		return inspUserNmList;
	}
	public void setInspUserNmList(String inspUserNmList) {
		this.inspUserNmList = inspUserNmList;
	}
	public String getInspResList() {
		return inspResList;
	}
	public void setInspResList(String inspResList) {
		this.inspResList = inspResList;
	}
	public String getInspFailCausList() {
		return inspFailCausList;
	}
	public void setInspFailCausList(String inspFailCausList) {
		this.inspFailCausList = inspFailCausList;
	}
	public String getInspMemoList() {
		return inspMemoList;
	}
	public void setInspMemoList(String inspMemoList) {
		this.inspMemoList = inspMemoList;
	}
	public String getAllUserIdList() {
		return allUserIdList;
	}
	public void setAllUserIdList(String allUserIdList) {
		this.allUserIdList = allUserIdList;
	}
	public String getAllUserNmList() {
		return allUserNmList;
	}
	public void setAllUserNmList(String allUserNmList) {
		this.allUserNmList = allUserNmList;
	}

    
}
