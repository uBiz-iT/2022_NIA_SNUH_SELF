package com.ubizit.dams.work.model;

/**
 * @Description: 
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.06
 *
 * @author: 
 * @since: 2022.06
 */
public class CrossValidationVO {

    private String projCd;
    private String projNm;
    private String taskCd;
    private String taskNm;
    private String userId;
    private String userNm;
    
    // TaskList
    private String dataRegYmd;
    private String caseCnt;
    private String compCnt;
    private String passCnt;
    private String failCnt;

    // 진단 검수 교차검증
    // 케이스 번호
    private String caseNo;
    // 라벨명
    private String lblDisp;
    // 진단자명
    private String diagUserNm;
    // 진단자 DROP 사유
    private String diagFailCausList;
    // 진단자 메모
    private String diagMemo;
    // 검수 최종 결과
    private String inspRes;
    // 검수자1
    private String user1Info;
    // 검수자2
    private String user2Info;
    // 검수자1 메모
    private String user1Memo;
    // 검수자2 메모
    private String user2Memo;
    // 검수자3 메모
    private String user3Memo;
    // 진단을 아직 안한경우 할당된 진단/검수자 이름 목록
    private String assignUsers;
    // 검수자 ID 목록
    private String inspUserIdList;
    // 검수자 이름 목록
    private String inspUserNmList;
    // 검수자별 검수 결과 목록
    private String inspResList;
    // 검수자1(검수결과)
    private String user1Res;
    // 검수자2(검수결과)
    private String user2Res;
    // 검수자3(검수결과)
    private String user3Res;
    
    
	public String getProjCd() {
		return projCd;
	}
	public String getProjNm() {
		return projNm;
	}
	public String getTaskCd() {
		return taskCd;
	}
	public String getTaskNm() {
		return taskNm;
	}
	public String getUserId() {
		return userId;
	}
	public String getUserNm() {
		return userNm;
	}
	public String getDataRegYmd() {
		return dataRegYmd;
	}
	public String getCaseCnt() {
		return caseCnt;
	}
	public String getCompCnt() {
		return compCnt;
	}
	public String getPassCnt() {
		return passCnt;
	}
	public String getFailCnt() {
		return failCnt;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public String getLblDisp() {
		return lblDisp;
	}
	public String getDiagUserNm() {
		return diagUserNm;
	}
	public String getDiagFailCausList() {
		return diagFailCausList;
	}
	public String getDiagMemo() {
		return diagMemo;
	}
	public String getInspRes() {
		return inspRes;
	}
	public String getUser1Info() {
		return user1Info;
	}
	public String getUser2Info() {
		return user2Info;
	}
	public String getUser1Memo() {
		return user1Memo;
	}
	public String getUser2Memo() {
		return user2Memo;
	}
	public String getUser3Memo() {
		return user3Memo;
	}
	public String getAssignUsers() {
		return assignUsers;
	}
	public String getInspUserIdList() {
		return inspUserIdList;
	}
	public String getInspUserNmList() {
		return inspUserNmList;
	}
	public String getInspResList() {
		return inspResList;
	}
	public String getUser1Res() {
		return user1Res;
	}
	public String getUser2Res() {
		return user2Res;
	}
	public String getUser3Res() {
		return user3Res;
	}
	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}
	public void setProjNm(String projNm) {
		this.projNm = projNm;
	}
	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}
	public void setTaskNm(String taskNm) {
		this.taskNm = taskNm;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public void setDataRegYmd(String dataRegYmd) {
		this.dataRegYmd = dataRegYmd;
	}
	public void setCaseCnt(String caseCnt) {
		this.caseCnt = caseCnt;
	}
	public void setCompCnt(String compCnt) {
		this.compCnt = compCnt;
	}
	public void setPassCnt(String passCnt) {
		this.passCnt = passCnt;
	}
	public void setFailCnt(String failCnt) {
		this.failCnt = failCnt;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public void setLblDisp(String lblDisp) {
		this.lblDisp = lblDisp;
	}
	public void setDiagUserNm(String diagUserNm) {
		this.diagUserNm = diagUserNm;
	}
	public void setDiagFailCausList(String diagFailCausList) {
		this.diagFailCausList = diagFailCausList;
	}
	public void setDiagMemo(String diagMemo) {
		this.diagMemo = diagMemo;
	}
	public void setInspRes(String inspRes) {
		this.inspRes = inspRes;
	}
	public void setUser1Info(String user1Info) {
		this.user1Info = user1Info;
	}
	public void setUser2Info(String user2Info) {
		this.user2Info = user2Info;
	}
	public void setUser1Memo(String user1Memo) {
		this.user1Memo = user1Memo;
	}
	public void setUser2Memo(String user2Memo) {
		this.user2Memo = user2Memo;
	}
	public void setUser3Memo(String user3Memo) {
		this.user3Memo = user3Memo;
	}
	public void setAssignUsers(String assignUsers) {
		this.assignUsers = assignUsers;
	}
	public void setInspUserIdList(String inspUserIdList) {
		this.inspUserIdList = inspUserIdList;
	}
	public void setInspUserNmList(String inspUserNmList) {
		this.inspUserNmList = inspUserNmList;
	}
	public void setInspResList(String inspResList) {
		this.inspResList = inspResList;
	}
	public void setUser1Res(String user1Res) {
		this.user1Res = user1Res;
	}
	public void setUser2Res(String user2Res) {
		this.user2Res = user2Res;
	}
	public void setUser3Res(String user3Res) {
		this.user3Res = user3Res;
	}

    
}
