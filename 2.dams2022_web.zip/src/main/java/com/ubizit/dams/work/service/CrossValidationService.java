package com.ubizit.dams.work.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.work.mapper.CrossValidationMapper;
import com.ubizit.dams.work.model.CrossValidationVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;


@Service("crossValidationService")
public class CrossValidationService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(CrossValidationService.class);
	
	@Resource(name="crossValidationMapper")
	private CrossValidationMapper crossValidationMapper;

	public List<?> getProjectList(CrossValidationVO crossVo) throws Exception {
		LOGGER.info(">>>>>> CrossValidationService.getProjectList >>>>>>");
		
		return crossValidationMapper.selectProjectList(crossVo);
	}
	
	public List<?> getTaskList(CrossValidationVO crossVo) throws Exception {
		LOGGER.info(">>>>>> CrossValidationService.getTaskList >>>>>>");
		
		return crossValidationMapper.selectTaskList(crossVo);
	}

	public void getCrossChkList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> CrossValidationService.getCrossChkList >>>>>>");

		crossValidationMapper.callGetCrossChkList(map);
	}

	public List<Map<String, Object>> crossValidationExcelDL(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> CrossValidationService.crossValidationExcelDL >>>>>>");
		
		return crossValidationMapper.crossValidationExcelDL(map);
	}
}
