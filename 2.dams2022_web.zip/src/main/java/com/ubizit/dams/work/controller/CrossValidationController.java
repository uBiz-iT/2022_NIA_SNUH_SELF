package com.ubizit.dams.work.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.model.UserVO;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.work.model.CrossValidationVO;
import com.ubizit.dams.work.service.CrossValidationService;

@Controller
public class CrossValidationController {
	
	@Resource(name="crossValidationService")
	private CrossValidationService crossValidationService;
	
	private final static Logger logger = LogManager.getLogger(CrossValidationController.class);
	
	/**
	 * 기본 페이지
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/crossValidation.do")
	public String getPage() throws Exception {
		logger.info(">>>>>> CrossValidationController.getPage >>>>>>");
		
		return "work/crossValidationList";
	}
	
	/**
	 * 프로젝트 리스트
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/crossValidation/getProjectList.do")
	@ResponseBody
	public Map<String, Object> getProjectList(HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> CrossValidationController.getProjectList >>>>>>");
		
		UserVO loginUser = (UserVO) session.getAttribute("LOGIN_USER");
		
		// PARAM
		String projCd = request.getParameter("projCd");
		String userId = loginUser.getUserId();

		// Project List
		CrossValidationVO crossVo = new CrossValidationVO();
		crossVo.setProjCd(projCd);
		crossVo.setUserId(userId);
		List<?> projectList = crossValidationService.getProjectList(crossVo);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("projectList", projectList);
		return resultMap;
	}
	
	/**
	 * 태스크 리스트
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/crossValidation/getTaskList.do")
	@ResponseBody
	public Map<String, Object> getTaskList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> CrossValidationController.getTaskList >>>>>>");
		
		// PARAM
		String projCd = request.getParameter("projCd");
		String taskCd = request.getParameter("taskCd");
		
		// Task List
		CrossValidationVO crossVo = new CrossValidationVO();
		crossVo.setProjCd(projCd);
		crossVo.setTaskCd(taskCd);
		List<?> taskList = crossValidationService.getTaskList(crossVo);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("taskList", taskList);
		return resultMap;
	}
	
	/** 
	 * 교차검증결과 리스트 (테이블 데이터)
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/work/crossValidation/getCrossChkList.do")
	@ResponseBody
	public Map<String, Object> getCrossChkList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> CrossValidationController.getCrossChkList >>>>>>");
		
		// PARAM
		String projCd = request.getParameter("projCd");
		String taskCd = request.getParameter("taskCd");
		String inspRes = request.getParameter("inspRes");

		// CrossCheckList
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("projCd", projCd);
		paramMap.put("taskCd", taskCd);
		paramMap.put("inspRes", inspRes);
		String rcvJson = new Gson().toJson(paramMap);
		System.out.println("getCrossChkList PARAM");
		System.out.println(rcvJson);
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		crossValidationService.getCrossChkList(procMap);

		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		return resultMap;
	}

	/**
	 * 테이블 데이터 엑셀 다운로드
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/work/crossValidation/excelCrossChkList.do")
	@ResponseBody
	public Map<String, Object> excelCrossChkList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> CrossValidationController.excelCrossChkList >>>>>>");
		Map<String,Object> resultMap = new HashMap<String, Object>();

		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");

		String projCd = request.getParameter("projCd");
		String taskCd = request.getParameter("taskCd");
		String inspRes = request.getParameter("inspRes");
		String mode = request.getParameter("mode");

		// 엑셀 이름: TASK전체_자가수면검사데이터_PASS건
		String excelName = "";
		if ("all".equals(mode)) {
			excelName += "TASK전체_";
		}
		
		// 프로젝트 이름.
		if ("2022A1".equals(projCd)) {
			excelName += "자가수면_검사_데이터";
		} else if ("2022B1".equals(projCd)) {
			excelName += "자가_폐기능_검사_데이터";
		} else if ("2022B2".equals(projCd)) {
			excelName += "폐음_검사_데이터_구축";
		}
		excelName += "_교차검증결과_";
		if ("Pass".equals(inspRes)) {
			excelName += "PASS건_";
		} else if ("Fail".equals(inspRes)) {
			excelName += "FAIL건_";
		} else {
			excelName += "전체건_";
		}

		resultMap.put("projCd", projCd);
		resultMap.put("taskCd", taskCd);
		resultMap.put("inspRes", inspRes);

		// 엑셀에 담을 데이터 조회
		List<Map<String, Object>> dbList = crossValidationService.crossValidationExcelDL(resultMap);

		if (dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('" + failMsg + "');</script>");
			out.flush();
			return null;
		}

		// 컬럼정보
		List<String> colList = new ArrayList<String>();

		if ("all".equals(mode)) {
			colList.add("태스크 코드");
		}
		
		if ("2022A1".equals(projCd)) {
			colList.add("케이스 No");
			colList.add("라벨명");
			colList.add("진단자명");
			colList.add("DROP 사유");
			colList.add("메모");
			colList.add("최종 결과");
			colList.add("검수자1");
			colList.add("검수자2");
			colList.add("검수자1 메모");
			colList.add("검수자2 메모");
		} else if ("2022B1".equals(projCd)) {
			colList.add("케이스 No");
			colList.add("최종 결과");
			colList.add("검수자1");
			colList.add("검수자2");
			colList.add("검수자1 메모");
			colList.add("검수자2 메모");
		} else if ("2022B2".equals(projCd)) {
			colList.add("케이스 No");
			colList.add("라벨명");
			colList.add("진단자명");
			colList.add("DROP 사유");
			colList.add("메모");
			colList.add("최종 결과");
			colList.add("검수자1");
			colList.add("검수자2");
			colList.add("검수자1 메모");
			colList.add("검수자2 메모");
		} else {

		}
		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		if ("all".equals(mode)) {
			bodyList.add("TASK_CD");
		}
		if ("2022A1".equals(projCd)) {
			bodyList.add("CASE_NO");
			bodyList.add("LBL_DISP");
			bodyList.add("DIAG_USER_NM");
			bodyList.add("DIAG_FAIL_CAUS_LIST");
			bodyList.add("DIAG_MEMO");
			bodyList.add("INSP_RES");
			bodyList.add("USER1_INFO");
			bodyList.add("USER2_INFO");
			bodyList.add("USER1_MEMO");
			bodyList.add("USER2_MEMO");
		} else if ("2022B1".equals(projCd)) {
			bodyList.add("CASE_NO");
			bodyList.add("INSP_RES");
			bodyList.add("USER1_INFO");
			bodyList.add("USER2_INFO");
			bodyList.add("USER1_MEMO");
			bodyList.add("USER2_MEMO");
		} else if ("2022B2".equals(projCd)) {
			bodyList.add("CASE_NO");
			bodyList.add("LBL_DISP");
			bodyList.add("DIAG_USER_NM");
			bodyList.add("DIAG_FAIL_CAUS_LIST");
			bodyList.add("DIAG_MEMO");
			bodyList.add("INSP_RES");
			bodyList.add("USER1_INFO");
			bodyList.add("USER2_INFO");
			bodyList.add("USER1_MEMO");
			bodyList.add("USER2_MEMO");
		}

		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = excelName + StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);
		
		int[] widths = new int[colNames.length];

		for(int i = 0; i < colNames.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);
		
		resultMap.put("result", "Y");
		return resultMap;
	}
	
}
