package com.ubizit.dams.work.mapper;

import java.util.List;
import java.util.Map;

import com.ubizit.dams.work.model.CrossValidationVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("crossValidationMapper")
public class CrossValidationMapper extends EgovAbstractMapper {

	public List<?> selectProjectList(CrossValidationVO crossVo) throws Exception {
		return selectList("CROSS_VALIDATION_MAPPER.selectProject", crossVo);
	}

	public List<?> selectTaskList(CrossValidationVO crossVo) throws Exception {
		return selectList("CROSS_VALIDATION_MAPPER.selectTask", crossVo);
	}

	public void callGetCrossChkList(Map<String, Object> map) throws Exception {
		selectList("CROSS_VALIDATION_MAPPER.callGetCrosschk", map);
	}

	public List<Map<String, Object>> crossValidationExcelDL(Map<String, Object> map) throws Exception {
		return selectList("CROSS_VALIDATION_MAPPER.crossValidationExcelDL", map);
	}
}
