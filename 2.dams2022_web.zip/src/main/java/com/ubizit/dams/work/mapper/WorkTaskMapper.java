package com.ubizit.dams.work.mapper;

import java.util.List;
import java.util.Map;

import com.ubizit.dams.common.model.FailCauseVO;
import com.ubizit.dams.common.model.LabelVO;
import com.ubizit.dams.common.model.ProjectVO;
import com.ubizit.dams.work.model.PltTaskCaseVO;
import com.ubizit.dams.work.model.PlvCaseDataItem;
import com.ubizit.dams.work.model.PlvCaseDataItemList;
import com.ubizit.dams.work.model.PlvCaseSoundImage;
import com.ubizit.dams.work.model.PlvTaskUserPlanVO;
import com.ubizit.dams.work.model.WkvTaskResultVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("workTaskMapper")
public class WorkTaskMapper extends EgovAbstractMapper {

	// ------------------------------------------------------------------------
	// SELECT Project
	// ------------------------------------------------------------------------
	public List<ProjectVO> selectProjectUseList(ProjectVO paramVO) throws Exception {
		return selectList("WORK_TASK_MAPPER.selectProjectUse", paramVO);
	}

	public ProjectVO selectProjectUseOne(ProjectVO paramVO) throws Exception {
		return selectOne("WORK_TASK_MAPPER.selectProjectUse", paramVO);
	}

	// ------------------------------------------------------------------------
	// SELECT Label Cause
	// ------------------------------------------------------------------------
	public List<LabelVO> selectLabelUseList(LabelVO paramVO) throws Exception {
		return selectList("WORK_TASK_MAPPER.selectLabelUse", paramVO);
	}

	public List<FailCauseVO> selectFailCauseUseList(FailCauseVO paramVO) throws Exception {
		return selectList("WORK_TASK_MAPPER.selectFailCauseUse", paramVO);
	}

	// ------------------------------------------------------------------------
	// SELECT Task
	// ------------------------------------------------------------------------
	public List<PlvTaskUserPlanVO> selectTaskUserPlanList(PlvTaskUserPlanVO paramVO) throws Exception {
		return selectList("WORK_TASK_MAPPER.selectTaskUserPlan", paramVO);
	}

	public PlvTaskUserPlanVO selectTaskUserPlanOne(PlvTaskUserPlanVO paramVO) throws Exception {
		return selectOne("WORK_TASK_MAPPER.selectTaskUserPlan", paramVO);
	}

	public List<Map<String, Object>> getTaskList(Map<String, Object> paramMap) throws Exception {
		return selectList("WORK_TASK_MAPPER.getTaskList", paramMap);
	}

	// ------------------------------------------------------------------------
	// SELECT TaskCase
	// ------------------------------------------------------------------------
	public List<WkvTaskResultVO> selectTaskResultList(WkvTaskResultVO paramVO) throws Exception {
		return selectList("WORK_TASK_MAPPER.selectTaskResult", paramVO);
	}

	public WkvTaskResultVO selectTaskResultOne(WkvTaskResultVO paramVO) throws Exception {
		return selectOne("WORK_TASK_MAPPER.selectTaskResult", paramVO);
	}

	public PltTaskCaseVO selectTaskCaseInfo(PltTaskCaseVO paramVO) {
		return selectOne("WORK_TASK_MAPPER.selectTaskCase", paramVO);
	}

	// ------------------------------------------------------------------------
	// SELECT Items
	// ------------------------------------------------------------------------
	public List<PlvCaseDataItem> selectCaseDataItemList(PlvCaseDataItem paramVO) throws Exception {
		return selectList("WORK_TASK_MAPPER.selectCaseDataItem", paramVO);
	}

	public List<PlvCaseDataItemList> selectCaseDataItemListList(PlvCaseDataItemList paramVO) throws Exception {
		return selectList("WORK_TASK_MAPPER.selectCaseDataItemList", paramVO);
	}

	public List<PlvCaseSoundImage> selectCaseSoundImage(PlvCaseSoundImage paramVO) throws Exception {
		return selectList("WORK_TASK_MAPPER.selectCaseSoundImage", paramVO);
	}

	public List<PlvCaseSoundImage> selectCaseSpectrogram(PlvCaseSoundImage paramVO) throws Exception {
		return selectList("WORK_TASK_MAPPER.selectCaseSpectrogram", paramVO); // 파라미터vo 위에거 일단 갖다씀. 따로 vo 만들어줘야 하는데 일단
																				// vo 겹치니까 사용.
	}

	public List<Map<String, Object>> selectCaseDataItemAll(Map<String, Object> paramMap) throws Exception {
		return selectList("WORK_TASK_MAPPER.selectCaseDataItemAll", paramMap);
	}

	public List<Map<String, Object>> selectGoodLungSoundList(Map<String, Object> paramMap) throws Exception {
		return selectList("WORK_TASK_MAPPER.selectGoodLungSound", paramMap);
	}

	// ------------------------------------------------------------------------
	// PROC WorkTask
	// ------------------------------------------------------------------------
	public String callRegistDiagnose(Map<String, Object> procMap) throws Exception {
		return selectOne("WORK_TASK_MAPPER.callRegistDiagnose", procMap);
	}

	public String callRegistInspect(Map<String, Object> procMap) throws Exception {
		return selectOne("WORK_TASK_MAPPER.callRegistInspect", procMap);
	}

	public String callModifyDiagnose(Map<String, Object> procMap) throws Exception {
		return selectOne("WORK_TASK_MAPPER.callModifyDiagnose", procMap);
	}

	public String callModifyInspect(Map<String, Object> procMap) throws Exception {
		return selectOne("WORK_TASK_MAPPER.callModifyInspect", procMap);
	}

}
