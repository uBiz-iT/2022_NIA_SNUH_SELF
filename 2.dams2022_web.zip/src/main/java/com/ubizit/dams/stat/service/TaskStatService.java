package com.ubizit.dams.stat.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.stat.mapper.TaskStatMapper;
import com.ubizit.dams.stat.model.TaskStatVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("taskStatService")
public class TaskStatService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(TaskStatService.class);

	@Resource(name = "taskStatMapper")
	private TaskStatMapper taskStatMapper;

	public TaskStatVO getTotalSearch(TaskStatVO projStatVO) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.getTotalSearch >>>>>>");

		return taskStatMapper.getTotalSearch(projStatVO);
	}

	public void getTaskStatSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.getTaskStatSearchList >>>>>>");

		taskStatMapper.callGetTaskStatSearchList(map);
	}

	public void getTaskStatChart1(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.getTaskStatChart1 >>>>>>");

		taskStatMapper.callGetTaskStatChart1(map);
	}

	public void getTaskStatChart2(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.getTaskStatChart2 >>>>>>");

		taskStatMapper.callGetTaskStatChart2(map);
	}

	public List<Map<String, Object>> taskStatExcelDL(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> taskManagerService.taskStatExcelDL >>>>>>");

		return taskStatMapper.taskStatExcelDL(map);
	}

}
