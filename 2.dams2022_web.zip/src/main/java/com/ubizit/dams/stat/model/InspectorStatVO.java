package com.ubizit.dams.stat.model;

/**
 * @Description: 
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.06.01 - ajg - 최초생성
 * 
 * @since: 2022.06.01
 */
public class InspectorStatVO {

    private String projCd;
    private String userId;
    private String userNm;
    private String baseYmd;
    private Integer assnCnt;
    private Integer diagWorkCnt;
    private Integer inspWorkCnt;
    private String baseYm;
    private String weekBeg;
    private String weekEnd;
    private String weekYm;
    private String weekNo;
    
    private String projNmParam;
    
    @Override
    public String toString() {
    	return "InspectorStatVO [projCd=" + projCd + ", userId=" + userId + ", userNm=" + userNm + ", baseYmd="
    			+ baseYmd + ", assnCnt=" + assnCnt + ", diagWorkCnt=" + diagWorkCnt + ", inspWorkCnt=" + inspWorkCnt
    			+ ", baseYm=" + baseYm + ", weekBeg=" + weekBeg + ", weekEnd=" + weekEnd + ", weekYm=" + weekYm
    			+ ", weekNo=" + weekNo + "]";
    }

	public String getProjCd() {
		return projCd;
	}

	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public String getBaseYmd() {
		return baseYmd;
	}

	public void setBaseYmd(String baseYmd) {
		this.baseYmd = baseYmd;
	}

	public Integer getAssnCnt() {
		return assnCnt;
	}

	public void setAssnCnt(Integer assnCnt) {
		this.assnCnt = assnCnt;
	}

	public Integer getDiagWorkCnt() {
		return diagWorkCnt;
	}

	public void setDiagWorkCnt(Integer diagWorkCnt) {
		this.diagWorkCnt = diagWorkCnt;
	}

	public Integer getInspWorkCnt() {
		return inspWorkCnt;
	}

	public void setInspWorkCnt(Integer inspWorkCnt) {
		this.inspWorkCnt = inspWorkCnt;
	}

	public String getBaseYm() {
		return baseYm;
	}

	public void setBaseYm(String baseYm) {
		this.baseYm = baseYm;
	}

	public String getWeekBeg() {
		return weekBeg;
	}

	public void setWeekBeg(String weekBeg) {
		this.weekBeg = weekBeg;
	}

	public String getWeekEnd() {
		return weekEnd;
	}

	public void setWeekEnd(String weekEnd) {
		this.weekEnd = weekEnd;
	}

	public String getWeekYm() {
		return weekYm;
	}

	public void setWeekYm(String weekYm) {
		this.weekYm = weekYm;
	}

	public String getWeekNo() {
		return weekNo;
	}

	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}

	public String getProjNmParam() {
		return projNmParam;
	}

	public void setProjNmParam(String projNmParam) {
		this.projNmParam = projNmParam;
	}
	
}
