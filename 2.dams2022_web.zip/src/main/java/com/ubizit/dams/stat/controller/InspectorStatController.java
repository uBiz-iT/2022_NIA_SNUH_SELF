package com.ubizit.dams.stat.controller;


import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.stat.model.InspectorStatVO;
import com.ubizit.dams.stat.service.InspectorStatService;

@Controller
@RequestMapping(method = {RequestMethod.GET, RequestMethod.POST})
public class InspectorStatController {

	@Resource(name="inspectorStatService")
	private InspectorStatService inspectorStatService;
	
	private final static Logger logger = LogManager.getLogger(InspectorStatController.class);

	/**
	 * 기본 페이지
	 * @param model
	 * @param insStatVo
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/inspectorStat.do")
	public String getPage(Model model, @ModelAttribute InspectorStatVO insStatVo) throws Exception {
		logger.info(">>>>>> InspectorStatManagerController.getPage >>>>>>");
		
		if(StringUtil.isNotBlank(insStatVo.getUserId())) {
			model.addAttribute("userId" , insStatVo.getUserId());
		}
		if(StringUtil.isNotBlank(insStatVo.getUserNm())) {
			model.addAttribute("userNm" , insStatVo.getUserNm());
		}
		if(StringUtil.isNotBlank(insStatVo.getProjCd())) {
			model.addAttribute("projCd" , insStatVo.getProjCd());
		}
		if(StringUtil.isNotBlank(insStatVo.getProjNmParam())) {
			model.addAttribute("projNmParam" , insStatVo.getProjNmParam());
		}
		return "stat/inspectorStatList";
	}

	/**
	 * 테이블 데이터
	 * @param model
	 * @param request
	 * @param session
	 * @param insStatVo
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/stat/inspectorStat/getInspectorList.do")
	@ResponseBody
	public Map<String, Object> getInsStatList(@ModelAttribute InspectorStatVO insStatVo) throws Exception {
		logger.info(">>>>>> InspectorStatController.getInsStatList() >>>>>>");

		Map<String, Object> requestMap = new HashMap<String, Object>();
		
		if(StringUtil.isNotBlank(insStatVo.getProjNmParam())) {
			requestMap.put("PROJ_CD", insStatVo.getProjNmParam() );
		}else if(StringUtil.isNotBlank(insStatVo.getProjCd())) {
			requestMap.put("PROJ_CD", insStatVo.getProjCd() );
		}
		
		if(StringUtil.isNotBlank(insStatVo.getUserId())) {
			requestMap.put("USER_ID", insStatVo.getUserId() );
			System.out.println("userId A : " + requestMap.get("USER_ID"));
		}else {
			requestMap.put("USER_ID", "");
			System.out.println("userId B : " + requestMap.get("USER_ID"));
		}
		if(StringUtil.isNotBlank(insStatVo.getUserNm())) {
			requestMap.put("USER_NM", insStatVo.getUserNm() );
			System.out.println("userNm A : " + requestMap.get("USER_NM"));
		}else {
			requestMap.put("USER_NM", "" );
			System.out.println("userNm B : " + requestMap.get("USER_NM"));
		}
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("p_rcv_json", new Gson().toJson(requestMap));
		inspectorStatService.getInspectorStatUserList(procMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = new Gson().fromJson( (String) procMap.get("p_ret_json") , Map.class);
		
		resultMap.put("p_ret_msg", procMap.get("p_ret_msg"));
		resultMap.put("p_ret_code", procMap.get("p_ret_code"));
		resultMap.put("insStatList", resultMap.get("insStatList"));
		return resultMap;
	}
	
	/**
	 * 차트 1
	 * @param request
	 * @param statVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/inspectorStat/getChart1Data.do")
	@ResponseBody
	public Map<String, Object> inspectorStatChart1(HttpServletRequest request, InspectorStatVO statVo) throws Exception{
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = inspectorStatChart(request , statVo);
		return resultMap;
	}
	
	/**
	 * 차트 2
	 * @param request
	 * @param statVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/inspectorStat/getChart2Data.do")
	@ResponseBody
	public Map<String, Object> inspectorStatChart2(HttpServletRequest request, InspectorStatVO statVo) throws Exception{
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = inspectorStatChart(request , statVo);
		return resultMap;
	}
	
	private Map<String, Object> inspectorStatChart(HttpServletRequest request , InspectorStatVO statVo) throws Exception{
		logger.info(">>>>>> InspectorStatController.inspectorStatChart() >>>>>>");
		
		Map<String, Object> searchMap = new HashMap<String, Object>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Map<String, Object> p_ret_json = new HashMap<String, Object>();
		
		searchMap.put("PROJ_CD", statVo.getProjCd());
		searchMap.put("USER_ID", statVo.getUserId());
		
		resultMap.put("p_rcv_json", new Gson().toJson(searchMap));
		
		inspectorStatService.getInspectorStatChart(resultMap);

		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json.put("chartList" , new Gson().fromJson((String) resultMap.get("p_ret_json"), Map.class).get("chartList"));
		}else{
			p_ret_json = null;
		}
		
		resultMap.put("rows", p_ret_json.get("chartList"));
		return resultMap;
	}

	/**
	 * 엑셀 다운로드
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/excelInspectorList.do")
	@ResponseBody
	public Map<String, Object> inspectorExcelDL(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> InspectorStatController.inspectorExcelDL >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		String projCd = request.getParameter("projCd");
		String userId = request.getParameter("userId");
		String userNm = request.getParameter("userNm");
		
		resultMap.put("projCd", projCd);
		resultMap.put("userId", userId);
		resultMap.put("userNm", userNm);
		
		// 엑셀에 담을 데이터 조회
		List<Map<String,Object>> dbList = inspectorStatService.inspectorExcelDL(resultMap);

		if(dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('"+failMsg+"');</script>");
			out.flush();
			return null;
		}
				
		// 컬럼정보
		List<String> colList = new ArrayList<String>();
		// 12
		colList.add("진단 및 검수자 아이디");
		colList.add("진단 및 검수자 이름");
		colList.add("참여 태스크 수");
		colList.add("진단/검수 대상건 수");
		colList.add("진단 완료건 수");
		colList.add("검수 완료건 수");
		colList.add("진단/검수 완료건 수");
		colList.add("진단 검수 진행률");
		colList.add("검수 PASS 건수");
		colList.add("검수 FAIL 건수");
		colList.add("검수 PASS 율");
		colList.add("검수 FAIL 율");
		
		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		bodyList.add("USER_ID");
		bodyList.add("USER_NM");
		bodyList.add("TASK_CNT");
		bodyList.add("CASE_CNT");
		bodyList.add("DIAG_WORK_CNT");
		bodyList.add("INSP_WORK_CNT");
		bodyList.add("WORK_CNT");
		bodyList.add("INSP_RATE");
		bodyList.add("INSP_PASS_CNT");
		bodyList.add("INSP_FAIL_CNT");
		bodyList.add("INSP_PASS_RATE");
		bodyList.add("INSP_FAIL_RATE");
		
//		int[] type_int = {99, 99, 2, 3, 4, 5, 6, 99, 8, 9, 99, 99}; // ver 1.
		int[] type_int = {99, 99, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}; // ver 2.
		int[][] cellRangeAddress = null;
		
		String downFileName = "사용자 진행률_현황_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);
		
		int[] widths = new int[colNames.length];

		for(int i = 0; i < colNames.length; i++){
			if( i < 2 ) {
				widths[i] = 22;
			}else {
				widths[i] = 18;
			}
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);
		
		resultMap.put("result", "Y");
		return resultMap;
	}
}
