package com.ubizit.dams.stat.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.stat.service.InstitutionStatService;

@Controller
public class InstitutionStatController {

	@Resource(name="institutionStatService")
	private InstitutionStatService institutionStatService;
	
	private final static Logger logger = LogManager.getLogger(InstitutionStatController.class);
	
	/**
	 * 기본 페이지
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/institutionStat.do")
	public String getPage() throws Exception {
		logger.info(">>>>>> DataDiversityController.getPage >>>>>>");

		return "stat/institutionStatList";
	}

	/**
	 * 프로젝트 리스트
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/institutionStat/getProjectList.do")
	@ResponseBody
	public Map<String, Object> getProjectList(@RequestParam Map<String, Object> paramMap) throws Exception {
		logger.debug(">>>>>> InstitutionStatController.getProjectList >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();

		// Project List
		List<Map<String, Object>> projectList = institutionStatService.getProjectList(paramMap);
		resultMap.put("projectList", projectList);
		
		return resultMap;
	}
	
	/**
	 * 병원기관별 통계 리스트 (테이블 데이터)
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/institutionStat/getInstitutionStatList.do")
	@ResponseBody
	public Map<String, Object> getInstitutionStatList(@RequestParam Map<String, Object> paramMap) throws Exception {
		logger.info(">>>>>> InstitutionStatController.getInstitutionStatList >>>>>>");

		// 1. paramMap 그대로 프로시저 파라미터로 활용.
		String rcvJson = new Gson().toJson(paramMap);
		
		// 2. procMap: retJson에 결과 받아옴.
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		institutionStatService.getInstitutionStatList(procMap);
		
		@SuppressWarnings("unchecked")
		Map<String, Object> resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);

		return resultMap;
	}
	
	/**
	 * 엑셀 다운로드
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/institutionStat/excelInstitutionStatList.do")
	@ResponseBody
	public Map<String, Object> excelInstitutionStatList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> InstitutionStatController.excelInstitutionStatList >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();

		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");

		// parameter
		String projCd = request.getParameter("projCd");
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("projCd", projCd);
		String rcvJson = new Gson().toJson(paramMap);
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		institutionStatService.getInstitutionStatList(procMap);
		
		// procResultMap
		@SuppressWarnings("unchecked")
		Map<String, Object> procResultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> dbList = (List<Map<String, Object>>) procResultMap.get("rows");

		if (dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('" + failMsg + "');</script>");
			out.flush();
			return null;
		}

		// 컬럼정보
		List<String> colList = new ArrayList<String>();
		colList.add("기관");
		colList.add("전체 인원수");
		colList.add("전체 건수");
		colList.add("전체 건수/인");
		colList.add("검수 건수");
		colList.add("검수 Pass건수");
		colList.add("검수 Pass율(%)");
		colList.add("3건이상 인원수");
		colList.add("3건이상 건수");
		colList.add("3건이상 검수/인");
		colList.add("3건이상 Pass율(%)");
		colList.add("4건이상 인원수");
		colList.add("4건이상 건수");
		colList.add("4건이상 검수/인");
		colList.add("4건이상 Pass율(%)");
		colList.add("5건이상 인원수");
		colList.add("5건이상 건수");
		colList.add("5건이상 검수/인");
		colList.add("5건이상 Pass율(%)");

		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		bodyList.add("hospCd");
		bodyList.add("regPatientCnt");
		bodyList.add("regCnt");
		bodyList.add("cntPerPatient");
		bodyList.add("inspCnt");
		bodyList.add("passCnt");
		bodyList.add("passRatio");
		bodyList.add("above3PatientCnt");
		bodyList.add("above3Cnt");
		bodyList.add("above3CntPerPatient");
		bodyList.add("above3Ratio");
		bodyList.add("above4PatientCnt");
		bodyList.add("above4Cnt");
		bodyList.add("above4CntPerPatient");
		bodyList.add("above4Ratio");
		bodyList.add("above5PatientCnt");
		bodyList.add("above5Cnt");
		bodyList.add("above5CntPerPatient");
		bodyList.add("above5Ratio");
		
		int[] type_int = {99, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18};
		int[][] cellRangeAddress = null;

		String downFileName = "병원기관별_Pass현황_" + StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);

		int[] widths = new int[colNames.length];

		for (int i = 0; i < colNames.length; i++) {
			widths[i] = 25;
		}
		
		try {
			ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);
		} catch(Exception e) {
			e.printStackTrace();
		}

		resultMap.put("result", "Y");
		return resultMap;
	}
	
}
