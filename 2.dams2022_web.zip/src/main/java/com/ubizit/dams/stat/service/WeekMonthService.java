package com.ubizit.dams.stat.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.stat.mapper.WeekMonthMapper;
import com.ubizit.dams.stat.model.WeekMonthVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("weekMonthService")
public class WeekMonthService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(WeekMonthService.class);

	@Resource(name = "weekMonthMapper")
	private WeekMonthMapper weekMonthMapper;

	public List<WeekMonthVO> getProgressList(WeekMonthVO weekVo) throws Exception {
		LOGGER.info(">>>>>> weekMonthService.getProgressList >>>>>>");
		return weekMonthMapper.selectProgressList(weekVo);
	}

	public void getWeekChart(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> weekMonthService.getWeekChart >>>>>>");
		weekMonthMapper.callGetWeekChart(map);
	}

	public void getWeekAcmChart(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> weekMonthService.getWeekAcmChart >>>>>>");
		weekMonthMapper.callGetWeekAcmChart(map);
	}

	public List<Map<String, Object>> weekMonthExcelDL(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> weekMonthService.weekMonthExcelDL >>>>>>");
		return weekMonthMapper.weekMonthExcelDL(map);
	}
}
