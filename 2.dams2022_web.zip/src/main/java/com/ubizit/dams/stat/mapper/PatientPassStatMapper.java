package com.ubizit.dams.stat.mapper;

import java.util.List;
import java.util.Map;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("patientPassStatMapper")
public class PatientPassStatMapper extends EgovAbstractMapper {

	public List<Map<String, Object>> selectProjectList(Map<String, Object> map) throws Exception {
		return selectList("PATIENTPASSSTAT_MAPPER.selectProject", map);
	}

	public void callGetPatientPassList(Map<String, Object> map) throws Exception {
		selectList("PATIENTPASSSTAT_MAPPER.callGetPatientPassList", map);
	}
	
	public void callGetPatientPassRatioList(Map<String, Object> map) throws Exception {
		selectList("PATIENTPASSSTAT_MAPPER.callGetPatientPassRatioList", map);
	}

}
