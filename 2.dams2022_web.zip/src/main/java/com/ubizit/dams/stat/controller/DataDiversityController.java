package com.ubizit.dams.stat.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.stat.model.WeekMonthVO;
import com.ubizit.dams.stat.service.DataDiversityService;

@Controller
public class DataDiversityController {

	@Resource(name="dataDiversityService")
	private DataDiversityService dataDiversityService;
	
	private final static Logger logger = LogManager.getLogger(DataDiversityController.class);
	
	/**
	 * 기본 페이지
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/dataDiversity.do")
	public String getPage() throws Exception {
		logger.info(">>>>>> DataDiversityController.getPage >>>>>>");

		return "stat/dataDiversityList";
	}

	/**
	 * 프로젝트 리스트
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/dataDiversity/getProjectList.do")
	@ResponseBody
	public Map<String, Object> getProjectList(@RequestParam Map<String, Object> paramMap) throws Exception {
		logger.debug(">>>>>> DataDiversityController.getProjectList >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();

		// Project List
		List<Map<String, Object>> projectList = dataDiversityService.getProjectList(paramMap);
		resultMap.put("projectList", projectList);
		
		return resultMap;
	}
	
	/**
	 * 데이터 다양성 데이터 (테이블 데이터)
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */	@RequestMapping(value="/stat/dataDiversity/getDiversityDistributionData.do")
	@ResponseBody
	public Map<String, Object> getDiversityDistributionList(HttpServletRequest request, HttpSession session, @RequestParam Map<String, Object> paramMap) throws Exception {
		logger.info(">>>>>> DataDiversityController.getDiversityDistributionList >>>>>>");

		// 1. paramMap 그대로 프로시저 파라미터로 활용.
		String rcvJson = new Gson().toJson(paramMap);
		
		// 2. procMap: retJson에 결과 받아옴.
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		dataDiversityService.getDiversityDistributionData(procMap);
		
		@SuppressWarnings("unchecked")
		Map<String, Object> resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);

		return resultMap;
	}
	
	/**
	 * 엑셀 다운로드
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/dataDiversity/excelDiversityDistributionData.do")
	@ResponseBody
	public Map<String, Object> excelDiversityDistributionData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> DataDiversityController.excelDiversityDistributionData >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();

		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");

		// PARAM
		String projCd = request.getParameter("projCd");
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("projCd", projCd);
		String rcvJson = new Gson().toJson(paramMap);
		
		// 2. procMap: retJson에 결과 받아옴.
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		dataDiversityService.getDiversityDistributionData(procMap);
		
		@SuppressWarnings("unchecked")
		Map<String, Object> procResultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> dbList = (List<Map<String, Object>>) procResultMap.get("rows");

		if (dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('" + failMsg + "');</script>");
			out.flush();
			return null;
		}

		// 컬럼정보
		List<String> colList = new ArrayList<String>();
		if ("2022A1".equals(projCd)) {
			colList.add("라벨");
			colList.add("라벨값");
			colList.add("목표구성비(%)");
			colList.add("4건 이상 Pass 환자수");
			colList.add("4건 이상 Pass 건수");
			colList.add("4건 이상 Pass 환자구성비(%)");
			colList.add("4건 이상 Pass 건수구성비(%)");
		} else if ("2022B1".equals(projCd)) {
			colList.add("진단명");
			
			colList.add("전체 목표");
			colList.add("전체 등록");
			colList.add("전체 PASS");
			colList.add("전체 달성률(%)");
			
			colList.add("남성 목표");
			colList.add("남성 등록");
			colList.add("남성 PASS");
			colList.add("남성 달성률(%)");
			
			colList.add("여성 목표");
			colList.add("여성 등록");
			colList.add("여성 PASS");
			colList.add("여성 달성률(%)");
			
			colList.add("65세 이하 목표");
			colList.add("65세 이하 등록");
			colList.add("65세 이하 PASS");
			colList.add("65세 이하 달성률(%)");
			
			colList.add("65세 초과 목표");
			colList.add("65세 초과 등록");
			colList.add("65세 초과 PASS");
			colList.add("65세 초과 달성률(%)");
		}

		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		if ("2022A1".equals(projCd)) {
			bodyList.add("baseGrp");
			bodyList.add("subGrpNm");
			bodyList.add("plnRate");
			bodyList.add("patientCnt");
			bodyList.add("cnt");
			bodyList.add("patientRate");
			bodyList.add("rate");
		} else if ("2022B1".equals(projCd)) {
			bodyList.add("labelNm");
			
			bodyList.add("plnCnt");
			bodyList.add("regCnt");
			bodyList.add("passCnt");
			bodyList.add("passRate");
			
			bodyList.add("plnMaleCnt");
			bodyList.add("regMaleCnt");
			bodyList.add("passMaleCnt");
			bodyList.add("passMaleRate");
			
			bodyList.add("plnFemaleCnt");
			bodyList.add("regFemaleCnt");
			bodyList.add("passFemaleCnt");
			bodyList.add("passFemaleRate");
			
			bodyList.add("plnAge65BelowCnt");
			bodyList.add("regAge65BelowCnt");
			bodyList.add("passAge65BelowCnt");
			bodyList.add("passAge65BelowRate");
			
			bodyList.add("plnAge65ExceedCnt");
			bodyList.add("regAge65ExceedCnt");
			bodyList.add("passAge65ExceedCnt");
			bodyList.add("passAge65ExceedRate");
		}
		
		int[] type_int = null;
		if ("2022A1".equals(projCd)) {
//			type_int = new int[] { 99, 99, 99, 3, 99 }; // ver 1.
			type_int = new int[] { 99, 99, 2, 3, 4, 5, 6}; // ver 2.
		} else if ("2022B1".equals(projCd)) {
//			type_int = new int[] { 99, 1, 2, 3, 99, 5, 6, 7, 99, 9, 10, 11, 99, 13, 14, 15, 99, 17, 18, 19, 99 }; // ver 1.
			type_int = new int[] { 99, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 }; // ver 2.
		}
		int[][] cellRangeAddress = null;

		String downFileName = "데이터_다양성_분포_현황_" + StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);

		int[] widths = new int[colNames.length];

		for (int i = 0; i < colNames.length; i++) {
			widths[i] = 25;
		}
		
		try {
			ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);
		} catch(Exception e) {
			e.printStackTrace();
		}

		resultMap.put("result", "Y");
		return resultMap;
	}
	
}
