package com.ubizit.dams.stat.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.stat.model.WeekMonthVO;
import com.ubizit.dams.stat.service.WeekMonthService;

@Controller
public class WeekMonthController {

	@Resource(name="weekMonthService")
	private WeekMonthService weekMonthService;
	
	private final static Logger logger = LogManager.getLogger(WeekMonthController.class);
	
	/**
	 * 기본 페이지
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/weekMonth.do")
	public String getPage() throws Exception {
		logger.info(">>>>>> weekMonthController.getPage >>>>>>");

		return "stat/weekMonthList";
	}
	
	/**
	 * 테이블 데이터
	 * @param weekVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/weekMonth/getProgressList.do")
	@ResponseBody
	public Map<String, Object> getProgressList(@ModelAttribute WeekMonthVO weekVO) throws Exception {
		logger.info(">>>>>> WeekMonthController.getProgressList >>>>>>");
		
		List<WeekMonthVO> weekProgressList = weekMonthService.getProgressList(weekVO);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("rows", weekProgressList);
		return resultMap;
	}
	
	/**
	 * 주간 실적 차트
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/weekMonth/getWeekChartData.do")
	@ResponseBody
	public Map<String, Object> getWeekChart(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> WeekMonthController.getWeekChart >>>>>>");
		
		// PARAM
		String projCd = request.getParameter("projCd");
		String year = request.getParameter("year");
		String month = request.getParameter("month");
		
		// procMap
		Map<String, Object> searchMap = new HashMap<String, Object>();
		searchMap.put("projCd", projCd);
		searchMap.put("year", year);
		searchMap.put("month", month);
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("p_rcv_json", new Gson().toJson(searchMap));
		weekMonthService.getWeekChart(procMap);
		Object chartList = new Gson().fromJson((String) procMap.get("p_ret_json"), Map.class).get("chartList");
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("msg", procMap.get("p_ret_msg"));
		resultMap.put("code", procMap.get("p_ret_code"));
		resultMap.put("rows", chartList);
		return resultMap;
	}
	
	/**
	 * 주간 누적 실적 차트
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/weekMonth/getWeekAcmChartData.do")
	@ResponseBody
	public Map<String, Object> getWeekAcmChart(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> WeekMonthController.getWeekAcmChart >>>>>>");
		
		// PARAM
		String projCd = request.getParameter("projCd");
		String year = request.getParameter("year");
		String month = request.getParameter("month");

		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			// procMap
			Map<String, Object> searchMap = new HashMap<String, Object>();
			searchMap.put("projCd", projCd);
			searchMap.put("year", year);
			searchMap.put("month", month);
			Map<String, Object> procMap = new HashMap<String, Object>();
			procMap.put("p_rcv_json", new Gson().toJson(searchMap));
			weekMonthService.getWeekAcmChart(procMap);
			Object chartList = new Gson().fromJson((String) procMap.get("p_ret_json"), Map.class).get("chartList");
			
			resultMap.put("msg", procMap.get("p_ret_msg"));
			resultMap.put("code", procMap.get("p_ret_code"));
			resultMap.put("rows", chartList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resultMap;
	}

	// 엑셀 다운로드
	@RequestMapping(value="/stat/weekMonth/excelProgressList.do")
	@ResponseBody
	public Map<String, Object> weekMonthExcelDL(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> weekMonthController.weekMonthExcelDown >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();

		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");

		String projCd = request.getParameter("projCd");
		resultMap.put("projCd", projCd);

		// 엑셀에 담을 데이터 조회
		List<Map<String, Object>> dbList = weekMonthService.weekMonthExcelDL(resultMap);

		if (dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('" + failMsg + "');</script>");
			out.flush();
			return null;
		}

		// 컬럼정보
		List<String> colList = new ArrayList<String>();
		colList.add("기준 일자");
		colList.add("등록 수량");
		colList.add("검수자 할당 수량");
		colList.add("진단 완료 수량");
		colList.add("검수 완료 수량");
		colList.add("완료 수량");
		colList.add("검수 일치 수량");
		colList.add("일치 건 중 PASS 수량");

		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		bodyList.add("BASE_YMD");
		bodyList.add("REG_CNT");
		bodyList.add("ASSN_CNT");
		bodyList.add("DIAG_WORK_CNT");
		bodyList.add("INSP_WORK_CNT");
		bodyList.add("WORK_CNT");
		bodyList.add("SAME_CNT");
		bodyList.add("PASS_CNT");

		int[] type_int = {99, 1, 2, 3, 4, 5, 6, 7}; // ver 1.
		int[][] cellRangeAddress = null;

		String downFileName = "주간-월간_실적_현황_" + StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);

		int[] widths = new int[colNames.length];

		for (int i = 0; i < colNames.length; i++) {
			widths[i] = 25;
		}

		ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);

		resultMap.put("result", "Y");
		return resultMap;
	}
}
