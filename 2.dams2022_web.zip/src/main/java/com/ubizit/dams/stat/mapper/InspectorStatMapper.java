package com.ubizit.dams.stat.mapper;

import java.util.List;
import java.util.Map;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("inspectorStatMapper")
public class InspectorStatMapper extends EgovAbstractMapper {

	public void callGetInspectorStatUserList(Map<String, Object> map) throws Exception {
		selectList("INSPECTORSTAT_MAPPER.callGetInspectorStatUserList", map);
	}
	
	public void callGetInspectorStatChart(Map<String, Object> map) throws Exception {
		selectList("INSPECTORSTAT_MAPPER.callGetInspectorStatChart", map);
	}

	public List<Map<String, Object>> inspectorExcelDL(Map<String, Object> map) throws Exception {
		return selectList("INSPECTORSTAT_MAPPER.inspectorExcelDL", map);
	}
}
