package com.ubizit.dams.stat.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.stat.mapper.PatientPassStatMapper;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("patientPassStatService")
public class PatientPassStatService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(PatientPassStatService.class);
	
	@Resource(name="patientPassStatMapper")
	private PatientPassStatMapper patientPassStatMapper;

	public List<Map<String, Object>> getProjectList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> PatientPassStatService.getProjectList >>>>>>");
		return patientPassStatMapper.selectProjectList(map);
	}
	
	public void getPatientPassList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> PatientPassStatService.getPatientPassList >>>>>>");
		patientPassStatMapper.callGetPatientPassList(map);
	}

	public void getPatientPassRatioList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> PatientPassStatService.getPatientPassRatioList >>>>>>");
		patientPassStatMapper.callGetPatientPassRatioList(map);
	}

}
