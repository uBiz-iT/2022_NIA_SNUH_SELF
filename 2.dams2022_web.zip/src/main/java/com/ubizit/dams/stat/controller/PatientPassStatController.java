package com.ubizit.dams.stat.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.stat.service.PatientPassStatService;

@Controller
public class PatientPassStatController {

	@Resource(name="patientPassStatService")
	private PatientPassStatService patientPassStatService;
	
	private final static Logger logger = LogManager.getLogger(PatientPassStatController.class);
	
	/**
	 * 기본 페이지
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/patientPassStat.do")
	public String getPage() throws Exception {
		logger.info(">>>>>> DataDiversityController.getPage >>>>>>");

		return "stat/patientPassStatList";
	}

	/**
	 * 프로젝트 리스트
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/patientPassStat/getProjectList.do")
	@ResponseBody
	public Map<String, Object> getProjectList(@RequestParam Map<String, Object> paramMap) throws Exception {
		logger.debug(">>>>>> PatientPassStatController.getProjectList >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();

		// Project List
		List<Map<String, Object>> projectList = patientPassStatService.getProjectList(paramMap);
		resultMap.put("projectList", projectList);
		
		return resultMap;
	}

	/**
	 * 환자별 초과건수 리스트 (테이블 데이터)
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/stat/patientPassStat/getPatientPassList.do")
	@ResponseBody
	public Map<String, Object> getPatientPassList(@RequestParam Map<String, Object> reqParamMap) throws Exception {
		logger.info(">>>>>> PatientPassStatController.getPatientPassList >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		try {
			// reqParamMap 그대로 프로시저 파라미터로 활용.
			String rcvJson = new Gson().toJson(reqParamMap);
			
			// procMap
			Map<String, Object> procMap = new HashMap<String, Object>();
			procMap.put("rcvJson", rcvJson);
			patientPassStatService.getPatientPassList(procMap);
			
			// resultMap
			int retCode = (int) procMap.get("retCode");
			String retMsg = (String) procMap.get("retMsg");
			if (retCode == 0) {
				resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
			}
			resultMap.put("code", retCode);
			resultMap.put("msg", retMsg);
		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("code", -1);
			resultMap.put("msg", "시스템 에러");
		}
		return resultMap;
	}
	/**
	 * 환자별 초과건수 리스트 (테이블 데이터)
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/stat/patientPassStat/getPatientPassRatioList.do")
	@ResponseBody
	public Map<String, Object> getPatientPassRatioList(@RequestParam Map<String, Object> reqParamMap) throws Exception {
		logger.info(">>>>>> PatientPassStatController.getPassStatList >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		try {
			// reqParamMap 그대로 프로시저 파라미터로 활용.
			String rcvJson = new Gson().toJson(reqParamMap);
			
			// procMap
			Map<String, Object> procMap = new HashMap<String, Object>();
			procMap.put("rcvJson", rcvJson);
			patientPassStatService.getPatientPassRatioList(procMap);
			
			// resultMap
			int retCode = (int) procMap.get("retCode");
			String retMsg = (String) procMap.get("retMsg");
			if (retCode == 0) {
				resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
			}
			resultMap.put("code", retCode);
			resultMap.put("msg", retMsg);
		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("code", -1);
			resultMap.put("msg", "시스템 에러");
		}
		return resultMap;
	}
	
	/**
	 * 엑셀 다운로드
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/patientPassStat/excelPatientPassList.do")
	@ResponseBody
	public Map<String, Object> excelPatientPassList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> PatientPassStatController.excelPatientPassList >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();

		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");

		// parameter
		String projCd = request.getParameter("projCd");
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("projCd", projCd);
		String rcvJson = new Gson().toJson(paramMap);
		
		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", rcvJson);
		patientPassStatService.getPatientPassList(procMap);
		
		// procResultMap
		@SuppressWarnings("unchecked")
		Map<String, Object> procResultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> dbList = (List<Map<String, Object>>) procResultMap.get("rows");

		if (dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('" + failMsg + "');</script>");
			out.flush();
			return null;
		}

		// 컬럼정보
		List<String> colList = new ArrayList<String>();
		colList.add("환자 번호");
		colList.add("등록 건수");
		colList.add("Pass 건수");
		colList.add("Fail 건수");
		colList.add("미검수 건수");
		colList.add("Pass 건수 + 미검수 건수");
		colList.add("Pass건중 최소기준 미만 건수");
		colList.add("Pass건중 최대기준 초과 건수");
		colList.add("검수태스크 목록");
		colList.add("최소기준수량");
		colList.add("최대기준수량");
	
		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		bodyList.add("patientNo");
		bodyList.add("regCnt");
		bodyList.add("passCnt");
		bodyList.add("failCnt");
		bodyList.add("noInspCnt");
		bodyList.add("passAndNoInspCnt");
		bodyList.add("passMinUnderCnt");
		bodyList.add("passMaxExcessCnt");
		bodyList.add("taskList");
		bodyList.add("minV");
		bodyList.add("maxV");
		
		int[] type_int = {99, 1, 2, 3, 4, 5, 6, 7, 99, 9, 10};
		int[][] cellRangeAddress = null;

		String downFileName = "환자별_건수(초과미만)_현황_" + StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);

		int[] widths = new int[colNames.length];

		for (int i = 0; i < colNames.length; i++) {
			widths[i] = 25;
		}
		
		try {
			ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);
		} catch(Exception e) {
			e.printStackTrace();
		}

		resultMap.put("result", "Y");
		return resultMap;
	}
	
}
