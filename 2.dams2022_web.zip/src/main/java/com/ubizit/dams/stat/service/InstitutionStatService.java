package com.ubizit.dams.stat.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.stat.mapper.InstitutionStatMapper;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("institutionStatService")
public class InstitutionStatService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(InstitutionStatService.class);
	
	@Resource(name="institutionStatMapper")
	private InstitutionStatMapper institutionStatMapper;

	public List<Map<String, Object>> getProjectList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> InstitutionStatService.getProjectList >>>>>>");
		return institutionStatMapper.selectProjectList(map);
	}
	
	public void getInstitutionStatList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> InstitutionStatService.getInstitutionStatList >>>>>>");
		institutionStatMapper.callGetInstitutionStatList(map);
	}

}
