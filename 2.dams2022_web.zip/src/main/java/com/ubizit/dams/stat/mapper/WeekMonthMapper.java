package com.ubizit.dams.stat.mapper;

import java.util.List;
import java.util.Map;

import com.ubizit.dams.stat.model.WeekMonthVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("weekMonthMapper")
public class WeekMonthMapper extends EgovAbstractMapper {

	public List<WeekMonthVO> selectProgressList(WeekMonthVO weekVo) throws Exception {
		return selectList("WEEKMONTH_MAPPER.selectProgress", weekVo);
	}

	public void callGetWeekChart(Map<String, Object> map) throws Exception {
		selectList("WEEKMONTH_MAPPER.callGetWeekChart", map);
	}

	public void callGetWeekAcmChart(Map<String, Object> map) throws Exception {
		selectList("WEEKMONTH_MAPPER.callGetWeekAcmChart", map);
	}

	public List<Map<String, Object>> weekMonthExcelDL(Map<String, Object> map) throws Exception {
		return selectList("WEEKMONTH_MAPPER.weekMonthExcelDL", map);
	}
}
