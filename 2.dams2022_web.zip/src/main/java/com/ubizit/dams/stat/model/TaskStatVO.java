package com.ubizit.dams.stat.model;

/**
 * @Description: 
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.06.01 - ajg - 최초생성
 * 
 * @since: 2022.06.01
 */
public class TaskStatVO {

    private String projCd;
    
    private String taskCd;
    private String taskNm;
    private String regCnt;
    private String assnCnt;
    private String diagWorkCnt;
    private String inspWorkCnt;
    private String workCnt;
    private String sameCnt;
    private String passCnt;
    private String totalProgress;
    private String failCnt;
    private String preWorkCnt;
    
    private String userId;
    
 // 콤보박스 조회값 20220721
    private String projNmParam;
	
    private String completeYn;
    
    // 2022-07-25
    private String diagRate; // 진단율
    private String inspRate; // 검수율
    private String passInspRate; // pass건수/검수건수 비율
    private String passRate; // pass건수/등록건수 비율
    private String inspPlanCnt;
    private String diagCnt;
    private String inspCnt;
    private String progressChk;
    private String crossChk;
    
	@Override
	public String toString() {
		return "TaskStatVO [projCd=" + projCd + ", taskCd=" + taskCd + ", taskNm=" + taskNm + ", regCnt=" + regCnt
				+ ", assnCnt=" + assnCnt + ", diagWorkCnt=" + diagWorkCnt + ", inspWorkCnt=" + inspWorkCnt
				+ ", workCnt=" + workCnt + ", sameCnt=" + sameCnt + ", passCnt=" + passCnt + ", totalProgress="
				+ totalProgress + ", failCnt=" + failCnt + ", preWorkCnt=" + preWorkCnt + ", userId=" + userId
				+ ", projNmParam=" + projNmParam + ", completeYn=" + completeYn + ", diagRate=" + diagRate
				+ ", inspRate=" + inspRate + ", passInspRate=" + passInspRate + ", passRate=" + passRate
				+ ", inspPlanCnt=" + inspPlanCnt + ", diagCnt=" + diagCnt + ", inspCnt=" + inspCnt + ", progressChk="
				+ progressChk + ", crossChk=" + crossChk + "]";
	}

	public String getProjCd() {
		return projCd;
	}

	public String getTaskCd() {
		return taskCd;
	}

	public void setTaskCd(String taskCd) {
		this.taskCd = taskCd;
	}

	public String getTaskNm() {
		return taskNm;
	}

	public void setTaskNm(String taskNm) {
		this.taskNm = taskNm;
	}

	public String getRegCnt() {
		return regCnt;
	}

	public void setRegCnt(String regCnt) {
		this.regCnt = regCnt;
	}

	public String getAssnCnt() {
		return assnCnt;
	}

	public void setAssnCnt(String assnCnt) {
		this.assnCnt = assnCnt;
	}

	public String getDiagWorkCnt() {
		return diagWorkCnt;
	}

	public void setDiagWorkCnt(String diagWorkCnt) {
		this.diagWorkCnt = diagWorkCnt;
	}

	public String getInspWorkCnt() {
		return inspWorkCnt;
	}

	public void setInspWorkCnt(String inspWorkCnt) {
		this.inspWorkCnt = inspWorkCnt;
	}

	public String getWorkCnt() {
		return workCnt;
	}

	public void setWorkCnt(String workCnt) {
		this.workCnt = workCnt;
	}

	public String getSameCnt() {
		return sameCnt;
	}

	public void setSameCnt(String sameCnt) {
		this.sameCnt = sameCnt;
	}

	public String getPassCnt() {
		return passCnt;
	}

	public void setPassCnt(String passCnt) {
		this.passCnt = passCnt;
	}

	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTotalProgress() {
		return totalProgress;
	}

	public void setTotalProgress(String totalProgress) {
		this.totalProgress = totalProgress;
	}

	public String getFailCnt() {
		return failCnt;
	}

	public void setFailCnt(String failCnt) {
		this.failCnt = failCnt;
	}
	public String getProjNmParam() {
		return projNmParam;
	}

	public void setProjNmParam(String projNmParam) {
		this.projNmParam = projNmParam;
	}

	public String getCompleteYn() {
		return completeYn;
	}

	public void setCompleteYn(String completeYn) {
		this.completeYn = completeYn;
	}

	public String getPreWorkCnt() {
		return preWorkCnt;
	}

	public void setPreWorkCnt(String preWorkCnt) {
		this.preWorkCnt = preWorkCnt;
	}

	public String getDiagRate() {
		return diagRate;
	}

	public void setDiagRate(String diagRate) {
		this.diagRate = diagRate;
	}

	public String getInspRate() {
		return inspRate;
	}

	public void setInspRate(String inspRate) {
		this.inspRate = inspRate;
	}

	public String getPassInspRate() {
		return passInspRate;
	}

	public void setPassInspRate(String passInspRate) {
		this.passInspRate = passInspRate;
	}

	public String getPassRate() {
		return passRate;
	}

	public void setPassRate(String passRate) {
		this.passRate = passRate;
	}

	public String getInspPlanCnt() {
		return inspPlanCnt;
	}

	public void setInspPlanCnt(String inspPlanCnt) {
		this.inspPlanCnt = inspPlanCnt;
	}

	public String getDiagCnt() {
		return diagCnt;
	}

	public void setDiagCnt(String diagCnt) {
		this.diagCnt = diagCnt;
	}

	public String getInspCnt() {
		return inspCnt;
	}

	public void setInspCnt(String inspCnt) {
		this.inspCnt = inspCnt;
	}

	public String getProgressChk() {
		return progressChk;
	}

	public void setProgressChk(String progressChk) {
		this.progressChk = progressChk;
	}

	public String getCrossChk() {
		return crossChk;
	}

	public void setCrossChk(String crossChk) {
		this.crossChk = crossChk;
	}

}
