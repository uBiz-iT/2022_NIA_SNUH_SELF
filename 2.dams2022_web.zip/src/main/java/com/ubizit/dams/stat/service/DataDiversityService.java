package com.ubizit.dams.stat.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.stat.mapper.DataDiversityMapper;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("dataDiversityService")
public class DataDiversityService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(DataDiversityService.class);
	
	@Resource(name="dataDiversityMapper")
	private DataDiversityMapper dataDiversityMapper;

	public List<Map<String, Object>> getProjectList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> DataDiversityService.getProjectList >>>>>>");
		return dataDiversityMapper.selectProjectList(map);
	}
	
	public void getDiversityDistributionData(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> DataDiversityService.getDiversityDistributionData >>>>>>");
		dataDiversityMapper.callGetDiversityDistributionData(map);
	}

}
