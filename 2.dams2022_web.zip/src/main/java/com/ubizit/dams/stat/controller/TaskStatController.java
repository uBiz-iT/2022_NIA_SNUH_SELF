package com.ubizit.dams.stat.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ubizit.dams.common.utils.ExcelUtil;
import com.ubizit.dams.common.utils.StringUtil;
import com.ubizit.dams.stat.model.TaskStatVO;
import com.ubizit.dams.stat.service.TaskStatService;

@Controller
public class TaskStatController {

	@Resource(name="taskStatService")
	private TaskStatService taskStatService;
	
	private final static Logger logger = LogManager.getLogger(TaskStatController.class);
	
	/**
	 * 기본 페이지
	 * @param model
	 * @param taskStatVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/taskStat.do")
	public String getPage(Model model, @ModelAttribute TaskStatVO taskStatVO) throws Exception {
		logger.info(">>>>>> taskStatController.getPage >>>>>>");
		
//		if(StringUtil.isNotBlank(taskStatVO.getProjCd())) {
//			model.addAttribute("projCd" , taskStatVO.getProjCd());
//		}
//		if(StringUtil.isNotBlank(taskStatVO.getTaskCd())) {
//			model.addAttribute("taskCd" , taskStatVO.getTaskCd());
//		}
//		if(StringUtil.isNotBlank(taskStatVO.getCompleteYn())) {
//			model.addAttribute("completeYn" , taskStatVO.getCompleteYn());
//		}
//		if(StringUtil.isNotBlank(taskStatVO.getProjNmParam())) {
//			model.addAttribute("projNmParam" , taskStatVO.getProjNmParam());
//		}
		
		return "stat/taskStatList";
	}

	/**
	 * 테이블 사이에 있는 통계.
	 * @param taskStatVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/taskStat/getTotalStat.do")
	@ResponseBody	
	public Map<String, Object> getTotalSearch(@ModelAttribute TaskStatVO taskStatVo) throws Exception {
		logger.info(">>>>>> taskStatController.getTotalSearch >>>>>>");
		
		TaskStatVO taskTotal = taskStatService.getTotalSearch(taskStatVo);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("rows", taskTotal);
		return resultMap;
	}
	
	/**
	 * 태스크 리스트 (테이블 데이터)
	 * @param taskStatVO
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/stat/taskStat/getTaskList.do")
	@ResponseBody
	public Map<String, Object> getTaskStatSearchList(@ModelAttribute TaskStatVO taskStatVO) throws Exception {
		logger.info(">>>>>> taskStatController.getTaskStatList >>>>>>");

		// paramMap
		Map<String, Object> paramMap = new HashMap<String, Object>();
		if (StringUtil.isNotBlank(taskStatVO.getProjNmParam())) {
			paramMap.put("projCd", taskStatVO.getProjNmParam());
		} else if (StringUtil.isNotBlank(taskStatVO.getProjCd())) {
			paramMap.put("projCd", taskStatVO.getProjCd());
		} else {
			paramMap.put("projCd", "");
		}

		if (StringUtil.isNotBlank(taskStatVO.getTaskCd())) {
			paramMap.put("taskCd", taskStatVO.getTaskCd());
		} else {
			paramMap.put("taskCd", "");
		}

		if (StringUtil.isNotBlank(taskStatVO.getCompleteYn())) {
			paramMap.put("completeYn", taskStatVO.getCompleteYn());
		} else {
			paramMap.put("completeYn", "");
		}

		// procMap
		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("rcvJson", new Gson().toJson(paramMap));
		taskStatService.getTaskStatSearchList(procMap);
		
		// resultMap
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = new Gson().fromJson((String) procMap.get("retJson"), Map.class);
		resultMap.put("code", procMap.get("retCode"));
		resultMap.put("msg", procMap.get("retMsg"));
		resultMap.put("rows", resultMap.get("taskStatList"));
		return resultMap;
	}
	
	/**
	 * 차트 1
	 * @param statVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/stat/taskStat/getChart1Data.do")
	@ResponseBody
	public Map<String, Object> taskStatChart1(@ModelAttribute TaskStatVO statVo) throws Exception {
		logger.info(">>>>>> taskStatController.taskStatChart1 >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();

		Map<String, Object> procMap = new HashMap<String, Object>();
		Map<String, Object> p_ret_json = new HashMap<String, Object>();

		procMap.put("PROJ_CD", statVo.getProjCd());
		procMap.put("TASK_CD", statVo.getTaskCd());

		resultMap.put("p_rcv_json", new Gson().toJson(procMap));

		taskStatService.getTaskStatChart1(resultMap);

		if ((int) resultMap.get("p_ret_code") == 0) {
			p_ret_json.put("chartList" , new Gson().fromJson((String) resultMap.get("p_ret_json"), Map.class).get("chartList"));
		} else {
			p_ret_json = null;
		}

		resultMap.put("rows", p_ret_json.get("chartList"));
		return resultMap;
	}

	/**
	 * 차트 2
	 * @param statVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/stat/taskStat/getChart2Data.do")
	@ResponseBody
	public Map<String, Object> taskStatChart2(@ModelAttribute TaskStatVO statVo) throws Exception {
		logger.info(">>>>>> taskStatController.taskStatChart2 >>>>>>");
		Map<String, Object> resultMap = new HashMap<String, Object>();

		Map<String, Object> p_ret_json = new HashMap<String, Object>();

		Map<String, Object> procMap = new HashMap<String, Object>();
		procMap.put("PROJ_CD", statVo.getProjCd());
		procMap.put("TASK_CD", statVo.getTaskCd());

		resultMap.put("p_rcv_json", new Gson().toJson(procMap));

		taskStatService.getTaskStatChart2(resultMap);

		if ((int) resultMap.get("p_ret_code") == 0) {
			p_ret_json.put("chartList" , new Gson().fromJson((String) resultMap.get("p_ret_json"), Map.class).get("chartList"));
		} else {
			p_ret_json = null;
		}
		
		resultMap.put("rows", p_ret_json.get("chartList"));
		return resultMap;
	}

	/**
	 * 엑셀 다운로드
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/stat/taskStat/excelTaskList.do")
	@ResponseBody
	public Map<String, Object> taskStatExcelDL(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> taskStatController.taskStatExcelDL >>>>>>");
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");

		String projCd = request.getParameter("projCd");
		String taskCd = request.getParameter("taskCd");
		String completeYn = request.getParameter("completeYn");
		
		resultMap.put("projCd", projCd);
		resultMap.put("taskCd", taskCd);
		resultMap.put("completeYn", completeYn);

		// 엑셀에 담을 데이터 조회
		List<Map<String, Object>> dbList = taskStatService.taskStatExcelDL(resultMap);

		if (dbList.size() < 1) {
			String failMsg = "해당하는 건이 없습니다.";
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('" + failMsg + "');</script>");
			out.flush();
			return null;
		}

		// 컬럼정보
		List<String> colList = new ArrayList<String>();
		colList.add("태스크 코드");
		colList.add("태스크 명");
		colList.add("검수 인원");
		colList.add("등록 건수");
		colList.add("진단 건수");
		colList.add("진단율(%)");
		colList.add("검수 건수");
		colList.add("PASS 건수");
		colList.add("FAIL 건수");
		colList.add("검수율(%)");
		colList.add("PASS/검수 비율(%)");
		colList.add("PASS/등록 비율(%)");

		// 조회데이터
		List<String> bodyList = new ArrayList<String>();
		bodyList.add("TASK_CD");
		bodyList.add("TASK_NM");
		bodyList.add("INSP_PLAN_CNT");
		bodyList.add("REG_CNT");
		bodyList.add("DIAG_CNT");
		bodyList.add("DIAG_RATE");
		bodyList.add("INSP_CNT");
		bodyList.add("PASS_CNT");
		bodyList.add("FAIL_CNT");
		bodyList.add("INSP_RATE");
		bodyList.add("PASS_INSP_RATE");
		bodyList.add("PASS_RATE");

//		int[] type_int = {99, 99, 2, 3, 4, 99, 6, 7, 8, 99, 99, 99}; // ver 1.
		int[] type_int = {99, 99, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}; // ver 2.
		int[][] cellRangeAddress = null;

		String downFileName = "태스크 진행_현황_" + StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] colNames = colList.toArray(new String[colList.size()]);
		String[] bodyNames = bodyList.toArray(new String[bodyList.size()]);

		int[] widths = new int[colNames.length];

		for (int i = 0; i < colNames.length; i++) {
			widths[i] = 25;
		}

		ExcelUtil.excelDownload(response, cellRangeAddress, colNames, bodyNames, widths, type_int, downFileName, dbList);

		resultMap.put("result", "Y");
		return resultMap;
	}
}
