package com.ubizit.dams.stat.mapper;

import java.util.List;
import java.util.Map;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("dataDiversityMapper")
public class DataDiversityMapper extends EgovAbstractMapper {
	
	public List<Map<String, Object>> selectProjectList(Map<String, Object> map) throws Exception {	
		return selectList("DATADIVERSITY_MAPPER.selectProject", map);
	}
	
	public void callGetDiversityDistributionData(Map<String, Object> map) throws Exception {
		selectList("DATADIVERSITY_MAPPER.callGetDiversityDistributionData", map);
	}
	
}
