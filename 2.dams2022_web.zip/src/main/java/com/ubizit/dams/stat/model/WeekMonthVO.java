package com.ubizit.dams.stat.model;

/**
 * @Description: 
 * @Modification: 수정일 - 수정자 - 수정내용
 * 2022.06.01 - ajg - 최초생성
 * 
 * @since: 2022.06.01
 */
public class WeekMonthVO {

    private String projCd;
    
    private String baseYmd;
    private String regCnt;
    private String assnCnt;
    private String diagWorkCnt;
    private String inspWorkCnt;
    private String workCnt;
    private String sameCnt;
    private String passCnt;
    private String baseYm;
    private String weekBeg;
    private String weekEnd;
    private String weekYm;
    private String weekNo;
    
	public String getProjCd() {
		return projCd;
	}

	public void setProjCd(String projCd) {
		this.projCd = projCd;
	}

	public String getBaseYmd() {
		return baseYmd;
	}

	public void setBaseYmd(String baseYmd) {
		this.baseYmd = baseYmd;
	}

	public String getRegCnt() {
		return regCnt;
	}

	public void setRegCnt(String regCnt) {
		this.regCnt = regCnt;
	}

	public String getAssnCnt() {
		return assnCnt;
	}

	public void setAssnCnt(String assnCnt) {
		this.assnCnt = assnCnt;
	}

	public String getDiagWorkCnt() {
		return diagWorkCnt;
	}

	public void setDiagWorkCnt(String diagWorkCnt) {
		this.diagWorkCnt = diagWorkCnt;
	}

	public String getInspWorkCnt() {
		return inspWorkCnt;
	}

	public void setInspWorkCnt(String inspWorkCnt) {
		this.inspWorkCnt = inspWorkCnt;
	}

	public String getWorkCnt() {
		return workCnt;
	}

	public void setWorkCnt(String workCnt) {
		this.workCnt = workCnt;
	}

	public String getSameCnt() {
		return sameCnt;
	}

	public void setSameCnt(String sameCnt) {
		this.sameCnt = sameCnt;
	}

	public String getPassCnt() {
		return passCnt;
	}

	public void setPassCnt(String passCnt) {
		this.passCnt = passCnt;
	}

	public String getBaseYm() {
		return baseYm;
	}

	public void setBaseYm(String baseYm) {
		this.baseYm = baseYm;
	}

	public String getWeekBeg() {
		return weekBeg;
	}

	public void setWeekBeg(String weekBeg) {
		this.weekBeg = weekBeg;
	}

	public String getWeekEnd() {
		return weekEnd;
	}

	public void setWeekEnd(String weekEnd) {
		this.weekEnd = weekEnd;
	}

	public String getWeekYm() {
		return weekYm;
	}

	public void setWeekYm(String weekYm) {
		this.weekYm = weekYm;
	}

	public String getWeekNo() {
		return weekNo;
	}

	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}
    
}
