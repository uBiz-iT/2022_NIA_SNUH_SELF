package com.ubizit.dams.stat.mapper;

import java.util.List;
import java.util.Map;

import com.ubizit.dams.stat.model.TaskStatVO;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("taskStatMapper")
public class TaskStatMapper extends EgovAbstractMapper {

	public TaskStatVO getTotalSearch(TaskStatVO taskStat) throws Exception {
		return selectOne("TASKSTAT_MAPPER.selectTaskTotal", taskStat);
	}

	public void callGetTaskStatSearchList(Map<String, Object> map) throws Exception {
		selectList("TASKSTAT_MAPPER.callGetTaskStatList", map);
	}

	public void callGetTaskStatChart1(Map<String, Object> map) throws Exception {
		selectList("TASKSTAT_MAPPER.callGetTaskChart1", map);
	}

	public void callGetTaskStatChart2(Map<String, Object> map) throws Exception {
		selectList("TASKSTAT_MAPPER.callGetTaskChart2", map);
	}

	public List<Map<String, Object>> taskStatExcelDL(Map<String, Object> map) throws Exception {
		return selectList("TASKSTAT_MAPPER.taskStatExcelDL", map);
	}
}
