package com.ubizit.dams.stat.mapper;

import java.util.List;
import java.util.Map;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("institutionStatMapper")
public class InstitutionStatMapper extends EgovAbstractMapper {

	public List<Map<String, Object>> selectProjectList(Map<String, Object> map) throws Exception {
		return selectList("INSTITUTIONSTAT_MAPPER.selectProject", map);
	}

	public void callGetInstitutionStatList(Map<String, Object> map) throws Exception {
		selectList("INSTITUTIONSTAT_MAPPER.callGetInstitutionStatList", map);
	}

}
