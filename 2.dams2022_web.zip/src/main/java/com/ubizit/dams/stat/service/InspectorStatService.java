package com.ubizit.dams.stat.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.dams.stat.mapper.InspectorStatMapper;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("inspectorStatService")
public class InspectorStatService extends EgovAbstractServiceImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(InspectorStatService.class);
	
	@Resource(name="inspectorStatMapper")
	private InspectorStatMapper inspectorStatMapper;
	
	public void getInspectorStatUserList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> inspectorStatService.getInsStatList >>>>>>");

		inspectorStatMapper.callGetInspectorStatUserList(map);
	}
	
	public void getInspectorStatChart(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> inspectorStatService.inspectorStatChart >>>>>>");
		
		inspectorStatMapper.callGetInspectorStatChart(map);
	}

	public List<Map<String, Object>> inspectorExcelDL(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> inspectorStatService.inspectorExcelDL >>>>>>");
		
		return inspectorStatMapper.inspectorExcelDL(map);
	}

}
