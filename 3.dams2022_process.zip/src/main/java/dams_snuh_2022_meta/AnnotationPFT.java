package dams_snuh_2022_meta;

public class AnnotationPFT {
    public String caseNumber = "";
    public String caseGroupId = "";  // 환자 1명에 여러 케이스인 경우 비식별 환자 id같은 값을 저장
    public String DiagName = "";     // B11100001, 진단명, PLT_CASE_DATA_ITEM
    public String gender = "";       // B11100010, 성별
    public String age = "";          // B11100020, 나이
    public String bmi = "";          // B11100025, BMI
    public String smoke = "";        // B11100030, 흡연
    public String weight = "";       // B11100040, 키
    public String height = "";       // B11100050, 체중
    public String Addr = "";         // B11100060, 거주지
    public String testDate = "";     // B11100110, 검사일자
    public String testTime = "";     // B11100120, 검사시각
    public String py = "";           // pack year
    
    public String fvc = "";          // B12100010, FVC(l)
    public String fvcRate = "";      // B12100015, FVC(%)
    public String fev1 = "";         // B12100020, FEV1(l)
    public String fev1Rate = "";     // B12100025, FEV1(%)
    public String fev1DevidedFvc = "";// B12100030, FEV1/FVC
    public String pef = "";          // B12100040, PEF
    public String fef2575 = "";      // B12100050, FEF 25-75
    public String pftfile = "";      // B12200010, 폐기능 검사 파일
    
    public String pm25 = "";         // B14100020, 초미세먼지(PM2.5) (㎍/㎥, 24h)
    public String no2 = "";          // B14100030, 이산화질소(ppm)
    public String o3 = "";           // B14100040, 오존(ppm)
    public String pm10 = "";         // B14100060, 미세먼지(PM10) (㎍/㎥, 24h)
    public String co = "";           // B14100070, 일산화탄소(ppm)
    public String so2 = "";          // B14100080, 아황산가스(ppm)

}


