package dams_snuh_2022_meta;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.SystemUtils;

import com.sun.org.apache.xpath.internal.operations.Bool;

//-----------------------------------------------------------------------------------------------------------------
// 수면 데이터의 경우 여러 폴더로 분리되어 있는 파일들을
// 케이스 ID 기준으로 병합하는 프로그램
//-----------------------------------------------------------------------------------------------------------------
public class CreateSetData {

    static String projectCode = "";
    static String taskCode = "";
    static String dataDir = "";
    static boolean labelingUpdate = false;;
    
    // 오라클 연결 및 SQL문 실행
    static db_oracle db = null;      

    static int complete_cnt = 0;
    
    static String dataRootDir = "";
    
    // 세트 데이터 Root 경로
    static String targetRootDir = "";

    static String configFileName = "";
    static String db_user = "";
    static String db_passwd = "";
    static String db_connString = "";
    static SQLResult sqlResult = new SQLResult();
    
    // 화면에 dot(.)을 출력하기 위하여
    static boolean isPrintDot = false;
    static Timer printDotTimer = new Timer();
    static TimerTask printDotTimerTask = new TimerTask() {
        @Override
        public void run() {
            if (isPrintDot) {
                System.out.print(".");
            }
        }
    };
    
    static Number nullCheckNum = 0;
    static String todayYYYYMMDD = "";
    
    static String jsonDir = "";
    static String jsonCompleteDir = "";
    static String soundDir = "";
    static String imageDir = "";
    static String edfDir = "";
    static int maxCaseCnt = 50; // 한번 작업시 최대 생성할 케이스 개수. default 50
    
    public static void main(String[] args) 
    {

        if (args.length <= 1) {
            System.out.println("병원 코드와 케이스 최대 수량을 입력해 주세요.");
            printDotTimer.cancel();
            return;
        }
        
        // 1번째(배열 0) 인자가 설정 파일 이름
        // 2번째(배열 1) 병원디렉토리 코드
        // 3번째(배열 2) case max 수량 설정 값
        try {
        	configFileName = args[0];        
        	maxCaseCnt = Integer.parseInt(args[1]);
        }
        catch (Exception e)
        {
            System.out.println(" main() args process exception");
            e.printStackTrace();
        	printDotTimer.cancel();
        	return;
        }
        
        // configuration 파일 read 
        if (!ReadProperties()) {
        	printDotTimer.cancel();
        	return;
        }
        
        // DB connection 
        if (!ConnectDB()) {
        	printDotTimer.cancel();
        	return;
        }
        
        // 오래 걸리는 작업의 경우 화면에 dot(.)를 출력하기 위함 
        printDotTimer.schedule(printDotTimerTask, 1000, 1000);

        try
        {
            // auto commit false 
            db.conn.setAutoCommit(false);
            
            System.out.println("--------------------------------------------------------------------");
        	System.out.println(" Data root              directory : " + dataRootDir);
            System.out.println("      json              directory : " + jsonDir);
            System.out.println("      edf               directory : " + edfDir);
            System.out.println("      json complete     directory : " + jsonCompleteDir);
            System.out.println("      spectrogram image directory : " + imageDir);
            System.out.println("      sound             directory : " + soundDir);
            System.out.println("      max case count              : " + maxCaseCnt);
            System.out.println("--------------------------------------------------------------------");

        	Path rootPath = Paths.get(dataRootDir);

        	File jsonRootPath = new File(dataRootDir, jsonDir);
        	
            // -------------------------------------------------------------------------------
            // 확장자가 JSON인 것만 추출
            // -------------------------------------------------------------------------------
            File[] jsonRootFileList = jsonRootPath.listFiles();
            
            Arrays.sort(jsonRootFileList);
            
            // 날짜시간으로 디렉토리 만들기 위함
            String targetDir = todayYYYYMMDDHHMMSS();
            
            // Target 디렉토리 설정
            Path targetDirPath = Paths.get(targetRootDir, targetDir);
            String targetDirPathString = targetDirPath.toString().replace("\\", "/");
            File targetDirFile = new File(targetDirPathString);
            
            // Target 디렉토리 생성
            targetDirFile.mkdirs();
            allowPermission(targetDirFile.toString());
            
            System.out.printf(" Target Dir : %s\n", targetDirPath.toString());
            System.out.println("--------------------------------------------------------------------");

            notfoundlog("-----------------------------------------------------\n", false);
            notfoundlog(" " + LocalDateTime.now().toString() + "\n", false);
            notfoundlog("-----------------------------------------------------\n", false);
            
        	for(File jsonHospitalDir : jsonRootFileList)
            {   
        		
                // -------------------------------------------------------------------------------
                // JSON 루트 밑에 병원코드가 디렉토리로 있음. 이것만 추출. 디렉토리가 아니면 continue
                // -------------------------------------------------------------------------------
                if(!jsonHospitalDir.isDirectory())
                {
                    continue;
                }
                
                String hospitalCode = jsonHospitalDir.getName();

            	Path jsonCompletePath = Paths.get(dataRootDir, jsonCompleteDir, hospitalCode);
            	Path soundPath = Paths.get(dataRootDir, soundDir, hospitalCode);
            	Path imagePath = Paths.get(dataRootDir, imageDir, hospitalCode);
            	Path edfPath = Paths.get(dataRootDir, edfDir, hospitalCode);

                System.out.println(" Hospital Code : " + hospitalCode);
                System.out.println("\t edf               directory : " + edfPath);
                System.out.println("\t json              directory : " + jsonHospitalDir.getPath());
                System.out.println("\t json complete     directory : " + jsonCompletePath);
                System.out.println("\t spectrogram image directory : " + imagePath);
                System.out.println("\t sound             directory : " + soundPath);

                // -------------------------------------------------------------------------------
                // 확장자가 JSON인 것만 추출
                // -------------------------------------------------------------------------------
                File[] jsonHospitalDirFileList = jsonHospitalDir.listFiles(new FilenameFilter() {
                    public boolean accept(File dir, String name) {
                        return name.toLowerCase().endsWith(".json");
                    }
                });
                
                Arrays.sort(jsonHospitalDirFileList);

                // Target hospital 디렉토리 설정
                Path targetHospitalDirPath = Paths.get(targetDirPath.toString(), hospitalCode);
                String targetHospitalDirPathString = targetHospitalDirPath.toString().replace("\\", "/");
                File targetHospitalDirFile = new File(targetHospitalDirPathString);
                
                // Target 디렉토리 생성
                targetHospitalDirFile.mkdirs();
                allowPermission(targetHospitalDirFile.toString());
                
                System.out.printf("\t Target Hospital   directory : %s\n", targetHospitalDirPath.toString());
                System.out.println();

                // -------------------------------------------------------------------------------
                // JSON 파일 하나씩 검색
                // -------------------------------------------------------------------------------
                int hispitalCaseCount = 0;
                
                for(File jsonFile : jsonHospitalDirFileList)
                {   
                    // 디렉토리이면 건너뜀.
                    if(jsonFile.isDirectory())
                    {
                        continue;
                    }
                    
                    String caseNo = getOnlyFileName(jsonFile);
                    
                    System.out.println("\t\t--------------------------------------------------------------------");
                    System.out.printf("\t\t %s\n", caseNo);
                    System.out.println("\t\t--------------------------------------------------------------------");
                    
                    // 타겟 디렉토리에 케이스 디렉토리 생성
                    Path caseDirPath = Paths.get(targetHospitalDirFile.toString(), caseNo);
                    String caseDirPathString = caseDirPath.toString().replace("\\", "/");
                    File caseDirFile = new File(caseDirPathString);
                    caseDirFile.mkdirs();
                    allowPermission(caseDirFile.toString());
                    
                    // -------------------------------------------------------------------------------
                    // JSON 파일 복사
                    // -------------------------------------------------------------------------------
                    File newJsonFile = new File(Paths.get(caseDirFile.toString(), jsonFile.getName()).toString().replace("\\", "/"));
                    
                    System.out.printf("\t\t json file name  (org) : %s\n", jsonFile);
                    System.out.printf("\t\t                 (new) : %s\n", newJsonFile);

                    try {
                        FileUtils.copyFile(jsonFile, newJsonFile);
                        allowPermission(newJsonFile.toString());
                    }
                    catch (FileNotFoundException  e) {
                    	notfoundlog(String.format("\t Error                 : Json File not found.(%s)\n", jsonFile.getName()), true);
                        FileUtils.forceDelete(caseDirFile);
                        continue;
					}
                    catch (Exception e) {
                        e.printStackTrace();
                        FileUtils.forceDelete(caseDirFile);
                        continue;
					}

                    // -------------------------------------------------------------------------------
                    // EDF 파일 복사(확장자는 edf)
                    // -------------------------------------------------------------------------------
                    File edfFile = new File(Paths.get(edfPath.toString(), caseNo + "-raw.edf").toString().replace("\\", "/"));
                    File newEdfFile = new File(Paths.get(caseDirFile.toString(), edfFile.getName()).toString().replace("\\", "/"));
                    
                    System.out.printf("\t\t edf file name   (org) : %s\n", edfFile);
                    System.out.printf("\t\t                 (new) : %s\n", newEdfFile);
                    
                    try {
                        FileUtils.copyFile(edfFile, newEdfFile);
                        allowPermission(newEdfFile.toString());
                    }
                    catch (FileNotFoundException  e) {
                    	notfoundlog(String.format("\t Error                 : EDF File not found.(%s)\n", edfFile.getName()), true);

                        FileUtils.forceDelete(caseDirFile);
                        continue;
					}
                    catch (Exception e) {
                        e.printStackTrace();
                        FileUtils.forceDelete(caseDirFile);
                        continue;
					}
                    
                    // -------------------------------------------------------------------------------
                    // 이미지 디렉토리 복사
                    // -------------------------------------------------------------------------------
                    File imageDir = new File(imagePath.toString(), caseNo);
                    File newImageDir = new File(Paths.get(caseDirFile.toString(), "spectrogram").toString().replace("\\", "/"));
                    
                    System.out.printf("\t\t image file name (org) : %s\n", imageDir);
                    System.out.printf("\t\t                 (new) : %s\n", newImageDir);
                    
                    try {
                        FileUtils.copyDirectory(imageDir, newImageDir);
                        allowPermission(newImageDir.toString());
                    }
                    catch (FileNotFoundException  e) {
                    	notfoundlog(String.format("\t Error                 : Mel image directory not found.(%s)\n", imageDir.getName()), true);
                        FileUtils.forceDelete(caseDirFile);
                        continue;
					}
                    catch (Exception e) {
                        e.printStackTrace();
                        FileUtils.forceDelete(caseDirFile);
                        continue;
					}
                    
                    // 이미지 디렉토리 밑에 이미지 파일이 있는지 체크하여 없으면 오류 처리
                    File[] checkImageFileList = newImageDir.listFiles();
                    if (checkImageFileList.length == 0) {
                    	notfoundlog(String.format("\t Error                 : Mel Image directory is empty.(%s)\n", imageDir.getName()), true);
                        FileUtils.forceDelete(caseDirFile);
                        continue;
                    }

            		//c399stvb_2022-08-18_033220-6
            		//0123456789012345678901234567
                    // -------------------------------------------------------------------------------
                    // 사운드 디렉토리 복사
                    // -------------------------------------------------------------------------------
                    String patientNo = caseNo.substring(0, 8); // 앞에서 8자리가 환자 고유 번호
                    String patientNoAsleep = patientNo + "@asleeptest.com";
                    String caseSoundDir = caseNo.substring(9, 13) + caseNo.substring(14, 16) + caseNo.substring(17, 19) + caseNo.substring(20, 26);
                    
                    File soundPatientDir = new File(soundPath.toString(), patientNoAsleep);
                    
                    File[] soundPatientDirFileList = soundPatientDir.listFiles(new FilenameFilter() {
                        public boolean accept(File dir, String name) {
                            return name.startsWith(caseSoundDir);
                        }
                    });
                    
                    File soundDir = null;
                    for(File orgSoundDir : soundPatientDirFileList) {
                    	soundDir = orgSoundDir;
                    	break;
                    }
                    File newSoundDir = new File(Paths.get(caseDirFile.toString(), "sound").toString().replace("\\", "/"));
                    
                    if (soundDir == null) {
                    	notfoundlog(String.format("\t Error                 : sound directory not found.(%s)\n", Paths.get(soundPatientDir.toString(), caseSoundDir).toString() + "*"), true);
                        FileUtils.forceDelete(caseDirFile);
                        continue;
                    }
                    
                    System.out.printf("\t\t sound file name (org) : %s\n", soundDir);
                    System.out.printf("\t\t                 (new) : %s\n", newSoundDir);
                    System.out.printf("\t\t             patientNo : %s\n", patientNo);
                    System.out.printf("\t\t       patientNoAsleep : %s\n", patientNoAsleep);
                    System.out.printf("\t\t          caseSoundDir : %s\n", caseSoundDir);

                    try {
                    	FileUtils.copyDirectory(soundDir, newSoundDir);
                    	allowPermission(newSoundDir.toString());
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                        FileUtils.forceDelete(caseDirFile);
                        continue;
					}
                    
                    // 사운드 디렉토리 밑에 사운드 파일이 있는지 체크하여 없으면 오류 처리
                    File[] checkSoundFileList = newSoundDir.listFiles();
                    if (checkSoundFileList.length == 0) {
                    	notfoundlog(String.format("\t Error                 : sound directory is empty.(%s)\n", Paths.get(soundPatientDir.toString(), caseSoundDir).toString() + "*"), true);
                        FileUtils.forceDelete(caseDirFile);
                        continue;
                    }

                    // -------------------------------------------------------------------------------
                    // JSON 파일은 complete 디렉토리로 이동 
                    // -------------------------------------------------------------------------------

                    String jsonCompleteHospitalDir = jsonCompletePath.toString().replace("\\", "/");
                    File jsonCompleteHospitalDirFile = new File(jsonCompleteHospitalDir);
                    jsonCompleteHospitalDirFile.mkdirs();
                    allowPermission(jsonCompleteHospitalDirFile.toString());
                    
                    try {
                    	// 복사 후 기존 파일 삭제
                        FileUtils.copyFileToDirectory(jsonFile, jsonCompleteHospitalDirFile, true);
                        String completeJsonFileString = Paths.get(jsonCompleteHospitalDirFile.toString(), jsonFile.getName()).toString();
                        allowPermission(completeJsonFileString);
                        FileUtils.forceDelete(jsonFile);
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                        FileUtils.forceDelete(caseDirFile);
                        continue;
					}
                    
                    hispitalCaseCount = hispitalCaseCount + 1;
                    
                    // 생성 수량이 최대 수량에 도달하면 종료
                    complete_cnt = complete_cnt + 1;
                    
                    if (complete_cnt >= maxCaseCnt) {
                    	break;
                    }
                }
                
            	System.out.printf("\t hispitalCaseCount = %d\n", hispitalCaseCount);

            	// 병원 디렉토리에 한건의 케이스도 없으면 생성한 폴더 삭제
                if (hispitalCaseCount == 0) {
                	FileUtils.forceDelete(targetHospitalDirFile);
                }
                
                System.out.println("--------------------------------------------------------------------");
            }

            // 만약 한건도 없으면 생성한 디렉토리 삭제
            if (complete_cnt == 0) {
                // 파일이던 디렉토리이던 무조건 삭제
            	System.out.printf(" total count is zero.\n");
                FileUtils.forceDelete(targetDirFile);
            }
            
            db.conn.commit();
            
            System.out.println();
            System.out.println(" " + complete_cnt + "개의 CASE 데이터가 생성되었습니다.");

        }
        catch (SQLException e)
        {
            System.out.println(" main() SQLException");
            e.printStackTrace();
        }
        catch (Exception e)
        {
            System.out.println(" main() Exception");
            e.printStackTrace();
        }
        
        // dot 출력 타이머 취소
        printDotTimer.cancel();
        
        db.Close(true);
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 파일 이름에서 확장자를 빼고 파일명만 가져오기
    // --------------------------------------------------------------------------------------------------------
    public static String getOnlyFileName(File file) 
    {
        int Idx = file.getName().lastIndexOf(".");
        return file.getName().substring(0, Idx);
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 설정 파일 읽기(DB 접속 정보 및 이미지 루트 경로)
    // --------------------------------------------------------------------------------------------------------
    private static boolean ReadProperties() 
    {
        try 
        {
            Properties pro = new Properties();

            InputStream is = new FileInputStream(configFileName);
            pro.load(is);

            db_connString = pro.getProperty("connectionString");
            db_user = pro.getProperty("userid");
            db_passwd = pro.getProperty("passwd");
            dataRootDir = pro.getProperty("dataRootDir");
            targetRootDir = pro.getProperty("targetRootDir");
            
            jsonDir = pro.getProperty("jsonDir");
            jsonCompleteDir = pro.getProperty("jsonCompleteDir");
            imageDir = pro.getProperty("imageDir");
            soundDir = pro.getProperty("soundDir");
            edfDir = pro.getProperty("edfDir");

            if (dataRootDir == null) {
                System.out.println("설정 파일에 데이터 최상위 디렉토리(dataRootDir)가 지정되지 않았습니다.");
                return false;
            }
            if (jsonDir == null) {
                System.out.println("설정 파일에 JSON 디렉토리(jsonDir)가 지정되지 않았습니다.");
                return false;
            }
            if (jsonCompleteDir == null) {
                System.out.println("설정 파일에 Json complete 디렉토리(jsonCompleteDir)가 지정되지 않았습니다.");
                return false;
            }
            if (imageDir == null) {
                System.out.println("설정 파일에 Mel spectrogram 이미지 디렉토리(imageDir)가 지정되지 않았습니다.");
                return false;
            }
            if (soundDir == null) {
                System.out.println("설정 파일에 sound 디렉토리(soundDir)가 지정되지 않았습니다.");
                return false;
            }
            if (edfDir == null) {
                System.out.println("설정 파일에 EDF 파일의 디렉토리(edfDir)가 지정되지 않았습니다.");
                return false;
            }
            
            return true;
        }
        catch (IOException e) 
        {
            System.out.println(" ReadProperties() IOException");
            e.printStackTrace();
            return false;
        }
        catch (Exception e) 
        {
            System.out.println(" ReadProperties() Exception");
            e.printStackTrace();
            return false;
        }
        
    }
    

    private static void notfoundlog(String msg, boolean printScreen) {
    	try
    	{
    	    String filename= "selfsleep_setdata_notfound.log";
    	    FileWriter fw = new FileWriter(filename, true);
    	    if (printScreen) {
        	    System.out.print(msg);
    	    }
    	    fw.write(msg);
    	    fw.close();
    	}
    	catch(IOException e)
    	{
    	    System.err.println("IOException: " + e.getMessage());
    	}
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 데이터베이스 연결
    // --------------------------------------------------------------------------------------------------------
    private static boolean ConnectDB() 
    {
        try 
        {
            String url = db_connString;
            String user = db_user;
            String password = db_passwd;
            
            db = new db_oracle(url, user, password);
            if (db.conn == null) return false;
            else return true;
            
        }
        catch (Exception e) 
        {
            System.out.println(" connectDB() Exception");
            e.printStackTrace();
            return false;
        }
        
    }
    
    
    public static String todayYYYYMMDDHHMMSS() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss"); 
        Calendar c1 = Calendar.getInstance();
        return sdf.format(c1.getTime());
    }
    

    // --------------------------------------------------------------------------------------------------------
    // 파일 존재 여부 체크
    // --------------------------------------------------------------------------------------------------------
    public static boolean isExistFile(String filePath) {
        
        boolean exist = false;
        
        try {
            File file = new File(filePath);

            if (file.exists()) {
                exist = true; 
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return exist;
    }
    
    public static String getYYYYMMDD(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        return simpleDateFormat.format(date);
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 생성한 파일의 접근 권한 변경
    // --------------------------------------------------------------------------------------------------------
    public static void allowPermission(String fileName) {
        
        if (SystemUtils.IS_OS_WINDOWS) {
            return;
        }
        
        Process p;
        try {
            p = Runtime.getRuntime().exec("chmod 777 -R " + fileName);
            p.waitFor();
        } 
        catch (Exception e) {
            e.printStackTrace();
            System.out.println("\t파일 권한 설정 에러 : " + fileName);
        }

        /*
        try {
            File targetFile = new File(fileName);
            if(targetFile.exists()){
                Path p = Paths.get(fileName);
                Set<PosixFilePermission> posixPermissions = PosixFilePermissions.fromString("rwxrwxrwx");
                Files.setPosixFilePermissions(p, posixPermissions);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
            System.out.println("\t파일 권한 설정 에러 : " + fileName);
        }
        */
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 화면상에 진행상황을 표시하기 위하여 점(.) 찍기
    // --------------------------------------------------------------------------------------------------------
    public static void printDotThread() {
        
        while(true) {
            try {
                System.out.print(".");
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
}
