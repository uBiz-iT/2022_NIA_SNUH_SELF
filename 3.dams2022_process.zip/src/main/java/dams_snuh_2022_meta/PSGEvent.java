package dams_snuh_2022_meta;

public class PSGEvent {
    public int event_seq;
    public String event_name;
    public String begin_date;
    public String end_date;
    public int begin_epoch_no;
    public int end_epoch_no;
    public float begin_second;
    public float end_second;
    public float elapsed_seconds;
}
