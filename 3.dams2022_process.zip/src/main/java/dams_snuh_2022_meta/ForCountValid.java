package dams_snuh_2022_meta;

import java.io.Console;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.io.FileUtils;

//-----------------------------------------------------------------------------------------------------------------
//제출용 구조 디렉토리에서 환자별 검사 수량이 유효한 것만 추출
//pft   : 5개이상 30개 이하
//sleep : 4개이상
//-----------------------------------------------------------------------------------------------------------------

public class ForCountValid {

	static String sourceDir = "";
	static String targetDir = "";
	static Integer minCaseCnt = 1;
	static Integer maxCaseCnt = 30;
	static boolean isRandom = false;
	
	static String sourcePathString = "";
	static String targetPathString = "";
	static File sourceRoot;
	static File targetRoot;

	static String labelingRootName = "라벨링데이터";	
	static String originRootName = "원천데이터";
	
	public static void main(String[] args) {

        if (args.length <= 3) {
            System.out.println("소스 디렉토리, 타겟 디렉토리, 최소수량, 최대수량, Random 추출여부를 입력하세요");
            return;
        }
        
		sourceDir = args[0];
		targetDir = args[1];
		minCaseCnt = Integer.parseInt(args[2]);
		maxCaseCnt = Integer.parseInt(args[3]);
		
        // 5번째(배열 4) 인자는 라벨링 결과를 업데이트 할지를 결정
        if (args.length == 4) {
        	isRandom = args[4].toUpperCase().equals("RANDOM") ? true : false;
        }
        System.out.printf("30개 초과시 Random 추출? : %s\n", isRandom);
		
		try {
			sourcePathString = new java.io.File(sourceDir).getCanonicalPath();
			
			String currentPath = new java.io.File(".").getCanonicalPath();
			targetPathString = Paths.get(currentPath, targetDir).toString().replace("\\", "/");

            System.out.println("source Path String : " + sourcePathString);
			System.out.println("target Path String : " + targetPathString);
			
            File targetRootDir = new File(targetPathString);
            
            if (targetRootDir.exists()) {
            	System.out.printf("target directory is already exist.\nDo delete first.\n");
            	System.exit(0);
            }
            
		} 
		catch (IOException e1) {
			e1.printStackTrace();
			System.exit(1);
		}
		
		try {

            sourceRoot = new File(sourcePathString);

            // -------------------------------------------------------------------------------
            // 프로젝트 데이터 디렉토리가 존재하는지 체크하여 없으면 종료
            // -------------------------------------------------------------------------------
            if(!sourceRoot.exists())
            {
                System.out.println(" 소스 디렉토리 경로 " + sourcePathString + "이 존재하지 않습니다.");
                return;
            }
            
            // -------------------------------------------------------------------------------
            // 소스 디렉토리 Path가 디렉토리가 아니면 종료
            // -------------------------------------------------------------------------------
            if(!sourceRoot.isDirectory())
            {
                System.out.println(" 소스 디렉토리 경로가 디렉토리가 아닙니다.");
                return;
            }

            copyConditionData();

		}
		catch (Exception e) {
			e.printStackTrace();
		}
            
	}
	
    // --------------------------------------------------------------------------------------------------------
    // 데이터 처리
    // --------------------------------------------------------------------------------------------------------
    private static void copyConditionData() 
    {
    	
    	String originPathString = Paths.get(sourcePathString, labelingRootName).toString().replace("\\", "/");
    	
    	File originDir = new File(originPathString); 
    	
        File[] diagList = originDir.listFiles();
        Arrays.sort(diagList);
        
        String diagName = "";
        String hospitalCode = "";
        String patientId = "";
        String caseId = "";

        // -------------------------------------------------------------------------------
        // 진단명 디렉토리 하나씩 검색
        // -------------------------------------------------------------------------------
        for(File diagDir : diagList)
        {   
            // 디렉토리가 아닌 것은 처리할 필요가 없음
            if(!diagDir.isDirectory())
            {
                continue;
            }
            
            
            diagName = diagDir.getName();
            System.out.printf("\t%s\n", diagName);
            
            File[] hospitalList = diagDir.listFiles();
            Arrays.sort(hospitalList);

            // 병원 디렉토리 하나씩
            for(File hospitalDir : hospitalList)
            {   
                // 디렉토리가 아닌 것은 처리할 필요가 없음
                if(!hospitalDir.isDirectory())
                {
                    continue;
                }
                
                hospitalCode = hospitalDir.getName();
                System.out.printf("\t\t%s\n", hospitalCode);
                
                // 환자ID 디렉토리 하나씩
                File[] patientList = hospitalDir.listFiles();
                Arrays.sort(patientList);

                for(File patientDir : patientList)
                {   
                    // 디렉토리가 아닌 것은 처리할 필요가 없음
                    if(!patientDir.isDirectory())
                    {
                        continue;
                    }
                    
                    patientId = patientDir.getName();
                    System.out.printf("\t\t\t%s\n", patientId);
                    
                    // 케이스 디렉토리 확인
                    File[] caseList = patientDir.listFiles();
                    
                    if (isRandom) {
                        List<File> caseListTypeList = Arrays.asList(caseList);
                		Collections.shuffle(caseListTypeList);
                		caseListTypeList.toArray(caseList);
                    }
                    else {
                        Arrays.sort(caseList);
                    }
                    
                	System.out.printf("\t\t\t\tcase count = %d\n", caseList.length);

                	// 케이스 디렉토리 수량이 최소 수량 이상이면 복사 시작
                    Integer cnt = 0;
                    if (caseList.length < minCaseCnt) { 
                    	System.out.printf("\t\t\t\tCase count is rather than minimum value.\n");
                    }
                    else {
                    	for(File caseDir : caseList)
                        {	
                            // 디렉토리가 아닌 것은 처리할 필요가 없음
                            if(!caseDir.isDirectory())
                            {
                                continue;
                            }
                            
                            caseId = caseDir.getName();

                            cnt = cnt + 1;
                            System.out.printf("\t\t\t\t%3d : %s\n", cnt, caseId);
                            
                            // -----------------
                            // 복사
                            // -----------------
                            
                            // 케이스 데이터 원본의 라벨링데이터 디렉토리 설정
                            String fromDirPathString;
                            File fromDirFile;
                            
                            // 케이스 데이터를 복사할 타겟 디렉토리의 라벨링데이터 디렉토리 설정
                            String toDirPathString;
                            File toDirFile;
                            
                            try {
                                fromDirPathString = Paths.get(sourcePathString, labelingRootName, diagName, hospitalCode, patientId, caseId).toString().replace("\\", "/");
                                fromDirFile = new File(fromDirPathString);
                                
                                toDirPathString = Paths.get(targetPathString, labelingRootName, diagName, hospitalCode, patientId, caseId).toString().replace("\\", "/");
                                toDirFile = new File(toDirPathString);
                                
                            	// 이미 있으면 삭제
                                if (toDirFile.exists()) {
									FileUtils.forceDelete(toDirFile);
                                }
                                
                                FileUtils.copyDirectory(fromDirFile, toDirFile);

                                fromDirPathString = Paths.get(sourcePathString, originRootName, diagName, hospitalCode, patientId, caseId).toString().replace("\\", "/");
                                fromDirFile = new File(fromDirPathString);
                                
                                toDirPathString = Paths.get(targetPathString, originRootName, diagName, hospitalCode, patientId, caseId).toString().replace("\\", "/");
                                toDirFile = new File(toDirPathString);
                                
                            	// 이미 있으면 삭제
                                if (toDirFile.exists()) {
									FileUtils.forceDelete(toDirFile);
                                }
                                
                                FileUtils.copyDirectory(fromDirFile, toDirFile);
                            }
                            catch (FileNotFoundException  e) {
                                e.printStackTrace();
                                continue;
        					}
                            catch (Exception e) {
                                e.printStackTrace();
                                continue;
        					}
                            
                            // 최대 수량을 초과하면 루프 종료
                        	if (cnt >= maxCaseCnt) {
                        		break;
                        	}
                        }
                    }
                    
                }
                
            } 

        } 
    }

}
