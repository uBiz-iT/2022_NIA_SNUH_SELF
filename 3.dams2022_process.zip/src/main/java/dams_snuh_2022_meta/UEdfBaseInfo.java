package dams_snuh_2022_meta;
import java.time.LocalDateTime;

public class UEdfBaseInfo {
    LocalDateTime startDateTime;
    String patient;
    int signalCount;
    long recordCount;
    double recordDuration;
    long totalDuration;
    int epochSize;
    long totalEpochCount;
}
