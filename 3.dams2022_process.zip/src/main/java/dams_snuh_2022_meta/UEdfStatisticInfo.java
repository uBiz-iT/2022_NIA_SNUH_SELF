package dams_snuh_2022_meta;

import java.util.ArrayList;
import java.util.List;

public class UEdfStatisticInfo {
    int secondsPerOneSample = 0;    // 1개당 몇초의 데이터인지
    int samplingCount = 0;          // 총 몇개인지
    List<UEdfStatisticData> statisticDataList = new ArrayList<UEdfStatisticData>();
}
