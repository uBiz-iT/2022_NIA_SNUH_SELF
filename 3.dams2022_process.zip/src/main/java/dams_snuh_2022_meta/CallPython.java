package dams_snuh_2022_meta;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.PumpStreamHandler;

public class CallPython {

    public static void main(String[] args)
    {

        System.out.println("Python 실행");
        String[] command = new String[4];
        command[0] = "python";
        //command[1] = "\\workspace\\java-call-python\\src\\main\\resources\\test.py";
        command[1] = "CreateSpectrogram.py";
        try {
            int res = execPython(command);
            if (res == 1) {
                System.out.println("Python 호출 에러");
            }
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int execPython(String[] command) {
        int errCode = 0;
        try {
            CommandLine commandLine = CommandLine.parse(command[0]);
            for (int i = 1, n = command.length; i < n; i++) {
                commandLine.addArgument(command[i]);
            }
    
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            PumpStreamHandler pumpStreamHandler = new PumpStreamHandler(outputStream);
            DefaultExecutor executor = new DefaultExecutor();
            executor.setStreamHandler(pumpStreamHandler);
        
            int result = executor.execute(commandLine);
            System.out.println("result: " + result);
            System.out.println("output: " + outputStream.toString());
        }
        catch(IOException e) {
            System.out.println(e.getMessage());
            errCode = 1;
        }
        catch(Exception e) {
            System.out.println(e.getMessage());
            errCode = 9;
        }
        return errCode;
    }  
}

