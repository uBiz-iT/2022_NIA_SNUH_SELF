package dams_snuh_2022_meta;

public class Diagnosis {
    public String gender;           // 진단파일(~~report.txt) 2번째
    public String age;              // 진단파일(~~report.txt) 3번째
    public String bmi;              // 진단파일(~~report.txt) 4번째
    public String tot_sleep_time;   // 진단파일(~~report.txt) 7번째
    public String sleep_effi;       // 진단파일(~~report.txt) 8번째
    public String sleep_latency;    // 진단파일(~~report.txt) 9번째
    public String ahi;              // 진단파일(~~report.txt) 42번째
    public String rdi;              // 진단파일(~~report.txt) 45번째 
    public String oxy_satu_avg;     // 진단파일(~~report.txt) 70번째
    public String oxy_satu_min;     // 진단파일(~~report.txt) 73번째
    public String tot_lm_index;     // 진단파일(~~report.txt) 79번째
    public String tot_lm_arou;      // 진단파일(~~report.txt) 82번째
    public String arou_index;       // 진단파일(~~report.txt) 84번째
}
