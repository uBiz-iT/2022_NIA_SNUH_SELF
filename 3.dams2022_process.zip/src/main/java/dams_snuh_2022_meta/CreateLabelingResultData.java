package dams_snuh_2022_meta;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.SystemUtils;
import org.json.simple.JSONObject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonWriter;
 
//-----------------------------------------------------------------------------------------------------------------
// 라벨링이 완료된 태스크에 대하여 라벨링 결과를 기존의 어노테이션 파일에 추가하거나 신규로 생성한 후
// 제출할 데이터셋 형태로 복사하여 새로운 경로에 저장
// 이 데이터를 인공지능 모델 팀에서 사용한다.
//-----------------------------------------------------------------------------------------------------------------
public class CreateLabelingResultData {

    static String projectCode = "";
    static String taskCode = "";
    static String dataDir = "";
    static boolean labelingUpdate = false;;
    
    // 오라클 연결 및 SQL문 실행
    static db_oracle db = null;      

    static int complete_cnt = 0;
    
    static String dataRootPath = "";
    
    // 라벨링 결과 Root 경로
    static String resultRootPath = "";

    static String configFileName = "";
    static String db_user = "";
    static String db_passwd = "";
    static String db_connString = "";
    static SQLResult sqlResult = new SQLResult();
    
    static TarFiles tar = null; 
    
    // 화면에 dot(.)을 출력하기 위하여
    static boolean isPrintDot = false;
    static Timer printDotTimer = new Timer();
    static TimerTask printDotTimerTask = new TimerTask() {
        @Override
        public void run() {
            if (isPrintDot) {
                System.out.print(".");
            }
        }
    };
    
    static Number nullCheckNum = 0;
    static String todayYYYYMMDD = "";
    
    public static void main(String[] args) 
    {

        if (args.length <= 2) {
            System.out.println("Task 코드를 입력하세요.");
            return;
        }
        
        // 1번째(배열 0) 인자가 설정 파일 이름
        // 2번째(배열 1) 인자는 프로젝트 코드
        configFileName = args[0];
        
        // 4번째(배열 3) 인자는 라벨링 결과를 업데이트 할지를 결정
        if (args.length == 4) {
            labelingUpdate = args[3].toUpperCase().equals("UPDATE") ? true : false;
            System.out.printf("라벨링 결과 Update? : %s\n", labelingUpdate);
        }
        
        // configuration 파일 read 
        if (!ReadProperties()) return;
        
        // DB connection 
        if (!ConnectDB()) return;
        
        tar = new TarFiles();
        
        // 오래 걸리는 작업의 경우 화면에 dot(.)를 출력하기 위함 
        printDotTimer.schedule(printDotTimerTask, 1000, 1000);

        try
        {
            // auto commit false 
            db.conn.setAutoCommit(false);
            
            // -------------------------------------------------------------------------------
            // 프로젝트, Task의 데이터 디렉토리 정보 읽어옴
            // -------------------------------------------------------------------------------
            String sql = "";
            sql  = " SELECT PROJ_CD, TASK_CD, DATA_DIR";
            sql += " FROM   PLT_TASK";
            sql += " WHERE  PROJ_CD = '" + args[1] + "'";
            sql += " AND    TASK_CD = '" + args[2] + "'";
            
            ResultSet rs = db.selectSQL(sql);
            
            System.out.println("");
            System.out.printf(" 프로젝트 %s, Task %s의 메타 데이터를 데이터베이스에 생성합니다.", args[1], args[2]);
            System.out.println("");

            boolean exist_task = false;
            while(rs.next())
            {
                projectCode = rs.getString("PROJ_CD");
                taskCode = rs.getString("TASK_CD");
                dataDir = rs.getString("DATA_DIR");
                exist_task = true;
                break;
            }
            
            rs.close();
            db.pstmt.close();

            // -------------------------------------------------------------------------------
            // Task가 없으면 종료
            // -------------------------------------------------------------------------------
            if (!exist_task) {
                System.out.println(" 입력된 Task 코드가 없습니다.");
                db.Close();
                printDotTimer.cancel();
                return;
            }
            
            if (dataDir == null) {
                System.out.println(" Task 코드 등록시 Task 데이터 디렉토리 경로가 입력되지 않았습니다.");
                db.Close();
                printDotTimer.cancel();
                return;
            }

            Path filePath = Paths.get(dataRootPath, dataDir);
            System.out.println(" Task 데이터 디렉토리 경로 : " + filePath.toString());
            System.out.println();

            File dataRoot = new File(filePath.toString());

            // -------------------------------------------------------------------------------
            // 태스크 데이터 디렉토리가 존재하는지 체크하여 없으면 종료
            // -------------------------------------------------------------------------------
            if(!dataRoot.exists())
            {
                System.out.println(" 데이터 경로 " + dataDir + "이 존재하지 않습니다.");
                db.Close();
                printDotTimer.cancel();
                return;
            }
            
            // -------------------------------------------------------------------------------
            // 데이터 디렉토리 Path가 디렉토리가 아니면 종료
            // -------------------------------------------------------------------------------
            if(!dataRoot.isDirectory())
            {
                System.out.println(" 데이터 파일 경로가 디렉토리가 아닙니다.");
                db.Close();
                printDotTimer.cancel();
                return;
            }

            todayYYYYMMDD = getYYYYMMDD(new Date());
            
            switch (projectCode) 
            {   
                case "2022A1":  // 수면 데이터의 경우
                    selectSleepLabelingResult();
                    break;
                case "2022B1":  // 폐기능 데이터의 경우
                    selectPftLabelingResult();
                    break;
                case "2022B2":  // 폐음 데이터의 경우
                    selectLungSoundLabelingResult();
                    break;
                default:
                    System.out.printf(" 프로젝트 코드가 없습니다. : " + projectCode);
                    db.Close();
                    printDotTimer.cancel();
                    System.exit(1);
                    break;
            }
            
            db.conn.commit();
            
            System.out.println();
            System.out.println(" " + complete_cnt + "개의 CASE 데이터가 복사되었습니다.");

        }
        catch (SQLException e)
        {
            System.out.println(" main() SQLException");
            e.printStackTrace();
        }
        catch (Exception e)
        {
            System.out.println(" main() Exception");
            e.printStackTrace();
        }
        
        // dot 출력 타이머 취소
        printDotTimer.cancel();
        
        db.Close(true);
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 설정 파일 읽기(DB 접속 정보 및 이미지 루트 경로)
    // --------------------------------------------------------------------------------------------------------
    private static boolean ReadProperties() 
    {
        try 
        {
            Properties pro = new Properties();

            InputStream is = new FileInputStream(configFileName);
            pro.load(is);

            db_connString = pro.getProperty("connectionString");
            db_user = pro.getProperty("userid");
            db_passwd = pro.getProperty("passwd");
            dataRootPath = pro.getProperty("dataRootDir");
            resultRootPath = pro.getProperty("resultRootDir");
            
            if (dataRootPath == null) {
                System.out.println("설정 파일에 데이터 최상위 디렉토리(dataRootDir)가 지정되지 않았습니다.");
                return false;
            }
            if (resultRootPath == null) {
                System.out.println("설정 파일에 복사할 데이터의 최상위 디렉토리(resultRootDir)가 지정되지 않았습니다.");
                return false;
            }
            
            return true;
        }
        catch (IOException e) 
        {
            System.out.println(" ReadProperties() IOException");
            e.printStackTrace();
            return false;
        }
        catch (Exception e) 
        {
            System.out.println(" ReadProperties() Exception");
            e.printStackTrace();
            return false;
        }
        
    }
    

    // --------------------------------------------------------------------------------------------------------
    // 데이터베이스 연결
    // --------------------------------------------------------------------------------------------------------
    private static boolean ConnectDB() 
    {
        try 
        {
            String url = db_connString;
            String user = db_user;
            String password = db_passwd;
            
            db = new db_oracle(url, user, password);
            if (db.conn == null) return false;
            else return true;
            
        }
        catch (Exception e) 
        {
            System.out.println(" connectDB() Exception");
            e.printStackTrace();
            return false;
        }
        
    }

    // ---------------------------------------------------------------------------------------------------------------------------
    // 검수 완료된 것 수면 json 파일에 라벨 추가
    // ---------------------------------------------------------------------------------------------------------------------------
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static boolean selectSleepLabelingResult() {
        
        LinkedHashMap<String, Object> OSAriskMapObject = new LinkedHashMap<String, Object>();

        ObjectMapper mapper = new ObjectMapper(); 
        mapper.setDefaultPropertyInclusion(JsonInclude.Include.ALWAYS);
        
        Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();

        ResultSet rs = null;
        String sql = "";

        String taskCaseNo = "";
        String creJsonFg = "";
        String inspRes = "";
        String lblCode = "";
        String osaRiskYN = "";
        
        try {
            sql  = " SELECT W.CASE_NO,                         ";
            sql += "        C.CRE_JSON_FG,                     ";
            sql += "        NVL(W.INSP_RES,'Not yet') INSP_RES,"; 
            sql += "        W.LBL_CD                           ";
            sql += " FROM   PLT_TASK_CASE C,                   ";
            sql += "        WKV_CC W                           ";
            sql += " WHERE  C.PROJ_CD        = '" + projectCode + "'";
            sql += " AND    C.TASK_CD        = '" + taskCode + "'";
            sql += " AND    W.PROJ_CD        = C.PROJ_CD       ";
            sql += " AND    W.TASK_CD        = C.TASK_CD       ";
            sql += " AND    W.CASE_NO        = C.CASE_NO       ";
            
            rs = db.selectSQL(sql);
            
            System.out.printf("\t Case No           Already  Risk  Result   Comment\n");
            System.out.printf("\t ----------------  -------  ----  -------  --------------------");

            while (rs.next())
            {
                taskCaseNo = rs.getString("CASE_NO");
                creJsonFg = rs.getString("CRE_JSON_FG");
                inspRes = rs.getString("INSP_RES");
                lblCode = rs.getString("LBL_CD");
                
                System.out.printf("\n\t %-16s  %-7s  %-4s  %-7s  ", taskCaseNo, creJsonFg, lblCode, inspRes);

                String annotationFileName = taskCaseNo + ".json";
                String edfFileName = taskCaseNo + "-raw.edf";

                // 이미 라벨링 결과를 반영하였으면 건너 뜀. 반영 후 다시 수정이 일어난 경우에는 진단/검수 프로그램에서 이 필드에  'N'으로 수정 필요
                if (creJsonFg.compareTo("Y") == 0 && labelingUpdate == false) {
                    System.out.printf("이미 반영된 케이스");
                    continue;
                }
                
                if (inspRes.compareTo("Pass") == 0) {
                }
                else if (inspRes.compareTo("Fail") == 0) {
                    if (lblCode.trim().compareTo("Z") == 0) {
                        System.out.printf("진단 결과 Drop");
                    }
                    else {
                        System.out.printf("교차 검증 결과 Fail");
                    }
                    continue;
                }
                else {
                    System.out.printf("미검수 상태");
                    continue;
                }
                
                // A101 : Normal, A102 : OSA risk, Z : Drop
                if (lblCode.compareTo("A101") == 0) {
                    osaRiskYN = "N";
                }
                else if (lblCode.compareTo("A102") == 0) {
                    osaRiskYN = "Y";
                }
                else {
                    System.out.printf("\t 라벨 데이터가 잘 못 되었습니다.\n");
                    continue;
                }


                try {     

                    // 기존 객체 클리어
                    OSAriskMapObject.clear();
                    
                    // OSA RISK 여부 객체 생성
                    OSAriskMapObject.put("OSA_Risk", osaRiskYN);
                    
                    // 기존 JSON 파일 설정
                    String jsonFilePathString = Paths.get(dataRootPath, dataDir, taskCaseNo, annotationFileName).toString().replace("\\", "/");

                    // 기존에 저장된 순서를 유지하기 위하여 JSONObject대신 LinkedHashMap 타입으로 읽어옴
                    LinkedHashMap map = mapper.readValue(new File(jsonFilePathString), LinkedHashMap.class); 
                 
                    // 라벨링 결과 오브젝트가 있는지 체크하고 있으면 replace, 없으면 두번째(index:1)에 추가
                    if (map.containsKey("Test_Result")) {
                        map.replace("Test_Result", OSAriskMapObject);
                    }
                    else {
                        putKeyVaue(map, 1, "Test_Result", OSAriskMapObject);
                    }

                    // 라벨링 결과 디렉토리 설정
                    Path resultDirPath = Paths.get(resultRootPath, "sleep", todayYYYYMMDD, taskCaseNo);
                    String resultDirPathString = resultDirPath.toString().replace("\\", "/");
                    File resultDir = new File(resultDirPathString);
                    
                    // 기존에 라벨링 결과 디렉토리가 있으면 삭제.
                    if (resultDir.exists()) {
                        // 파일이던 디렉토리이던 무조건 삭제
                        FileUtils.forceDelete(resultDir);
                    }
                    
                    // 라벨링 결과 디렉토리 생성
                    resultDir.mkdirs();
                    
                    // 라벨링 결과 JSON 파일 설정
                    String jsonNewFilePathString = Paths.get(resultDirPathString, annotationFileName).toString().replace("\\", "/");
                    
                    // 라벨링 결과를 결과 디렉토리 경로의 파일명에 저장 후 close
                    PrintWriter pWriter = new PrintWriter(jsonNewFilePathString);
                    JsonWriter jWriter = gson.newJsonWriter(pWriter);
                    jWriter.setIndent("    ");
                    gson.toJson(map, LinkedHashMap.class, jWriter);
                    pWriter.println();
                    jWriter.flush();
                    jWriter.close();
                    pWriter.flush();
                    pWriter.close();
                    
                    // -------------------------------------------------------------------------------
                    // 여기서부터는 다른 원천 파일 복사
                    // -------------------------------------------------------------------------------
                    // EDF 파일 복사
                    File edfFile = new File(Paths.get(dataRootPath, dataDir, taskCaseNo, edfFileName).toString().replace("\\", "/"));
                    File edfNewFile = new File(Paths.get(resultDirPathString, edfFileName).toString().replace("\\", "/"));
                    FileUtils.copyFile(edfFile, edfNewFile);

                    // spectrogram 디렉토리 복사
                    File spectrogramFile = new File(Paths.get(dataRootPath, dataDir, taskCaseNo, "spectrogram").toString().replace("\\", "/"));
                    File spectrogramNewFile = new File(Paths.get(resultDirPathString, "spectrogram").toString().replace("\\", "/"));
                    FileUtils.copyDirectory(spectrogramFile, spectrogramNewFile);

                    updatePLT_TASK_CASE(taskCaseNo);  
                    
                    System.out.printf("Risk=%s, 복사/결과 반영 성공", osaRiskYN);
                    
                    complete_cnt += 1;


                }
                catch (FileNotFoundException e1) {
                    System.out.println("\tAnnotation 파일이 없습니다.(파일명 = " + annotationFileName + ")");
                } 
                catch (IOException e2) {
                    System.out.println("\t--- IOException");
                    e2.printStackTrace();
                } 
                catch (Exception e4) {
                    System.out.println("\t--- Exception e");
                    e4.printStackTrace();
                }
                
            }
            
            System.out.println();
            System.out.println();
            System.out.println(" Target 디렉토리 경로 : " + Paths.get(resultRootPath, "sleep", todayYYYYMMDD).toString().replace("\\", "/"));
            
        }
        catch (SQLException se) 
        {
            System.out.println("\tError SQL : " + sql);
            se.printStackTrace();
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
        
        return true;
        
    }
    
    public static String todayYYYYMMDD() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd"); 
        Calendar c1 = Calendar.getInstance();
        return sdf.format(c1.getTime());
    }
    
    // ---------------------------------------------------------------------------------------------------------------------------
    // 검수 완료된 것 폐기능 검사 데이터 복사
    // ---------------------------------------------------------------------------------------------------------------------------
    @SuppressWarnings("rawtypes")
    public static boolean selectPftLabelingResult() {
        
        ObjectMapper mapper = new ObjectMapper(); 
        mapper.setDefaultPropertyInclusion(JsonInclude.Include.ALWAYS);
        
        Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();

        ResultSet rs = null;
        String sql = "";

        String taskCaseNo = "";
        String creJsonFg = "";
        String inspRes = "";
        
        try {
            sql  = " SELECT W.CASE_NO,                         ";
            sql += "        C.CRE_JSON_FG,                     ";
            sql += "        NVL(W.INSP_RES,'Not yet') INSP_RES "; 
            sql += " FROM   PLT_TASK_CASE C,                   ";
            sql += "        WKV_CC W                           ";
            sql += " WHERE  C.PROJ_CD        = '" + projectCode + "'";
            sql += " AND    C.TASK_CD        = '" + taskCode + "'";
            sql += " AND    W.PROJ_CD        = C.PROJ_CD       ";
            sql += " AND    W.TASK_CD        = C.TASK_CD       ";
            sql += " AND    W.CASE_NO        = C.CASE_NO       ";
            
            rs = db.selectSQL(sql);
            
            System.out.printf("\t Case No          Already  Result   Comment\n");
            System.out.printf("\t ---------------  -------  -------  --------------------");

            while (rs.next())
            {
                taskCaseNo = rs.getString("CASE_NO");
                creJsonFg = rs.getString("CRE_JSON_FG");
                inspRes = rs.getString("INSP_RES");

                System.out.printf("\n\t %-15s  %-7s  %-7s  ", taskCaseNo, creJsonFg, inspRes);

                // 이미 라벨링 결과를 반영하였으면 건너 뜀. 반영 후 다시 수정이 일어난 경우에는 진단/검수 프로그램에서 이 필드에  'N'으로 수정 필요
                if (creJsonFg.compareTo("Y") == 0 && labelingUpdate == false) {
                    System.out.printf("이미 반영된 케이스");
                    continue;
                }
                
                // 검수 결과가 pass가 아니면 건너 뜀
                if (inspRes.compareTo("Pass") == 0) {
                }
                else if (inspRes.compareTo("Fail") == 0) {
                    System.out.printf("교차 검증 결과 Fail");
                    continue;
                }
                else {
                    System.out.printf("미검수 상태");
                    continue;
                }
                
                String annotationFileName = taskCaseNo + "-annotation.json";
                String edfFileName = taskCaseNo + "-pft-source.edf";			// EDF 파일만 복사하기 위하여 추가
                String patientCodeDir = "";
                
                try {     

                    // 먼저 환자 코드 추출, 앞 3자리
                    String patientcode = taskCaseNo.substring(0, 3);
                    
                    // 기존 JSON 파일 설정
                    String jsonFilePathString = Paths.get(dataRootPath, dataDir, taskCaseNo, annotationFileName).toString().replace("\\", "/");
                    String edfFilePathString = Paths.get(dataRootPath, dataDir, taskCaseNo, edfFileName).toString().replace("\\", "/");
                    
                    // 존재하지 않으면 상위 디렉토리가 patient code일수 있으므로 변경해서 찾아본다
                    if (!isExistFile(jsonFilePathString)) {
                        patientCodeDir = patientcode;
                        jsonFilePathString = Paths.get(dataRootPath, dataDir, patientCodeDir, taskCaseNo, annotationFileName).toString().replace("\\", "/");
                        edfFilePathString = Paths.get(dataRootPath, dataDir, patientCodeDir, taskCaseNo, edfFileName).toString().replace("\\", "/");
                    }

                    // 기존에 저장된 순서를 유지하기 위하여 JSONObject대신 LinkedHashMap 타입으로 읽어옴
                    LinkedHashMap map = mapper.readValue(new File(jsonFilePathString), LinkedHashMap.class); 
                 

                    // 라벨링 결과 디렉토리 설정
                    
                    Path resultDirPath = Paths.get(resultRootPath, "pft", todayYYYYMMDD, patientcode, taskCaseNo);
                    String resultDirPathString = resultDirPath.toString().replace("\\", "/");
                    File resultDir = new File(resultDirPathString);
                    
                    // 기존에 라벨링 결과 디렉토리가 있으면 삭제.
                    if (resultDir.exists()) {
                        // 파일이던 디렉토리이던 무조건 삭제
                        FileUtils.forceDelete(resultDir);
                    }
                    
                    // 라벨링 결과 디렉토리 생성
                    resultDir.mkdirs();
                    
                    // -------------------------------------------------------------------------------
                    // 디렉토리 통으로 복사
                    // -------------------------------------------------------------------------------
                    //File sourceDir = new File(Paths.get(dataRootPath, dataDir, patientCodeDir, taskCaseNo).toString().replace("\\", "/"));
                    //FileUtils.copyDirectory(sourceDir, resultDir);
                    
                    // EDF 파일만 복사하는 것으로 수정
                	File srcFile = new File(edfFilePathString);
					FileUtils.copyFileToDirectory(srcFile, resultDir);

                    // 라벨링 결과 JSON 파일 설정(안해도 되지만 알투에서 만든 것이 pretty하게 나오지 않아서 새로 생성
                    String jsonNewFilePathString = Paths.get(resultDirPathString, annotationFileName).toString().replace("\\", "/");
                    
                    // 라벨링 결과를 결과 디렉토리 경로의 파일명에 저장 후 close
                    PrintWriter pWriter = new PrintWriter(jsonNewFilePathString);
                    JsonWriter jWriter = gson.newJsonWriter(pWriter);
                    jWriter.setIndent("    ");
                    gson.toJson(map, LinkedHashMap.class, jWriter);
                    pWriter.println();
                    jWriter.flush();
                    jWriter.close();
                    pWriter.flush();
                    pWriter.close();
                    
                    updatePLT_TASK_CASE(taskCaseNo);  
                    
                    System.out.printf("복사 및 진단 결과 추가 성공");
                    
                    complete_cnt += 1;

                }
                catch (FileNotFoundException e) {
                    e.printStackTrace();
                } 
                catch (IOException e) {
                    e.printStackTrace();
                } 
                catch (Exception e) {
                    e.printStackTrace();
                }
                
            }       
            
            System.out.println();
            System.out.println();
            System.out.println(" Target 디렉토리 경로 : " + Paths.get(resultRootPath, "pft", todayYYYYMMDD).toString().replace("\\", "/"));

        }
        catch (SQLException se) 
        {
            System.out.println("\tError SQL : " + sql);
            se.printStackTrace();
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
        
        return true;
        
    }
    
    // ---------------------------------------------------------------------------------------------------------------------------
    // 검수 완료된 것 폐음 검사 데이터 json 파일 생성
    // ---------------------------------------------------------------------------------------------------------------------------
    @SuppressWarnings({ "rawtypes", "unchecked"})
    public static boolean selectLungSoundLabelingResult() {
        
        LinkedHashMap<String, Object> LungsoundResultMapObject = new LinkedHashMap<String, Object>();

        ObjectMapper mapper = new ObjectMapper(); 
        mapper.setDefaultPropertyInclusion(JsonInclude.Include.ALWAYS);
        
        Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();

        ResultSet rs = null;
        String sql = "";
        ResultSet rsGood = null;
        String sqlGood = "";

        String taskCaseNo = "";
        String creJsonFg = "";
        String inspRes = "";
        String description = "";
        String lblCode = "";
        
        try {
            sql  = " SELECT W.CASE_NO,                         ";
            sql += "        C.CRE_JSON_FG,                     ";
            sql += "        NVL(W.INSP_RES,'Not yet') INSP_RES,"; 
            sql += "        W.LBL_CD,                          ";
            sql += "        W.DIAG_MEMO                        ";
            sql += " FROM   PLT_TASK_CASE C,                   ";
            sql += "        WKV_CC W                           ";
            sql += " WHERE  C.PROJ_CD        = '" + projectCode + "'";
            sql += " AND    C.TASK_CD        = '" + taskCode + "'";
            sql += " AND    W.PROJ_CD        = C.PROJ_CD       ";
            sql += " AND    W.TASK_CD        = C.TASK_CD       ";
            sql += " AND    W.CASE_NO        = C.CASE_NO       ";

            
            rs = db.selectSQL(sql);
            
            System.out.printf("\t Case No          Already  Result   Comment\n");
            System.out.printf("\t ---------------  -------  -------  --------------------");

            while (rs.next())
            {
                taskCaseNo = rs.getString("CASE_NO");
                creJsonFg = rs.getString("CRE_JSON_FG");
                inspRes = rs.getString("INSP_RES");
                description = rs.getString("DIAG_MEMO");
                lblCode = rs.getString("LBL_CD");
                
                System.out.printf("\n\t %-15s  %-7s  %-7s  ", taskCaseNo, creJsonFg, inspRes);

                String annotationFileName = taskCaseNo + "-annotation.json";

                // 이미 라벨링 결과를 반영하였으면 건너 뜀. 반영 후 다시 수정이 일어난 경우에는 진단/검수 프로그램에서 이 필드에  'N'으로 수정 필요
                if (creJsonFg.compareTo("Y") == 0 && labelingUpdate == false) {
                    System.out.printf("이미 반영된 케이스");
                    continue;
                }
                
                if (inspRes.compareTo("Pass") == 0) {
                }
                else if (inspRes.compareTo("Fail") == 0) {
                    if (lblCode.trim().compareTo("Z") == 0) {
                        System.out.printf("Description 결과 Fail");
                    }
                    else {
                        System.out.printf("교차 검증 결과 Fail");
                    }
                    continue;
                }
                else {
                    System.out.printf("미검수 상태");
                    continue;
                }
                
                // good인 목록 및 best 처리
                String bestYN = "";
                String goodFileName = "";
                ArrayList<String> goodList = new ArrayList<String>();
                String bestFileName = "";
                String testLoc = "";
                String testLocList = "";
                String bestLoc = "";
                
                sqlGood  = " SELECT BEST_YN, DATA_ITEM_VAL, TEST_LOC";
                sqlGood += " FROM   WKV_LUNGSOUND_LIST      ";
                sqlGood += " WHERE  PROJ_CD = '" + projectCode + "'";
                sqlGood += " AND    TASK_CD = '" + taskCode + "'";
                sqlGood += " AND    CASE_NO = '" + taskCaseNo + "'";
                sqlGood += " AND    GOOD_YN = 'Y'           ";
                sqlGood += " ORDER BY TEST_LOC ";
                
                rsGood = db.selectSQL(sqlGood);
                
                while (rsGood.next())
                {
                    bestYN = rsGood.getString("BEST_YN");
                    goodFileName = rsGood.getString("DATA_ITEM_VAL");
                    testLoc = rsGood.getString("TEST_LOC");
                    testLocList = testLocList + "," + testLoc; 
                    /*
                    System.out.println();
                    System.out.printf("\t BEST_YN     : %s\n", bestYN);
                    System.out.printf("\t FILE NAME   : %s\n", goodFileName);
                    */
                    
                    // good 리스트에 추가
                    goodList.add(goodFileName);
                    
                    // best 파일명 저장
                    if (bestYN.compareTo("Y") == 0) {
                        bestFileName = goodFileName;
                        bestLoc = testLoc;
                    }
                }
                    
                if (rsGood != null) {
                    rsGood.close();
                }

                String patientCodeDir = "";
                
                try {     

                    // 기존 객체 클리어
                    LungsoundResultMapObject.clear();
                    
                    // good, best, description put
                    LungsoundResultMapObject.put("good", goodList.toArray());
                    LungsoundResultMapObject.put("best", bestFileName);
                    LungsoundResultMapObject.put("description", description);
                    
                    // 먼저 환자 코드 추출, 앞 3자리
                    String patientcode = taskCaseNo.substring(0, 3);
                    
                    // 기존 JSON 파일 설정
                    String jsonFilePathString = Paths.get(dataRootPath, dataDir, taskCaseNo, annotationFileName).toString().replace("\\", "/");

                    // 존재하지 않으면 상위 디렉토리가 patient code일수 있으므로 변경해서 찾아본다
                    if (!isExistFile(jsonFilePathString)) {
                        patientCodeDir = patientcode;
                        jsonFilePathString = Paths.get(dataRootPath, dataDir, patientCodeDir, taskCaseNo, annotationFileName).toString().replace("\\", "/");
                    }

                    // 기존에 저장된 순서를 유지하기 위하여 JSONObject대신 LinkedHashMap 타입으로 읽어옴
                    LinkedHashMap map = mapper.readValue(new File(jsonFilePathString), LinkedHashMap.class); 
                 
                    // 라벨링 결과 오브젝트가 있는지 체크하고 있으면 replace, 없으면 두번째(index:1)에 추가
                    if (map.containsKey("Lungsound_Result")) {
                        map.replace("Lungsound_Result", LungsoundResultMapObject);
                    }
                    else {
                        map.put("Lungsound_Result", LungsoundResultMapObject);
                    }

                    // 라벨링 결과 디렉토리 설정

                    Path resultDirPath = Paths.get(resultRootPath, "lungsound", todayYYYYMMDD, patientcode, taskCaseNo);
                    String resultDirPathString = resultDirPath.toString().replace("\\", "/");
                    File resultDir = new File(resultDirPathString);
                    
                    // 기존에 라벨링 결과 디렉토리가 있으면 삭제.
                    if (resultDir.exists()) {
                        // 파일이던 디렉토리이던 무조건 삭제
                        FileUtils.forceDelete(resultDir);
                    }
                    
                    // 라벨링 결과 디렉토리 생성
                    resultDir.mkdirs();
                    
                    // -------------------------------------------------------------------------------
                    // 디렉토리 통으로 일단 복사 후 JSON 파일만 새로 생성하여 엎어침
                    // -------------------------------------------------------------------------------
                    //File sourceDir = new File(Paths.get(dataRootPath, dataDir, patientCodeDir, taskCaseNo).toString().replace("\\", "/"));
                    // FileUtils.copyDirectory(sourceDir, resultDir);
                    
                    // 결과 디렉토리에 good 파일 목록 복사
                    for (int i = 0; i < goodList.size(); i++) {
                    	File srcFile = new File(Paths.get(dataRootPath, dataDir, goodList.get(i)).toString().replace("\\", "/"));
						FileUtils.copyFileToDirectory(srcFile, resultDir);
                    }
                    
                    
                    // 라벨링 결과 JSON 파일 설정
                    String jsonNewFilePathString = Paths.get(resultDirPathString, annotationFileName).toString().replace("\\", "/");
                    
                    // 라벨링 결과를 결과 디렉토리 경로의 파일명에 저장 후 close
                    PrintWriter pWriter = new PrintWriter(jsonNewFilePathString);
                    JsonWriter jWriter = gson.newJsonWriter(pWriter);
                    jWriter.setIndent("    ");
                    gson.toJson(map, LinkedHashMap.class, jWriter);
                    pWriter.println();
                    jWriter.flush();
                    jWriter.close();
                    pWriter.flush();
                    pWriter.close();
                    
                    updatePLT_TASK_CASE(taskCaseNo);  
                    
                    System.out.printf("Best=%s,Good=[%s],Desc=%s", bestLoc, testLocList.substring(1), description);
                    
                    complete_cnt += 1;
                    
                }
                catch (FileNotFoundException e1) {
                    System.out.println("\tAnnotation 파일이 없습니다.(파일명 = " + annotationFileName + ")");
                } 
                catch (IOException e2) {
                    System.out.println("\t--- IOException");
                    e2.printStackTrace();
                } 
                catch (Exception e4) {
                    System.out.println("\t--- Exception e");
                    e4.printStackTrace();
                }
            }
            
            System.out.println();
            System.out.println();
            System.out.println(" Target 디렉토리 경로 : " + Paths.get(resultRootPath, "lungsound", todayYYYYMMDD).toString().replace("\\", "/"));

            
        }
        catch (SQLException se) 
        {
            System.out.println("\tError SQL : " + sql);
            se.printStackTrace();
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (rsGood != null) {
                    rsGood.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
        
        return true;
        
    }

    // ---------------------------------------------------------------------------------------------------------------------------
    // 케이스 마스터에 JSON 파일 생성했다는 표시 
    // ---------------------------------------------------------------------------------------------------------------------------
    public static void updatePLT_TASK_CASE(String caseNo) {
        
        String sql = "";
        
        sql  = " UPDATE PLT_TASK_CASE              ";
        sql += " SET    CRE_JSON_FG  = 'Y',        ";
        sql += "        CRE_JSON_DT  = SYSDATE     ";
        sql += " WHERE  PROJ_CD      = '" + projectCode + "'";
        sql += " AND    TASK_CD      = '" + taskCode + "'";
        sql += " AND    CASE_NO      = '" + caseNo + "'";
        
        if (!db.executeSQL(sql, sqlResult)) {
            System.out.println("\tError SQL : " + sql);
            System.out.println("\t에러가 발생하여 프로그램을 종료합니다.");
            db.Close(true);
            printDotTimer.cancel();
            System.exit(1);
        }

        return;
        
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 생성한 파일의 접근 권한 변경
    // --------------------------------------------------------------------------------------------------------
    public static void allowPermission(String fileName) {
        
        if (SystemUtils.IS_OS_WINDOWS) {
            return;
        }
        try {
            File targetFile = new File(fileName);
            if(targetFile.exists()){
                Path p = Paths.get(fileName);
                Set<PosixFilePermission> posixPermissions = PosixFilePermissions.fromString("rw-r--r--");
                Files.setPosixFilePermissions(p, posixPermissions);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
            System.out.println("\t파일 권한 설정 에러 : " + fileName);
            db.Close(true);
            printDotTimer.cancel();
            System.exit(1);
        }
    }
    

    // --------------------------------------------------------------------------------------------------------
    // 파일 존재 여부 체크
    // --------------------------------------------------------------------------------------------------------
    public static boolean isExistFile(String filePath) {
        
        boolean exist = false;
        
        try {
            File file = new File(filePath);

            if (file.exists()) {
                exist = true; 
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return exist;
    }
    
    public static String getYYYYMMDD(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        return simpleDateFormat.format(date);
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 화면상에 진행상황을 표시하기 위하여 점(.) 찍기
    // --------------------------------------------------------------------------------------------------------
    public static void printDotThread() {
        
        while(true) {
            try {
                System.out.print(".");
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    // --------------------------------------------------------------------------------------------------------
    // json 파일에서 문자값 읽어오기
    // --------------------------------------------------------------------------------------------------------
    public static String getStringFromJson(String key, JSONObject object) {
        try {
            if (object.containsKey(key)) {
                Object obj = object.get(key);
                if (obj instanceof String) {
                    return (String) obj;
                }
                else {
                    System.out.printf("\t\tJson parsing warning = %s: %s\n", key, String.valueOf(obj));
                }
            }
            else {
                System.out.printf("\t\tJson parsing warning = key %s not found\n", key);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.printf("\t\tJson parsing error = key %s\n", key);
        }
        return "";
    }
    
    // --------------------------------------------------------------------------------------------------------
    // json 파일에서 숫자값 읽어오기
    // --------------------------------------------------------------------------------------------------------
    public static Number getNumberFromJson(String key, JSONObject object) {
        
        try {
            if (object.containsKey(key)) {
                Object obj = object.get(key);
                if (obj instanceof Number ) {
                    return (Number) obj;
                }
                else {
                    System.out.printf("\t\tJson parsing warning = %s: %s\n", key, String.valueOf(obj));
                    return null;
                }
            }
            else {
                System.out.printf("\t\tJson parsing warning = key %s not found\n", key);
                return null;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.printf("\t\tJson parsing error = key %s\n", key);
        }
        return 0;
    }


    public static void putKeyVaue(LinkedHashMap<String, Object> input, int index, String key, Object value) {

        if (index >= 0 && index <= input.size()) {
            LinkedHashMap<String, Object> output=new LinkedHashMap<String, Object>();
            int i = 0;
            if (index == 0) {
                output.put(key, value);
                output.putAll(input);
            } 
            else {
                for (Map.Entry<String, Object> entry : input.entrySet()) {
                    if (i == index) {
                        output.put(key, value);
                    }
                    output.put(entry.getKey(), entry.getValue());
                    i++;
                }
            }
            if (index == input.size()) {
                output.put(key, value);
            }
            input.clear();
            input.putAll(output);
            output.clear();
            output = null;
        } 
        else {
            throw new IndexOutOfBoundsException("index " + index + " must be equal or greater than zero and less than size of the map");
        }
    }
}
