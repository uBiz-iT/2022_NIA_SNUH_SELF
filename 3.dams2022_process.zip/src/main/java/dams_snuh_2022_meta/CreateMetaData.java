package dams_snuh_2022_meta;


import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
// properties 처리
import java.util.Properties;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.lang3.SystemUtils;
import org.apache.commons.lang3.time.DurationFormatUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;

//-----------------------------------------------------------------------------------------------------------------
// 정제된 원천데이터, 원시데이터 및 어노테이션 파일(JSON) 등을 읽어서 DB에 넣는 프로그램
// 일반적으로 어노테이션 파일에서 정보를 읽어서 DB에 반영하고
// 원시/원천 데이터의 경우에는 LINK 정보만 DB에 반영함
//-----------------------------------------------------------------------------------------------------------------
public class CreateMetaData 
{
    static String projectCode = "";
    static String taskCode = "";
    static String dataDir = "";
    static boolean noedfupdate = false;;
    
    // 오라클 연결 및 SQL문 실행
    static db_oracle db = null;      

    static int update_cnt = 0;
    static int insert_cnt = 0;
    static int error_cnt = 0;
    static int event_update_cnt = 0;
    static int event_insert_cnt = 0; 
    static int image_update_cnt = 0;
    static int image_insert_cnt = 0; 
    
    static String dataRootPath = "";

    static String configFileName = "";
    static String db_user = "";
    static String db_passwd = "";
    static String db_connString = "";
    static SQLResult sqlResult = new SQLResult();
    
    static TarFiles tar = null; 
    
    // 화면에 dot(.)을 출력하기 위하여
    static boolean isPrintDot = false;
    static Timer printDotTimer = new Timer();
    static TimerTask printDotTimerTask = new TimerTask() {
        @Override
        public void run() {
            if (isPrintDot) {
                System.out.print(".");
            }
        }
    };
    
    static Number nullCheckNum = 0;
    
    public static void main(String[] args) 
    {

        if (args.length <= 2) {
            System.out.println("Task 코드를 입력하세요.");
            return;
        }
        
        // 1번째(배열 0) 인자가 설정 파일 이름
        // 2번째(배열 1) 인자는 프로젝트 코드
        configFileName = args[0];
        
        // 4번째(배열 3) 인자는 edf 통계 파일을 만들것인지 체크(edf 파일이 변경되지 않고 다른 것이 변경되어 다시 작업할 경우 시간 단축을 위할 때 사용)
        if (args.length == 4) {
            noedfupdate = args[3].toUpperCase().equals("NOEDFUPDATE") ? true : false;
            System.out.printf("edf 파일 통계 작업 제외? : %s\n", noedfupdate);
        }
        
        if (!ReadProperties()) return;
        
        if (!ConnectDB()) return;
        
        tar = new TarFiles();
        
        printDotTimer.schedule(printDotTimerTask, 1000, 1000);

        try
        {
            db.conn.setAutoCommit(false);
            
            // -------------------------------------------------------------------------------
            // 프로젝트, Task의 데이터 디렉토리 정보 읽어옴
            // -------------------------------------------------------------------------------
            String sql = "";
            sql  = " SELECT PROJ_CD, TASK_CD, DATA_DIR";
            sql += " FROM   PLT_TASK";
            sql += " WHERE  PROJ_CD = '" + args[1] + "'";
            sql += " AND    TASK_CD = '" + args[2] + "'";
            
            ResultSet rs = db.selectSQL(sql);
            
            System.out.println("");
            System.out.printf(" 프로젝트 %s, Task %s의 메타 데이터를 데이터베이스에 생성합니다.", args[1], args[2]);
            System.out.println("");

            boolean exist_task = false;
            while(rs.next())
            {
                projectCode = rs.getString("PROJ_CD");
                taskCode = rs.getString("TASK_CD");
                dataDir = rs.getString("DATA_DIR");
                exist_task = true;
                break;
            }
            
            rs.close();
            db.pstmt.close();

            // -------------------------------------------------------------------------------
            // Task가 없으면 종료
            // -------------------------------------------------------------------------------
            if (!exist_task) {
                System.out.println(" 입력된 Task 코드가 없습니다.");
                db.Close();
                printDotTimer.cancel();
                return;
            }
            
            if (dataDir == null) {
                System.out.println(" Task 코드 등록시 Task 데이터 디렉토리 경로가 입력되지 않았습니다.");
                db.Close();
                printDotTimer.cancel();
                return;
            }

            Path filePath = Paths.get(dataRootPath, dataDir);
            System.out.println(" Task 데이터 디렉토리 경로 : " + filePath.toString());
            System.out.println();

            File dataRoot = new File(filePath.toString());

            // -------------------------------------------------------------------------------
            // 프로젝트 데이터 디렉토리가 존재하는지 체크하여 없으면 종료
            // -------------------------------------------------------------------------------
            if(!dataRoot.exists())
            {
                System.out.println(" 데이터 경로 " + dataDir + "이 존재하지 않습니다.");
                db.Close();
                printDotTimer.cancel();
                return;
            }
            
            // -------------------------------------------------------------------------------
            // 데이터 디렉토리 Path가 디렉토리가 아니면 종료
            // -------------------------------------------------------------------------------
            if(!dataRoot.isDirectory())
            {
                System.out.println(" 데이터 파일 경로가 디렉토리가 아닙니다.");
                db.Close();
                printDotTimer.cancel();
                return;
            }

            // -------------------------------------------------------------------------------
            // 이미 테이블에 있는 CASE 목록 테이블의 컬럼 AUTO_LOAD_FG의 값을 'N'으로 전체 변경
            // 향후에 'N'으로 남아 있는 놈은 테이블에서 삭제 대상
            // -------------------------------------------------------------------------------
            sql  = " UPDATE PLT_TASK_CASE";
            sql += " SET    AUTO_LOAD_FG = 'N'";
            sql += " WHERE  PROJ_CD = '" + projectCode + "'";
            sql += " AND    TASK_CD = '" + taskCode + "'";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println(" Error SQL : " + sql);
                System.out.println(" 에러가 발생하여 프로그램을 종료합니다.");
                db.Close();
                printDotTimer.cancel();
                System.exit(1);
            }

            File[] dataRootFileList = dataRoot.listFiles();
            Arrays.sort(dataRootFileList);

            // -------------------------------------------------------------------------------
            // CASE 디렉토리 하나씩 검색
            // -------------------------------------------------------------------------------
            for(File caseRoot : dataRootFileList)
            {   
                // 디렉토리가 아닌 것은 처리할 필요가 없음
                if(!caseRoot.isDirectory())
                {
                    continue;
                }

                System.out.println("--------------------------------------------------------------------");
                System.out.printf(" Case Number : %s\n", caseRoot.getName());
                System.out.println("--------------------------------------------------------------------");

                switch (caseRoot.getName())
                {   
                    case "result":          // 향후 진단 결과를 오노테이션 파일에 반영이 필요할 경우에 사용 예정
                        break;
                    
                    default:                
                        switch (projectCode) 
                        {   
                            case "2022A1":  // 수면 데이터의 경우
                                if (!manageSleepCaseDirectory(caseRoot)) {
                                	error_cnt = error_cnt + 1; 
                                };
                                break;
                            
                            case "2022B1":  // 폐기능 데이터의 경우

                                // 3자리이면 patient code 디렉토리임. 그 밑에 case 목록이 있음. 어떻게 할지 정해지지 않아서 바로 case가 나올경우, 환자 코드가 나올경우를 각각 대비
                                if (caseRoot.getName().length() == 3) {
                                    File[] taskRootFileList = caseRoot.listFiles();
                                    Arrays.sort(taskRootFileList);
                                    
                                    for(File innerCaseRoot : taskRootFileList) {
                                        // 디렉토리가 아닌 것은 처리할 필요가 없음
                                        if(!innerCaseRoot.isDirectory())
                                        {
                                            continue;
                                        }
                                        
                                        System.out.println("--------------------------------------------------------------------");
                                        System.out.printf(" Case Number : %s\n", innerCaseRoot.getAbsolutePath());
                                        System.out.println("--------------------------------------------------------------------");
                                        
                                        if (!managePftCaseDirectory(innerCaseRoot, caseRoot.getName())) {
                                        	error_cnt = error_cnt + 1; 
                                        }
                                        
                                    }
                                }
                                else {
                                    if (!managePftCaseDirectory(caseRoot, "")) {
                                    	error_cnt = error_cnt + 1; 
                                    }
                                }
                                
                                break;
                                
                            case "2022B2":  // 폐음 데이터의 경우

                                // 3자리이면 patient code 디렉토리임. 그 밑에 case 목록이 있음
                                if (caseRoot.getName().length() == 3) {
                                    File[] taskRootFileList = caseRoot.listFiles();
                                    Arrays.sort(taskRootFileList);
                                    
                                    for(File innerCaseRoot : taskRootFileList) {
                                        // 디렉토리가 아닌 것은 처리할 필요가 없음
                                        if(!innerCaseRoot.isDirectory())
                                        {
                                            continue;
                                        }
                                        
                                        System.out.println("--------------------------------------------------------------------");
                                        System.out.printf(" Case Number : %s\n", innerCaseRoot.getName());
                                        System.out.println("--------------------------------------------------------------------");
                                        
                                        if (!manageLungSoundCaseDirectory(innerCaseRoot, caseRoot.getName())) {
                                        	error_cnt = error_cnt + 1; 
                                        }
                                        
                                    }
                                }
                                else {
                                    if (!manageLungSoundCaseDirectory(caseRoot, "")) {
                                    	error_cnt = error_cnt + 1; 
                                    }
                                }
                                
                                break;
                            default:
                                System.out.printf(" 프로젝트 코드가 없습니다. : " + projectCode);
                                db.Close();
                                printDotTimer.cancel();
                                System.exit(1);
                                break;
                        }
                        break;
                } 
                
                // case 1개마다 commit 하자
                db.conn.commit();
            } 
            
            // 그럴일이 없어서 삭제하지 않는 것으로 수정 20220922
            // -------------------------------------------------------------------------------
            // CASE 목록 테이블에서 AUTO_LOAD_FG = 'N'로 여전히 있는 놈에 해당하는 진단/검수 결과 테이블들 삭제하러 감
            // -------------------------------------------------------------------------------
            //deleteResultData();
            
            // -------------------------------------------------------------------------------
            // CASE 목록 테이블에서 AUTO_LOAD_FG = 'N'로 여전히 있는 놈은 삭제
            // -------------------------------------------------------------------------------
            // 그럴일이 없어서 삭제하지 않는 것으로 수정 20220922
            
            /*
            sql  = " DELETE FROM PLT_TASK_CASE";
            sql += " WHERE  PROJ_CD = '" + projectCode + "'";
            sql += " AND    TASK_CD = '" + taskCode + "'";
            sql += " AND    AUTO_LOAD_FG = 'N'";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println(" Error Code : " + sql);
                System.out.println(" Error SQL  : " + sql);
                System.out.println(" 에러가 발생하여 프로그램을 종료합니다.");
                db.Close(true);
                printDotTimer.cancel();
                System.exit(1);
            } 
            */

            System.out.println();
            System.out.println(" " + update_cnt + "개의 CASE 데이터가 수정되었습니다.");
            System.out.println(" " + insert_cnt + "개의 CASE 데이터가 등록되었습니다.");
            System.out.println(" " + error_cnt + "개의 CASE 데이터에서 오류가 발생하였습니다.");

            db.conn.commit();
        }
        catch (SQLException e)
        {
            System.out.println(" main() SQLException");
            e.printStackTrace();
        }
        catch (Exception e)
        {
            System.out.println(" main() Exception");
            e.printStackTrace();
        }
        
        // dot 출력 타이머 취소
        printDotTimer.cancel();
        
        db.Close(true);
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 설정 파일 읽기(DB 접속 정보 및 이미지 루트 경로)
    // --------------------------------------------------------------------------------------------------------
    private static boolean ReadProperties() 
    {
        try 
        {
            Properties pro = new Properties();

            InputStream is = new FileInputStream(configFileName);
            pro.load(is);

            db_connString = pro.getProperty("connectionString");
            db_user = pro.getProperty("userid");
            db_passwd = pro.getProperty("passwd");
            dataRootPath = pro.getProperty("dataRootDir");
            
            return true;
        }
        catch (IOException e) 
        {
            System.out.println(" ReadProperties() IOException");
            e.printStackTrace();
            return false;
        }
        catch (Exception e) 
        {
            System.out.println(" ReadProperties() Exception");
            e.printStackTrace();
            return false;
        }
        
    }
    

    // --------------------------------------------------------------------------------------------------------
    // 데이터베이스 연결
    // --------------------------------------------------------------------------------------------------------
    private static boolean ConnectDB() 
    {
        try 
        {
            String url = db_connString;
            String user = db_user;
            String password = db_passwd;
            
            db = new db_oracle(url, user, password);
            if (db.conn == null) return false;
            else return true;
            
        }
        catch (Exception e) 
        {
            System.out.println(" connectDB() Exception");
            e.printStackTrace();
            return false;
        }
        
    }

    
    // --------------------------------------------------------------------------------------------------------
    // 삭제된 case 관련 진단/검수 실적 테이블 들 삭제하기
    // --------------------------------------------------------------------------------------------------------
    private static void deleteResultData() {

        String sql = "";
        
        try
        {
            // -------------------------------------------------------------------------------
            // CASE 목록 테이블에서 AUTO_LOAD_FG = 'N'로 여전히 있는 놈에 해당하는 진단/검수 결과 삭제
            // -------------------------------------------------------------------------------
            // 검수 FAIL 사유 삭제 1
            // -------------------------------------------------------------------------------
            sql  = " DELETE FROM WKT_FAIL_INSP";
            sql += " WHERE  PROJ_CD = '" + projectCode + "'";
            sql += " AND    TASK_CD = '" + taskCode + "'";
            sql += " AND    CASE_NO IN (SELECT CASE_NO";
            sql += "                    FROM   PLT_TASK_CASE";
            sql += "                    WHERE  PROJ_CD   = '" + projectCode + "'";
            sql += "                    AND    TASK_CD   = '" + taskCode + "'";
            sql += "                    AND    AUTO_LOAD_FG = 'N')";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println(" Error SQL : " + sql);
                System.out.println(" 에러가 발생하여 프로그램을 종료합니다.");
                db.Close(true);
                printDotTimer.cancel();
                System.exit(1);
            }
            
            // -------------------------------------------------------------------------------
            // 진단 FAIL 사유 삭제 2
            // -------------------------------------------------------------------------------
            sql  = " DELETE FROM WKT_FAIL_DIAG";
            sql += " WHERE  PROJ_CD = '" + projectCode + "'";
            sql += " AND    TASK_CD = '" + taskCode + "'";
            sql += " AND    CASE_NO IN (SELECT CASE_NO";
            sql += "                    FROM   PLT_TASK_CASE";
            sql += "                    WHERE  PROJ_CD   = '" + projectCode + "'";
            sql += "                    AND    TASK_CD   = '" + taskCode + "'";
            sql += "                    AND    AUTO_LOAD_FG = 'N')";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println(" Error SQL : " + sql);
                System.out.println(" 에러가 발생하여 프로그램을 종료합니다.");
                db.Close(true);
                printDotTimer.cancel();
                System.exit(1);
            }
            
            // -------------------------------------------------------------------------------
            // 폐음 라벨링 결과 삭제 3
            // -------------------------------------------------------------------------------
            sql  = " DELETE FROM WKT_GOOD_LUNGSOUND";
            sql += " WHERE  PROJ_CD = '" + projectCode + "'";
            sql += " AND    TASK_CD = '" + taskCode + "'";
            sql += " AND    CASE_NO IN (SELECT CASE_NO";
            sql += "                    FROM   PLT_TASK_CASE";
            sql += "                    WHERE  PROJ_CD   = '" + projectCode + "'";
            sql += "                    AND    TASK_CD   = '" + taskCode + "'";
            sql += "                    AND    AUTO_LOAD_FG = 'N')";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println(" Error SQL : " + sql);
                System.out.println(" 에러가 발생하여 프로그램을 종료합니다.");
                db.Close(true);
                printDotTimer.cancel();
                System.exit(1);
            }
            
            // -------------------------------------------------------------------------------
            // 검수 결과 삭제 4
            // -------------------------------------------------------------------------------
            sql  = " DELETE FROM WKT_TASK_INSP";
            sql += " WHERE  PROJ_CD = '" + projectCode + "'";
            sql += " AND    TASK_CD = '" + taskCode + "'";
            sql += " AND    CASE_NO IN (SELECT CASE_NO";
            sql += "                    FROM   PLT_TASK_CASE";
            sql += "                    WHERE  PROJ_CD   = '" + projectCode + "'";
            sql += "                    AND    TASK_CD   = '" + taskCode + "'";
            sql += "                    AND    AUTO_LOAD_FG = 'N')";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println(" Error SQL : " + sql);
                System.out.println(" 에러가 발생하여 프로그램을 종료합니다.");
                db.Close(true);
                printDotTimer.cancel();
                System.exit(1);
            }
            
            // -------------------------------------------------------------------------------
            // 진단 결과 삭제 5
            // -------------------------------------------------------------------------------
            sql  = " DELETE FROM WKT_TASK_DIAG";
            sql += " WHERE  PROJ_CD = '" + projectCode + "'";
            sql += " AND    TASK_CD = '" + taskCode + "'";
            sql += " AND    CASE_NO IN (SELECT CASE_NO";
            sql += "                    FROM   PLT_TASK_CASE";
            sql += "                    WHERE  PROJ_CD   = '" + projectCode + "'";
            sql += "                    AND    TASK_CD   = '" + taskCode + "'";
            sql += "                    AND    AUTO_LOAD_FG = 'N')";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println(" Error SQL : " + sql);
                System.out.println(" 에러가 발생하여 프로그램을 종료합니다.");
                db.Close(true);
                printDotTimer.cancel();
                System.exit(1);
            }
        }
        catch (Exception e)
        {
            System.out.println(" deleteMetaData() Exception");
            e.printStackTrace();
        }
        
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 수면 데이터 읽어오기
    // --------------------------------------------------------------------------------------------------------
    public static boolean manageSleepCaseDirectory(File caseRoot) 
    {
        String caseNo = caseRoot.getName();
        AnnotationSleep annotationSleep = new AnnotationSleep();
        JSONParser parser = new JSONParser();
        
        annotationSleep.caseNumber = caseNo;
        
        String annotationFileName = caseNo + ".json";
        String edfFileName = caseNo + "-raw.edf";
        String avgFileName = caseNo + "-raw-avg.csv";

        try {     
            
            String jsonPath = Paths.get(dataRootPath, dataDir, caseNo, annotationFileName).toString().replace("\\", "/");
            
            System.out.println("\tAnnotation 파일명 : " + caseNo + ".json");
            
            FileReader jsonFile = new FileReader(jsonPath);
            
            Object obj = parser.parse(jsonFile);

            JSONObject jsonObject =  (JSONObject) obj;

            // -----------------------------------------------------------------------------
            // Case_Info 객체 read
            // -----------------------------------------------------------------------------
            JSONObject caseInfo = (JSONObject) jsonObject.get("Case_info");
            annotationSleep.caseGroupId = getStringFromJson("Case_Number", caseInfo);

            // -----------------------------------------------------------------------------
            // Report
            // -----------------------------------------------------------------------------
            JSONObject report = (JSONObject) jsonObject.get("Report");
            
            annotationSleep.gender = getStringFromJson("Sex", report);
            annotationSleep.age = String.valueOf(getNumberFromJson("Age", report));

            // 베르린에서 사용하기 위하여 숫자 형식으로 저장
            Float bmi = getNumberFromJson("BMI", report).floatValue(); 

            annotationSleep.bmi = String.valueOf(bmi);
            annotationSleep.tot_sleep_time = String.valueOf(getNumberFromJson("Total_Sleep_Time(TST)", report));
            annotationSleep.sleep_effi = String.valueOf(getNumberFromJson("Sleep_Efficiency", report));
            annotationSleep.sleep_latency = String.valueOf(getNumberFromJson("Sleep_Latency", report));
            annotationSleep.ahi = String.valueOf(getNumberFromJson("AHI", report));
            annotationSleep.rdi = String.valueOf(getNumberFromJson("RDI", report));
            annotationSleep.oxy_satu_avg = String.valueOf(getNumberFromJson("Mean_Oxygen_Saturation", report));
            annotationSleep.oxy_satu_min = String.valueOf(getNumberFromJson("Lowest_Oxygen_Desaturation", report));
            annotationSleep.tot_lm_index = String.valueOf(getNumberFromJson("Total_LM_Index", report));
            annotationSleep.tot_lm_arou = String.valueOf(getNumberFromJson("Total_LM_Arousal_Index", report));
            annotationSleep.arou_index =String.valueOf( getNumberFromJson("Total_Arousal_Index", report));

            // -----------------------------------------------------------------------------
            // Survey
            // -----------------------------------------------------------------------------
            JSONObject survey = (JSONObject) jsonObject.get("Sleep_Questionnaire");

            // PSQI
            JSONObject surveyPSQI = (JSONObject) survey.get("PSQI");

            String psqiQ1 = getStringFromJson("PSQI_Q1", surveyPSQI);
            String psqiQ2 = getStringFromJson("PSQI_Q2", surveyPSQI); 
            String psqiQ3 = getStringFromJson("PSQI_Q3", surveyPSQI); 
            String psqiQ4 = getStringFromJson("PSQI_Q4", surveyPSQI); 

            Integer psqiQ51 = getNumberFromJson("PSQI_Q5-1", surveyPSQI).intValue(); 
            Integer psqiQ52 = getNumberFromJson("PSQI_Q5-2", surveyPSQI).intValue(); 
            Integer psqiQ53 = getNumberFromJson("PSQI_Q5-3", surveyPSQI).intValue(); 
            Integer psqiQ54 = getNumberFromJson("PSQI_Q5-4", surveyPSQI).intValue(); 
            Integer psqiQ55 = getNumberFromJson("PSQI_Q5-5", surveyPSQI).intValue(); 
            Integer psqiQ56 = getNumberFromJson("PSQI_Q5-6", surveyPSQI).intValue(); 
            Integer psqiQ57 = getNumberFromJson("PSQI_Q5-7", surveyPSQI).intValue(); 
            Integer psqiQ58 = getNumberFromJson("PSQI_Q5-8", surveyPSQI).intValue(); 
            Integer psqiQ59 = getNumberFromJson("PSQI_Q5-9", surveyPSQI).intValue(); 
            Integer psqiQ510 = getNumberFromJson("PSQI_Q5-10", surveyPSQI).intValue(); 
            String psqiQ511 = getStringFromJson("PSQI_Q5-11", surveyPSQI);              // 510에 대한 기타 이유 문자열
            Integer psqiQ6 = getNumberFromJson("PSQI_Q6", surveyPSQI).intValue(); 
            Integer psqiQ7 = getNumberFromJson("PSQI_Q7", surveyPSQI).intValue(); 
            Integer psqiQ8 = getNumberFromJson("PSQI_Q8", surveyPSQI).intValue(); 
            Integer psqiQ9 = getNumberFromJson("PSQI_Q9", surveyPSQI).intValue();
            
            annotationSleep.PSQI_Q1 = psqiQ1; 
            annotationSleep.PSQI_Q2 = psqiQ2;  
            annotationSleep.PSQI_Q3 = psqiQ3;  
            annotationSleep.PSQI_Q4 = psqiQ4;  
            annotationSleep.PSQI_Q5_1 = psqiQ51.toString(); 
            annotationSleep.PSQI_Q5_2 = psqiQ52.toString(); 
            annotationSleep.PSQI_Q5_3 = psqiQ53.toString(); 
            annotationSleep.PSQI_Q5_4 = psqiQ54.toString(); 
            annotationSleep.PSQI_Q5_5 = psqiQ55.toString(); 
            annotationSleep.PSQI_Q5_6 = psqiQ56.toString(); 
            annotationSleep.PSQI_Q5_7 = psqiQ57.toString(); 
            annotationSleep.PSQI_Q5_8 = psqiQ58.toString(); 
            annotationSleep.PSQI_Q5_9 = psqiQ59.toString(); 
            annotationSleep.PSQI_Q5_10 = psqiQ510.toString(); 
            annotationSleep.PSQI_Q5_11 = psqiQ511; 
            annotationSleep.PSQI_Q6 = psqiQ6.toString();  
            annotationSleep.PSQI_Q7 = psqiQ7.toString();  
            annotationSleep.PSQI_Q8 = psqiQ8.toString();  
            annotationSleep.PSQI_Q9 = psqiQ9.toString();  
            
            Integer psqiScore = 0;
            
            // 1. 주관적 수면의 질(0 ~ 3)
            System.out.println("\tScoring PSQI, ESS, Baerlin~");
            System.out.printf("\tPSQI Q1=%s, Q2=%s, Q2=%s, Q2=%s\n", psqiQ1, psqiQ2, psqiQ3, psqiQ4);
            System.out.printf("\tPSQI C1   : %d\n", psqiQ6);
            
            psqiScore += psqiQ6;
            
            // 2. 수면 잠복기
            // 잠자리에 든 후 잠들기 까지의 시간 체크한 결과 체크(15분 이하, 30분 이하, 1시간 이하, 1시간 초과로 구분)
            Integer sleepLatency = 0;
            if (psqiQ2.compareTo("00:15:00") <= 0) sleepLatency = 0;  
            else if (psqiQ2.compareTo("00:30:00") <= 0) sleepLatency = 1;
            else if (psqiQ2.compareTo("01:00:00") <= 0) sleepLatency = 2;
            else sleepLatency = 3;
            
            // 취침후 30분 이내에 잠들수 없었다 (0 ~ 3) 점수를 더함
            Integer C2Base = sleepLatency + psqiQ51;
            
            // 더한 값에 따라 최종 점수 계산(5이상, 3이상, 1이상으로 구분)
            Integer C2Value = 0;
            if (C2Base >= 5) C2Value = 3;
            else if (C2Base >= 3) C2Value = 2;
            else if (C2Base >= 1) C2Value = 1;  

            System.out.printf("\tPSQI C2   : %d (%d = %d+%d)\n", C2Value, C2Base, sleepLatency, psqiQ51);
            
            psqiScore += C2Value;
            
            // 3. 수면 시간(실제 잠든 시간 체크, 5시간 미만, 6시간 미만, 7시간 미만, 7시간 이상으로 구분)
            Integer C3Value = 0;
            if (psqiQ4.compareTo("05:00:00") < 0) C3Value = 3;  
            else if (psqiQ4.compareTo("06:00:00") < 0) C3Value = 2;  
            else if (psqiQ4.compareTo("07:00:00") < 0) C3Value = 1;  

            System.out.println("\tPSQI C3   : " + C3Value);
            
            psqiScore += C3Value;

            // 4. 평소의 수면 효율
            try {
                
                DateTimeFormatter jsonDateFormat = DateTimeFormatter.ofPattern("yyyyMMddHH:mm:ss").withLocale(Locale.US);
                
                LocalDateTime fromDateTime = LocalDateTime.parse("20220101"+psqiQ1, jsonDateFormat);
                LocalDateTime toDateTime = LocalDateTime.parse("20220101"+psqiQ3, jsonDateFormat);
                
                // 잠자러 눕는 시간이 늦으면 전일 날짜로 해야 함.
                if (fromDateTime.compareTo(toDateTime) > 0) {
                    fromDateTime = fromDateTime.minusDays(1);
                }
                
                // 누운 시간과 깨는 시간의 차이
                int bedSeconds = (int) Duration.between(fromDateTime, toDateTime).getSeconds();
                
                // 순수 잠자는 시간
                int sleepSeconds = Integer.parseInt(psqiQ4.substring(0, 2)) * 60 * 60;
                sleepSeconds += Integer.parseInt(psqiQ4.substring(3, 5)) * 60;
                sleepSeconds += Integer.parseInt(psqiQ4.substring(6, 8));
                
                // 효율
                double sleepEffi = (double)sleepSeconds / (double)bedSeconds * 100;
                
                Integer C4Value = 0;
                
                // 65 미만, 75 미만, 85 미만으로 구분
                if (sleepEffi < 65) C4Value = 3;
                else if (sleepEffi < 75) C4Value = 2;
                else if (sleepEffi < 85) C4Value = 1;
                
                System.out.printf("\tPSQI C4   : %d (%5.1f = %d/%d)\n", C4Value, sleepEffi, sleepSeconds, bedSeconds);
                
                psqiScore += C4Value;
                
            }
            catch (Exception e) {
                System.out.println("\tPSQI 수면시간 오류");
                return false;
            }
            
            // 5. 수면 방해
            Integer sleepDisturbance = psqiQ52 + psqiQ53 + psqiQ54 + psqiQ55 + psqiQ56 + psqiQ57 + psqiQ58 + psqiQ59 + psqiQ510;

            Integer C5Value = 0;
            // 19이상, 10이상, 1이상으로 구분
            if (sleepDisturbance >= 19) C5Value = 3; 
            else if (sleepDisturbance >= 10) C5Value = 2; 
            else if (sleepDisturbance >= 1) C5Value = 1; 

            System.out.printf("\tPSQI C5   : %d (%d = %d+%d+%d+%d+%d+%d+%d+%d+%d)\n", C5Value, sleepDisturbance, psqiQ52, psqiQ53, psqiQ54, psqiQ55, psqiQ56, psqiQ57, psqiQ58, psqiQ59, psqiQ510);

            psqiScore += C5Value;

            // 6. 수면제 약물의 사용
            System.out.println("\tPSQI C6   : " + psqiQ7);
            psqiScore += psqiQ7;                                                            
                        
            // 7. 주간 기능 장애
            Integer C7Value = 0;
            
            // 일상 졸음, 일 방해
            Integer daytimeDysFunction = psqiQ8 + psqiQ9;
            
            // 5이상, 3이상, 1이상으로 구분
            if (daytimeDysFunction >= 5) C7Value = 3; 
            else if (daytimeDysFunction >= 3) C7Value = 2; 
            else if (daytimeDysFunction >= 1) C7Value = 1; 
            
            System.out.printf("\tPSQI C7   : %d (%d = %d+%d)\n", C7Value, daytimeDysFunction, psqiQ8, psqiQ9);

            psqiScore += C7Value;
            
            System.out.printf("\tPSQI Score: %d\n", psqiScore);

            annotationSleep.PSQI_Score = psqiScore.toString();
            
            // ESS
            JSONObject surveyESS = (JSONObject) survey.get("ESS");
            
            Integer essq1 = getNumberFromJson("ESS_Q1", surveyESS).intValue();
            Integer essq2 = getNumberFromJson("ESS_Q2", surveyESS).intValue();
            Integer essq3 = getNumberFromJson("ESS_Q3", surveyESS).intValue();
            Integer essq4 = getNumberFromJson("ESS_Q4", surveyESS).intValue();
            Integer essq5 = getNumberFromJson("ESS_Q5", surveyESS).intValue();
            Integer essq6 = getNumberFromJson("ESS_Q6", surveyESS).intValue();
            Integer essq7 = getNumberFromJson("ESS_Q7", surveyESS).intValue();
            Integer essq8 = getNumberFromJson("ESS_Q8", surveyESS).intValue();
            Integer essq9 = getNumberFromJson("ESS_Q9", surveyESS).intValue();
            Integer essq10 = getNumberFromJson("ESS_Q10", surveyESS).intValue();
            Integer essq11 = getNumberFromJson("ESS_Q11", surveyESS).intValue();
                        
            annotationSleep.ESS_Q1 = essq1.toString();
            annotationSleep.ESS_Q2 = essq2.toString();
            annotationSleep.ESS_Q3 = essq3.toString();
            annotationSleep.ESS_Q4 = essq4.toString();
            annotationSleep.ESS_Q5 = essq5.toString();
            annotationSleep.ESS_Q6 = essq6.toString();
            annotationSleep.ESS_Q7 = essq7.toString();
            annotationSleep.ESS_Q8 = essq8.toString();
            annotationSleep.ESS_Q9 = essq9.toString();
            annotationSleep.ESS_Q10 = essq10.toString();
            annotationSleep.ESS_Q11 = essq11.toString();

            Integer essScore = essq1 + essq2 + essq3 + essq4 + essq5 + essq6 + essq7 + essq8;

            System.out.printf("\tESS Score : %d (Q1=%d, Q2=%d, Q3=%d, Q4=%d, Q5=%d, Q6=%d, Q7=%d, Q8=%d)\n", essScore, essq1, essq2, essq3, essq4, essq5, essq6, essq7, essq8);
            
            annotationSleep.ESS_Score = essScore.toString();
            
            // Berlin
            JSONObject surveyBerlin = (JSONObject) survey.get("Berlin");
            
            Number berlinC11 = getNumberFromJson("Berlin_C1-1", surveyBerlin);
            Number berlinC12 = getNumberFromJson("Berlin_C1-2", surveyBerlin);
            Number berlinC13 = getNumberFromJson("Berlin_C1-3", surveyBerlin);
            Number berlinC14 = getNumberFromJson("Berlin_C1-4", surveyBerlin);
            Number berlinC15 = getNumberFromJson("Berlin_C1-5", surveyBerlin);
            Number berlinC21 = getNumberFromJson("Berlin_C2-1", surveyBerlin);
            Number berlinC22 = getNumberFromJson("Berlin_C2-2", surveyBerlin);
            Number berlinC23 = getNumberFromJson("Berlin_C2-3", surveyBerlin);
            Number berlinC24 = getNumberFromJson("Berlin_C2-4", surveyBerlin);
            Number berlinC31 = getNumberFromJson("Berlin_C3-1", surveyBerlin);
            
            annotationSleep.Berlin_C1_1 = String.valueOf(berlinC11);
            annotationSleep.Berlin_C1_2 = String.valueOf(berlinC12);
            annotationSleep.Berlin_C1_3 = String.valueOf(berlinC13);
            annotationSleep.Berlin_C1_4 = String.valueOf(berlinC14);
            annotationSleep.Berlin_C1_5 = String.valueOf(berlinC15);
            annotationSleep.Berlin_C2_1 = String.valueOf(berlinC21);
            annotationSleep.Berlin_C2_2 = String.valueOf(berlinC22);
            annotationSleep.Berlin_C2_3 = String.valueOf(berlinC23);
            annotationSleep.Berlin_C2_4 = String.valueOf(berlinC24);
            annotationSleep.Berlin_C3_1 = String.valueOf(berlinC31);

            Integer berlinC1Score = 0;
            
            /*
            if (berlinC11.intValue() == 0) {
                berlinC1Score += 1;
                if (berlinC12.intValue() == 2 || berlinC12.intValue() == 3) berlinC1Score += 1;
                if (berlinC13.intValue() == 0 || berlinC13.intValue() == 1) berlinC1Score += 1;
                if (berlinC14.intValue() == 0) berlinC1Score += 1;
                if (berlinC15.intValue() == 0 || berlinC15.intValue() == 1) berlinC1Score += 2;
            }

            System.out.printf("\tBerlin C1 : %d (Q1=%d, Q2=%d, Q3=%d, Q4=%d, Q5=%d)\n", berlinC1Score, berlinC11, berlinC12, berlinC13, berlinC14, berlinC15);
            
            Integer berlinC2Score = 0;
            
            if (berlinC21.intValue() == 0 || berlinC21.intValue() == 1 ) {
                berlinC2Score += 1;
            }
            if (berlinC22.intValue() == 0 || berlinC22.intValue() == 1) berlinC2Score += 1;
            
            // 아래 막고 0이면 무조건 1점
            if (berlinC23.intValue() == 0) berlinC2Score += 1;
            
            //if (berlinC23.intValue() == 0) {
            //    if (berlinC24.intValue() == 0 || berlinC24.intValue() == 1) berlinC2Score += 1;
            //}

            System.out.printf("\tBerlin C2 : %d (Q6=%d, Q7=%d, Q8=%d, Q9=%d)\n", berlinC2Score, berlinC21, berlinC22, berlinC23, berlinC24);

            Integer berlinC3Score = 0;
            
            // bmi 값이 30이상이어도 1점 
            if (berlinC31.intValue() == 0 || bmi >= 30) berlinC3Score += 1;
            
            System.out.printf("\tBerlin C3 : %d (Q10=%d)\n", berlinC3Score, berlinC31);

			*/

            // 베를린 값 역순으로 변경. 220926
            if (berlinC11.intValue() == 1) {
                berlinC1Score += 1;
                if (berlinC12.intValue() == 2 || berlinC12.intValue() == 3) berlinC1Score += 1;
                if (berlinC13.intValue() == 3 || berlinC13.intValue() == 4) berlinC1Score += 1;
                if (berlinC14.intValue() == 1) berlinC1Score += 1;
                if (berlinC15.intValue() == 3 || berlinC15.intValue() == 4) berlinC1Score += 2;
            }

            System.out.printf("\tBerlin C1 : %d (Q1=%d, Q2=%d, Q3=%d, Q4=%d, Q5=%d)\n", berlinC1Score, berlinC11, berlinC12, berlinC13, berlinC14, berlinC15);
            
            Integer berlinC2Score = 0;
            
            if (berlinC21.intValue() == 3 || berlinC21.intValue() == 4 ) {
                berlinC2Score += 1;
            }
            if (berlinC22.intValue() == 3 || berlinC22.intValue() == 4) berlinC2Score += 1;
            
            // 아래 막고 0이면 무조건 1점
            if (berlinC23.intValue() == 1) berlinC2Score += 1;
            
            System.out.printf("\tBerlin C2 : %d (Q6=%d, Q7=%d, Q8=%d, Q9=%d)\n", berlinC2Score, berlinC21, berlinC22, berlinC23, berlinC24);

            Integer berlinC3Score = 0;
            
            // bmi 값이 30이상이어도 1점 
            if (berlinC31.intValue() == 1 || bmi >= 30) berlinC3Score += 1;
            
            System.out.printf("\tBerlin C3 : %d (Q10=%d)\n", berlinC3Score, berlinC31);

            annotationSleep.Berlin_Score1 = berlinC1Score.toString();
            annotationSleep.Berlin_Score2 = berlinC2Score.toString();
            annotationSleep.Berlin_Score3 = berlinC3Score.toString();
            
            Integer berlinScore = 0;

            if (berlinC1Score >= 2) berlinScore += 1;   // 양성 개수
            if (berlinC2Score >= 2) berlinScore += 1;   // 양성 개수
            if (berlinC3Score >= 1) berlinScore += 1;   // 양성 개수
                
            // 카테코리 3개 중 2개 이상이 양성이면 최종 양성, 아니면 음성
            annotationSleep.Berlin_Score = berlinScore.toString();

            System.out.printf("\tBerlin sum: %s\n", annotationSleep.Berlin_Score);
            
            annotationSleep.signalFileName = caseNo + "/" + edfFileName;
            annotationSleep.avgFileName = caseNo + "/" + avgFileName;
            
            // -----------------------------------------------------------------------------
            // Sound 파일 목록
            // -----------------------------------------------------------------------------
            File soundRoot = new File(Paths.get(dataRootPath, dataDir, caseNo, "sound").toString()); 
            
            if(!soundRoot.exists())
            {
                System.out.println("\t사운드 디렉토리 " + soundRoot + "이(가) 존재하지 않습니다.");
                return false;
            }
            else {
                //File[] soundFileList = soundRoot.listFiles();
                
            	// mp3 파일만 가져오기
                File[] soundFileList = soundRoot.listFiles(new FilenameFilter() {
                    public boolean accept(File dir, String name) {
                        return name.toLowerCase().endsWith(".mp3");
                    }
                });
                
                Arrays.sort(soundFileList);

                for(File soundFile : soundFileList)
                {
                    if(!soundFile.isDirectory())
                    {
                        annotationSleep.soundFileList.add(caseNo + "/sound/" + soundFile.getName());
                    }
                }
            }

            // -----------------------------------------------------------------------------
            // Spectrogram 파일 목록
            // -----------------------------------------------------------------------------
            File spectrogramRoot = new File(Paths.get(dataRootPath, dataDir, caseNo, "spectrogram").toString()); 
            
            if(!spectrogramRoot.exists())
            {
                System.out.println("\tSpectrogram 디렉토리 " + spectrogramRoot + "이(가) 존재하지 않습니다.");
                return false;
            }
            else {
                File[] spectrogramFileList = spectrogramRoot.listFiles();
                Arrays.sort(spectrogramFileList);

                for(File spectrogramFile : spectrogramFileList)
                {
                    if(!spectrogramFile.isDirectory())
                    {
                        annotationSleep.spectrogramList.add(caseNo + "/spectrogram/" + spectrogramFile.getName());
                    }
                }
            }
            
            // -----------------------------------------------------------------------------
            // EDF 파일을 읽어서 평균 데이터 파일 만들어 놓기(edf 파일은 변경되지 않고 다른 것이 변경되어 edf 통계 생성이 불필요할 경우에는 수행하지 않음, 시간 단축)
            // -----------------------------------------------------------------------------
            // CSV 파일에 쓰기
            String csvFilePathString = Paths.get(dataRootPath, dataDir, caseNo, avgFileName).toString().replace("\\", "/");
            File csvFile = new File(csvFilePathString);

            int epochSize = 30;

            UEdfModule edf = new UEdfModule(Paths.get(dataRootPath, dataDir, caseNo, edfFileName).toString(), epochSize);
            
            if (!edf.success) {
                System.out.println("\n\tEDF 파일 Open 에러!!");
                return false;
            }
            else {
                
                // 총 저장된 시간을 가져와서 분으로 환산하여 저장
                annotationSleep.signalDuration = String.valueOf((int)edf.getTotalDuration() / 60);

                // csv 파일이 없으면 무조건 실행, 있는데도 noedfupdate(edf파일을 읽어 통계용 데이터를 만들지 마라)가 false이면 실행
                if (csvFile.exists() == false || noedfupdate == false) {
                    
                    //int count = 3600;               // 총 몇개로 sampling 할 것인가. 이거 사용안함
                    int secondsPerOneSample = 5;    // 1개당 몇 초 평균을 낼지
                    
                    //System.out.printf("\tECG, ActX, ActY, ActZ Signal 전체 데이터로부터 %d초에 하나씩 Sampling start(전체 현황 파악용, 구간별 평균값 산출)\n", secondsPerOneSample);

                    isPrintDot = true;
                    UEdfStatisticInfo ecgData = edf.getStatisticDataInfo(3, secondsPerOneSample);
                    isPrintDot = false;
                    
                    //edf.printStatisticData(ecgData);

                    isPrintDot = true;                        
                    UEdfStatisticInfo actxData = edf.getStatisticDataInfo(0, secondsPerOneSample);
                    isPrintDot = false;

                    //edf.printStatisticData(actxData);
                    
                    isPrintDot = true;                        
                    UEdfStatisticInfo actyData = edf.getStatisticDataInfo(1, secondsPerOneSample);
                    isPrintDot = false;
                    
                    //edf.printStatisticData(actyData);

                    isPrintDot = true;                        
                    UEdfStatisticInfo actzData = edf.getStatisticDataInfo(2, secondsPerOneSample);
                    isPrintDot = false;
                    
                    //edf.printStatisticData(actzData);
                
                    
                    try (PrintWriter writer = new PrintWriter(csvFile)) 
                    {
                        
                        int minCount = min(ecgData.samplingCount, actxData.samplingCount, actyData.samplingCount, actzData.samplingCount);
                        
                        StringBuilder sb = new StringBuilder();

                        sb.append(String.format ("%d,%d\n", ecgData.secondsPerOneSample, minCount));
                        sb.append(String.format ("seq,ecg,actx,acty,actz\n"));

                        for(int i=0; i < minCount; i++) {
                            sb.append(String.format ("%d,%.5f,%.5f,%.5f,%.5f\n", i, ecgData.statisticDataList.get(i).avg, actxData.statisticDataList.get(i).avg, actyData.statisticDataList.get(i).avg, actzData.statisticDataList.get(i).avg));
                        }

                        writer.write(sb.toString());
                        writer.close();

                        // 권한 주기
                        allowPermission(csvFilePathString);
                        
                        System.out.println("\n\tSignal 데이터 구간 평균 값 파일 생성 OK!");
                    } 
                    catch (FileNotFoundException e) 
                    {
                        System.out.println(e.getMessage());
                        return false;
                    }
                }
            }
            
            System.out.println("\t추출 결과 데이터베이스 반영 중... ");

            // 가져온 데이터 DB에 반영하러 가기
            insertSleepCaseData(annotationSleep);

            System.out.println("\t추출 결과 데이터베이스 반영 완료! ");


        }
        catch (FileNotFoundException e1) {
            System.out.println("\tAnnotation 파일이 없습니다.(파일명 = " + annotationFileName + ")");
            return false;
        } 
        catch (IOException e2) {
            System.out.println("\t--- IOException");
            e2.printStackTrace();
            return false;
        } 
        catch (ParseException e3) {
            System.out.println("\t--- ParseException e");
            e3.printStackTrace();
            return false;
        }
        catch (Exception e4) {
            System.out.println("\t--- Exception e");
            e4.printStackTrace();
            return false;
        }

        return true;
        
    }
    
    public static int min(int a, int b, int... c) {

        int min = a < b ? a : b; // manual max

        if (c != null) {
          for (int i : c) { 
            if (i < min) min = i; 
          }
        }

        return min;
      }
    
    // --------------------------------------------------------------------------------------------------------
    // 수면 데이터 DB 저장
    // --------------------------------------------------------------------------------------------------------
    public static void insertSleepCaseData(AnnotationSleep annotationSleep) 
    {
        ResultSet rs = null;
        
        try {
            // -----------------------------------------------------------------------------
            // 케이스 마스터에 저장
            // -----------------------------------------------------------------------------
            if (!insertPLT_TASK_CASE(annotationSleep.caseNumber, annotationSleep.age, annotationSleep.gender, annotationSleep.caseGroupId)) {
                return;
            }
                    
            // -----------------------------------------------------------------------------
            // PLT_CASE_DATA_ITEM 삭제 후 저장
            // -----------------------------------------------------------------------------
            deletePLT_CASE_DATA_ITEM(annotationSleep.caseNumber);
            
            String grpCode = "";
            String itemCode = "";
            String itemValue = "";
            String itemNote = "";
            String testYMD = "";
            
            // 총 22개의 항목 insert. 추가 되면 수정해야 함.
            for (int i=0; i <= 60; i++) {

                itemNote = "";
                testYMD = "";
                
                switch (i) {
                    // 환자 임상 정보
                    case 0: // 성별
                        grpCode = "Case_Info";
                        itemCode = "Sex";
                        itemValue = annotationSleep.gender;
                        break;
                    case 1: // 나이
                        grpCode = "Case_Info";
                        itemCode = "Age";
                        itemValue = annotationSleep.age;
                        break;
                    case 2: // BMI
                        grpCode = "Case_Info";
                        itemCode = "BMI";
                        itemValue = annotationSleep.bmi;
                        break;
                    // 기본 수면 정보
                    case 3: // 총 수면 시간
                        grpCode = "Report1";
                        itemCode = "Total_Sleep_Time(TST)";
                        itemValue = annotationSleep.tot_sleep_time;
                        break;
                    case 4: // 수면효율(%)   
                        grpCode = "Report1";
                        itemCode = "Sleep_Efficiency";
                        itemValue = annotationSleep.sleep_effi;
                        break;
                    case 5: // 수면잠복기(분)   
                        grpCode = "Report1";
                        itemCode = "Sleep_Latency";
                        itemValue = annotationSleep.sleep_latency;
                        break;
                    // 수면 호흡 장애 검사
                    case 6: // AHI
                        grpCode = "Report2";
                        itemCode = "AHI";
                        itemValue = annotationSleep.ahi;
                        break;
                    case 7: // RDI
                        grpCode = "Report2";
                        itemCode = "RDI";
                        itemValue = annotationSleep.rdi;
                        break;
                    case 8: // 평균산소포화도(%) 
                        grpCode = "Report2";
                        itemCode = "Mean_Oxygen_Saturation";
                        itemValue = annotationSleep.oxy_satu_avg;
                        break;
                    case 9: // 최저산소포화도(%) 
                        grpCode = "Report2";
                        itemCode = "Lowest_Oxygen_Desaturation";
                        itemValue = annotationSleep.oxy_satu_min;
                        break;
                    // 수면 운동 장애 검사
                    case 10: // 총 LM index  
                        grpCode = "Report3";
                        itemCode = "Total_LM_Index";
                        itemValue = annotationSleep.tot_lm_index;
                        break;
                    case 11: // 총 LM Arousal index  
                        grpCode = "Report3";
                        itemCode = "Total_LM_Arousal_Index";
                        itemValue = annotationSleep.tot_lm_arou;
                        break;
                    case 12: // 총 Arousal index     
                        grpCode = "Report3";
                        itemCode = "Total_Arousal_Index";
                        itemValue = annotationSleep.arou_index;
                        break;
                    // 시그널 파일
                    case 13: // EKG,Actigraphy EDF 파일
                        grpCode = "Ekg_Act";
                        itemCode = "edf_file";
                        itemValue = annotationSleep.signalFileName;
                        itemNote = annotationSleep.signalDuration;
                        break;
                    case 14: 
                        grpCode = "Ekg_Act";
                        itemCode = "average_file";
                        itemValue = annotationSleep.avgFileName;
                        break;
                    // 설문지
                    case 15: 
                        grpCode = "SurveyPSQI1";
                        itemCode = "PSQI_Q1";
                        itemValue = annotationSleep.PSQI_Q1;
                        break;
                    case 16: 
                        grpCode = "SurveyPSQI1";
                        itemCode = "PSQI_Q2";
                        itemValue = annotationSleep.PSQI_Q2;
                        break;
                    case 17: 
                        grpCode = "SurveyPSQI1";
                        itemCode = "PSQI_Q3";
                        itemValue = annotationSleep.PSQI_Q3;
                        break;
                    case 18: 
                        grpCode = "SurveyPSQI1";
                        itemCode = "PSQI_Q4";
                        itemValue = annotationSleep.PSQI_Q4;
                        break;
                    case 19: 
                        grpCode = "SurveyPSQI2";
                        itemCode = "PSQI_Q5-1";
                        itemValue = annotationSleep.PSQI_Q5_1;
                        break;
                    case 20: 
                        grpCode = "SurveyPSQI2";
                        itemCode = "PSQI_Q5-2";
                        itemValue = annotationSleep.PSQI_Q5_2;
                        break;
                    case 21: 
                        grpCode = "SurveyPSQI2";
                        itemCode = "PSQI_Q5-3";
                        itemValue = annotationSleep.PSQI_Q5_3;
                        break;
                    case 22: 
                        grpCode = "SurveyPSQI2";
                        itemCode = "PSQI_Q5-4";
                        itemValue = annotationSleep.PSQI_Q5_4;
                        break;
                    case 23: 
                        grpCode = "SurveyPSQI2";
                        itemCode = "PSQI_Q5-5";
                        itemValue = annotationSleep.PSQI_Q5_5;
                        break;
                    case 24: 
                        grpCode = "SurveyPSQI2";
                        itemCode = "PSQI_Q5-6";
                        itemValue = annotationSleep.PSQI_Q5_6;
                        break;
                    case 25: 
                        grpCode = "SurveyPSQI2";
                        itemCode = "PSQI_Q5-7";
                        itemValue = annotationSleep.PSQI_Q5_7;
                        break;
                    case 26: 
                        grpCode = "SurveyPSQI2";
                        itemCode = "PSQI_Q5-8";
                        itemValue = annotationSleep.PSQI_Q5_8;
                        break;
                    case 27: 
                        grpCode = "SurveyPSQI2";
                        itemCode = "PSQI_Q5-9";
                        itemValue = annotationSleep.PSQI_Q5_9;
                        break;
                    case 28: 
                        grpCode = "SurveyPSQI2";
                        itemCode = "PSQI_Q5-10";
                        itemValue = annotationSleep.PSQI_Q5_10;
                        break;
                    case 29: 
                        grpCode = "SurveyPSQI3";
                        itemCode = "PSQI_Q5-11";
                        itemValue = annotationSleep.PSQI_Q5_11;
                        break;
                    case 30: 
                        grpCode = "SurveyPSQI4";
                        itemCode = "PSQI_Q6";
                        itemValue = annotationSleep.PSQI_Q6;
                        break;
                    case 31: 
                        grpCode = "SurveyPSQI4";
                        itemCode = "PSQI_Q7";
                        itemValue = annotationSleep.PSQI_Q7;
                        break;
                    case 32: 
                        grpCode = "SurveyPSQI4";
                        itemCode = "PSQI_Q8";
                        itemValue = annotationSleep.PSQI_Q8;
                        break;
                    case 33: 
                        grpCode = "SurveyPSQI4";
                        itemCode = "PSQI_Q9";
                        itemValue = annotationSleep.PSQI_Q9;
                        break;
                    case 34: 
                        grpCode = "SurveyESS1";
                        itemCode = "ESS_Q1";
                        itemValue = annotationSleep.ESS_Q1;
                        break;
                    case 35: 
                        grpCode = "SurveyESS1";
                        itemCode = "ESS_Q2";
                        itemValue = annotationSleep.ESS_Q2;
                        break;
                    case 36: 
                        grpCode = "SurveyESS1";
                        itemCode = "ESS_Q3";
                        itemValue = annotationSleep.ESS_Q3;
                        break;
                    case 37: 
                        grpCode = "SurveyESS1";
                        itemCode = "ESS_Q4";
                        itemValue = annotationSleep.ESS_Q4;
                        break;
                    case 38: 
                        grpCode = "SurveyESS1";
                        itemCode = "ESS_Q5";
                        itemValue = annotationSleep.ESS_Q5;
                        break;
                    case 39: 
                        grpCode = "SurveyESS1";
                        itemCode = "ESS_Q6";
                        itemValue = annotationSleep.ESS_Q6;
                        break;
                    case 40: 
                        grpCode = "SurveyESS1";
                        itemCode = "ESS_Q7";
                        itemValue = annotationSleep.ESS_Q7;
                        break;
                    case 41: 
                        grpCode = "SurveyESS1";
                        itemCode = "ESS_Q8";
                        itemValue = annotationSleep.ESS_Q8;
                        break;
                    case 42: 
                        grpCode = "SurveyESS2";
                        itemCode = "ESS_Q9";
                        itemValue = annotationSleep.ESS_Q9;
                        break;
                    case 43: 
                        grpCode = "SurveyESS2";
                        itemCode = "ESS_Q10";
                        itemValue = annotationSleep.ESS_Q10;
                        break;
                    case 44: 
                        grpCode = "SurveyESS2";
                        itemCode = "ESS_Q11";
                        itemValue = annotationSleep.ESS_Q11;
                        break;
                    case 45: 
                        grpCode = "SurveyBerlin1";
                        itemCode = "Berlin_C1-1";
                        itemValue = annotationSleep.Berlin_C1_1;
                        break;
                    case 46: 
                        grpCode = "SurveyBerlin1";
                        itemCode = "Berlin_C1-2";
                        itemValue = annotationSleep.Berlin_C1_2;
                        break;
                    case 47: 
                        grpCode = "SurveyBerlin1";
                        itemCode = "Berlin_C1-3";
                        itemValue = annotationSleep.Berlin_C1_3;
                        break;
                    case 48: 
                        grpCode = "SurveyBerlin1";
                        itemCode = "Berlin_C1-4";
                        itemValue = annotationSleep.Berlin_C1_4;
                        break;
                    case 49: 
                        grpCode = "SurveyBerlin1";
                        itemCode = "Berlin_C1-5";
                        itemValue = annotationSleep.Berlin_C1_5;
                        break;
                    case 50: 
                        grpCode = "SurveyBerlin2";
                        itemCode = "Berlin_C2-1";
                        itemValue = annotationSleep.Berlin_C2_1;
                        break;
                    case 51: 
                        grpCode = "SurveyBerlin2";
                        itemCode = "Berlin_C2-2";
                        itemValue = annotationSleep.Berlin_C2_2;
                        break;
                    case 52: 
                        grpCode = "SurveyBerlin2";
                        itemCode = "Berlin_C2-3";
                        itemValue = annotationSleep.Berlin_C2_3;
                        break;
                    case 53: 
                        grpCode = "SurveyBerlin2";
                        itemCode = "Berlin_C2-4";
                        itemValue = annotationSleep.Berlin_C2_4;
                        break;
                    case 54: 
                        grpCode = "SurveyBerlin3";
                        itemCode = "Berlin_C3-1";
                        itemValue = annotationSleep.Berlin_C3_1;
                        break;
                    case 55: 
                        grpCode = "SurveySummary";
                        itemCode = "PSQI_Score";
                        itemValue = annotationSleep.PSQI_Score;
                        break;
                    case 56: 
                        grpCode = "SurveySummary";
                        itemCode = "ESS_Score";
                        itemValue = annotationSleep.ESS_Score;
                        break;
                    case 57: 
                        grpCode = "SurveySummary";
                        itemCode = "Berlin_Score1";
                        itemValue = annotationSleep.Berlin_Score1;
                        break;
                    case 58: 
                        grpCode = "SurveySummary";
                        itemCode = "Berlin_Score2";
                        itemValue = annotationSleep.Berlin_Score2;
                        break;
                    case 59: 
                        grpCode = "SurveySummary";
                        itemCode = "Berlin_Score3";
                        itemValue = annotationSleep.Berlin_Score3;
                        break;
                    case 60: 
                        grpCode = "SurveySummary";
                        itemCode = "Berlin_Score";
                        itemValue = annotationSleep.Berlin_Score;
                        break;
                    default :
                        continue;
                }
                
                insertPLT_CASE_DATA_ITEM(annotationSleep.caseNumber, grpCode, itemCode, itemValue, itemNote, testYMD);
                
            }

            // -----------------------------------------------------------------------------
            // PLT_CASE_DATA_ITEM_LIST 삭제 후 저장 (수면의 경우 사운드 파일)
            // -----------------------------------------------------------------------------
            deletePLT_CASE_DATA_ITEM_LIST(annotationSleep.caseNumber);

            for (int i=0; i < annotationSleep.soundFileList.size(); i++) {
                
                grpCode = "Sound";
                itemCode = "sound_file";
                itemValue = annotationSleep.soundFileList.get(i);
                itemNote = "";
                testYMD = "";
                
                insertPLT_CASE_DATA_ITEM_LIST(annotationSleep.caseNumber, grpCode, itemCode, itemValue, itemNote, testYMD, i + 1);
            }

            // -----------------------------------------------------------------------------
            // PLT_CASE_SPECTROGRAM 삭제 후 저장
            // -----------------------------------------------------------------------------
            deletePLT_CASE_SPECTROGRAM(annotationSleep.caseNumber);

            String imgFilePath = "";
            String imgFileName = "";
            
            for (int i=0; i < annotationSleep.spectrogramList.size(); i++) {
                
                grpCode = "Sound";
                itemCode = "sound_file"; 
                imgFilePath = annotationSleep.spectrogramList.get(i);
                imgFileName = Paths.get(imgFilePath).getFileName().toString();
            
                insertPLT_CASE_SPECTROGRAM(annotationSleep.caseNumber, grpCode, itemCode, imgFileName, imgFilePath, i + 1);
            }
            
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
            }
        }

    }

    
    // --------------------------------------------------------------------------------------------------------
    // 폐기능 데이터 읽어오기
    // --------------------------------------------------------------------------------------------------------
    public static boolean managePftCaseDirectory(File caseRoot, String patientCode) 
    {
        
        String caseNo = caseRoot.getName();
        AnnotationPFT annotationPFT = new AnnotationPFT();
        JSONParser parser = new JSONParser();
        
        annotationPFT.caseNumber = caseNo;

        
        String annotationFileName = caseNo + "-annotation.json";
        String csvFileName = Paths.get(patientCode, caseNo, caseNo).toString().replace("\\", "/") + "-pft-validation.csv";
        
        /*
        String annotationFileName = caseNo + ".JSON";
        String csvFileName = caseNo + ".csv";
        */

        try {     
            
            String jsonPath = Paths.get(dataRootPath, dataDir, patientCode, caseNo, annotationFileName).toString().replace("\\", "/");
            
            System.out.println("\tAnnotation 파일명 : " + annotationFileName);
            
            FileReader jsonFile = new FileReader(jsonPath);
            
            Object obj = parser.parse(jsonFile);

            JSONObject jsonObject =  (JSONObject) obj;

            // -----------------------------------------------------------------------------
            // Case_Info 객체 read
            // -----------------------------------------------------------------------------
            JSONObject caseInfo = (JSONObject) jsonObject.get("Case_Info");

            annotationPFT.caseGroupId = getStringFromJson("patient_id", caseInfo);
            annotationPFT.DiagName = getStringFromJson("diagnosis", caseInfo);
            annotationPFT.gender = getStringFromJson("gender", caseInfo);
            
            if (annotationPFT.gender.compareTo("여성") == 0) {
                annotationPFT.gender = "F";
            }
            else if (annotationPFT.gender.compareTo("남성") == 0) {
                annotationPFT.gender = "M";
            }
            else {
                //System.out.println("\tannotationPFT.gender : " + annotationPFT.gender);
            }

            annotationPFT.age = String.valueOf(getNumberFromJson("age", caseInfo));
            annotationPFT.bmi = String.valueOf(getNumberFromJson("bmi", caseInfo));
            annotationPFT.smoke = getStringFromJson("smoking", caseInfo);
            annotationPFT.py = String.valueOf(getNumberFromJson("py", caseInfo));
            annotationPFT.Addr = getStringFromJson("residence", caseInfo);
            annotationPFT.weight = String.valueOf(getNumberFromJson("weight", caseInfo));
            annotationPFT.height = String.valueOf(getNumberFromJson("height", caseInfo));
            annotationPFT.testDate = getStringFromJson("date", caseInfo);
            annotationPFT.testTime = getStringFromJson("time", caseInfo);
            
            // -----------------------------------------------------------------------------
            // 대기 오염 데이터
            // -----------------------------------------------------------------------------
            //JSONObject pollution = (JSONObject) jsonObject.get("Air_Pollution");
            JSONObject pollution = (JSONObject) jsonObject.get("Air_Pollution");
            
            annotationPFT.pm25 = String.valueOf(getNumberFromJson("pm25_value", pollution));
            annotationPFT.no2 = String.valueOf(getNumberFromJson("no2_value", pollution));
            annotationPFT.o3 = String.valueOf(getNumberFromJson("o3_value", pollution));
            annotationPFT.pm10 = String.valueOf(getNumberFromJson("pm10_value", pollution));
            annotationPFT.co = String.valueOf(getNumberFromJson("co_value", pollution));
            annotationPFT.so2 = String.valueOf(getNumberFromJson("so2_value", pollution));

            // -----------------------------------------------------------------------------
            // 폐기능 결과 데이터
            // -----------------------------------------------------------------------------
            JSONObject result = (JSONObject) jsonObject.get("PFT_Result");
            
            annotationPFT.fvc = String.valueOf(getNumberFromJson("FVC_L", result));
            annotationPFT.fvcRate = String.valueOf(getNumberFromJson("FVC_P", result));
            annotationPFT.fev1 = String.valueOf(getNumberFromJson("FEV1_L", result));
            annotationPFT.fev1Rate = String.valueOf(getNumberFromJson("FEV1_P", result));
            annotationPFT.fev1DevidedFvc = String.valueOf(getNumberFromJson("FEV1_FVC", result));
            annotationPFT.pef = String.valueOf(getNumberFromJson("PEF", result));
            annotationPFT.fef2575 = String.valueOf(getNumberFromJson("FEF25_75", result));
            
            annotationPFT.pftfile = csvFileName;
            
            System.out.println("\t추출 결과 데이터베이스 반영 중... ");

            // 가져온 데이터 DB에 반영하러 가기
            insertPftCaseData(annotationPFT);

            System.out.println("\t추출 결과 데이터베이스 반영 완료! ");

            
        }
        catch (FileNotFoundException e1) {
            System.out.println("\tAnnotation 파일이 없습니다.(파일명 = " + annotationFileName + ")");
            return false;
        } 
        catch (IOException e2) {
            System.out.println("\t--- IOException");
            e2.printStackTrace();
            return false;
        } 
        catch (ParseException e3) {
            System.out.println("\t--- ParseException e");
            e3.printStackTrace();
            return false;
        }
        catch (Exception e4) {
            System.out.println("\t--- Exception e");
            e4.printStackTrace();
            return false;
        }
        
        return true;
    }
    
    
    // --------------------------------------------------------------------------------------------------------
    // 폐기능 데이터 DB 저장
    // --------------------------------------------------------------------------------------------------------
    public static void insertPftCaseData(AnnotationPFT annotationPFT) {
        
        ResultSet rs = null;
        
        try {
            // -----------------------------------------------------------------------------
            // 케이스 마스터에 저장
            // -----------------------------------------------------------------------------
            if (!insertPLT_TASK_CASE(annotationPFT.caseNumber, annotationPFT.age, annotationPFT.gender, annotationPFT.caseGroupId)) {
                return;
            }
                    
            // -----------------------------------------------------------------------------
            // PLT_CASE_DATA_ITEM 삭제 후 저장
            // -----------------------------------------------------------------------------
            deletePLT_CASE_DATA_ITEM(annotationPFT.caseNumber);
            
            String grpCode = "";
            String itemCode = "";
            String itemValue = "";
            String itemNote = "";
            String testYMD = "";
            
            // 총 22개의 항목 insert. 추가 되면 수정해야 함.
            for (int i=0; i < 30; i++) {

                itemNote = "";
                testYMD = "";
                
                switch (i) {
                    // 환자 임상 정보
                    case 0: // 진단명
                        grpCode = "Case_Info";
                        itemCode = "diagnosis";
                        itemValue = annotationPFT.DiagName;
                        break;
                    case 1: // 성별
                        grpCode = "Case_Info";
                        itemCode = "gender";
                        itemValue = annotationPFT.gender;
                        break;
                    case 3: // 나이
                        grpCode = "Case_Info";
                        itemCode = "age";
                        itemValue = annotationPFT.age;
                        break;
                    case 4: // BMI
                        grpCode = "Case_Info";
                        itemCode = "bmi";
                        itemValue = annotationPFT.bmi;
                        break;
                    case 5: // 흡연  
                        grpCode = "Case_Info";
                        itemCode = "smoking";
                        itemValue = annotationPFT.smoke;
                        break;
                    case 6: // pack year
                        grpCode = "Case_Info";
                        itemCode = "py";
                        itemValue = annotationPFT.py;
                        break;
                    case 7: // 키
                        grpCode = "Case_Info";
                        itemCode = "height";
                        itemValue = annotationPFT.height;
                        break;
                    case 8: // 체중
                        grpCode = "Case_Info";
                        itemCode = "weight";
                        itemValue = annotationPFT.weight;
                        break;
                    case 9: // 거주지
                        grpCode = "Case_Info";
                        itemCode = "residence";
                        itemValue = annotationPFT.Addr;
                        break;
                    case 10: // 검사일자
                        grpCode = "Case_Info";
                        itemCode = "date";
                        itemValue = annotationPFT.testDate;
                        break;
                    case 11: // 검사시각
                        grpCode = "Case_Info";
                        itemCode = "time";
                        itemValue = annotationPFT.testTime;
                        break;
                        
                    // 폐기능 검사 데이터
                    case 12: // FVC
                        grpCode = "PFT_Result";
                        itemCode = "FVC_L";
                        itemValue = annotationPFT.fvc;
                        break;
                    case 13: // FVC %  
                        grpCode = "PFT_Result";
                        itemCode = "FVC_P";
                        itemValue = annotationPFT.fvcRate;
                        break;
                    case 14: // FEV1
                        grpCode = "PFT_Result";
                        itemCode = "FEV1_L";
                        itemValue = annotationPFT.fev1;
                        break;
                    case 15: // FEV1 %     
                        grpCode = "PFT_Result";
                        itemCode = "FEV1_P";
                        itemValue = annotationPFT.fev1Rate;
                        break;
                    case 16: // FEV1/FVC
                        grpCode = "PFT_Result";
                        itemCode = "FEV1_FVC";
                        itemValue = annotationPFT.fev1DevidedFvc;
                        break;
                    case 17: // PEF
                        grpCode = "PFT_Result";
                        itemCode = "PEF";
                        itemValue = annotationPFT.pef;
                        break;
                    case 18: // FEF 25-75
                        grpCode = "PFT_Result";
                        itemCode = "FEF25-75";
                        itemValue = annotationPFT.fef2575;
                        break;

                    // 대기 오염 데이터
                    case 20: // 초미세먼지(PM2.5) (㎍/㎥, 24h)
                        grpCode = "Air_Pollution";
                        itemCode = "pm2.5_value";
                        itemValue = annotationPFT.pm25;
                        break;
                    case 21: // 이산화질소(ppm)
                        grpCode = "Air_Pollution";
                        itemCode = "no2_value";
                        itemValue = annotationPFT.no2;
                        break;
                    case 22: // 오존(ppm)
                        grpCode = "Air_Pollution";
                        itemCode = "o3_value";
                        itemValue = annotationPFT.o3;
                        break;
                    case 23: // 미세먼지(PM10) (㎍/㎥, 24h)
                        grpCode = "Air_Pollution";
                        itemCode = "pm10_value";
                        itemValue = annotationPFT.pm10;
                        break;
                    case 25: // 일산화탄소(ppm)
                        grpCode = "Air_Pollution";
                        itemCode = "co_value";
                        itemValue = annotationPFT.co;
                        break;
                    case 26: // 아황산가스(ppm)
                        grpCode = "Air_Pollution";
                        itemCode = "so2_value";
                        itemValue = annotationPFT.so2;
                        break;
                        
                    case 27: // PFT CSV 파일
                        grpCode = "PFT_File";
                        itemCode = "pft_file";
                        itemValue = annotationPFT.pftfile;
                        break;
                    default :
                        continue;
                }
                
                insertPLT_CASE_DATA_ITEM(annotationPFT.caseNumber, grpCode, itemCode, itemValue, itemNote, testYMD);

            }

            // -----------------------------------------------------------------------------
            // PLT_CASE_DATA_ITEM_LIST 삭제 후 저장 - 해당 사항 없음
            // -----------------------------------------------------------------------------

            // -----------------------------------------------------------------------------
            // PLT_CASE_SPECTROGRAM 삭제 후 저장 - 해당 사항 없음
            // -----------------------------------------------------------------------------
            
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
            }
        }

    }

    // --------------------------------------------------------------------------------------------------------
    // 폐음 데이터 읽어오기
    // --------------------------------------------------------------------------------------------------------
    public static boolean manageLungSoundCaseDirectory(File caseRoot, String patientCode) 
    {
        String caseNo = caseRoot.getName();
        AnnotationLungSound annotationLungSound = new AnnotationLungSound();
        JSONParser parser = new JSONParser();
        
        annotationLungSound.caseNumber = caseNo;
        
        String annotationFileName = caseNo + "-annotation.json";
        String audioFileNameL1 = Paths.get(patientCode, caseNo, caseNo).toString().replace("\\", "/") + "-sound-L1.wav";
        String audioFileNameL3 = Paths.get(patientCode, caseNo, caseNo).toString().replace("\\", "/") + "-sound-L3.wav";
        String audioFileNameL4 = Paths.get(patientCode, caseNo, caseNo).toString().replace("\\", "/") + "-sound-L4.wav";
        String audioFileNameL6 = Paths.get(patientCode, caseNo, caseNo).toString().replace("\\", "/") + "-sound-L6.wav";
        String audioFileNameR1 = Paths.get(patientCode, caseNo, caseNo).toString().replace("\\", "/") + "-sound-R1.wav";
        String audioFileNameR3 = Paths.get(patientCode, caseNo, caseNo).toString().replace("\\", "/") + "-sound-R3.wav";
        String audioFileNameR4 = Paths.get(patientCode, caseNo, caseNo).toString().replace("\\", "/") + "-sound-R4.wav";
        String audioFileNameR6 = Paths.get(patientCode, caseNo, caseNo).toString().replace("\\", "/") + "-sound-R6.wav";

        try {     
            
            String jsonPath = Paths.get(dataRootPath, dataDir, patientCode, caseNo, annotationFileName).toString().replace("\\", "/");
            
            System.out.println("\tAnnotation 파일명 : " + caseNo + "-annotation.json");
            
            FileReader jsonFile = new FileReader(jsonPath);
            
            Object obj = parser.parse(jsonFile);

            JSONObject jsonObject =  (JSONObject) obj;

            // -----------------------------------------------------------------------------
            // Case_Info 객체 read
            // -----------------------------------------------------------------------------
            JSONObject caseInfo = (JSONObject) jsonObject.get("Case_Info");

            annotationLungSound.caseGroupId = getStringFromJson("patient_id", caseInfo);
            annotationLungSound.DiagName = getStringFromJson("diagnosis", caseInfo);
            annotationLungSound.gender = getStringFromJson("gender", caseInfo);
            
            if (annotationLungSound.gender.compareTo("여성") == 0) {
                annotationLungSound.gender = "F";
            }
            else if (annotationLungSound.gender.compareTo("남성") == 0) {
                annotationLungSound.gender = "M";
            }
            else {
                System.out.println("\tannotationLungSound.gender : " + annotationLungSound.gender);
            }

            annotationLungSound.age = String.valueOf(getNumberFromJson("age", caseInfo));
            annotationLungSound.bmi = String.valueOf(getNumberFromJson("bmi", caseInfo));
            annotationLungSound.smoke = getStringFromJson("smoking", caseInfo);
            annotationLungSound.py = String.valueOf(getNumberFromJson("py", caseInfo));
            annotationLungSound.weight = String.valueOf(getNumberFromJson("weight", caseInfo));
            annotationLungSound.height = String.valueOf(getNumberFromJson("height", caseInfo));
            annotationLungSound.testDate = getStringFromJson("date", caseInfo);
            annotationLungSound.testTime = getStringFromJson("time", caseInfo);
            
            // -----------------------------------------------------------------------------
            // 폐음 파일
            // -----------------------------------------------------------------------------
            AnnotationLungSoundFile lungSoundFile;
            
            lungSoundFile = new AnnotationLungSoundFile();
            lungSoundFile.lungSoundfileName = audioFileNameL1;
            lungSoundFile.Location = "L1";
            annotationLungSound.lungSoundFileList.add(lungSoundFile);
            
            lungSoundFile = new AnnotationLungSoundFile();
            lungSoundFile.lungSoundfileName = audioFileNameL3;
            lungSoundFile.Location = "L3";
            annotationLungSound.lungSoundFileList.add(lungSoundFile);
            
            lungSoundFile = new AnnotationLungSoundFile();
            lungSoundFile.lungSoundfileName = audioFileNameL4;
            lungSoundFile.Location = "L4";
            annotationLungSound.lungSoundFileList.add(lungSoundFile);
            
            lungSoundFile = new AnnotationLungSoundFile();
            lungSoundFile.lungSoundfileName = audioFileNameL6;
            lungSoundFile.Location = "L6";
            annotationLungSound.lungSoundFileList.add(lungSoundFile);
            
            lungSoundFile = new AnnotationLungSoundFile();
            lungSoundFile.lungSoundfileName = audioFileNameR1;
            lungSoundFile.Location = "R1";
            annotationLungSound.lungSoundFileList.add(lungSoundFile);
            
            lungSoundFile = new AnnotationLungSoundFile();
            lungSoundFile.lungSoundfileName = audioFileNameR3;
            lungSoundFile.Location = "R3";
            annotationLungSound.lungSoundFileList.add(lungSoundFile);
            
            lungSoundFile = new AnnotationLungSoundFile();
            lungSoundFile.lungSoundfileName = audioFileNameR4;
            lungSoundFile.Location = "R4";
            annotationLungSound.lungSoundFileList.add(lungSoundFile);
            
            lungSoundFile = new AnnotationLungSoundFile();
            lungSoundFile.lungSoundfileName = audioFileNameR6;
            lungSoundFile.Location = "R6";
            annotationLungSound.lungSoundFileList.add(lungSoundFile);
            
            System.out.println("\t추출 결과 데이터베이스 반영 중... ");

            insertLungSoundCaseData(annotationLungSound);
            
            System.out.println("\t추출 결과 데이터베이스 반영 완료! ");
        }
        catch (FileNotFoundException e1) {
            System.out.println("\tAnnotation 파일이 없습니다.(파일명 = " + annotationFileName + ")");
            return false;
        } 
        catch (IOException e2) {
            System.out.println("\t--- IOException");
            e2.printStackTrace();
            return false;
        } 
        catch (ParseException e3) {
            System.out.println("\t--- ParseException e");
            e3.printStackTrace();
            return false;
        }
        catch (Exception e4) {
            System.out.println("\t--- Exception e");
            e4.printStackTrace();
            return false;
        }
        
        return true;
        
    }
    
    
    // --------------------------------------------------------------------------------------------------------
    // 폐음 데이터 DB 저장
    // --------------------------------------------------------------------------------------------------------
    public static void insertLungSoundCaseData(AnnotationLungSound annotationLungSound) {
        ResultSet rs = null;
        
        try {
            // -----------------------------------------------------------------------------
            // 케이스 마스터에 저장
            // -----------------------------------------------------------------------------
            if (!insertPLT_TASK_CASE(annotationLungSound.caseNumber, annotationLungSound.age, annotationLungSound.gender, annotationLungSound.caseGroupId)) {
                return;
            }
                    
            // -----------------------------------------------------------------------------
            // PLT_CASE_DATA_ITEM 삭제 후 저장
            // -----------------------------------------------------------------------------
            deletePLT_CASE_DATA_ITEM(annotationLungSound.caseNumber);
            
            String grpCode = "";
            String itemCode = "";
            String itemValue = "";
            String itemNote = "";
            String testYMD = "";
            
            // 총 22개의 항목 insert. 추가 되면 수정해야 함.
            for (int i=0; i < 30; i++) {

                itemNote = "";
                testYMD = "";
                
                switch (i) {
                    // 환자 임상 정보
                    case 0: // 진단명
                        grpCode = "Case_Info";
                        itemCode = "diagnosis";
                        itemValue = annotationLungSound.DiagName;
                        break;
                    case 1: // 성별
                        grpCode = "Case_Info";
                        itemCode = "gender";
                        itemValue = annotationLungSound.gender;
                        break;
                    case 3: // 나이
                        grpCode = "Case_Info";
                        itemCode = "age";
                        itemValue = annotationLungSound.age;
                        break;
                    case 4: // BMI
                        grpCode = "Case_Info";
                        itemCode = "bmi";
                        itemValue = annotationLungSound.bmi;
                        break;
                    case 5: // 흡연  
                        grpCode = "Case_Info";
                        itemCode = "smoking";
                        itemValue = annotationLungSound.smoke;
                        break;
                    case 6: // pack year
                        grpCode = "Case_Info";
                        itemCode = "py";
                        itemValue = annotationLungSound.py;
                        break;
                    case 7: // 키
                        grpCode = "Case_Info";
                        itemCode = "height";
                        itemValue = annotationLungSound.height;
                        break;
                    case 8: // 체중
                        grpCode = "Case_Info";
                        itemCode = "weight";
                        itemValue = annotationLungSound.weight;
                        break;
                    case 9: // 검사일자
                        grpCode = "Case_Info";
                        itemCode = "date";
                        itemValue = annotationLungSound.testDate;
                        break;
                    case 10: // 검사시각
                        grpCode = "Case_Info";
                        itemCode = "time";
                        itemValue = annotationLungSound.testTime;
                        break;
                        
                    default :
                        continue;
                }
                
                insertPLT_CASE_DATA_ITEM(annotationLungSound.caseNumber, grpCode, itemCode, itemValue, itemNote, testYMD);
                
            }

            // -----------------------------------------------------------------------------
            // PLT_CASE_DATA_ITEM_LIST 삭제 후 저장 - 폐음 파일
            // -----------------------------------------------------------------------------
            deletePLT_CASE_DATA_ITEM_LIST(annotationLungSound.caseNumber);

            for (int i=0; i < annotationLungSound.lungSoundFileList.size(); i++) {
                
                grpCode = "Sound";
                itemCode = "sound_file";
                itemValue = annotationLungSound.lungSoundFileList.get(i).lungSoundfileName;
                itemNote = annotationLungSound.lungSoundFileList.get(i).Location;
                testYMD = "";
                
                insertPLT_CASE_DATA_ITEM_LIST(annotationLungSound.caseNumber, grpCode, itemCode, itemValue, itemNote, testYMD, i + 1);
            }
            
            // -----------------------------------------------------------------------------
            // PLT_CASE_SPECTROGRAM 삭제 후 저장 - 해당 사항 없음
            // -----------------------------------------------------------------------------
            
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
            }
        }
    }

    

    public static boolean insertPLT_TASK_CASE(String caseNo, String age, String gender, String caseGrpId) {
        
        ResultSet rs = null;
        String sql = "";

        // -----------------------------------------------------------------------------
        // 케이스 저장
        // -----------------------------------------------------------------------------
        try {
            sql  = " SELECT *";
            sql += " FROM   PLT_TASK_CASE";
            sql += " WHERE  PROJ_CD = '" + projectCode + "'";
            sql += " AND    TASK_CD = '" + taskCode + "'";
            sql += " AND    CASE_NO = '" + caseNo + "'";
    
            rs = db.selectSQL(sql);
            
            if(rs.next())
            {
                sql  = " UPDATE PLT_TASK_CASE";
                sql += " SET    AGE             = '" + age + "'";
                sql += "       ,GEN             = '" + gender.substring(0,1).toUpperCase() + "'";
                sql += "       ,REG_ID          = 'AUTO'";
                sql += "       ,REG_DT          =  SYSDATE";
                sql += "       ,AUTO_LOAD_FG    = 'Y'";
                sql += "       ,CASE_GRP_ID     = '" + caseGrpId + "'";
                sql += " WHERE  PROJ_CD         = '" + projectCode + "'";
                sql += " AND    TASK_CD         = '" + taskCode + "'";
                sql += " AND    CASE_NO         = '" + caseNo + "'";
    
                if (!db.executeSQL(sql, sqlResult)) {
                    System.out.println("\tError SQL : " + sql);
                    System.out.println("\t에러가 발생하여 프로그램을 종료합니다.");
                    db.Close(true);
                    printDotTimer.cancel();
                    System.exit(1);
                }
    
                update_cnt++;
            }
            else
            {
                sql  = " INSERT INTO PLT_TASK_CASE";
                sql += "       (PROJ_CD,";
                sql += "        TASK_CD,";
                sql += "        CASE_NO,";
                sql += "        AGE,";
                sql += "        GEN,";
                sql += "        AUTO_LOAD_FG,";
                sql += "        CASE_GRP_ID";
                sql += "       )";
                sql += " VALUES ('" + projectCode + "',";
                sql += "        '" + taskCode +"',";
                sql += "        '" + caseNo +"',";
                sql += "        '" + age + "',";
                sql += "        '" + gender.substring(0,1).toUpperCase() + "',";
                sql += "        'Y',";
                sql += "        '" + caseGrpId + "')";
                
                if (!db.executeSQL(sql, sqlResult)) {
                    System.out.println("\tError SQL : " + sql);
                    System.out.println("\t에러가 발생하여 프로그램을 종료합니다.");
                    db.Close(true);
                    printDotTimer.cancel();
                    System.exit(1);
                }
    
                insert_cnt++;
            };

            sql  = " UPDATE PLT_TASK";
            sql += " SET    DATA_REG_YMD    = CASE WHEN DATA_REG_YMD IS NULL THEN TO_CHAR(SYSDATE,'YYYYMMDD') ELSE DATA_REG_YMD END";
            sql += " WHERE  PROJ_CD         = '" + projectCode + "'";
            sql += " AND    TASK_CD         = '" + taskCode + "'";

            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println("\tError SQL : " + sql);
                System.out.println("\t에러가 발생하여 프로그램을 종료합니다.");
                db.Close(true);
                printDotTimer.cancel();
                System.exit(1);
            }
            
        }
        catch (SQLException se) 
        {
            System.out.println("\tError SQL : " + sql);
            se.printStackTrace();
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
        
        return true;
        
    }
    
    public static void deletePLT_CASE_DATA_ITEM(String caseNo) {
        
        String sql = "";
        
        sql  = " DELETE FROM PLT_CASE_DATA_ITEM";
        sql += " WHERE  PROJ_CD = '" + projectCode + "'";
        sql += " AND    TASK_CD = '" + taskCode + "'";
        sql += " AND    CASE_NO = '" + caseNo + "'";

        if (!db.executeSQL(sql, sqlResult)) {
            System.out.println("\tError SQL : " + sql);
            System.out.println("\t에러가 발생하여 프로그램을 종료합니다.");
            db.Close(true);
            printDotTimer.cancel();
            System.exit(1);
        }

        return;
        
    }
    
    public static void insertPLT_CASE_DATA_ITEM(String caseNo, String grpCode, String itemCode, String itemValue, String itemNote, String testYMD) {
        
        String sql = "";
        
        sql  = " INSERT INTO PLT_CASE_DATA_ITEM";
        sql += "       (PROJ_CD,";
        sql += "        TASK_CD,";
        sql += "        CASE_NO,";
        sql += "        DATA_GRP_CD,";
        sql += "        DATA_ITEM_CD,";
        sql += "        DATA_ITEM_VAL,";
        sql += "        DATA_ITEM_NOTE,";
        sql += "        TEST_YMD";
        sql += "       )";
        sql += " VALUES ('" + projectCode + "',";
        sql += "        '" + taskCode +"',";
        sql += "        '" + caseNo +"',";
        sql += "        '" + grpCode + "',";
        sql += "        '" + itemCode + "',";
        sql += "        '" + itemValue + "',";
        sql += "        '" + itemNote + "',";
        sql += "        '" + testYMD + "')";
        
        if (!db.executeSQL(sql, sqlResult)) {
            System.out.println("\tError SQL : " + sql);
            System.out.println("\t에러가 발생하여 프로그램을 종료합니다.");
            db.Close(true);
            printDotTimer.cancel();
            System.exit(1);
        }
        return;
    }
    
    public static void deletePLT_CASE_DATA_ITEM_LIST(String caseNo) {
        
        String sql = "";
        
        sql  = " DELETE FROM PLT_CASE_DATA_ITEM_LIST";
        sql += " WHERE  PROJ_CD = '" + projectCode + "'";
        sql += " AND    TASK_CD = '" + taskCode + "'";
        sql += " AND    CASE_NO = '" + caseNo + "'";

        if (!db.executeSQL(sql, sqlResult)) {
            System.out.println("\tError SQL : " + sql);
            System.out.println("\t에러가 발생하여 프로그램을 종료합니다.");
            db.Close(true);
            printDotTimer.cancel();
            System.exit(1);
        }

        return;
        
    }
    
    public static void insertPLT_CASE_DATA_ITEM_LIST(String caseNo, String grpCode, String itemCode, String itemValue, String itemNote, String testYMD, int seq) {
        
        String sql = "";
        
        sql  = " INSERT INTO PLT_CASE_DATA_ITEM_LIST";
        sql += "       (PROJ_CD,";
        sql += "        TASK_CD,";
        sql += "        CASE_NO,";
        sql += "        DATA_GRP_CD,";
        sql += "        DATA_ITEM_CD,";
        sql += "        ITEM_SEQ,";
        sql += "        DATA_ITEM_VAL,";
        sql += "        DATA_ITEM_NOTE,";
        sql += "        TEST_YMD,";
        sql += "        TEST_DURA_MIN";
        sql += "       )";
        sql += " VALUES ('" + projectCode + "',";
        sql += "        '" + taskCode +"',";
        sql += "        '" + caseNo +"',";
        sql += "        '" + grpCode + "',";
        sql += "        '" + itemCode + "',";
        sql += "         " + seq + ",";
        sql += "        '" + itemValue + "',";
        sql += "        '" + itemNote + "',";
        sql += "        '" + testYMD + "',";
        sql += "         " + "0" + ")";
        
        if (!db.executeSQL(sql, sqlResult)) {
            System.out.println("\tError SQL : " + sql);
            System.out.println("\t에러가 발생하여 프로그램을 종료합니다.");
            db.Close(true);
            printDotTimer.cancel();
            System.exit(1);
        }
        return;
    }
    
    public static void deletePLT_CASE_SPECTROGRAM(String caseNo) {
        
        String sql = "";
        
        sql  = " DELETE FROM PLT_CASE_SPECTROGRAM";
        sql += " WHERE  PROJ_CD = '" + projectCode + "'";
        sql += " AND    TASK_CD = '" + taskCode + "'";
        sql += " AND    CASE_NO = '" + caseNo + "'";

        if (!db.executeSQL(sql, sqlResult)) {
            System.out.println("\tError SQL : " + sql);
            System.out.println("\t에러가 발생하여 프로그램을 종료합니다.");
            db.Close(true);
            printDotTimer.cancel();
            System.exit(1);
        }

        return;
        
    }
    
    public static void insertPLT_CASE_SPECTROGRAM(String caseNo, String grpCode, String itemCode, String imgFileName, String imgFilePath, int seq) {
        
        String sql = "";
        
        sql  = " INSERT INTO PLT_CASE_SPECTROGRAM";
        sql += "       (PROJ_CD,";
        sql += "        TASK_CD,";
        sql += "        CASE_NO,";
        sql += "        DATA_GRP_CD,";
        sql += "        DATA_ITEM_CD,";
        sql += "        IMG_SEQ,";
        sql += "        IMG_FILE_NM,";
        sql += "        IMG_FILE_PATH";
        sql += "       )";
        sql += " VALUES ('" + projectCode + "',";
        sql += "        '" + taskCode +"',";
        sql += "        '" + caseNo +"',";
        sql += "        '" + grpCode + "',";
        sql += "        '" + itemCode + "',";
        sql += "         " + seq + ",";
        sql += "        '" + imgFileName + "',";
        sql += "        '" + imgFilePath + "')";
        
        if (!db.executeSQL(sql, sqlResult)) {
            System.out.println("\tError SQL : " + sql);
            System.out.println("\t에러가 발생하여 프로그램을 종료합니다.");
            db.Close(true);
            printDotTimer.cancel();
            System.exit(1);
        }
        return;
    }
    

    // --------------------------------------------------------------------------------------------------------
    // 생성한 파일의 접근 권한 변경
    // --------------------------------------------------------------------------------------------------------
    public static void allowPermission(String fileName) {
        
        if (SystemUtils.IS_OS_WINDOWS) {
            return;
        }
        try {
            File targetFile = new File(fileName);
            if(targetFile.exists()){
                Path p = Paths.get(fileName);
                Set<PosixFilePermission> posixPermissions = PosixFilePermissions.fromString("rw-r--r--");
                Files.setPosixFilePermissions(p, posixPermissions);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
            System.out.println("\t파일 권한 설정 에러 : " + fileName);
            db.Close(true);
            printDotTimer.cancel();
            System.exit(1);
        }
    }
    

    // --------------------------------------------------------------------------------------------------------
    // 파일 존재 여부 체크
    // --------------------------------------------------------------------------------------------------------
    public static boolean isExistFile(String filePath) {
        
        boolean exist = false;
        
        try {
            File file = new File(filePath);

            if (file.exists()) {
                exist = true; 
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return exist;
    }
    
    
    // --------------------------------------------------------------------------------------------------------
    // milliseconds를 입력받아 시간분초 형태로 만들기
    // --------------------------------------------------------------------------------------------------------
    public static String hhmmss(float milliseconds) {
        return DurationFormatUtils.formatDuration((long)(milliseconds * 1000), "HH:mm:ss.SSS");
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 화면상에 진행상황을 표시하기 위하여 점(.) 찍기
    // --------------------------------------------------------------------------------------------------------
    public static void printDotThread() {
        
        while(true) {
            try {
                System.out.print(".");
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    // --------------------------------------------------------------------------------------------------------
    // json 파일에서 문자값 읽어오기
    // --------------------------------------------------------------------------------------------------------
    public static String getStringFromJson(String key, JSONObject object) {
        try {
            if (object.containsKey(key)) {
                Object obj = object.get(key);
                if (obj instanceof String) {
                    return (String) obj;
                }
                else {
                    System.out.printf("\t\tJson parsing warning = %s: %s\n", key, String.valueOf(obj));
                }
            }
            else {
                System.out.printf("\t\tJson parsing warning = key %s not found\n", key);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.printf("\t\tJson parsing error = key %s\n", key);
        }
        return "";
    }
    
    // --------------------------------------------------------------------------------------------------------
    // json 파일에서 숫자값 읽어오기
    // --------------------------------------------------------------------------------------------------------
    public static Number getNumberFromJson(String key, JSONObject object) {
        
        try {
            if (object.containsKey(key)) {
                Object obj = object.get(key);
                if (obj instanceof Number ) {
                    return (Number) obj;
                }
                else {
                    System.out.printf("\t\tJson parsing warning = %s: %s\n", key, String.valueOf(obj));
                    return null;
                }
            }
            else {
                System.out.printf("\t\tJson parsing warning = key %s not found\n", key);
                return null;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.printf("\t\tJson parsing error = key %s\n", key);
        }
        return 0;
    }


}
