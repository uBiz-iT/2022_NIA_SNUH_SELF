package dams_snuh_2022_meta;

import java.util.ArrayList;
import java.util.List;

public class AnnotationLungSound {
    public String caseNumber = "";
    public String caseGroupId = "";  // 환자 1명에 여러 케이스인 경우 비식별 환자 id같은 값을 저장
    public String DiagName = "";     // B21100001, 진단명, , PLT_CASE_DATA_ITEM
    public String gender = "";       // B21100010, 성별
    public String age = "";          // B21100020, 나이
    public String bmi = "";          // B21100025, BMI
    public String smoke = "";        // B21100030, 흡연
    public String weight = "";       // B21100040, 키
    public String height = "";       // B21100050, 체중
    
    public String testDate = "";     // 검사일자
    public String testTime = "";     // 검사시각
    public String py = "";           // pack year

    
    public List<AnnotationLungSoundFile> lungSoundFileList = new ArrayList<AnnotationLungSoundFile>(); // B22100010, 폐음 파일 목록, , PLT_CASE_DATA_ITEM_LIST
}





