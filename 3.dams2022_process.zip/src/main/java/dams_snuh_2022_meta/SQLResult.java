package dams_snuh_2022_meta;

public class SQLResult {
    public Integer code; 
    public String msg;   
}
