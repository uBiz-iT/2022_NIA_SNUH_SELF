package dams_snuh_2022_meta;

public class UEdfSignalInfo {
    int signalNo = -1;
    String signalLabel = "";
    String dimension = "";
    double freq = 0;
    String transducer = "";
    double physicalMin = 0;
    double physicalMax = 0;
    int digitalMin = 0;
    int digitalMax = 0;
    String preFilter = "";
    int sampelsPerDataRecord = 0;
    long totalSamples = 0;
    String reserved = "";
    long totalEpochCount = 0;
}
