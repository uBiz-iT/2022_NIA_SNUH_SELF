package dams_snuh_2022_meta;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class UEdfModule {

    EDFreader hdl;
    
    UEdfBaseInfo baseInfo;
    List<UEdfSignalInfo> signalList;
    
    boolean success = false;
    
    public UEdfModule(String p_path, int epochSize) {
        
        try
        {
            hdl = new EDFreader(p_path);
            baseInfo = setBaseInfo(epochSize);
            signalList = setSignalList();        
            
            success = true;
        }
        catch(IOException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }
        catch(EDFException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }
    }
    
    public long getTotalDuration() {
        return baseInfo.totalDuration;
    }
    
    // --------------------------------------------------------------------------------------------------------
    // edf 파일로부터 기본적인 검사 기본 정보를 가져옴
    // --------------------------------------------------------------------------------------------------------
    public UEdfBaseInfo setBaseInfo(int epochSize) {

        UEdfBaseInfo edfBaseInfo = new UEdfBaseInfo();
        
        // 측정 시작 시각 읽어오기
        int startDateYear = hdl.getStartDateYear();
        int startDateMonth = hdl.getStartDateMonth();
        int startDateDay = hdl.getStartDateDay();
        int startDateHour = hdl.getStartTimeHour();
        int startDateMinute = hdl.getStartTimeMinute();
        int startDateSecond = hdl.getStartTimeSecond();

        edfBaseInfo.startDateTime = LocalDateTime.of(startDateYear, startDateMonth, startDateDay, startDateHour, startDateMinute, startDateSecond);

        int filetype = hdl.getFileType();
        
        // 파일의 타입에 따라 파일의 헤더에 있는 정보를 읽어와서 화면에 출력. edf 파일이냐 edf plus 파일이냐.. 
        if((filetype == EDFreader.EDFLIB_FILETYPE_EDF)  || (filetype == EDFreader.EDFLIB_FILETYPE_BDF))
        {
            edfBaseInfo.patient = hdl.getPatient().trim();
        }
        else
        {
            edfBaseInfo.patient = hdl.getPatientCode().trim();
        }

        edfBaseInfo.signalCount = hdl.getNumSignals();

        edfBaseInfo.recordDuration = (double)(hdl.getLongDataRecordDuration()) / 10000000.0;
        edfBaseInfo.recordCount = hdl.getNumDataRecords();
        edfBaseInfo.totalDuration = (long) (edfBaseInfo.recordDuration * edfBaseInfo.recordCount);
        
        // epoch 수량 계산해보기
        // --------------------------------------------------------------------------------------------------------
        edfBaseInfo.epochSize = epochSize;
        double temp = edfBaseInfo.recordDuration * edfBaseInfo.recordCount / epochSize;     // 시간과 수량을 곱한후 epoch 사이즈로 나눔.
        
        if (temp % 1 > 0) {
            edfBaseInfo.totalEpochCount = (int) temp + 1;
        }
        else {
            edfBaseInfo.totalEpochCount = (int) temp;
        }
        
        return edfBaseInfo;
    }
    
    // --------------------------------------------------------------------------------------------------------
    // edf 파일로부터 시그널 목록 및 정보를 가져옴
    // --------------------------------------------------------------------------------------------------------
    public List<UEdfSignalInfo> setSignalList() {
        
        List<UEdfSignalInfo> edfSignalList = new ArrayList<UEdfSignalInfo>();
        
        for(int i=0; i < hdl.getNumSignals(); i++)
        {
            try {
                UEdfSignalInfo edfSignalInfo = new UEdfSignalInfo();
                
                edfSignalInfo.signalNo = i;
                edfSignalInfo.signalLabel = hdl.getSignalLabel(i).trim();
                edfSignalInfo.dimension = hdl.getPhysicalDimension(i).trim();
                edfSignalInfo.freq = hdl.getSampleFrequency(i);
                edfSignalInfo.transducer = hdl.getTransducer(i);
                edfSignalInfo.physicalMin = hdl.getPhysicalMinimum(i);
                edfSignalInfo.physicalMax = hdl.getPhysicalMaximum(i);
                edfSignalInfo.digitalMin = hdl.getDigitalMinimum(i);
                edfSignalInfo.digitalMax = hdl.getDigitalMaximum(i);
                edfSignalInfo.preFilter = hdl.getPreFilter(i).trim();
                edfSignalInfo.sampelsPerDataRecord = hdl.getSampelsPerDataRecord(i);
                edfSignalInfo.totalSamples = hdl.getTotalSamples(i);
                edfSignalInfo.reserved = hdl.getReserved(i).trim();
                
                edfSignalList.add(edfSignalInfo);
            }
            catch(EDFException e)
            {
                System.out.printf("에러 : ");
                System.out.printf(e.getMessage());
            }
        }
        return edfSignalList;
    }
    

    // --------------------------------------------------------------------------------------------------------
    // 헤더에 있는 기본 정보들 출력해보기
    // --------------------------------------------------------------------------------------------------------
    public void printHeaderInfo() {
        
        System.out.println("------------------------------------------------------------------");
        System.out.println("EDF 파일의 헤더 정보");
        System.out.println("------------------------------------------------------------------");

        // 측정 일자, 측정 시작 시간 등 출력
        System.out.printf("baseInfo.startDateTime   : %s\n", baseInfo.startDateTime);

        System.out.printf("Startdate                : %02d-%02d-%02d\n", hdl.getStartDateDay(), hdl.getStartDateMonth(), hdl.getStartDateYear());
        System.out.printf("Starttime                : %02d:%02d:%02d\n", hdl.getStartTimeHour(), hdl.getStartTimeMinute(), hdl.getStartTimeSecond());
        int filetype = hdl.getFileType();

        // 파일 타입 출력
        System.out.printf("hdl.getFileType()        : %d\n", filetype);

        // 파일의 타입에 따라 파일의 헤더에 있는 정보를 읽어와서 화면에 출력. edf 파일이냐 edf plus 파일이냐.. 
        if((filetype == EDFreader.EDFLIB_FILETYPE_EDF)  || (filetype == EDFreader.EDFLIB_FILETYPE_BDF))
        {
            System.out.printf("Patient                  : %s\n", hdl.getPatient());
            System.out.printf("Recording                : %s\n", hdl.getRecording());
        }
        else
        {
            System.out.printf("Patient code             : %s\n", hdl.getPatientCode());
            System.out.printf("Gender                   : %s\n", hdl.getPatientGender());
            System.out.printf("Birthdate                : %s\n", hdl.getPatientBirthDate());
            System.out.printf("Patient name             : %s\n", hdl.getPatientName());
            System.out.printf("Patient additional       : %s\n", hdl.getPatientAdditional());
            System.out.printf("Admin. code              : %s\n", hdl.getAdministrationCode());
            System.out.printf("Technician               : %s\n", hdl.getTechnician());
            System.out.printf("Equipment                : %s\n", hdl.getEquipment());
            System.out.printf("Recording additional     : %s\n", hdl.getRecordingAdditional());
        }

        System.out.printf("Reserved                 : %s\n", hdl.getReserved());
        System.out.printf("Number of signals        : %d\n", hdl.getNumSignals());

        double durPerRecord = (double)(hdl.getLongDataRecordDuration()) / 10000000.0;
        long numberOfRecords = hdl.getNumDataRecords();
        
        System.out.printf("Number of datarecords    : %d\n", numberOfRecords);
        System.out.printf("Datarecord duration      : %f\n", durPerRecord);
        System.out.printf("Total Duration(sec)      : %f\n", durPerRecord * numberOfRecords);
        
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 어노테이션 정보 출력해보기
    // --------------------------------------------------------------------------------------------------------
    public void printAnnotation() {
        
        System.out.println("------------------------------------------------------------------");
        System.out.println("EDF 파일의 Annotations 정보");
        System.out.println("------------------------------------------------------------------");

        for(int i=0; i<hdl.annotationslist.size(); i++)
        {
            System.out.printf("annotation: onset    : %d:%02d:%02d    description: %s    duration: %d\n",
                                (hdl.annotationslist.get(i).onset / 10000000) / 3600,
                                ((hdl.annotationslist.get(i).onset / 10000000) % 3600) / 60,
                                (hdl.annotationslist.get(i).onset / 10000000) % 60,
                                hdl.annotationslist.get(i).description,
                                hdl.annotationslist.get(i).duration / 1000000);
        }
        
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 기본 정보들 출력해보기
    // --------------------------------------------------------------------------------------------------------
    public void printBaseInfo() {
        
        System.out.println("------------------------------------------------------------------");
        System.out.println("기본 정보");
        System.out.println("------------------------------------------------------------------");

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS").withLocale(Locale.US);
        System.out.printf("Start Date Time          : %s\n", baseInfo.startDateTime.format(formatter));
        System.out.printf("Patient Code             : %s\n", baseInfo.patient);
        System.out.printf("Number of signals        : %d\n", baseInfo.signalCount);
        System.out.printf("Number of records        : %d\n", baseInfo.recordCount);
        System.out.printf("Duration per records(sec): %f\n", baseInfo.recordDuration);
        System.out.printf("Total duration(sec)      : %d\n", baseInfo.totalDuration);
        System.out.printf("epoch size(sec)          : %d\n", baseInfo.epochSize);
        System.out.printf("Number of epoch          : %d\n", baseInfo.totalEpochCount);

    }
    
    // --------------------------------------------------------------------------------------------------------
    // 시그널 정보 출력하기
    // --------------------------------------------------------------------------------------------------------
    public void printOriginSignals() {
        
        // 시그널 수량만큼 시그널 정보 출력 
        for(int i=0; i < hdl.getNumSignals(); i++)
        {
            // 해당 시그널에 대한 여러가지 정보 출력하기
            printOriginSignalInfo(i);
        }

    }
    
    // --------------------------------------------------------------------------------------------------------
    // 시그널 목록 및 정보 출력 하기
    // --------------------------------------------------------------------------------------------------------
    public void printOriginSignalInfo(int signalNo) {
        
        System.out.println("------------------------------------------------------------------");
        System.out.printf("EDF 파일의 시그널 %d번 정보\n", signalNo);
        System.out.println("------------------------------------------------------------------");

        // 해당 시그널에 대한 여러가지 정보 출력하기
        try {
            System.out.printf("Signal No                : %d\n", signalNo);
            System.out.printf("Signal Label             : %s\n", hdl.getSignalLabel(signalNo));
            System.out.printf("Sample frequency         : %f Hz\n", hdl.getSampleFrequency(signalNo));
            System.out.printf("Transducer               : %s\n", hdl.getTransducer(signalNo));
            System.out.printf("Physical dimension       : %s\n", hdl.getPhysicalDimension(signalNo));
            System.out.printf("Physical minimum         : %.10f\n", hdl.getPhysicalMinimum(signalNo));
            System.out.printf("Physical maximum         : %.10f\n", hdl.getPhysicalMaximum(signalNo));
            System.out.printf("Digital minimum          : %d\n", hdl.getDigitalMinimum(signalNo));
            System.out.printf("Digital maximum          : %d\n", hdl.getDigitalMaximum(signalNo));
            System.out.printf("Prefilter                : %s\n", hdl.getPreFilter(signalNo));
            System.out.printf("Samples per record       : %d\n", hdl.getSampelsPerDataRecord(signalNo));
            System.out.printf("Total samples in file    : %d\n", hdl.getTotalSamples(signalNo));
            System.out.printf("Reserved                 : %s\n", hdl.getReserved(signalNo));
        }
        catch(EDFException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
            return;
        }
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 시그널 정보 출력하기
    // --------------------------------------------------------------------------------------------------------
    public void printSignals() {
        
        // 시그널 수량만큼 시그널 정보 출력 
        for(int i=0; i < signalList.size(); i++)
        {
            // 해당 시그널에 대한 여러가지 정보 출력하기
            printSignalInfo(signalList.get(i));
        }

    }
    
    // --------------------------------------------------------------------------------------------------------
    // 시그널 목록 및 정보 출력 하기
    // --------------------------------------------------------------------------------------------------------
    public void printSignalInfo(UEdfSignalInfo signalInfo) {
        
        System.out.println("------------------------------------------------------------------");
        System.out.printf("시그널 %d번 정보\n", signalInfo.signalNo);
        System.out.println("------------------------------------------------------------------");

        System.out.printf("Signal No                : %d\n", signalInfo.signalNo);
        System.out.printf("Signal Label             : %s\n", signalInfo.signalLabel);
        System.out.printf("Sample frequency         : %f Hz\n", signalInfo.freq);
        System.out.printf("Transducer               : %s\n", signalInfo.transducer);
        System.out.printf("Physical dimension       : %s\n", signalInfo.dimension);
        System.out.printf("Physical minimum         : %.10f\n", signalInfo.physicalMin);
        System.out.printf("Physical maximum         : %.10f\n", signalInfo.physicalMax);
        System.out.printf("Digital minimum          : %d\n", signalInfo.digitalMin);
        System.out.printf("Digital maximum          : %d\n", signalInfo.digitalMax);
        System.out.printf("Prefilter                : %s\n", signalInfo.preFilter);
        System.out.printf("Samples per record       : %d\n", signalInfo.sampelsPerDataRecord);
        System.out.printf("Total samples in file    : %d\n", signalInfo.totalSamples);
        System.out.printf("Reserved                 : %s\n", signalInfo.reserved);

    }
    
    // --------------------------------------------------------------------------------------------------------
    // 파일의 시그널 데이터를 뽑은 후 해당 데이터의 시간 정보 등 계산하기(원하는 epoch 번호의 데이터 뽑아오기)
    // --------------------------------------------------------------------------------------------------------
    public List<UEdfOriginData> getOriginData(int signalNo, int epochNo, int epochCount)  
    {
        
        List<UEdfOriginData> originDataList = new ArrayList<UEdfOriginData>();
        
        if (epochNo < 1 || epochNo > baseInfo.totalEpochCount) {
            System.out.printf("epoch 번호 %d가(이) 상한(%d), 하한(1)을 벗어났습니다.\n", epochNo, baseInfo.totalEpochCount);
            return originDataList;
        }

        double[] buf = getData(signalNo, epochNo, epochCount);

        // 읽어올 위치 계산하기 : (에폭번호 - 1) * 하나의 epoch에 표현될 크기(초) * 초당샘플링건수
        long bufStartPosition = (long) ((epochNo - 1) * baseInfo.epochSize * signalList.get(signalNo).freq);

        System.out.printf("Start position       : %d\n", bufStartPosition);

        long startSeconds = (epochNo - 1) * baseInfo.epochSize; // 읽어온 데이터의 첫번째 데이터 시간 구하기(초)

        for(int i=0; i < buf.length; i++)
        {
            UEdfOriginData originData = new UEdfOriginData();

            originData.realPosition = bufStartPosition + i;
            originData.relativeSeconds = (double)Math.round(((double)i/(long)signalList.get(signalNo).freq) * 1000) / 1000;     // 읽은 데이터 처음부터의 경과 시간
            originData.absoluteSeconds = startSeconds + originData.relativeSeconds;                                             // 측정 시각부터 경과 시간
            originData.sampleDateTime = baseInfo.startDateTime.plusNanos(BigDecimal.valueOf(originData.absoluteSeconds).multiply(BigDecimal.valueOf(1000000000)).longValue());  // 측정 시작 시간부터 경과 시간을 더하여 샘플링 데이터의 시간을 구함
            originData.value = buf[i]; 
            originDataList.add(originData);
        }
        
        return originDataList;
     
    }

    public List<UEdfOriginData> getOriginDigitalData(int signalNo, int epochNo, int epochCount)  
    {
        
        List<UEdfOriginData> originDataList = new ArrayList<UEdfOriginData>();
        
        if (epochNo < 1 || epochNo > baseInfo.totalEpochCount) {
            System.out.printf("epoch 번호 %d가(이) 상한(%d), 하한(1)을 벗어났습니다.\n", epochNo, baseInfo.totalEpochCount);
            return originDataList;
        }

        int[] buf = getDigitalData(signalNo, epochNo, epochCount);

        // 읽어올 위치 계산하기 : (에폭번호 - 1) * 하나의 epoch에 표현될 크기(초) * 초당샘플링건수
        long bufStartPosition = (long) ((epochNo - 1) * baseInfo.epochSize * signalList.get(signalNo).freq);

        System.out.printf("Start position       : %d\n", bufStartPosition);

        long startSeconds = (epochNo - 1) * baseInfo.epochSize; // 읽어온 데이터의 첫번째 데이터 시간 구하기(초)

        for(int i=0; i < buf.length; i++)
        {
            UEdfOriginData originData = new UEdfOriginData();

            originData.realPosition = bufStartPosition + i;
            originData.relativeSeconds = (double)Math.round(((double)i/(long)signalList.get(signalNo).freq) * 1000) / 1000;     // 읽은 데이터 처음부터의 경과 시간
            originData.absoluteSeconds = startSeconds + originData.relativeSeconds;                                             // 측정 시각부터 경과 시간
            originData.sampleDateTime = baseInfo.startDateTime.plusNanos(BigDecimal.valueOf(originData.absoluteSeconds).multiply(BigDecimal.valueOf(1000000000)).longValue());  // 측정 시작 시간부터 경과 시간을 더하여 샘플링 데이터의 시간을 구함
            originData.digitalValue = buf[i]; 
            originDataList.add(originData);
        }
        
        return originDataList;
     
    }

    // --------------------------------------------------------------------------------------------------------
    // 파일의 시그널 데이터를 뽑은 후 해당 데이터의 시간 정보 등 계산하기(원하는 시간의 데이터 뽑아오기)
    // --------------------------------------------------------------------------------------------------------
    public List<UEdfOriginData> getOriginData(int signalNo, LocalDateTime queryDateTime, int epochCount)  
    {
        Duration duration = Duration.between(baseInfo.startDateTime, queryDateTime);
        long seconds = duration.getSeconds();
        
        // epoch 번호 찾기. epoch번호는 1부터 이므로 1을 더해준다.
        int epochNo = (int) (seconds / baseInfo.epochSize) + 1;     
        
        return getOriginData(signalNo, epochNo, epochCount);
     
    }

    // --------------------------------------------------------------------------------------------------------
    // 파일의 시그널 데이터 뽑아오기
    // --------------------------------------------------------------------------------------------------------
    @SuppressWarnings("static-access")
    public double[] getData(int signalNo, int epochNo, int epochCount)  
    {
        
        // 1 epoch에 해당하는 샘플링 수량 = 시간(초) * Sampling Rate
        int epochSamplingSize = (int) (signalList.get(signalNo).freq * baseInfo.epochSize * epochCount);

        // 정해진 시간만큼을 가져오기 위한 버퍼 정의. 버퍼 크기는 epochSamplingSize + 1(1개를 더 읽어옴)
        double[] buf = new double[epochSamplingSize + 1];

        // 읽어올 위치 계산하기 : (에폭번호 - 1) * 하나의 epoch에 표현될 크기(초) * 초당샘플링건수
        long bufStartPosition = (long) ((epochNo - 1) * baseInfo.epochSize * signalList.get(signalNo).freq);

        try
        {
            // 파일의 해당 위치로 포인터 이동
            hdl.fseek(signalNo, bufStartPosition, hdl.EDFSEEK_SET);
            
            // 현재 포인터로부터 데이터를 버퍼 크기만큼 읽어옴
            hdl.readPhysicalSamples(signalNo, buf);
        }
        catch(IOException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
        }
        catch(EDFException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
        }        
        
        return buf;
     
    }

    @SuppressWarnings("static-access")
    public int[] getDigitalData(int signalNo, int epochNo, int epochCount)  
    {
        
        // 1 epoch에 해당하는 샘플링 수량 = 시간(초) * Sampling Rate
        int epochSamplingSize = (int) (signalList.get(signalNo).freq * baseInfo.epochSize * epochCount);

        // 정해진 시간만큼을 가져오기 위한 버퍼 정의. 버퍼 크기는 epochSamplingSize + 1(1개를 더 읽어옴)
        int[] buf = new int[epochSamplingSize + 1];

        // 읽어올 위치 계산하기 : (에폭번호 - 1) * 하나의 epoch에 표현될 크기(초) * 초당샘플링건수
        long bufStartPosition = (long) ((epochNo - 1) * baseInfo.epochSize * signalList.get(signalNo).freq);

        try
        {
            // 파일의 해당 위치로 포인터 이동
            hdl.fseek(signalNo, bufStartPosition, hdl.EDFSEEK_SET);
            
            // 현재 포인터로부터 데이터를 버퍼 크기만큼 읽어옴
            //hdl.readPhysicalSamples(signalNo, buf);
            hdl.readDigitalSamples(signalNo, buf);
        }
        catch(IOException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
        }
        catch(EDFException e)
        {
            System.out.printf("에러 : ");
            System.out.printf(e.getMessage());
        }        
        
        return buf;
     
    }

    public void printOriginData(List<UEdfOriginData> originDataList) {
        
        System.out.println("------------------------------------------------------------------");
        System.out.printf("Origin Data List : Sampling count = %d\n", originDataList.size());
        System.out.println("------------------------------------------------------------------");

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS").withLocale(Locale.US);
        
        for(int i=0; i < originDataList.size(); i++) {
            UEdfOriginData originData = originDataList.get(i);
            System.out.printf("%5d: %12.3f: %8d: %12.3f: %s: %.10f: %10d\n", i, originData.relativeSeconds, originData.realPosition, originData.absoluteSeconds, originData.sampleDateTime.format(formatter), originData.value, originData.digitalValue);
        }
        
    }

    // --------------------------------------------------------------------------------------------------------
    // 원본 데이터에서 원하는 샘플링 레이트로 데이터 추출하기
    // 단순하게 선형 보간법 사용, 특정한 보간 방법이 필요한 경우 해당 보간 알고리즘 구현 필요
    // --------------------------------------------------------------------------------------------------------
    public List<UEdfInterpolationData> getInterpolationData(List<UEdfOriginData> originDataList, int originSamplingRate, int targetSamplingRate, int epochNo, int epochCount)  
    {   
        List<UEdfInterpolationData> interpolationDataList = new ArrayList<UEdfInterpolationData>();
        
        double[] source = new double[originDataList.size()];
        for(int i=0; i < originDataList.size(); i++) {
            source[i] = originDataList.get(i).value;
        }
        
        double[] y = getInterpolationData(source, originSamplingRate, targetSamplingRate, epochCount);
        
        long startSeconds = (epochNo - 1) * baseInfo.epochSize; // 읽어온 데이터의 첫번째 데이터 시간 구하기(초)

        for(int i=0; i < y.length; i++) {
            
            UEdfInterpolationData interpolationData = new UEdfInterpolationData();
            
            interpolationData.relativeSeconds = (double)Math.round(((double)i/(long)targetSamplingRate) * 1000) / 1000;     // 읽은 데이터 처음부터의 경과 시간
            interpolationData.absoluteSeconds = startSeconds + interpolationData.relativeSeconds;                           // 측정 시각부터 경과 시간

            // 측정 시작 시간부터 경과 시간을 더하여 샘플링 데이터의 시간을 구함, BigDemal을 사용하지 않으면 부동소수점 방식이라 연산 후 결과값이 원하지 않는 값이 나오는 경우가 발생함.
            interpolationData.sampleDateTime = baseInfo.startDateTime.plusNanos(BigDecimal.valueOf(interpolationData.absoluteSeconds).multiply(BigDecimal.valueOf(1000000000)).longValue());     
            interpolationData.value = y[i];
            
            interpolationDataList.add(interpolationData);
        }
        
        return interpolationDataList;
        
    }
    

    // --------------------------------------------------------------------------------------------------------
    // 원본 데이터를 뽑은 후 보간 데이터까지 한번에 뽑아오기
    // 단순하게 선형 보간법 사용, 특정한 보간 방법이 필요한 경우 해당 보간 알고리즘 구현 필요
    // --------------------------------------------------------------------------------------------------------
    public List<UEdfInterpolationData> getInterpolationData(int signalNo, int targetSamplingRate, int epochNo, int epochCount)  
    {   
        int originSamplingRate = (int) signalList.get(signalNo).freq;

        List<UEdfOriginData> originDataList = getOriginData(signalNo, epochNo, epochCount);

        return getInterpolationData(originDataList, originSamplingRate, targetSamplingRate, epochNo, epochCount);
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 원본 데이터를 뽑은 후 보간 데이터까지 한번에 뽑아오기(시간으로)
    // --------------------------------------------------------------------------------------------------------
    public List<UEdfInterpolationData> getInterpolationData(int signalNo, int targetSamplingRate, LocalDateTime queryDateTime, int epochCount)  
    {   
        Duration duration = Duration.between(baseInfo.startDateTime, queryDateTime);
        long seconds = duration.getSeconds();
        
        // epoch 번호 찾기. epoch번호는 1부터 이므로 1을 더해준다.
        int epochNo = (int) (seconds / baseInfo.epochSize) + 1;     

        return getInterpolationData(signalNo, targetSamplingRate, epochNo, epochCount);
    }
    
    public void printInterpolationData(List<UEdfInterpolationData> interpolationDataList, int samplingRate) {
        
        System.out.println("------------------------------------------------------------------");
        System.out.printf("Interpolation Data List : sampling rate = %d, sampling count = %d\n", samplingRate, interpolationDataList.size());
        System.out.println("------------------------------------------------------------------");

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS").withLocale(Locale.US);
        
        for(int i=0; i < interpolationDataList.size(); i++) {
            UEdfInterpolationData interpolationData = interpolationDataList.get(i);
            System.out.printf("%5d: %12.3f: %12.3f: %s: %20.10f\n", i, interpolationData.relativeSeconds, interpolationData.absoluteSeconds, interpolationData.sampleDateTime.format(formatter), interpolationData.value);
        }
        
    }

    private double[] getInterpolationData(double[] source, int originSamplingRate, int targetSamplingRate, int epochCount)  
    {   
        int x1, x2;
        double y1, y2, xn, yn, a, xZeroBase;
        double[] y = new double[targetSamplingRate*baseInfo.epochSize*epochCount + 1];
        
        double samplingOffset = (double)originSamplingRate / (double)targetSamplingRate;
                
        for(int i=0; i < y.length; i++) {
            
            xn = samplingOffset * i;        // 원하는 x 좌표값 구하기
            x1 = (int) xn;                    // xPos보다 작거나 같은 정수 구하기
            x2 = (int) Math.ceil(xn);        // xPos보다 크거나 같은 정수 구하기, x2는 x1과 동일하거나 1만큼 큼
            yn = 0;
            
            if (x1 < source.length && x2 < source.length) {
                if (x1 == x2) {
                    yn = source[x1];
                }
                else {
                    y1 = source[x1];
                    y2 = source[x2];
                    a = y2 - y1;        // 기울기
                    xZeroBase = xn - x1;        // 소숫점만 남기기
                    yn = a * xZeroBase + y1;    // y값 구하기
                }
                
            }
            y[i] = yn;
        }
        
        return y;
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 특정 시그널의 전체 데이터를 추출하여 구간별로 평균, 최대, 최소값 구하기
    // --------------------------------------------------------------------------------------------------------
    public List<UEdfStatisticData> getStatisticData(int signalNo, long wantedCount)  
    {   
        List<UEdfStatisticData> statisticDataList = new ArrayList<UEdfStatisticData>();
        
        if (wantedCount <= 0 || signalNo >= signalList.size()) {
            return statisticDataList;
        }
        
        // 버퍼 사이즈는 전체 샘플링 개수를 화면에 표시하기 위하여 필요한 개수로 나눈 값을 소수점 자리 올림
        // 계산된 값이 0이면 1로 강제 세팅.  
        int bufSize = Math.round(signalList.get(signalNo).totalSamples / wantedCount);
        if (bufSize == 0) {
            bufSize = 1;
        }

        // 버퍼사이즈만큼 일단 가져옴 
        double[] buf = new double[bufSize];

        // 읽어올 위치 계산하기 : 처음부터 마지막까지 전부 읽어야 함
        long bufStartPosition = 0;
        int readByteCount = 0;
        int readCount = 0;
        long currentPosition = 0;
        double sum = 0;
        double sumAbs = 0;
        
        System.out.printf("\tCalculating statistic data : signalNo = %d, wantedCount = %d\n", signalNo, wantedCount);

        try
        {
            // 파일의 해당 위치로 포인터 이동
            hdl.fseek(signalNo, bufStartPosition, EDFreader.EDFSEEK_SET);
            
            while(true) {
                Arrays.fill(buf, 0);
                
                currentPosition = hdl.ftell(signalNo);
                
                readByteCount = hdl.readPhysicalSamples(signalNo, buf);

                if (readByteCount == 0) {
                    break;
                }
                
                readCount += 1;
                
                UEdfStatisticData statisticData = new UEdfStatisticData();

                // 최소,최대값에 첫번째 값 저장
                statisticData.max = buf[0];
                statisticData.min = buf[0];
                statisticData.count = readByteCount;

                sum = 0;
                sumAbs = 0;
                
                // sum of all values in array using for loop
                for (int i = 0; i < readByteCount; i++) {
                    
                    sum += buf[i];
                    sumAbs += Math.abs(buf[i]);
                            
                    if (buf[i] > statisticData.max) {
                        statisticData.max = buf[i];
                    }
                    if (buf[i] < statisticData.min) {
                        statisticData.min = buf[i];
                    }
                    
                    //if (readCount == 1) {
                    //    System.out.printf(" %d, %15.9f\n", currentPosition + i , buf[i]);
                    //}
                }
         
                // 평균값 구하기
                statisticData.avg = sum / readByteCount;
                statisticData.avgAbs = sumAbs / readByteCount;
                
                // 목록에 추가
                statisticDataList.add(statisticData);
                
                // System.out.printf(" readCount = %d, readCount=%d\n", readCount, readByteCount);

                if (readCount >= wantedCount) {
                    break;
                }

            }

            // 원하는 수량보다 작으면 나머지를 0으로 채운다. 
            // 원하는 수량보다 총 샘플링 수가 적을 경우 나타나는 현상이며 원래 이렇게 하면 안되는데 일단 이렇게 한다. 
            int listCount = statisticDataList.size();
            
            if (listCount < wantedCount) {
                
                System.out.printf("\tSampling 수량(%d)이 작습니다. 데이터 이상일 수 있음.\n", listCount);

                for (int i = listCount; i < wantedCount; i++) {
                    UEdfStatisticData statisticData = new UEdfStatisticData();
                    statisticData.max = 0;
                    statisticData.min = 0;
                    statisticData.avg = 0;
                    statisticData.avgAbs = 0;
                    statisticDataList.add(statisticData);
                }
            }
            else {
                System.out.printf("\n\tSampling 수량 체크 결과 OK \n", listCount);
            }
            
        }
        catch(IOException e)
        {
            System.out.printf("\t에러 : ");
            System.out.printf(e.getMessage());
        }
        catch(EDFException e)
        {
            System.out.printf("\t에러 : ");
            System.out.printf(e.getMessage());
        }           
        
        return statisticDataList;
        
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 특정 시그널의 전체 데이터를 추출하여 구간별로 평균, 최대, 최소값 구하기(1개의 sample당 몇초로 할지)
    // --------------------------------------------------------------------------------------------------------
    public UEdfStatisticInfo getStatisticDataInfo(int signalNo, int secondsPerOneSample)  
    {   
        UEdfStatisticInfo statisticInfo = new UEdfStatisticInfo();
        
        if (secondsPerOneSample <= 0 || signalNo >= signalList.size()) {
            return statisticInfo;
        }
        
        // 몇 초에 1개씩 Sampling을 할지. 계산하기 좋게.. 20220708
        // buffer size = 초당 샘플링 수 * 5초        
        int bufSize = (int) Math.round(signalList.get(signalNo).freq * 5);

        // 버퍼사이즈만큼 일단 가져옴 
        double[] buf = new double[bufSize];

        // 읽어올 위치 계산하기 : 처음부터 마지막까지 전부 읽어야 함
        long bufStartPosition = 0;
        int readByteCount = 0;
        int readCount = 0;
        long currentPosition = 0;
        double sum = 0;
        double sumAbs = 0;
        
        System.out.printf("\tCalculating statistic data : signalNo = %d(%s), 평균/%d초\n", signalNo, signalList.get(signalNo).signalLabel, secondsPerOneSample);

        try
        {
            // 파일의 해당 위치로 포인터 이동
            hdl.fseek(signalNo, bufStartPosition, EDFreader.EDFSEEK_SET);
            
            while(true) {
                Arrays.fill(buf, 0);
                
                currentPosition = hdl.ftell(signalNo);
                
                readByteCount = hdl.readPhysicalSamples(signalNo, buf);

                if (readByteCount == 0) {
                    break;
                }
                
                readCount += 1;
                
                UEdfStatisticData statisticData = new UEdfStatisticData();

                // 최소,최대값에 첫번째 값 저장
                statisticData.max = buf[0];
                statisticData.min = buf[0];
                statisticData.count = readByteCount;

                sum = 0;
                sumAbs = 0;
                
                // sum of all values in array using for loop
                for (int i = 0; i < readByteCount; i++) {
                    
                    sum += buf[i];
                    sumAbs += Math.abs(buf[i]);
                            
                    if (buf[i] > statisticData.max) {
                        statisticData.max = buf[i];
                    }
                    if (buf[i] < statisticData.min) {
                        statisticData.min = buf[i];
                    }
                    
                    //if (readCount == 1) {
                    //    System.out.printf(" %d, %15.9f\n", currentPosition + i , buf[i]);
                    //}
                }
         
                // 평균값 구하기
                statisticData.avg = sum / readByteCount;
                statisticData.avgAbs = sumAbs / readByteCount;
                
                // 목록에 추가
                statisticInfo.statisticDataList.add(statisticData);
                
                // System.out.printf(" readCount = %d, readCount=%d\n", readCount, readByteCount);

            }

            statisticInfo.samplingCount = statisticInfo.statisticDataList.size();
            statisticInfo.secondsPerOneSample = secondsPerOneSample;
            
        }
        catch(IOException e)
        {
            System.out.printf("\t에러 : ");
            System.out.printf(e.getMessage());
        }
        catch(EDFException e)
        {
            System.out.printf("\t에러 : ");
            System.out.printf(e.getMessage());
        }           
        
        return statisticInfo;
        
    }
    
    public void printStatisticData(List<UEdfStatisticData> statisticDataList) {
        
        System.out.println("------------------------------------------------------------------");
        System.out.printf(" Statistic Data List : sampling count = %d\n", statisticDataList.size());
        System.out.println("------------------------------------------------------------------");

        for(int i=0; i < statisticDataList.size(); i++) {
            UEdfStatisticData statisticData = statisticDataList.get(i);
            System.out.printf("%5d: %15.9f: %15.9f: %15.9f: %d\n", i, statisticData.avg, statisticData.min, statisticData.max, statisticData.count);
        }
        
    }


}
