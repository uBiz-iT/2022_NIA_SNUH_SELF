package dams_snuh_2022_meta;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class ForSubmission {

	static String projectCode = "";
	static String sourceDir = "";
	static String targetDir = "";
	
	static String sourcePathString = "";
	static String targetPathString = "";
	static File sourceRoot;
	static File targetRoot;
	
	static JSONParser parser = new JSONParser();
	
	Integer caseCount = 0;
	
	public static void main(String[] args) {

        if (args.length <= 2) {
            System.out.println("프로젝트 코드와 소스 디렉토리 및 원본 디렉토리를 입력하세요");
            return;
        }
        
		projectCode = args[0];
		sourceDir = args[1];
		targetDir = args[2];
        
		try {
			sourcePathString = new java.io.File(sourceDir).getCanonicalPath();
			targetPathString = new java.io.File(targetDir).getCanonicalPath();
		} 
		catch (IOException e1) {
			e1.printStackTrace();
			System.exit(1);
		}
		
		try {

            sourceRoot = new File(sourcePathString);

            // -------------------------------------------------------------------------------
            // 프로젝트 데이터 디렉토리가 존재하는지 체크하여 없으면 종료
            // -------------------------------------------------------------------------------
            if(!sourceRoot.exists())
            {
                System.out.println(" 소스 디렉토리 경로 " + sourcePathString + "이 존재하지 않습니다.");
                return;
            }
            
            // -------------------------------------------------------------------------------
            // 소스 디렉토리 Path가 디렉토리가 아니면 종료
            // -------------------------------------------------------------------------------
            if(!sourceRoot.isDirectory())
            {
                System.out.println(" 소스 디렉토리 경로가 디렉토리가 아닙니다.");
                return;
            }

            // 타겟 디렉토리
            targetRoot = new File(targetPathString);

            System.out.println(" 타겟 디렉토리 경로 " + targetRoot);

            switch (projectCode) 
            {   
                case "2022A1":  // 수면 데이터의 경우
                	sleep();
                    break;
                
                case "2022B1":  // 폐기능 데이터의 경우
                	pft();
                    break;
                    
                case "2022B2":  // 폐음 데이터의 경우
                	lungsound();
                	break;
                	
                default:
                    System.out.printf(" 유효한 프로젝트 코드가 아닙니다. : " + projectCode);
                    break;
            }
		}
		catch (Exception e) {
			e.printStackTrace();
		}
            
	}
	
    // --------------------------------------------------------------------------------------------------------
    // 폐기능 데이터 처리
    // --------------------------------------------------------------------------------------------------------
    private static void pft() 
    {
        File[] sourceRootFileList = sourceRoot.listFiles();
        Arrays.sort(sourceRootFileList);

        // -------------------------------------------------------------------------------
        // 환자 코드 디렉토리 하나씩 검색
        // -------------------------------------------------------------------------------
        for(File patientRootFile : sourceRootFileList)
        {   
            // 디렉토리가 아닌 것은 처리할 필요가 없음
            if(!patientRootFile.isDirectory())
            {
                continue;
            }
            
            File[] caseRootFileList = patientRootFile.listFiles();
            Arrays.sort(caseRootFileList);

            // 케이스 디렉토리 하나씩
            for(File caseRootFile : caseRootFileList)
            {   
                // 디렉토리가 아닌 것은 처리할 필요가 없음
                if(!caseRootFile.isDirectory())
                {
                    continue;
                }
                
                String hospitalCode = caseRootFile.getName().substring(0, 1).toUpperCase();

                try {
                    // JSON 파일 명
                    String jsonFileName = caseRootFile.getName() + "-annotation.json";
                    
                    // JSON 파일 읽기
                    String jsonSourcePath = Paths.get(caseRootFile.getCanonicalPath(), jsonFileName).toString().replace("\\", "/");
                    
                    System.out.println("\tAnnotation 파일 경로 : " + jsonSourcePath);
                    
                    FileReader jsonSourceFileReader = new FileReader(jsonSourcePath);
                    
                    Object obj = parser.parse(jsonSourceFileReader);

                    JSONObject jsonObject =  (JSONObject) obj;

                    // -----------------------------------------------------------------------------
                    // Case_Info 객체 read, 진단명 읽기
                    // -----------------------------------------------------------------------------
                    JSONObject caseInfo = (JSONObject) jsonObject.get("Case_Info");
                    String diagClass = getStringFromJson("diagnosis", caseInfo);
                    
                    // 라벨링 타겟 디렉토리 설정. 진단명 디렉토리 포함
                    String targetLabelingDirPathString = Paths.get(targetRoot.getCanonicalPath(), "라벨링데이터", diagClass, hospitalCode, patientRootFile.getName(), caseRootFile.getName()).toString().replace("\\", "/");
                    File targetLabelingDirFile = new File(targetLabelingDirPathString);

                    // 소스 타겟 디렉토리 설정, 진단명 디렉토리 포함
                    String targetSourceDirPathString = Paths.get(targetRoot.getCanonicalPath(), "원천데이터", diagClass, hospitalCode, patientRootFile.getName(), caseRootFile.getName()).toString().replace("\\", "/");
                    File targetSourceDirFile = new File(targetSourceDirPathString);
                    
                    // 기존에 디렉토리가 있으면 삭제.
                    if (targetLabelingDirFile.exists()) {
                        // 파일이던 디렉토리이던 무조건 삭제
                        FileUtils.forceDelete(targetLabelingDirFile);
                    }
                            
                    // 기존에 디렉토리가 있으면 삭제.
                    if (targetSourceDirFile.exists()) {
                        // 파일이던 디렉토리이던 무조건 삭제
                        FileUtils.forceDelete(targetSourceDirFile);
                    }
                            
                    // 타겟 디렉토리 생성
                    targetLabelingDirFile.mkdirs();
                    targetSourceDirFile.mkdirs();
                    
                    // -------------------------------------------------------------------------------
                    // 디렉토리에 JSON 파일 복사
                    // -------------------------------------------------------------------------------
                	File labelingFile = new File(jsonSourcePath);
					FileUtils.copyFileToDirectory(labelingFile, targetLabelingDirFile);
					
					System.out.println("\t복사 from : " + labelingFile.getCanonicalPath());
					System.out.println("\t복사 to   : " + targetLabelingDirFile.getCanonicalPath());
					
                    // 원천 데이터 복사하기
					String sourceFileName = caseRootFile.getName() + "-pft-source.edf";
                    String sourceFilePath = Paths.get(caseRootFile.getCanonicalPath(), sourceFileName).toString().replace("\\", "/");
                	File sourceFile = new File(sourceFilePath);
					FileUtils.copyFileToDirectory(sourceFile, targetSourceDirFile);
                	
					System.out.println("\t복사 from : " + sourceFile.getCanonicalPath());
					System.out.println("\t복사 to   : " + targetSourceDirFile.getCanonicalPath());
					
                }
                catch (IOException e) {
                	e.printStackTrace();
                }
                catch (Exception e) {
                	e.printStackTrace();
				}
                
            } 

        } 
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 폐음 데이터 처리
    // --------------------------------------------------------------------------------------------------------
    private static void lungsound() 
    {
        File[] sourceRootFileList = sourceRoot.listFiles();
        Arrays.sort(sourceRootFileList);

        // -------------------------------------------------------------------------------
        // 환자 코드 디렉토리 하나씩 검색
        // -------------------------------------------------------------------------------
        for(File patientRootFile : sourceRootFileList)
        {   
            // 디렉토리가 아닌 것은 처리할 필요가 없음
            if(!patientRootFile.isDirectory())
            {
                continue;
            }
            
            File[] caseRootFileList = patientRootFile.listFiles();
            Arrays.sort(caseRootFileList);

            // 케이스 디렉토리 하나씩
            for(File caseRootFile : caseRootFileList)
            {   
                // 디렉토리가 아닌 것은 처리할 필요가 없음
                if(!caseRootFile.isDirectory())
                {
                    continue;
                }
                
                String hospitalCode = caseRootFile.getName().substring(0, 1).toUpperCase();

                try {
                    // JSON 파일 명
                    String jsonFileName = caseRootFile.getName() + "-annotation.json";
                    
                    // JSON 파일 읽기
                    String jsonSourcePath = Paths.get(caseRootFile.getCanonicalPath(), jsonFileName).toString().replace("\\", "/");
                    
                    System.out.println("\tAnnotation 파일 경로 : " + jsonSourcePath);
                    
                    FileReader jsonSourceFileReader = new FileReader(jsonSourcePath);
                    
                    Object obj = parser.parse(jsonSourceFileReader);

                    JSONObject jsonObject =  (JSONObject) obj;

                    // -----------------------------------------------------------------------------
                    // Case_Info 객체 read, 진단명 읽기
                    // -----------------------------------------------------------------------------
                    JSONObject caseInfo = (JSONObject) jsonObject.get("Case_Info");
                    String diagClass = getStringFromJson("diagnosis", caseInfo);
                    
                    // 라벨링 타겟 디렉토리 설정. 진단명 디렉토리 포함
                    String targetLabelingDirPathString = Paths.get(targetRoot.getCanonicalPath(), "메타데이터", diagClass, hospitalCode, patientRootFile.getName(), caseRootFile.getName()).toString().replace("\\", "/");
                    File targetLabelingDirFile = new File(targetLabelingDirPathString);

                    // 소스 타겟 디렉토리 설정, 진단명 디렉토리 포함
                    String targetSourceDirPathString = Paths.get(targetRoot.getCanonicalPath(), "원천데이터", diagClass, hospitalCode, patientRootFile.getName(), caseRootFile.getName()).toString().replace("\\", "/");
                    File targetSourceDirFile = new File(targetSourceDirPathString);
                    
                    // 기존에 디렉토리가 있으면 삭제.
                    if (targetLabelingDirFile.exists()) {
                        // 파일이던 디렉토리이던 무조건 삭제
                        FileUtils.forceDelete(targetLabelingDirFile);
                    }
                            
                    // 기존에 디렉토리가 있으면 삭제.
                    if (targetSourceDirFile.exists()) {
                        // 파일이던 디렉토리이던 무조건 삭제
                        FileUtils.forceDelete(targetSourceDirFile);
                    }
                            
                    // 타겟 디렉토리 생성
                    targetLabelingDirFile.mkdirs();
                    targetSourceDirFile.mkdirs();
                    
                    // -------------------------------------------------------------------------------
                    // 디렉토리에 JSON 파일 복사
                    // -------------------------------------------------------------------------------
                	File labelingFile = new File(jsonSourcePath);
					FileUtils.copyFileToDirectory(labelingFile, targetLabelingDirFile);
					
					System.out.println("\t복사 from : " + labelingFile.getCanonicalPath());
					System.out.println("\t복사 to   : " + targetLabelingDirFile.getCanonicalPath());
					
                    // 원천 데이터 복사하기(규칙에 맞는 WAV 파일만 추출하여 복사)
	                File[] sourceWavList = caseRootFile.listFiles(new FilenameFilter() {
	                    public boolean accept(File dir, String name) {
	                    	return name.matches(caseRootFile.getName() + "-sound-[L,R][1-8].wav");
	                    }
	                });
	                
	                Arrays.sort(sourceWavList);
	                
	                int i = 0;
	                for (File waveFile : sourceWavList) {
						FileUtils.copyFileToDirectory(waveFile, targetSourceDirFile);
						System.out.printf("\t복사 from : (%d) %s\n", ++i, waveFile.getCanonicalPath());
						System.out.printf("\t복사 to   : (%d) %s\n", i, targetSourceDirFile.getCanonicalPath());
	                }

                }
                catch (IOException e) {
                	e.printStackTrace();
                }
                catch (Exception e) {
                	e.printStackTrace();
				}
                
            } 

        } 
    }
    

    // --------------------------------------------------------------------------------------------------------
    // 수면 데이터 처리
    // --------------------------------------------------------------------------------------------------------
    private static void sleep() 
    {
        File[] caseRootFileList = sourceRoot.listFiles();
        Arrays.sort(caseRootFileList);

        // 케이스 디렉토리 하나씩
        for(File caseRootFile : caseRootFileList)
        {   
            // 디렉토리가 아닌 것은 처리할 필요가 없음
            if(!caseRootFile.isDirectory())
            {
                continue;
            }
            
            String hospitalCode = caseRootFile.getName().substring(0, 1).toUpperCase();
            String patientCode = caseRootFile.getName().substring(0, 9);
            
            try {
                // JSON 파일 명
                String jsonFileName = caseRootFile.getName() + ".json";
                
                // JSON 파일 읽기
                String jsonSourcePath = Paths.get(caseRootFile.getCanonicalPath(), jsonFileName).toString().replace("\\", "/");
                
                System.out.println("\tAnnotation 파일 경로 : " + jsonSourcePath);
                
                FileReader jsonSourceFileReader = new FileReader(jsonSourcePath);
                
                Object obj = parser.parse(jsonSourceFileReader);

                JSONObject jsonObject =  (JSONObject) obj;

                // -----------------------------------------------------------------------------
                // Test_Result 객체 read, 진단명 읽기
                // -----------------------------------------------------------------------------
                JSONObject caseInfo = (JSONObject) jsonObject.get("Test_Result");
                String osaRisk = getStringFromJson("OSA_Risk", caseInfo);
                
                String diagClass = "Normal";
                if (osaRisk.compareTo("Y") == 0) {
                	diagClass = "OSA";
                }
                
                // 라벨링 타겟 디렉토리 설정. 진단명 디렉토리 포함
                String targetLabelingDirPathString = Paths.get(targetRoot.getCanonicalPath(), "라벨링데이터", diagClass, hospitalCode, caseRootFile.getName()).toString().replace("\\", "/");
                File targetLabelingDirFile = new File(targetLabelingDirPathString);

                // 소스 타겟 디렉토리 설정, 진단명 디렉토리 포함
                String targetSourceDirPathString = Paths.get(targetRoot.getCanonicalPath(), "원천데이터", diagClass, hospitalCode, caseRootFile.getName()).toString().replace("\\", "/");
                File targetSourceDirFile = new File(targetSourceDirPathString);
                
                // 기존에 디렉토리가 있으면 삭제.
                if (targetLabelingDirFile.exists()) {
                    // 파일이던 디렉토리이던 무조건 삭제
                    FileUtils.forceDelete(targetLabelingDirFile);
                }
                        
                // 기존에 디렉토리가 있으면 삭제.
                if (targetSourceDirFile.exists()) {
                    // 파일이던 디렉토리이던 무조건 삭제
                    FileUtils.forceDelete(targetSourceDirFile);
                }
                        
                // 타겟 디렉토리 생성
                targetLabelingDirFile.mkdirs();
                targetSourceDirFile.mkdirs();
                
                // -------------------------------------------------------------------------------
                // 디렉토리에 JSON 파일 복사
                // -------------------------------------------------------------------------------
            	File labelingFile = new File(jsonSourcePath);
				FileUtils.copyFileToDirectory(labelingFile, targetLabelingDirFile);
				
				System.out.println("\t복사 from : " + labelingFile.getCanonicalPath());
				System.out.println("\t복사 to   : " + targetLabelingDirFile.getCanonicalPath());
				
                // 원천 데이터 복사하기
				String sourceFileName = caseRootFile.getName() + "-raw.edf";
                String sourceFilePath = Paths.get(caseRootFile.getCanonicalPath(), sourceFileName).toString().replace("\\", "/");
            	File sourceFile = new File(sourceFilePath);
				FileUtils.copyFileToDirectory(sourceFile, targetSourceDirFile);
            	
				System.out.println("\t복사 from : " + sourceFile.getCanonicalPath());
				System.out.println("\t복사 to   : " + targetSourceDirFile.getCanonicalPath());
				
            }
            catch (IOException e) {
            	e.printStackTrace();
            }
            catch (Exception e) {
            	e.printStackTrace();
			}
            
        } 

    }

    
    // --------------------------------------------------------------------------------------------------------
    // json 파일에서 문자값 읽어오기
    // --------------------------------------------------------------------------------------------------------
    public static String getStringFromJson(String key, JSONObject object) {
        try {
            if (object.containsKey(key)) {
                Object obj = object.get(key);
                if (obj instanceof String) {
                    return (String) obj;
                }
                else {
                    System.out.printf("\t\tJson parsing warning = %s: %s\n", key, String.valueOf(obj));
                }
            }
            else {
                System.out.printf("\t\tJson parsing warning = key %s not found\n", key);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.printf("\t\tJson parsing error = key %s\n", key);
        }
        return "";
    }
    
    // --------------------------------------------------------------------------------------------------------
    // json 파일에서 숫자값 읽어오기
    // --------------------------------------------------------------------------------------------------------
    public static Number getNumberFromJson(String key, JSONObject object) {
        
        try {
            if (object.containsKey(key)) {
                Object obj = object.get(key);
                if (obj instanceof Number ) {
                    return (Number) obj;
                }
                else {
                    System.out.printf("\t\tJson parsing warning = %s: %s\n", key, String.valueOf(obj));
                    return null;
                }
            }
            else {
                System.out.printf("\t\tJson parsing warning = key %s not found\n", key);
                return null;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.printf("\t\tJson parsing error = key %s\n", key);
        }
        return 0;
    }

}
