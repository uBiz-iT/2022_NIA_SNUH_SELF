package dams_snuh_2022_meta;

import java.util.ArrayList;
import java.util.List;

public class AnnotationSleep {
    public String caseNumber = "";
    public String caseGroupId = "";          // 환자 1명에 여러 케이스인 경우 비식별 환자 id같은 값을 저장
    public String gender = "";               // A21100010   성별, PLT_CASE_DATA_ITEM
    public String age = "";                  // A21100020   나이
    public String bmi = "";                  // A21100030   BMI
    
    public String tot_sleep_time = "";       // A21200010   총수면시간(분)              
    public String sleep_effi = "";           // A21200020   수면효율(%)              
    public String sleep_latency = "";        // A21200030   수면잠복기(분)             
    public String ahi = "";                  // A21300010   AHI                  
    public String rdi = "";                  // A21300020   RDI                   
    public String oxy_satu_avg = "";         // A21300030   평균산소포화도(%)           
    public String oxy_satu_min = "";         // A21300040   최저산소포화도(%)           
    public String tot_lm_index = "";         // A21400010   총 LM index           
    public String tot_lm_arou = "";          // A21400020   총 LM Arousal index   
    public String arou_index = "";           // A21400030   총 Arousal index      
                                        
    public String signalFileName = "";       // A22100000   EKG,Actigraphy EDF 파일
    public String signalDuration = "";       // 시그널 파일의 총 저장 시간
    public String avgFileName = "";          // A22100005   EKG,Actigraphy 평균 값 CSV 파일
    
    // 설문지 문항
    public String PSQI_Q1 = "";
    public String PSQI_Q2 = "";
    public String PSQI_Q3 = "";
    public String PSQI_Q4 = "";
    public String PSQI_Q5_1 = "";
    public String PSQI_Q5_2 = "";
    public String PSQI_Q5_3 = "";
    public String PSQI_Q5_4 = "";
    public String PSQI_Q5_5 = "";
    public String PSQI_Q5_6 = "";
    public String PSQI_Q5_7 = "";
    public String PSQI_Q5_8 = "";
    public String PSQI_Q5_9 = "";
    public String PSQI_Q5_10 = "";
    public String PSQI_Q5_11 = "";
    public String PSQI_Q6 = "";
    public String PSQI_Q7 = "";
    public String PSQI_Q8 = "";
    public String PSQI_Q9 = "";
    
    public String ESS_Q1 = ""; 
    public String ESS_Q2 = ""; 
    public String ESS_Q3 = ""; 
    public String ESS_Q4 = ""; 
    public String ESS_Q5 = ""; 
    public String ESS_Q6 = ""; 
    public String ESS_Q7 = ""; 
    public String ESS_Q8 = ""; 
    public String ESS_Q9 = ""; 
    public String ESS_Q10 = ""; 
    public String ESS_Q11 = "";
    
    public String Berlin_C1_1 = "";
    public String Berlin_C1_2 = "";
    public String Berlin_C1_3 = "";
    public String Berlin_C1_4 = "";
    public String Berlin_C1_5 = "";
    public String Berlin_C2_1 = "";
    public String Berlin_C2_2 = "";
    public String Berlin_C2_3 = "";
    public String Berlin_C2_4 = "";
    public String Berlin_C3_1 = "";
    
    public String PSQI_Score = "";
    public String ESS_Score = "";
    public String Berlin_Score = "";
    public String Berlin_Score1 = "";
    public String Berlin_Score2 = "";
    public String Berlin_Score3 = "";

    public List<String> soundFileList = new ArrayList<String>();    // A24100010   5분 단위 수면 사운드 파일, PLT_CASE_DATA_ITEM_LIST
    public List<String> spectrogramList = new ArrayList<String>();  // 30초 단위 mel spectrogram image 파일 목록,  PLT_CASE_SPECTROGRAM

}



