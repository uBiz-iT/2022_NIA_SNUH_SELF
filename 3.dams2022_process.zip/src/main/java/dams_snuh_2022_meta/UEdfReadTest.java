package dams_snuh_2022_meta;

/*
 *****************************************************************************
 * edf file 읽기 테스트 프로그램
 * 2022/06/15
 * midas
 * 
 * Teunis van Beelen 가 개발한 모듈 사용
 *****************************************************************************
 */

import java.io.*;
import java.math.BigDecimal;
import java.nio.*;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.PumpStreamHandler;

public class UEdfReadTest
{

    // 화면에 dot(.)을 출력하기 위하여
    static boolean isPrintDot = false;
    static Timer printDotTimer = new Timer();
    static TimerTask printDotTimerTask = new TimerTask() {
        @Override
        public void run() {
            if (isPrintDot) {
                System.out.print(".");
            }
        }
    };

    @SuppressWarnings("static-access")
    public static void main(String[] args)
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS").withLocale(Locale.US);

        if(args.length == 0)
        {
            System.out.println("아규먼트에 파일명을 추가하세요.\n");
            printDotTimer.cancel();
            return;
        }

        // --------------------------------------------------------------------------------------------------------
        // 한번에 가져올때 얼마큼의 데이터를 가져올지 변수 정의. 단위 : 초. 기본적으로 PSG 검사 1 epoch 단위가 30초이므로 해당 값으로 설정
        // epoch : 일정한 단위(주로 화면에서 분석하는 그래프의 시간축 크기를 의미함. 수면쪽 데이터 분석은 주로 1 epoch이 30초이다.
        // 30초 단위를 1 epoch이라고 하며,  1부터 30초 단위로 epoch 번호를 부여한다.
        // --------------------------------------------------------------------------------------------------------
        int epochSize = 300;

        UEdfModule edf = new UEdfModule(args[0], epochSize);
        if (!edf.success) {
            printDotTimer.cancel();
            return;
        }
        
        // ----------------------------------------------------------------------------------------------------
        // 파일의 정보를 바로 읽어보자
        // ----------------------------------------------------------------------------------------------------
        edf.printHeaderInfo();
        edf.printAnnotation();
        edf.printOriginSignals();
        
        // ----------------------------------------------------------------------------------------------------
        // 파일을 읽어서 저장해 놓은 데이터를 읽어보자
        // ----------------------------------------------------------------------------------------------------
        edf.printBaseInfo();
        //edf.printSignals();
        
        // ----------------------------------------------------------------------------------------------------
        // 실제 원하는 시그널의 특정 위치의 데이터를 특정 크기만큼 읽어보자 
        // ----------------------------------------------------------------------------------------------------

        // --------------------------------------------------------------------------------------------------------
        // epoch no, signal no 설정
        // --------------------------------------------------------------------------------------------------------
        int signalNo = 3;              // 시그널 번호 설정
        int epochNo = 41;                // 읽고자 하는 epoch 번호 설정. 1이면 첫번째 epoch
        int epochCount = 1;             // 몇개의 epoch 데이터를 가져올 것인지. ex) 1이면 30초, 2이면 60초

        int targetSamplingRate = 10;   // 초당 몇개의 데이터를 화면에서 핸들링할지 정하기
        int originSamplingRate = (int) edf.signalList.get(signalNo).freq;

        edf.printSignalInfo(edf.signalList.get(signalNo));

        printDotTimer.schedule(printDotTimerTask, 1000, 1000);

        // --------------------------------------------------------------------------------------------------------
        // 원본 데이터를 가져와서 보간 데이터 구하기
        // --------------------------------------------------------------------------------------------------------
        
        System.out.println("------------------------------------------------------------------");
        System.out.println("원본 데이터 가져온 후 보간 데이터 가져오기");
        System.out.println("------------------------------------------------------------------");

        List<UEdfOriginData> originDataList = edf.getOriginDigitalData(signalNo, epochNo, epochCount);
        edf.printOriginData(originDataList);
        
        
        //List<UEdfInterpolationData> iDataList = edf.getInterpolationData(originDataList, originSamplingRate, targetSamplingRate, epochNo, epochCount);
        //edf.printInterpolationData(iDataList, targetSamplingRate);
        
        
        // --------------------------------------------------------------------------------------------------------
        // 한번에 보간 데이터 가져오기
        // --------------------------------------------------------------------------------------------------------
        /*
        System.out.println("------------------------------------------------------------------");
        System.out.println("보간 데이터 한방에 가져오기");
        System.out.println("------------------------------------------------------------------");

        List<UEdfInterpolationData> iDataList2 = edf.getInterpolationData(signalNo, targetSamplingRate, epochNo, epochCount);
        edf.printInterpolationData(iDataList2, targetSamplingRate);
        */
        
        // --------------------------------------------------------------------------------------------------------
        // 특정 시간(현실 시간) 에 해당하는 데이터 가져오기
        // --------------------------------------------------------------------------------------------------------
        // 원하는 년월일시분초
        /*
        LocalDateTime queryDateTime = LocalDateTime.of(2020, 2, 20, 22, 31, 11);

        System.out.println("------------------------------------------------------------------");
        System.out.println("원하는 시간의 보간 데이터 한방에 가져오기");
        System.out.println("------------------------------------------------------------------");
        System.out.printf("Request date, time   : %s\n", queryDateTime.format(formatter));

        List<UEdfInterpolationData> iDataList3 = edf.getInterpolationData(signalNo, targetSamplingRate, queryDateTime, epochCount);
        edf.printInterpolationData(iDataList3, targetSamplingRate);
        */
        
        // --------------------------------------------------------------------------------------------------------
        // 전체 데이터를 특정 개수만큼 가져오는데 해당 구간별 평균값을 구해서 가져옴
        // --------------------------------------------------------------------------------------------------------
        /*

        int count = 3600;
        
        System.out.println("------------------------------------------------------------------");
        System.out.printf(" 전체 데이터로부터 %d개 Sampling(전체 현황 파악용, 구간별 평균값 산출)\n", count);
        System.out.println("------------------------------------------------------------------");

        isPrintDot = true;                        
        List<UEdfStatisticData> iDataList4 = edf.getStatisticData(8, count);
        isPrintDot = false;
        
        //edf.printStatisticData(iDataList4);

        isPrintDot = true;                        
        List<UEdfStatisticData> iDataList5 = edf.getStatisticData(21, count);
        isPrintDot = false;

        //edf.printStatisticData(iDataList5);
        
        isPrintDot = true;                        
        List<UEdfStatisticData> iDataList6 = edf.getStatisticData(22, count);
        isPrintDot = false;
        
        //edf.printStatisticData(iDataList6);

        isPrintDot = true;                        
        List<UEdfStatisticData> iDataList7 = edf.getStatisticData(23, count);
        isPrintDot = false;
        
        //edf.printStatisticData(iDataList7);
        
        
        try (PrintWriter writer = new PrintWriter(new File("data" + count + ".csv"))) {

            StringBuilder sb = new StringBuilder();

            sb.append(String.format ("%d\n", count));
            sb.append(String.format ("seq,ecg,actx,acty,actz\n"));
            
            for(int i=0; i < count; i++) {
                sb.append(String.format ("%d,%.5f,%.5f,%.5f,%.5f\n", i, iDataList4.get(i).avg, iDataList5.get(i).avg, iDataList6.get(i).avg, iDataList7.get(i).avg));
            }

            writer.write(sb.toString());
            writer.close();
            System.out.println("\n 구간 평균 값 파일 생성 OK!");

        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
        */

        /*
        for(int i=0; i < 5000; i++) {
            System.out.printf("%5d,%15.9f,%15.9f,%15.9f,%15.9f,%15.9f,%15.9f,%15.9f,%15.9f\n", i, iDataList4.get(i).avg, iDataList4.get(i).avgAbs, iDataList5.get(i).avg, iDataList5.get(i).avgAbs, iDataList6.get(i).avg, iDataList6.get(i).avgAbs, iDataList7.get(i).avg, iDataList7.get(i).avgAbs);
        }
        */
        
        // dot 출력 타이머 취소
        printDotTimer.cancel();
        
        
    } // main 끝

  

} // 클래스 끝




