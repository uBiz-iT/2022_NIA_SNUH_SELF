package dams_snuh_2022_meta;

public class AnnotationLungSoundFile {
    public String Location = "";
    public String lungSoundfileName = ""; // B22100010, 폐음 파일 
}
