package dams_snuh_2022_meta;

public class UEdfStatisticData {
    double avg;         // 평균값
    double avgAbs;      // 절대값 평균
    double min;         // 최소값
    double max;         // 최대값
    int count;          // 샘플링개수
}
