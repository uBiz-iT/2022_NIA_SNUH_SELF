package dams_snuh_2022_meta;
import java.time.LocalDateTime;

public class UEdfInterpolationData {
    double relativeSeconds;         // buffer의 첫번째 데이터의 시간을 0초로 놓고 경과 시간
    double absoluteSeconds;         // 파일의 첫번째 데이터의 시간을 0초로 놓고 경과 시간
    LocalDateTime sampleDateTime;   // 현실 시간 값 저장용, 기본 값은 헤더에서 읽어온 측정 시작 시각
    double value;  
}
