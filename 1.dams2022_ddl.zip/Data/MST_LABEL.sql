SET DEFINE OFF;
Insert into MST_LABEL
   (PROJ_CD, LBL_CD, LBL_DISP, LBL_NM, USE_YN, 
    DISP_SEQ, REG_ID, REG_DT)
 Values
   ('2022A1', 'A101', 'Normal', '����', 'Y', 
    1, 'SUPERUSER', TO_DATE('06/20/2022 19:48:17', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_LABEL
   (PROJ_CD, LBL_CD, LBL_DISP, LBL_NM, USE_YN, 
    DISP_SEQ, REG_ID, REG_DT)
 Values
   ('2022A1', 'A102', 'OSA risk', 'OSA ���� ��ȣ', 'Y', 
    2, 'SUPERUSER', TO_DATE('04/26/2022 12:19:50', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_LABEL
   (PROJ_CD, LBL_CD, LBL_DISP, LBL_NM, USE_YN, 
    DISP_SEQ, REG_ID, REG_DT)
 Values
   ('2022A1', 'Z   ', 'Drop', '���ܺҰ�,�����Ϳ���', 'Y', 
    3, 'SUPERUSER', TO_DATE('04/26/2022 12:25:14', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_LABEL
   (PROJ_CD, LBL_CD, LBL_DISP, LBL_NM, USE_YN, 
    DISP_SEQ, REG_ID, REG_DT)
 Values
   ('2022B1', 'B101', 'Normal', '����', 'Y', 
    1, 'SUPERUSER', TO_DATE('06/20/2022 19:46:43', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_LABEL
   (PROJ_CD, LBL_CD, LBL_DISP, LBL_NM, USE_YN, 
    DISP_SEQ, REG_ID, REG_DT)
 Values
   ('2022B1', 'B102', 'COPD', '������⼺����ȯ', 'Y', 
    2, 'SUPERUSER', TO_DATE('06/20/2022 19:47:03', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_LABEL
   (PROJ_CD, LBL_CD, LBL_DISP, LBL_NM, USE_YN, 
    DISP_SEQ, REG_ID, REG_DT)
 Values
   ('2022B1', 'B103', 'Asthma', 'õ��', 'Y', 
    3, 'SUPERUSER', TO_DATE('06/20/2022 19:47:30', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_LABEL
   (PROJ_CD, LBL_CD, LBL_DISP, LBL_NM, USE_YN, 
    DISP_SEQ, REG_ID, REG_DT)
 Values
   ('2022B1', 'B104', 'IPF', 'Ư�߼�����ȭ��', 'Y', 
    4, 'SUPERUSER', TO_DATE('06/20/2022 19:47:39', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_LABEL
   (PROJ_CD, LBL_CD, LBL_DISP, LBL_NM, USE_YN, 
    DISP_SEQ, REG_ID, REG_DT)
 Values
   ('2022B1', 'Z   ', 'Drop', '���ܺҰ�,�����Ϳ���', 'Y', 
    5, 'SUPERUSER', TO_DATE('06/20/2022 19:48:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_LABEL
   (PROJ_CD, LBL_CD, LBL_DISP, LBL_NM, USE_YN, 
    DISP_SEQ, REG_ID, REG_DT)
 Values
   ('2022B2', 'B201', 'Pass', '����������', 'Y', 
    1, 'SUPERUSER', TO_DATE('06/20/2022 19:46:43', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_LABEL
   (PROJ_CD, LBL_CD, LBL_DISP, LBL_NM, USE_YN, 
    DISP_SEQ, REG_ID, REG_DT)
 Values
   ('2022B2', 'Z   ', 'Fail', '�����Ϳ���', 'Y', 
    2, 'SUPERUSER', TO_DATE('06/20/2022 19:48:17', 'MM/DD/YYYY HH24:MI:SS'));
COMMIT;
