SET DEFINE OFF;
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'Case_Info', 'ȯ�� �ӻ�����', 'Y', 1, 
    'midas', TO_DATE('05/26/2022 08:27:59', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'Ekg_Act', 'EKG, Actigraphy', 'Y', 5, 
    'midas', TO_DATE('05/26/2022 08:31:03', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'Report1', '�⺻ ��������', 'Y', 2, 
    'midas', TO_DATE('05/26/2022 08:27:59', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'Report2', '���� ȣ�� ��� �˻�', 'Y', 3, 
    'midas', TO_DATE('05/26/2022 08:28:45', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'Report3', '���� � ��� �˻�', 'Y', 4, 
    'midas', TO_DATE('05/26/2022 08:30:45', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'Sound', '���� ����', 'Y', 6, 
    'midas', TO_DATE('05/26/2022 08:31:26', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'Survey', '���� ���', 'N', 7, 
    'midas', TO_DATE('05/26/2022 08:32:04', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'SurveySummary', '���� ���ھ�', 'Y', 17, 
    'midas', TO_DATE('05/26/2022 08:32:04', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022B1', 'Air_Pollution', '��� ���� ������', 'Y', 4, 
    'midas', TO_DATE('05/26/2022 08:35:15', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022B1', 'Case_Info', 'ȯ�� �ӻ�����', 'Y', 1, 
    'midas', TO_DATE('05/26/2022 08:32:10', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022B1', 'PFT_File', '���� �˻� ����', 'Y', 3, 
    'midas', TO_DATE('05/26/2022 08:34:27', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022B1', 'PFT_Result', '���� �˻� ������', 'Y', 2, 
    'midas', TO_DATE('05/26/2022 08:33:45', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022B2', 'Case_Info', 'ȯ�� �ӻ�����', 'Y', 1, 
    'midas', TO_DATE('05/26/2022 08:32:10', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022B2', 'Sound', '���� ������', 'Y', 2, 
    'midas', TO_DATE('05/26/2022 08:34:40', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'SurveyBerlin1', 'Berlin ī�װ��� 1 (1~5)', 'Y', 14, 
    'midas', TO_DATE('05/26/2022 08:32:04', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'SurveyBerlin2', 'Berlin ī�װ��� 2 (6~9)', 'Y', 15, 
    'midas', TO_DATE('05/26/2022 08:32:04', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'SurveyBerlin3', 'Berlin ī�װ��� 3 (10)', 'Y', 16, 
    'midas', TO_DATE('05/26/2022 08:32:04', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'SurveyESS1', 'ESS ���� ���(1~8)', 'Y', 12, 
    'midas', TO_DATE('05/26/2022 08:32:04', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'SurveyESS2', 'ESS ���� ���(9~11)', 'Y', 13, 
    'midas', TO_DATE('05/26/2022 08:32:04', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'SurveyPSQI1', 'PSQI ���� ���(1~4)', 'Y', 8, 
    'midas', TO_DATE('05/26/2022 08:32:04', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'SurveyPSQI2', 'PSQI ���� ���(5)', 'Y', 9, 
    'midas', TO_DATE('05/26/2022 08:32:04', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'SurveyPSQI3', 'PSQI ���� ���(5,��Ÿ)', 'Y', 10, 
    'midas', TO_DATE('05/26/2022 08:32:04', 'MM/DD/YYYY HH24:MI:SS'));
Insert into MST_DATA_GROUP
   (PROJ_CD, DATA_GRP_CD, DATA_GRP_NM, USE_YN, DISP_SEQ, 
    REG_ID, REG_DT)
 Values
   ('2022A1', 'SurveyPSQI4', 'PSQI ���� ���(6~9)', 'Y', 11, 
    'midas', TO_DATE('05/26/2022 08:32:04', 'MM/DD/YYYY HH24:MI:SS'));
COMMIT;
