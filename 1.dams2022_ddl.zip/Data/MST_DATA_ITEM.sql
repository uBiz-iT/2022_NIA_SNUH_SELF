SET DEFINE OFF;
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Case_Info', 'Sex', '����', 'N', 
    'S', 'Y', 1, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Case_Info', 'Age', '����', 'N', 
    'I', 'Y', 2, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Case_Info', 'BMI', 'BMI', 'N', 
    'D', 'Y', 3, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, FILE_TP, USE_YN, DISP_SEQ, REG_ID, 
    REG_DT, VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Ekg_Act', 'edf_file', 'EKG,Actigraphy EDF ����', 'N', 
    'L', 'B', 'Y', 1, 'SUPERUSER', 
    TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, FILE_TP, USE_YN, DISP_SEQ, REG_ID, 
    REG_DT, VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Ekg_Act', 'average_file', 'EKG,Actigraphy ��� �� CSV ����', 'N', 
    'L', 'C', 'Y', 1, 'SUPERUSER', 
    TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Report1', 'Total_Sleep_Time(TST)', '�Ѽ���ð�(��)', 'N', 
    'D', 'Y', 1, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Report1', 'Sleep_Efficiency', '����ȿ��(%)', 'N', 
    'D', 'Y', 2, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Report1', 'Sleep_Latency', '�����ẹ��(��)', 'N', 
    'D', 'Y', 3, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Report2', 'AHI', 'AHI', 'N', 
    'D', 'Y', 1, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Report2', 'RDI', 'RDI', 'N', 
    'D', 'Y', 2, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Report2', 'Mean_Oxygen_Saturation', '��ջ����ȭ��(%)', 'N', 
    'D', 'Y', 3, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Report2', 'Lowest_Oxygen_Desaturation', '���������ȭ��(%)', 'N', 
    'D', 'Y', 4, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Report3', 'Total_LM_Index', '�� LM index', 'N', 
    'D', 'Y', 1, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Report3', 'Total_LM_Arousal_Index', '�� LM Arousal index', 'N', 
    'D', 'Y', 2, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Report3', 'Total_Arousal_Index', '�� Arousal index', 'N', 
    'D', 'Y', 3, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, FILE_TP, USE_YN, DISP_SEQ, REG_ID, 
    REG_DT, VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Sound', 'sound_file', '���� ���� ����', 'N', 
    'L', 'A', 'Y', 1, 'SUPERUSER', 
    TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Survey', 'A15100010', '�ڰ���(���ۿ� �鸱 ������ �ڸ� ���.)', 'N', 
    'B', 'N', 1, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Survey', 'A15100020', '�ǰ���(�� ���� ���� �ǰ��ϰų� ������)', 'N', 
    'B', 'N', 2, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Survey', 'A15100030', '����(���� ��, ���� ���߰ų� ���� ���� ���� �ִ�.)', 'N', 
    'B', 'N', 3, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Survey', 'A15100040', '������(�������� �ִ�)', 'N', 
    'B', 'N', 4, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Survey', 'A15100050', 'BMI(ü���������� 35�� �Ѵ´�.)', 'N', 
    'B', 'N', 5, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Survey', 'A15100060', '����(50�� �̻��̴�.)', 'N', 
    'B', 'N', 6, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Survey', 'A15100070', '��ѷ�(��ѷ��� ���� 43cm, ���� 41cm �̻�)', 'N', 
    'B', 'N', 7, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'Survey', 'A15100080', '����(����)', 'N', 
    'B', 'N', 8, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveySummary', 'ESS_Score', 'ESS ���ھ�', 'N', 
    'I', 'Y', 2, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', 100, 0, '����ġ: 10�� �̻�');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveySummary', 'Berlin_Score', 'Berlin ���ھ�', 'N', 
    'I', 'Y', 3, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', 100, 0, '����ġ: 2���̻� �缺');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Air_Pollution', 'pm10_value', '�̼�����(PM10) (��/��, 24h)', 'N', 
    'D', 'Y', 1, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Air_Pollution', 'pm2.5_value', '�ʹ̼�����(PM2.5) (��/��, 24h)', 'N', 
    'D', 'Y', 2, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Air_Pollution', 'no2_value', '�̻�ȭ����(ppm)', 'N', 
    'D', 'Y', 3, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Air_Pollution', 'o3_value', '����(ppm)', 'N', 
    'D', 'Y', 4, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Air_Pollution', 'co_value', '�ϻ�ȭź��(ppm)', 'N', 
    'D', 'Y', 5, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Air_Pollution', 'so2_value', '��Ȳ�갡��(ppm)', 'N', 
    'D', 'Y', 6, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Case_Info', 'diagnosis', '���ܸ�', 'N', 
    'S', 'Y', 1, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Case_Info', 'gender', '����', 'N', 
    'S', 'Y', 2, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Case_Info', 'age', '����', 'N', 
    'I', 'Y', 3, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Case_Info', 'bmi', 'BMI', 'N', 
    'D', 'Y', 4, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Case_Info', 'smoking', '����', 'N', 
    'S', 'Y', 5, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Case_Info', 'py', 'Pack Year', 'N', 
    'I', 'Y', 6, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Case_Info', 'height', 'Ű', 'N', 
    'D', 'Y', 7, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Case_Info', 'weight', 'ü��', 'N', 
    'D', 'Y', 8, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Case_Info', 'date', '�˻�����', 'N', 
    'S', 'Y', 9, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Case_Info', 'time', '�˽ýð�', 'N', 
    'S', 'Y', 10, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'Case_Info', 'residence', '������', 'N', 
    'S', 'Y', 11, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, FILE_TP, USE_YN, DISP_SEQ, REG_ID, 
    REG_DT, VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'PFT_File', 'pft_file', '���� �˻� ����', 'N', 
    'L', 'C', 'Y', 1, 'SUPERUSER', 
    TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'PFT_Result', 'FVC_L', 'FVC(l)', 'N', 
    'D', 'Y', 1, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'PFT_Result', 'FVC_P', 'FVC(%)', 'N', 
    'D', 'Y', 2, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'PFT_Result', 'FEV1_L', 'FEV1(l)', 'N', 
    'D', 'Y', 3, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'PFT_Result', 'FEV1_P', 'FEV1(%)', 'N', 
    'D', 'Y', 4, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'PFT_Result', 'FEV1_FVC', 'FEV1/FVC', 'N', 
    'D', 'Y', 5, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'PFT_Result', 'PEF', 'PEF', 'N', 
    'D', 'Y', 6, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B1', 'PFT_Result', 'FEF25-75', 'FEF 25-75', 'N', 
    'D', 'Y', 7, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B2', 'Case_Info', 'diagnosis', '���ܸ�', 'N', 
    'S', 'Y', 1, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B2', 'Case_Info', 'gender', '����', 'N', 
    'S', 'Y', 2, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B2', 'Case_Info', 'age', '����', 'N', 
    'I', 'Y', 3, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B2', 'Case_Info', 'bmi', 'BMI', 'N', 
    'D', 'Y', 4, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B2', 'Case_Info', 'smoking', '����', 'N', 
    'S', 'Y', 5, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B2', 'Case_Info', 'py', 'Pack Year', 'N', 
    'I', 'Y', 6, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B2', 'Case_Info', 'height', 'Ű', 'N', 
    'D', 'Y', 7, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B2', 'Case_Info', 'weight', 'ü��', 'N', 
    'D', 'Y', 8, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B2', 'Case_Info', 'date', '�˻�����', 'N', 
    'S', 'Y', 9, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B2', 'Case_Info', 'time', '�˽ýð�', 'N', 
    'S', 'Y', 10, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, FILE_TP, USE_YN, DISP_SEQ, REG_ID, 
    REG_DT, VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022B2', 'Sound', 'sound_file', '���� ����', 'Y', 
    'L', 'A', 'Y', 1, 'SUPERUSER', 
    TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyBerlin1', 'Berlin_C1-1', '1. �ڰ��̰� �ֳ���?', 'N', 
    'I', 'Y', 1, 'N', 2, 
    0, '�ƴϿ�|��(1)|��');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyBerlin1', 'Berlin_C1-2', '2. ���� �ڸ� ��ٸ� �ڰ��� �Ҹ��� �����?', 'N', 
    'I', 'Y', 2, 'N', 3, 
    0, '���Ҹ����� �ణ ũ��|���Ҹ���ŭ ũ��|���Ҹ����� ũ��(1)|�ſ� ũ��(���濡�� �鸱 ����)(1)');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyBerlin1', 'Berlin_C1-3', '3. �󸶳� ���� �ڸ� ������?', 'N', 
    'I', 'Y', 3, 'N', 4, 
    0, '���� ����,����|�� 1~2ȸ|�� 1~2ȸ|�� 3~4ȸ(1)|���� ����(1)');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyBerlin1', 'Berlin_C1-4', '4. �ڰ��̷� �ٸ� ������� �����ð� �� ���� �ֳ���?', 'N', 
    'I', 'Y', 4, 'N', 2, 
    0, '�ƴϿ�|��(1)|��');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyBerlin1', 'Berlin_C1-5', '5. ���� �� ��ȣ���� �ִ� ���� �ٸ� ������� �˰� �ֳ���?', 'N', 
    'I', 'Y', 5, 'N', 4, 
    0, '���� ����,����|�� 1~2ȸ|�� 1~2ȸ|�� 3~4ȸ(1)|���� ����(1)');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyBerlin2', 'Berlin_C2-1', '6. ���� �Ŀ� �󸶳� ���� �ǰ����� ��������?', 'N', 
    'I', 'Y', 6, 'N', 4, 
    0, '���� ����,����|�� 1~2ȸ|�� 1~2ȸ|�� 3~4ȸ(1)|���� ����(1)');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyBerlin2', 'Berlin_C2-2', '7. ���� ���� �� �ǰ����� ��������?', 'N', 
    'I', 'Y', 7, 'N', 4, 
    0, '���� ����,����|�� 1~2ȸ|�� 1~2ȸ|�� 3~4ȸ(1)|���� ����(1)');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyBerlin2', 'Berlin_C2-3', '8. �ڵ��� ���� �� �ῡ �� ���� �ֳ���?', 'N', 
    'I', 'Y', 8, 'N', 1, 
    0, '�ƴϿ�|��(1)');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyBerlin2', 'Berlin_C2-4', '9. ���� �ִٸ� �󸶳� ���� �ڵ��� ���� �� ���� �峪��?', 'N', 
    'I', 'Y', 9, 'N', 4, 
    0, '���� ����,����|�� 1~2ȸ|�� 1~2ȸ|�� 3~4ȸ(1)|���� ����(1)');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyBerlin3', 'Berlin_C3-1', '10. �������� �ΰ� �ֳ���?', 'N', 
    'I', 'Y', 10, 'N', 2, 
    0, '�ƴϿ�|��(1)|��');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyESS1', 'ESS_Q1', '1. �ɾƼ� ������ ��', 'N', 
    'I', 'Y', 1, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyESS1', 'ESS_Q2', '2. TV �� ��', 'N', 
    'I', 'Y', 2, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyESS1', 'ESS_Q3', '3. ������ҿ��� �ϴ� �� ���� ������ �ɾ� ���� ��', 'N', 
    'I', 'Y', 3, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyESS1', 'ESS_Q4', '4. �ѽð� �̻� ��� �������� �� �ӿ� �°����� ���� ��', 'N', 
    'I', 'Y', 4, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyESS1', 'ESS_Q5', '5. ���Ŀ� ���鼭 ȥ�� ���� ���� ��', 'N', 
    'I', 'Y', 5, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyESS1', 'ESS_Q6', '6. �ɾƼ� ����� ��ȭ�� ��', 'N', 
    'I', 'Y', 6, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyESS1', 'ESS_Q7', '7. ���� ������ �ʰ� ���ɽĻ� �� ������ �ɾ� ���� ��', 'N', 
    'I', 'Y', 7, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyESS1', 'ESS_Q8', '8. ���� Ÿ�� ���� ���� ��ȣ�� ��ٸ��� ���� ��', 'N', 
    'I', 'Y', 8, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyESS2', 'ESS_Q9', '9. ȯ�ں��� �����ϴ� �������� �ְ� ������ ����(Daytime Sleepiness VAS)', 'N', 
    'I', 'Y', 9, 'N', 10, 
    1, '1 ������|2|3|4|5|6|7|8|9|10 ����');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyESS2', 'ESS_Q10', '10. ȯ�ں��� �����ϴ� ������ ������ �� ����(Sleep Quality VAS)', 'N', 
    'I', 'Y', 10, 'N', 10, 
    1, '1 ����|2|3|4|5|6|7|8|9|10 ����');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyESS2', 'ESS_Q11', '11. ȯ�ں��� �����ϴ� ������ �ڰ����� ����(Snoring VAS)', 'N', 
    'I', 'Y', 11, 'N', 10, 
    1, '1 ����|2|3|4|5|6|7|8|9|10 ����');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'SurveyPSQI1', 'PSQI_Q1', '1. ���� �� �ް�, �㿡 ���� �� �ÿ� ���ڸ��� ������ϱ�?', 'N', 
    'S', 'Y', 1, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'SurveyPSQI1', 'PSQI_Q2', '2. ���� �� �ް�, ���� �Ŀ� ��� ������ ���� �󸶳� �ɷȽ��ϱ�?', 'N', 
    'S', 'Y', 2, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'SurveyPSQI1', 'PSQI_Q3', '3. ���� �� �ް�, ���� ��ħ �� �ÿ� �Ͼ���ϱ�?', 'N', 
    'S', 'Y', 3, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'SurveyPSQI1', 'PSQI_Q4', '4. ���� �� �ް�, �� ���ȿ� ������ �� �ð��� �� �ð��̳� �˴ϱ�?', 'N', 
    'S', 'Y', 4, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL)
 Values
   ('2022A1', 'SurveyPSQI2', 'PSQI_Q5-1', '5-1. ���� �� �ް�, ������ 30�� �̳��� ����� ���Ͽ���.', 'N', 
    'I', 'Y', 5, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', -1000000000, 1000000000);
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI2', 'PSQI_Q5-2', '5-2. �ڴٰ� �� �� ���̳� �̸� ��ħ�� ���� ����.', 'N', 
    'I', 'Y', 6, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI2', 'PSQI_Q5-3', '5-3. �Һ� ������ ȭ��ǿ� ������ �ڴٰ� �Ͼ��.', 'N', 
    'I', 'Y', 7, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI2', 'PSQI_Q5-4', '5-4. �ڸ鼭 ���� ���� ���� ���Ͽ���.', 'N', 
    'I', 'Y', 8, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI2', 'PSQI_Q5-5', '5-5. �� �� ��ħ�� �ϰų� �ڸ� ���ϰ� ��Ҵ�.', 'N', 
    'I', 'Y', 9, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI2', 'PSQI_Q5-6', '5-6. �ڴٰ� �ʹ� ��� ������', 'N', 
    'I', 'Y', 10, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI2', 'PSQI_Q5-7', '5-7. �ڴٰ� �ʹ� ���� ������.', 'N', 
    'I', 'Y', 11, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI2', 'PSQI_Q5-8', '5-8. �ڸ鼭 �Ǹ��� �پ���.', 'N', 
    'I', 'Y', 12, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI2', 'PSQI_Q5-9', '5-9. �ڴٰ� ������ ������.', 'N', 
    'I', 'Y', 13, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI2', 'PSQI_Q5-10', '5-10.��Ÿ �ٸ� ������ ���� �� �ް� ���� �� ������ �󸶳� ���� �־����ϱ�?', 'N', 
    'I', 'Y', 14, 'N', 3, 
    0, '0|1|2|3');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN)
 Values
   ('2022A1', 'SurveyPSQI3', 'PSQI_Q5-11', '     ��Ÿ �ٸ� ����', 'N', 
    'S', 'Y', 15, 'N');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI4', 'PSQI_Q6', '6. ���� �� �ް�, ����� �������� ���� ���¸� ��� ���Ͻðڽ��ϱ�?', 'N', 
    'I', 'Y', 16, 'N', 3, 
    0, '0: �ſ����Ҵ�|1: ���� ���̾���|2: ���� ���̾���|3: �ſ� ������');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI4', 'PSQI_Q7', '7. ���� �� �ް�, ���� �ڱ� ���� ó�� �ްų� �౹���� ������ ���� �󸶳� ���� �����ϼ̽��ϱ�?', 'N', 
    'I', 'Y', 17, 'N', 3, 
    0, '0: �׷� ���� ������|1: 1���Ͽ� �ѹ� �̸�|2: 1���Ͽ� �� �ι�|3: 1���Ͽ� �� �� �̻�');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI4', 'PSQI_Q8', '8. ���� �� �ް�, �����ϰų� �Ļ��ϰų� ��ȸ�� Ȱ�� ���� �ϸ鼭 ���� �ֱ� ������� ��찡 �󸶳� ���� �־����ϱ�?', 'N', 
    'I', 'Y', 18, 'N', 3, 
    0, '0: �׷� ���� ������|1: 1���Ͽ� �ѹ� �̸�|2: 1���Ͽ� �� �ι�|3: 1���Ͽ� �� �� �̻�');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, VAL_CHK_YN, MAX_VAL, 
    MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveyPSQI4', 'PSQI_Q9', '9. ���� �� �ް�, ������ ���� �ϴµ� �־� �󸶳� ���� ������� �־����ϱ�?', 'N', 
    'I', 'Y', 19, 'N', 3, 
    0, '0: ���� ������|1: ���� ����� ������� �־���|2: ��� ���� ������� �־���|3: �ſ� ū ������� �־���');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveySummary', 'PSQI_Score', 'PSQI ���ھ�', 'N', 
    'I', 'Y', 1, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', 100, 0, '����ġ: 9�� �̻�');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveySummary', 'Berlin_Score1', 'Berlin ���ھ�(ī�װ���1)', 'N', 
    'I', 'Y', 4, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', 100, 0, '����ġ: 2���̻� �缺');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveySummary', 'Berlin_Score2', 'Berlin ���ھ�(ī�װ���2)', 'N', 
    'I', 'Y', 5, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', 100, 0, '����ġ: 2���̻� �缺');
Insert into MST_DATA_ITEM
   (PROJ_CD, DATA_GRP_CD, DATA_ITEM_CD, DATA_ITEM_NM, ARR_YN, 
    DATA_TP, USE_YN, DISP_SEQ, REG_ID, REG_DT, 
    VAL_CHK_YN, MAX_VAL, MIN_VAL, SEL_LIST)
 Values
   ('2022A1', 'SurveySummary', 'Berlin_Score3', 'Berlin ���ھ�(ī�װ���3)', 'N', 
    'I', 'Y', 6, 'SUPERUSER', TO_DATE('05/26/2022 08:38:45', 'MM/DD/YYYY HH24:MI:SS'), 
    'N', 100, 0, '����ġ: 1�� or BMI��30 �缺');
COMMIT;
