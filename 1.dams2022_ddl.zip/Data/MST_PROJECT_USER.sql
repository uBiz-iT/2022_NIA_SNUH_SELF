SET DEFINE OFF;

Insert into MST_PROJECT_USER
   (PROJ_CD, USER_ID, MGR_YN, REG_ID, REG_DT)
 Values
   ('2022A1', 'midas', 'Y', 'midas', SYSDATE);

Insert into MST_PROJECT_USER
   (PROJ_CD, USER_ID, MGR_YN, REG_ID, REG_DT)
 Values
   ('2022B1', 'midas', 'Y', 'midas', SYSDATE);

Insert into MST_PROJECT_USER
   (PROJ_CD, USER_ID, MGR_YN, REG_ID, REG_DT)
 Values
   ('2022B2', 'midas', 'Y', 'midas', SYSDATE);

COMMIT;
