SET DEFINE OFF;

Insert into MST_USER
   (USER_ID, USER_NM, PSWD, USE_YN, SYS_MGR_YN, 
    REG_ID, REG_DT)
 Values
   ('SUPERUSER', 'System Manager', '$2a$10$xVVs8mlDTYSX8YMAfK7QcOw/ZWG0JC0uPNvtjowfWfzqVvm7p6JQK', 'Y', 'Y', 
    'SUPERUSER', SYSDATE);


Insert into MST_USER
   (USER_ID, USER_NM, PSWD, USE_YN, SYS_MGR_YN, 
    REG_ID, REG_DT)
 Values
   ('midas', 'ubiz1', '$2a$10$u4GrQyQHwQ4niK3zy7GP1ereP.c5NAw0Sg.bzFeRO7M/DERNAWhqa', 'Y', 'Y', 
    'midas', SYSDATE);

COMMIT;
