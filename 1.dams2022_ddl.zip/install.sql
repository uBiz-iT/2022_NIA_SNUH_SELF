SET DEFINE OFF

PROMPT --------------------------------------------------------
PROMPT -- Creating objects for Labeling & Inspection System  --
PROMPT --------------------------------------------------------

@@sequence/SEQ_HISTORY.sql;

@@Table/MST_PROJECT.sql;
@@Table/MST_USER.sql;
@@Table/MST_DATA_GROUP.sql;
@@Table/MST_DATA_ITEM.sql;
@@Table/MST_EVENT_GROUP.sql;
@@Table/MST_EVENT_TYPE.sql;
@@Table/MST_EVENT.sql;
@@Table/MST_FAIL_CAUSE.sql;
@@Table/MST_LABEL.sql;
@@Table/MST_PROJECT_USER.sql;
@@Table/PLT_TASK.sql;
@@Table/PLT_TASK_CASE.sql;
@@Table/PLT_TASK_USER.sql;
@@Table/PLT_EVENT.sql;
@@Table/PLT_CASE_DATA_ITEM.sql;
@@Table/PLT_CASE_DATA_ITEM_LIST.sql;
@@Table/PLT_CASE_SOUND_IMAGE.sql;
@@Table/PLT_CASE_SPECTROGRAM.sql;
@@Table/WKT_TASK_DIAG.sql;
@@Table/WKT_TASK_INSP.sql;
@@Table/WKT_FAIL_DIAG.sql;
@@Table/WKT_FAIL_INSP.sql;
@@Table/WKT_GOOD_LUNGSOUND.sql;
@@Table/SYT_ERROR.sql;
@@Table/SYT_VERSION.sql;

@@View/MSV_DATA_GROUP_U.vw;
@@View/MSV_DATA_ITEM_U.vw;
@@View/MSV_EVENT.vw;
@@View/MSV_FAIL_CAUSE_U.vw;
@@View/MSV_LABEL_U.vw;
@@View/MSV_PROJECT_U.vw;
@@View/MSV_USER_U.vw;

@@View/PLV_CASE_DATA_ITEM.vw;
@@View/PLV_CASE_DATA_ITEM_LIST.vw;
@@View/PLV_CASE_SOUND_IMAGE.vw;
@@View/PLV_CASE_SPECTORGRAM.vw;
@@View/PLV_TASK.vw;
@@View/PLV_TASK_USER_PLAN.vw;
@@View/WKV_FAIL_DIAG_ALL.vw;
@@View/WKV_FAIL_INSP.vw;
@@View/WKV_TASK_INSP.vw;
@@View/WKV_FAIL_DIAG.vw;
@@View/WKV_TASK_DIAG_ALL.vw;
@@View/PLV_TASK_CASE_USER_DIAG.vw;
@@View/WKV_PROGRESS_TASK_USER.vw;
@@View/WKV_TASK_DIAG.vw;
@@View/PLV_TASK_CASE_DIAG.vw;
@@View/WKV_PROGRESS_USER.vw;
@@View/WKV_TASK_RESULT.vw;
@@View/WKV_CC.vw;
@@View/WKV_CC_INSP.vw;
@@View/WKV_DIAG_PASS_RESULT.vw;
@@View/WKV_TASK_RESULT_BY_LABEL.vw;
@@View/WKV_CC_DIAG.vw;
@@View/WKV_PROGRESS_PROJECT.vw;
@@View/WKV_LUNGSOUND_LIST.vw;
@@View/WKV_PROGRESS_PROJECT_STAT_Y.vw;
@@View/WKV_COUNT_PFT_PASS.vw;
@@View/WKV_COUNT_PFT_PASS_D.vw;
@@View/WKV_COUNT_PFT_REG.vw;
@@View/WKV_COUNT_PFT_REG_D.vw;

PROMPT --------------------------------------------------------;
PROMPT -- Compiling objects for Labeling & Inspection System --;
PROMPT --------------------------------------------------------;

@@Function/F_OCCR_ID.fnc;
@@Function/F_SPLIT.fnc;

@@Procedure/P_ERROR.prc;
@@Procedure/P_GET_CASE_BASE_INFO_HORI.prc;
@@Procedure/P_GET_CAUSE_TO_PROJECT.prc;
@@Procedure/P_GET_CROSS_CHECK.prc;
@@Procedure/P_GET_INSPECTOR_STAT_USER_LIST.prc;
@@Procedure/P_GET_LABEL_LIST.prc;
@@Procedure/P_GET_MAIN_PROGRESS_CNT.prc;
@@Procedure/P_GET_MAIN_USER_CHART.prc;
@@Procedure/P_GET_PROJECT_MAP.prc;
@@Procedure/P_GET_PROJECT_TO_LABEL.prc;
@@Procedure/P_GET_PROJECT_TO_READ_LABEL.prc;
@@Procedure/P_GET_TASKCASE_STEP.prc;
@@Procedure/P_GET_TASK_TO_USER.prc;
@@Procedure/P_GET_USER_MAP.prc;
@@Procedure/P_GET_USER_TO_PROJECT.prc;
@@Procedure/P_GET_USER_TO_READ_PROJECT.prc;
@@Procedure/P_INSERT_PROJECT.prc;
@@Procedure/P_INSERT_TASK.prc;
@@Procedure/P_INSERT_USER.prc;
@@Procedure/P_MODIFY_PROJECT.prc;
@@Procedure/P_MODIFY_TASK.prc;
@@Procedure/P_MODIFY_USER.prc;
@@Procedure/P_VALID_USER_PROJECT.prc;
@@Procedure/P_REMOVE_USER.prc;
@@Procedure/P_WORKTASK_MODIFY_LASK_WORK.prc;
@@Procedure/P_WORKTASK_MODIFY_DIAGNOSE.prc;
@@Procedure/P_WORKTASK_MODIFY_INSPECT.prc;
@@Procedure/P_WORKTASK_REGIST_DIAGNOSE.prc;
@@Procedure/P_WORKTASK_REGIST_INSPECT.prc;
@@Procedure/P_REMOVE_TASK.prc;
@@Procedure/P_GET_PATIENT_PASS_RATIO_LIST.prc;
@@Procedure/P_GET_INSTITUTION_STAT_LIST.prc;

@@Procedure/P_REGIST_PROJECT.prc;
@@Procedure/P_REGIST_TASK.prc;
@@Procedure/P_REGIST_USER.prc;
@@Procedure/P_GET_PATIENT_PASS_LIST.prc;
@@Procedure/P_GET_TASK_STAT_CHART2.prc;
@@Procedure/P_GET_TASK_STAT_CHART1.prc;
@@Procedure/P_GET_INSPECTOR_STAT_CHART.prc;
@@Procedure/P_GET_TASK_STAT_LIST.prc;
@@Procedure/P_REMOVE_PROJECT.prc;
@@Procedure/P_GET_DIVERSITY_DISTRIBUTION.prc;
@@Procedure/P_GET_MAIN_MONTH_CHART.prc;
@@Procedure/P_GET_MAIN_MONTH_ACM_CHART.prc;
@@Procedure/P_GET_WEEK_ACM_CHART.prc;
@@Procedure/P_GET_WEEK_CHART.prc;

PROMPT --------------------------------------------------------;
PROMPT -- Inserting initial data                             --;
PROMPT -- User password : 1111                               --;
PROMPT --------------------------------------------------------;

@@Data/MST_PROJECT.sql;
@@Data/MST_USER.sql;
@@Data/MST_PROJECT_USER.sql;
@@Data/MST_LABEL.sql;
@@Data/MST_DATA_GROUP.sql;
@@Data/MST_DATA_ITEM.sql;
@@Data/MST_FAIL_CAUSE.sql;


