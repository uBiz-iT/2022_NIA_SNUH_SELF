maxCaseCnt=$1
if [ "$#" -gt 0 ]
then
    cd /home/ouarlab2/2022_self
    java -cp .:dams_snuh_2022_meta.jar dams_snuh_2022_meta.CreateSetData dams_set_data.conf $maxCaseCnt
else
    echo "---------------------------------------------------------" 
    echo "Usage : selfsleep_setdata.sh {maxCaseCnt}"
    echo "  ex1)  selfsleep_setdata.sh 50"
    echo "---------------------------------------------------------" 
    exit 1
fi
