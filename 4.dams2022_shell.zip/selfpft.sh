task=$1
if [ "$#" -eq 1 ]
then
    cd /home/ouarlab2/2022_self
    java -cp .:dams_snuh_2022_meta.jar dams_snuh_2022_meta.CreateMetaData dams.conf 2022B1 $task
else
    echo "---------------------------------------------------------" 
    echo "Usage : selfpft.sh {task code}"
    echo "  ex)   selfpft.sh ONECYCLE"
    echo "---------------------------------------------------------" 
    exit 1
fi
