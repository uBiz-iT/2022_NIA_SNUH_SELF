task=$1
update=$2
if [ "$#" -gt 0 ]
then
    cd /home/ouarlab2/2022_self
    java -cp .:dams_snuh_2022_meta.jar dams_snuh_2022_meta.CreateLabelingResultData dams_lung.conf 2022B2 $task $update 
else
    echo "---------------------------------------------------------" 
    echo "Usage : selflung_result {task code}"
    echo "  ex1)  selflung_result.sh onecycle1 update"
    echo "---------------------------------------------------------" 
    exit 1
fi
