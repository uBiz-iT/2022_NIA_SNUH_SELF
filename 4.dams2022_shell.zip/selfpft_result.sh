task=$1
update=$2
if [ "$#" -gt 0 ]
then
    cd /home/ouarlab2/2022_self
    java -cp .:dams_snuh_2022_meta.jar dams_snuh_2022_meta.CreateLabelingResultData dams_lung.conf 2022B1 $task $update
else
    echo "---------------------------------------------------------" 
    echo "Usage : selfpft_result.sh {task code}"
    echo "  ex)   selfpft_result.sh ONECYCLE"
    echo "  ex)   selfpft_result.sh ONECYCLE update"
    echo "---------------------------------------------------------" 
    exit 1
fi
