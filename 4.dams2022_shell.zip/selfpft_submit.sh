sourceDir=$1
if [ "$#" -gt 0 ]
then
    java -cp .:/home/ouarlab2/2022_self:/home/ouarlab2/2022_self/dams_snuh_2022_meta.jar \
         dams_snuh_2022_meta.ForSubmission \
         2022B1 $sourceDir /data/2022_self/@_RESULT/for_submission/lung/pft
else
    echo "---------------------------------------------------------" 
    echo "Usage : selfpft_submit {source directory} "
    echo "---------------------------------------------------------" 
    exit 1
fi
