projectCode=$1
sourceDir=$2
targetDir=$3
if [ "$#" -gt 2 ]
then
    cd /home/ouarlab2/2022_self
    java -cp .:dams_snuh_2022_meta.jar dams_snuh_2022_meta.ForSubmission $projectCode $sourceDir $targetDir
else
    echo "---------------------------------------------------------" 
    echo "Usage : self_submit {project code} {source directory} {target directory}"
    echo "---------------------------------------------------------" 
    exit 1
fi
