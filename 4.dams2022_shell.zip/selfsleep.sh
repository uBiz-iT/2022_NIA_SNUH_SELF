task=$1
noedfupdate=$2
if [ "$#" -gt 0 ]
then
    cd /home/ouarlab2/2022_self
    java -cp .:dams_snuh_2022_meta.jar dams_snuh_2022_meta.CreateMetaData dams_sleep.conf 2022A1 $task $noedfupdate
else
    echo "---------------------------------------------------------" 
    echo "Usage : selfsleep.sh {task code} [noedfupdate]"
    echo "  ex1)  selfsleep.sh onecycle1"
    echo "  ex2)  selfsleep.sh onecycle1 noedfupdate"
    echo "---------------------------------------------------------" 
    exit 1
fi
