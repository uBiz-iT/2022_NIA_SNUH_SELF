task=$1
if [ "$#" -eq 1 ]
then
    cd /home/ouarlab2/2022_self
    java -cp .:dams_snuh_2022_meta.jar dams_snuh_2022_meta.CreateMetaData dams.conf 2022B2 $task
else
    echo "---------------------------------------------------------" 
    echo "Usage : selflung.sh {task code}"
    echo "  ex)   selflung.sh ONECYCLE"
    echo "---------------------------------------------------------" 
    exit 1
fi
